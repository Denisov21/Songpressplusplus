###############################################################
# Name:             Preferences.py
# Purpose:     Hold program preferences
# Author:         Luca Allulli (webmaster@roma21.it)
# Created:     2010-01-31
# Modified by:  Denisov21
# Copyright: Luca Allulli (https://www.skeed.it/songpress)
#               Modifications copyright Denisov21
# License:     GNU GPL v2
##############################################################

import os
import re

from . import i18n
from .SongFormat import *
from .decorators import StandardVerseNumbers
from .Transpose import *

_ = wx.GetTranslation


def get_chords_positions():
    return {
        'above': _("Above text"),
        'below': _("Below text"),
    }
    
class Preferences(object):
    """
        Available preferences

        * format
        * decoratorFormat
        * decorator
        * chorusLabel (None or string)
        * labelVerses
        * editorFace
        * editorSize
        * fontFace
        * defaultNotation
        * notations
        * defaultNotation
        * autoAdjustSpuriousLines
        * autoAdjustTab2Chordpro
        * autoAdjustEasyKey
        * chordsPosition ('above' or 'below')
        * locale
        * Set/GetEasyChordsGroup
        * GetEasyChords
        * showRecentFiles (bool)
    """
    def __init__(self):
        object.__init__(self)
        self.config = wx.Config.Get()
        self.format = SongFormat()
        self.decoratorFormat = StandardVerseNumbers.Format(self.format, _("Chorus"))
        self.decorator = StandardVerseNumbers.Decorator(self.decoratorFormat)
        self.notations = [enNotation, itNotation, itUcNotation, deNotation, tradDeNotation, frNotation, ptNotation, nashvilleNotation, romanNotation]
        self.easyChordsGroup = {}
        self.titleLineWidth = 4
        self.verseBoxWidth = 1
        self.Load()

    def SetFont(self, font, showChords=None):
        self.fontFace = font
        self.format.face = font
        self.format.comment.face = font
        self.format.chord.face = font
        self.format.chorus.face = font
        self.format.chorus.chord.face = font
        self.format.chorus.comment.face = font
        for v in self.format.verse:
            v.face = font
            v.chord.face = font
            v.comment.face = font
        self.format.title.face = font
        self.format.subtitle.face = font
        self.decoratorFormat.face = font
        self.decoratorFormat.chorus.face = font
        if showChords is not None:
            self.format.showChords = showChords

    def Load(self):
        self.notices = {}
        self.config.SetPath('/Format')
        l = self.config.Read('ChorusLabel')
        if l:
            self.chorusLabel = l
            self.decoratorFormat.SetChorusLabel(l)
        else:
            self.chorusLabel = None
        showChords = int(self.config.Read('ShowChords', "2"))
        self.config.SetPath('/Format/Font')
        face = self.config.Read('Face')
        if face:
            self.fontFace = face
        else:
            self.fontFace = "Arial"
        self.SetFont(self.fontFace, showChords)
        self.config.SetPath('/Format/Style')
        labelVerses = self.config.Read('LabelVerses')
        if labelVerses:
            self.labelVerses = bool(int(labelVerses))
        else:
            self.labelVerses = True
        self.config.SetPath('/Editor')
        self.editorFace = self.config.Read('Face')
        self.editorSize = self.config.Read('Size')
        if not self.editorFace:
            self.editorFace = wx.SystemSettings().GetFont(wx.SYS_ANSI_FIXED_FONT).GetFaceName() # "Lucida Console"
            self.editorSize = 12
        else:
            self.editorSize = int(self.editorSize)
        n = self.config.Read('DefaultNotation')
        if n:
            self.defaultNotation = n
            self.notations = [x for x in self.notations if x.id == n] + [x for x in self.notations if x.id != n]
        else:
            lang = i18n.getLang()
            self.defaultNotation = None
            if lang in defaultLangNotation:
                n = defaultLangNotation[lang].id
                self.notations = [x for x in self.notations if x.id == n] + [x for x in self.notations if x.id != n]
        self.config.SetPath('/AutoAdjust')
        spuriousLines = self.config.Read('spuriousLines')
        if spuriousLines:
            self.autoAdjustSpuriousLines = bool(int(spuriousLines))
        else:
            self.autoAdjustSpuriousLines = True
        tab2chordpro = self.config.Read('tab2chordpro')
        if tab2chordpro:
            self.autoAdjustTab2Chordpro = bool(int(tab2chordpro))
        else:
            self.autoAdjustTab2Chordpro = True
        easyKey = self.config.Read('easyKey')
        if easyKey:
            self.autoAdjustEasyKey = bool(int(easyKey))
        else:
            self.autoAdjustEasyKey = False
            self.notices['firstTimeEasyKey'] = True
        chordsPosition = self.config.Read('chordsPosition')
        if chordsPosition in ('above', 'below'):
            self.chordsPosition = chordsPosition
        else:
            self.chordsPosition = 'above'
        self.config.SetPath('/AutoAdjust/EasyChordsGroups')
        for k in easyChordsOrder:
            l = self.config.Read(k)
            if l:
                l = int(l)
            else:
                l = easyChords[k][2]
            self.SetEasyChordsGroup(k, l)
        self.config.SetPath('/App')
        ext = self.config.Read('defaultExtension')
        if not ext:
            self.defaultExtension = 'crd'
        else:
            self.defaultExtension = ext
        lang = self.config.Read('locale')
        if not lang:
            self.locale = None
        else:
            self.locale = lang
        self.config.SetPath('/App')
        showRecentFiles = self.config.Read('showRecentFiles')
        if showRecentFiles:
            self.showRecentFiles = bool(int(showRecentFiles))
        else:
            self.showRecentFiles = True
        self.config.SetPath('/Format/Style')
        titleLineWidth = self.config.Read('TitleLineWidth')
        self.titleLineWidth = int(titleLineWidth) if titleLineWidth else 4
        verseBoxWidth = self.config.Read('VerseBoxWidth')
        self.verseBoxWidth = int(verseBoxWidth) if verseBoxWidth else 1
        self._LoadKlavierColour()
        self._LoadFingerNumColour()
        self._LoadContextMenu()
        self._LoadEditorBg()
        self._LoadSelColour()
        self._LoadCaretColour()
        self._LoadCaptionColours()
        self._LoadPrintOptions()
        self._LoadMultiCursor()
        self._LoadTempoIconSize()
        self._LoadWindowGeometryPref()
        self._LoadPreviewOptions()
        self._LoadGridDisplayMode()
        self._LoadDurationBeats()
        self._LoadMusicalSymbol()
        self._LoadSyntaxColours()
        self._LoadDebugOptions()
        self._LoadIntellisense()
        self._LoadDecoSliderColour()
        self._LoadNoChordHide()
        self._LoadSingleInstance()
        self._LoadShowRestartMenuItem()
        self._LoadSaveOnModified()
        self._LoadReplaceSpacesInFilenames()
        self._LoadToolbarVis()

    def _LoadKlavierColour(self):
        self.config.SetPath('/KlavierColour')
        h = self.config.Read('highlightHex')
        self.klavierHighlightHex = h if h else '#D23C3C'
        self.config.SetPath('/')

    def _LoadFingerNumColour(self):
        self.config.SetPath('/FingerNumColour')
        h = self.config.Read('fingerNumHex')
        self.fingerNumColourHex = h if h else '#1A1A1A'
        self.config.SetPath('/')

    def _LoadContextMenu(self):
        self.config.SetPath('/ContextMenu')
        def rb(key):
            v = self.config.Read(key)
            return bool(int(v)) if v != '' else True
        self.cmUndo         = rb('undo')
        self.cmRedo         = rb('redo')
        self.cmCut          = rb('cut')
        self.cmCopy         = rb('copy')
        self.cmPaste        = rb('paste')
        self.cmDelete       = rb('delete')
        v = self.config.Read('confirmDelete')
        self.cmConfirmDelete = bool(int(v)) if v != '' else False
        self.cmPasteChords           = rb('pasteChords')
        self.cmPropagateVerseChords  = rb('propagateVerseChords')
        self.cmPropagateChorusChords = rb('propagateChorusChords')
        self.cmCopyTextOnly          = rb('copyTextOnly')
        self.cmSelectAll    = rb('selectAll')
        v = self.config.Read('showIcons')
        self.cmShowIcons = bool(int(v)) if v != '' else True
        self.config.SetPath('/')

    def _LoadEditorBg(self):
        self.config.SetPath('/Editor')
        h = self.config.Read('BgHex')
        self.editorBgHex = h if h else '#FFFFFF'
        self.config.SetPath('/')

    def _LoadSelColour(self):
        self.config.SetPath('/Editor')
        h = self.config.Read('SelColourHex')
        self.selColourHex = h if h else '#C0C0C0'
        self.config.SetPath('/')

    def _LoadCaretColour(self):
        self.config.SetPath('/Editor')
        h = self.config.Read('CaretColourHex')
        self.caretColourHex = h if h else '#000000'
        self.config.SetPath('/')

    def _LoadPrintOptions(self):
        self.config.SetPath('/Print')
        v = self.config.Read('showPrintPreview')
        self.showPrintPreview = bool(int(v)) if v != '' else True
        v = self.config.Read('printPreviewAlwaysOnTop')
        self.printPreviewAlwaysOnTop = bool(int(v)) if v != '' else False
        self.config.SetPath('/')

    def _LoadMultiCursor(self):
        self.config.SetPath('/Editor')
        v = self.config.Read('multiCursor')
        self.multiCursor = bool(int(v)) if v != '' else False
        self.config.SetPath('/')

    def _LoadTempoIconSize(self):
        self.config.SetPath('/Format')
        v = self.config.Read('tempoIconSize')
        self.tempoIconSize = int(v) if v in ('16', '24', '32') else 24
        self.config.SetPath('/')

    def _LoadWindowGeometryPref(self):
        self.config.SetPath('/App')
        v = self.config.Read('saveWindowGeometry')
        self.saveWindowGeometry = bool(int(v)) if v != '' else True
        self.config.SetPath('/')

    def _LoadPreviewOptions(self):
        self.config.SetPath('/Preview')
        v = self.config.Read('showPageIndicator')
        self.showPageIndicator = bool(int(v)) if v != '' else True
        v = self.config.Read('greyBackground')
        self.greyBackground = bool(int(v)) if v != '' else True
        v = self.config.Read('debounceRefresh')
        self.debounceRefresh = bool(int(v)) if v != '' else True
        v = self.config.Read('dblClickFocus')
        self.dblClickFocus = bool(int(v)) if v != '' else True
        v = self.config.Read('previewMinSize')
        self.previewMinSize = bool(int(v)) if v != '' else True
        v = self.config.Read('guideViewer')
        self.guideViewer = v if v in ('auto', 'builtin', 'markdown', 'mistune') else 'auto'
        v = self.config.Read('liveDriverPoll')
        self.liveDriverPoll = bool(int(v)) if v != '' else True
        self.config.SetPath('/')

    def _LoadGridDisplayMode(self):
        """Carica la modalità di visualizzazione del blocco {start_of_grid}.

        Valori:
            'pipe'  -- | C   | G   | Am  | F   |  (separatori pipe, default)
            'plain' -- C   G   Am  F               (testo spaziato senza pipe)
            'table' -- griglia con celle evidenziate (bordi disegnati)
        """
        self.config.SetPath('/Format')
        v = self.config.Read('gridDisplayMode')
        self.gridDisplayMode = v if v in ('pipe', 'plain', 'table') else 'pipe'
        v2 = self.config.Read('gridDefaultLabel')
        self.gridDefaultLabel = v2 if v2 else _("Grid")
        v3 = self.config.Read('gridSpaceAsPipe')
        self.gridSpaceAsPipe = bool(int(v3)) if v3 != '' else True
        v4 = self.config.Read('gridSizeDir')
        self.gridSizeDir = v4 if v4 in ('both', 'horizontal', 'vertical') else 'both'
        self.config.SetPath('/')

    def Bool2String(self, param):
        return "1" if param else "0"

    def Save(self):
        self.config.SetPath('/Format')
        if self.chorusLabel is not None:
            self.config.Write('ChorusLabel', self.chorusLabel)
        self.config.Write('ShowChords', str(self.format.showChords))
        self.config.SetPath('/Format/Font')
        self.config.Write('Face', self.fontFace)
        self.config.SetPath('/Format/Style')
        self.config.Write('LabelVerses', self.Bool2String(self.labelVerses))
        self.config.SetPath('/Editor')
        self.config.Write('Face', self.editorFace)
        self.config.Write('Size', str(self.editorSize))
        if self.defaultNotation is not None:
            self.config.Write('DefaultNotation', self.defaultNotation)
        self.config.SetPath('/AutoAdjust')
        self.config.Write('spuriousLines', self.Bool2String(self.autoAdjustSpuriousLines))
        self.config.Write('tab2chordpro', self.Bool2String(self.autoAdjustTab2Chordpro))
        self.config.Write('easyKey', self.Bool2String(self.autoAdjustEasyKey))
        self.config.Write('chordsPosition', self.chordsPosition)
        self.config.SetPath('/AutoAdjust/EasyChordsGroups')
        for k in easyChordsOrder:
            self.config.Write(k, str(self.GetEasyChordsGroup(k)))
        self.config.SetPath('/App')
        self.config.Write('defaultExtension', self.defaultExtension)
        if self.locale is not None:
            lang = self.config.Write('locale', self.locale)
        self.config.SetPath('/App')
        self.config.Write('showRecentFiles', self.Bool2String(self.showRecentFiles))
        self.config.SetPath('/Format/Style')
        self.config.Write('TitleLineWidth', str(self.titleLineWidth))
        self.config.Write('VerseBoxWidth', str(self.verseBoxWidth))
        self._SaveKlavierColour()
        self._SaveFingerNumColour()
        self._SaveContextMenu()
        self._SaveEditorBg()
        self._SaveSelColour()
        self._SaveCaretColour()
        self._SaveCaptionColours()
        self._SavePrintOptions()
        self._SaveMultiCursor()
        self._SaveTempoIconSize()
        self._SaveWindowGeometryPref()
        self._SavePreviewOptions()
        self._SaveGridDisplayMode()
        self._SaveDurationBeats()
        self._SaveMusicalSymbol()
        self._SaveSyntaxColours()
        self._SaveDebugOptions()
        self._SaveIntellisense()
        self._SaveDecoSliderColour()
        self._SaveNoChordHide()
        self._SaveSingleInstance()
        self._SaveShowRestartMenuItem()
        self._SaveSaveOnModified()
        self._SaveReplaceSpacesInFilenames()
        self._SaveToolbarVis()
        self.config.Flush()

    def _SaveKlavierColour(self):
        self.config.SetPath('/KlavierColour')
        self.config.Write('highlightHex', getattr(self, 'klavierHighlightHex', '#D23C3C'))
        self.config.SetPath('/')

    def _SaveFingerNumColour(self):
        self.config.SetPath('/FingerNumColour')
        self.config.Write('fingerNumHex', getattr(self, 'fingerNumColourHex', '#1A1A1A'))
        self.config.SetPath('/')

    def _SaveContextMenu(self):
        self.config.SetPath('/ContextMenu')
        self.config.Write('undo',         '1' if getattr(self, 'cmUndo',         True) else '0')
        self.config.Write('redo',         '1' if getattr(self, 'cmRedo',         True) else '0')
        self.config.Write('cut',          '1' if getattr(self, 'cmCut',          True) else '0')
        self.config.Write('copy',         '1' if getattr(self, 'cmCopy',         True) else '0')
        self.config.Write('paste',        '1' if getattr(self, 'cmPaste',        True) else '0')
        self.config.Write('delete',       '1' if getattr(self, 'cmDelete',       True) else '0')
        self.config.Write('confirmDelete', '1' if getattr(self, 'cmConfirmDelete', False) else '0')
        self.config.Write('pasteChords',           '1' if getattr(self, 'cmPasteChords',           True) else '0')
        self.config.Write('propagateVerseChords',  '1' if getattr(self, 'cmPropagateVerseChords',  True) else '0')
        self.config.Write('propagateChorusChords', '1' if getattr(self, 'cmPropagateChorusChords', True) else '0')
        self.config.Write('copyTextOnly',          '1' if getattr(self, 'cmCopyTextOnly',          True) else '0')
        self.config.Write('selectAll',    '1' if getattr(self, 'cmSelectAll',    True) else '0')
        self.config.Write('showIcons',    '1' if getattr(self, 'cmShowIcons',    True) else '0')
        self.config.SetPath('/')

    def _SaveEditorBg(self):
        self.config.SetPath('/Editor')
        self.config.Write('BgHex', getattr(self, 'editorBgHex', '#FFFFFF'))
        self.config.SetPath('/')

    def _SaveSelColour(self):
        self.config.SetPath('/Editor')
        self.config.Write('SelColourHex', getattr(self, 'selColourHex', '#C0C0C0'))
        self.config.SetPath('/')

    def _SaveCaretColour(self):
        self.config.SetPath('/Editor')
        self.config.Write('CaretColourHex', getattr(self, 'caretColourHex', '#000000'))
        self.config.SetPath('/')

    def _LoadCaptionColours(self):
        self.config.SetPath('/CaptionColours')
        h = self.config.Read('EditorActiveHex')
        self.captionEditorActiveHex = h if h else '#4682C8'
        h = self.config.Read('PreviewActiveHex')
        self.captionPreviewActiveHex = h if h else '#329B82'
        self.config.SetPath('/')

    def _SaveCaptionColours(self):
        self.config.SetPath('/CaptionColours')
        self.config.Write('EditorActiveHex',  getattr(self, 'captionEditorActiveHex',  '#4682C8'))
        self.config.Write('PreviewActiveHex', getattr(self, 'captionPreviewActiveHex', '#329B82'))
        self.config.SetPath('/')

    # Colori predefiniti per ogni stile sintattico dell'editor
    SYNTAX_COLOUR_DEFAULTS = {
        'normal':   '#000000',
        'chorus':   '#000000',
        'chord':    '#FF0000',
        'command':  '#0000FF',
        'attr':     '#008000',
        'comment':  '#808080',
        'tabgrid':  '#8B5A00',
    }

    def _LoadSyntaxColours(self):
        self.config.SetPath('/EditorSyntaxColours')
        self.syntaxColours = {}
        for key, default in self.SYNTAX_COLOUR_DEFAULTS.items():
            h = self.config.Read(key)
            self.syntaxColours[key] = h if h else default
        self.config.SetPath('/')

    def _SaveSyntaxColours(self):
        self.config.SetPath('/EditorSyntaxColours')
        for key, default in self.SYNTAX_COLOUR_DEFAULTS.items():
            self.config.Write(key, self.syntaxColours.get(key, default))
        self.config.SetPath('/')

    def _LoadDebugOptions(self):
        self.config.SetPath('/Debug')
        v = self.config.Read('showDebugMsg')
        self.showDebugMsg = bool(int(v)) if v != '' else False
        self.config.SetPath('/')

    def _SaveDebugOptions(self):
        self.config.SetPath('/Debug')
        self.config.Write('showDebugMsg', '1' if getattr(self, 'showDebugMsg', False) else '0')
        self.config.SetPath('/')

    def _LoadIntellisense(self):
        self.config.SetPath('/Editor')
        v = self.config.Read('intellisense')
        self.intellisense = bool(int(v)) if v != '' else True
        self.config.SetPath('/')

    def _SaveIntellisense(self):
        self.config.SetPath('/Editor')
        self.config.Write('intellisense', '1' if getattr(self, 'intellisense', True) else '0')
        self.config.SetPath('/')

    def _SavePrintOptions(self):
        self.config.SetPath('/Print')
        self.config.Write('showPrintPreview', '1' if getattr(self, 'showPrintPreview', True) else '0')
        self.config.Write('printPreviewAlwaysOnTop', '1' if getattr(self, 'printPreviewAlwaysOnTop', False) else '0')
        self.config.SetPath('/')

    def _SaveMultiCursor(self):
        self.config.SetPath('/Editor')
        self.config.Write('multiCursor', '1' if getattr(self, 'multiCursor', False) else '0')
        self.config.SetPath('/')

    def _SaveTempoIconSize(self):
        self.config.SetPath('/Format')
        self.config.Write('tempoIconSize', str(getattr(self, 'tempoIconSize', 24)))
        self.config.SetPath('/')

    def _SaveWindowGeometryPref(self):
        self.config.SetPath('/App')
        self.config.Write('saveWindowGeometry', '1' if getattr(self, 'saveWindowGeometry', True) else '0')
        self.config.SetPath('/')

    def _SavePreviewOptions(self):
        self.config.SetPath('/Preview')
        self.config.Write('showPageIndicator', '1' if getattr(self, 'showPageIndicator', True) else '0')
        self.config.Write('greyBackground',    '1' if getattr(self, 'greyBackground',    True) else '0')
        self.config.Write('debounceRefresh',   '1' if getattr(self, 'debounceRefresh',   True) else '0')
        self.config.Write('dblClickFocus',     '1' if getattr(self, 'dblClickFocus',     True) else '0')
        self.config.Write('previewMinSize',    '1' if getattr(self, 'previewMinSize',    True) else '0')
        self.config.Write('guideViewer',           getattr(self, 'guideViewer', 'auto'))
        self.config.Write('liveDriverPoll',        '1' if getattr(self, 'liveDriverPoll', True) else '0')
        self.config.SetPath('/')

    def _SaveGridDisplayMode(self):
        self.config.SetPath('/Format')
        self.config.Write('gridDisplayMode', getattr(self, 'gridDisplayMode', 'pipe'))
        self.config.Write('gridDefaultLabel', getattr(self, 'gridDefaultLabel', _("Grid")))
        self.config.Write('gridSpaceAsPipe', '1' if getattr(self, 'gridSpaceAsPipe', True) else '0')
        self.config.Write('gridSizeDir', getattr(self, 'gridSizeDir', 'both'))
        self.config.SetPath('/')

    def _LoadDurationBeats(self):
        self.config.SetPath('/Format')
        v = self.config.Read('durationBeatsColourHex')
        self.durationBeatsColourHex = v if v else '#6464C8'
        v2 = self.config.Read('durationBeatsSizePct')
        try:
            self.durationBeatsSizePct = max(30, min(int(v2), 150)) if v2 != '' else 60
        except ValueError:
            self.durationBeatsSizePct = 60
        v3 = self.config.Read('durationBeatsBold')
        self.durationBeatsBold = bool(int(v3)) if v3 != '' else False
        v4 = self.config.Read('durationBeatsAlign')
        self.durationBeatsAlign = v4 if v4 in ('left', 'center', 'right') else 'right'
        v5 = self.config.Read('durationBeatsMode')
        self.durationBeatsMode = v5 if v5 in ('number', 'dots', 'both') else 'number'
        self.config.SetPath('/')

    def _LoadMusicalSymbol(self):
        self.config.SetPath('/MusicalSymbol')
        v = self.config.Read('scaleEnabled')
        self.symbolScaleEnabled = bool(int(v)) if v != '' else False
        v2 = self.config.Read('fontSize')
        try:
            self.symbolFontSize = max(6, min(int(v2), 144)) if v2 != '' else 24
        except ValueError:
            self.symbolFontSize = 24
        v3 = self.config.Read('insertVerse')
        self.symbolInsertVerse = bool(int(v3)) if v3 != '' else False
        self.config.SetPath('/')

    def _SaveDurationBeats(self):
        self.config.SetPath('/Format')
        self.config.Write('durationBeatsColourHex', getattr(self, 'durationBeatsColourHex', '#6464C8'))
        self.config.Write('durationBeatsSizePct',   str(getattr(self, 'durationBeatsSizePct', 60)))
        self.config.Write('durationBeatsBold',      '1' if getattr(self, 'durationBeatsBold', False) else '0')
        self.config.Write('durationBeatsAlign',     getattr(self, 'durationBeatsAlign', 'right'))
        self.config.Write('durationBeatsMode',      getattr(self, 'durationBeatsMode', 'number'))
        self.config.SetPath('/')

    def _SaveMusicalSymbol(self):
        self.config.SetPath('/MusicalSymbol')
        self.config.Write('scaleEnabled', '1' if getattr(self, 'symbolScaleEnabled', False) else '0')
        self.config.Write('fontSize', str(getattr(self, 'symbolFontSize', 24)))
        self.config.Write('insertVerse', '1' if getattr(self, 'symbolInsertVerse', False) else '0')
        self.config.SetPath('/')

    def _LoadDecoSliderColour(self):
        self.config.SetPath('/DecoSlider')
        h = self.config.Read('barColourHex')
        self.decoSliderBarColourHex = h if h else '#2980B9'
        self.config.SetPath('/')

    def _SaveDecoSliderColour(self):
        self.config.SetPath('/DecoSlider')
        self.config.Write('barColourHex', getattr(self, 'decoSliderBarColourHex', '#2980B9'))
        self.config.SetPath('/')

    def _LoadNoChordHide(self):
        self.config.SetPath('/Format')
        def _rb(key, default):
            v = self.config.Read(key)
            return bool(int(v)) if v != '' else default
        self.hideIntroChord = _rb('hideIntroChord', False)
        self.hideBridge     = _rb('hideBridge',     False)
        self.hideGrid       = _rb('hideGrid',        False)
        self.hideTempo      = _rb('hideTempo',       False)
        self.hideTime       = _rb('hideTime',        False)
        self.config.SetPath('/')

    def _SaveNoChordHide(self):
        self.config.SetPath('/Format')
        self.config.Write('hideIntroChord', '1' if getattr(self, 'hideIntroChord', False) else '0')
        self.config.Write('hideBridge',     '1' if getattr(self, 'hideBridge',     False) else '0')
        self.config.Write('hideGrid',        '1' if getattr(self, 'hideGrid',        False) else '0')
        self.config.Write('hideTempo',       '1' if getattr(self, 'hideTempo',       False) else '0')
        self.config.Write('hideTime',        '1' if getattr(self, 'hideTime',        False) else '0')
        self.config.SetPath('/')

    def _LoadSaveOnModified(self):
        self.config.SetPath('/App')
        v = self.config.Read('enableSaveOnModified')
        self.enableSaveOnModified = bool(int(v)) if v != '' else True
        self.config.SetPath('/')

    def _SaveSaveOnModified(self):
        self.config.SetPath('/App')
        self.config.Write('enableSaveOnModified', '1' if getattr(self, 'enableSaveOnModified', True) else '0')
        self.config.SetPath('/')

    def _LoadReplaceSpacesInFilenames(self):
        self.config.SetPath('/App')
        v = self.config.Read('replaceSpacesInFilenames')
        self.replaceSpacesInFilenames = bool(int(v)) if v != '' else False
        self.config.SetPath('/')

    def _SaveReplaceSpacesInFilenames(self):
        self.config.SetPath('/App')
        self.config.Write('replaceSpacesInFilenames', '1' if getattr(self, 'replaceSpacesInFilenames', False) else '0')
        self.config.SetPath('/')

    def _LoadToolbarVis(self):
        """Carica la visibilità delle icone delle quattro toolbar dal config.

        Le chiavi seguono il prefisso del gruppo:
          tbm_*  →  Standard toolbar
          tbf_*  →  Format toolbar
          tbv_*  →  View toolbar
          tb_*   →  Insert toolbar
        Il default per tutte le voci è True (icona visibile).
        """
        self.config.SetPath('/ToolbarVis')
        def _rb(key):
            v = self.config.Read(key)
            return bool(int(v)) if v != '' else True
        # Standard toolbar
        self.tbm_new           = _rb('tbm_new')
        self.tbm_open          = _rb('tbm_open')
        self.tbm_save          = _rb('tbm_save')
        self.tbm_printPreview  = _rb('tbm_printPreview')
        self.tbm_print         = _rb('tbm_print')
        self.tbm_undo          = _rb('tbm_undo')
        self.tbm_redo          = _rb('tbm_redo')
        self.tbm_cut           = _rb('tbm_cut')
        self.tbm_copy          = _rb('tbm_copy')
        self.tbm_copyAsImage   = _rb('tbm_copyAsImage')
        self.tbm_paste         = _rb('tbm_paste')
        self.tbm_pasteChords   = _rb('tbm_pasteChords')
        self.tbm_syntaxCheck   = _rb('tbm_syntaxCheck')
        self.tbm_options       = _rb('tbm_options')
        # Format toolbar
        self.tbf_fontChooser      = _rb('tbf_fontChooser')
        self.tbf_showChords       = _rb('tbf_showChords')
        self.tbf_insertLinespacing = _rb('tbf_insertLinespacing')
        # View toolbar
        self.tbv_preview     = _rb('tbv_preview')
        self.tbv_labelVerses = _rb('tbv_labelVerses')
        # Insert toolbar
        self.tb_title               = _rb('tb_title')
        self.tb_subtitle            = _rb('tb_subtitle')
        self.tb_chord               = _rb('tb_chord')
        self.tb_chorus              = _rb('tb_chorus')
        self.tb_verse               = _rb('tb_verse')
        self.tb_comment             = _rb('tb_comment')
        self.tb_pageBreak           = _rb('tb_pageBreak')
        self.tb_columnBreak         = _rb('tb_columnBreak')
        self.tb_insertVerse         = _rb('tb_insertVerse')
        self.tb_insertVerseNum      = _rb('tb_insertVerseNum')
        self.tb_insertChorusBlock   = _rb('tb_insertChorusBlock')
        self.tb_insertChordBlock    = _rb('tb_insertChordBlock')
        self.tb_insertBridge        = _rb('tb_insertBridge')
        self.tb_insertGrid          = _rb('tb_insertGrid')
        self.tb_insertTempo         = _rb('tb_insertTempo')
        self.tb_insertTempoLabel    = _rb('tb_insertTempoLabel')
        self.tb_insertTime          = _rb('tb_insertTime')
        self.tb_insertKey           = _rb('tb_insertKey')
        self.tb_insertDuration      = _rb('tb_insertDuration')
        self.tb_insertTaste         = _rb('tb_insertTaste')
        self.tb_insertFingering     = _rb('tb_insertFingering')
        self.tb_insertDefine        = _rb('tb_insertDefine')
        self.tb_insertImage         = _rb('tb_insertImage')
        self.tb_insertTransposerImage = _rb('tb_insertTransposerImage')
        self.tb_insertMusicalSymbol = _rb('tb_insertMusicalSymbol')
        self.config.SetPath('/')

    def _SaveToolbarVis(self):
        """Salva la visibilità delle icone delle quattro toolbar nel config."""
        self.config.SetPath('/ToolbarVis')
        def _w(key):
            self.config.Write(key, '1' if getattr(self, key, True) else '0')
        # Standard toolbar
        _w('tbm_new');          _w('tbm_open');         _w('tbm_save')
        _w('tbm_printPreview'); _w('tbm_print')
        _w('tbm_undo');         _w('tbm_redo')
        _w('tbm_cut');          _w('tbm_copy');         _w('tbm_copyAsImage')
        _w('tbm_paste');        _w('tbm_pasteChords')
        _w('tbm_syntaxCheck');  _w('tbm_options')
        # Format toolbar
        _w('tbf_fontChooser'); _w('tbf_showChords'); _w('tbf_insertLinespacing')
        # View toolbar
        _w('tbv_preview'); _w('tbv_labelVerses')
        # Insert toolbar
        _w('tb_title');             _w('tb_subtitle')
        _w('tb_chord');             _w('tb_chorus')
        _w('tb_verse');             _w('tb_comment')
        _w('tb_pageBreak');         _w('tb_columnBreak')
        _w('tb_insertVerse');       _w('tb_insertVerseNum')
        _w('tb_insertChorusBlock'); _w('tb_insertChordBlock')
        _w('tb_insertBridge');      _w('tb_insertGrid')
        _w('tb_insertTempo');       _w('tb_insertTempoLabel')
        _w('tb_insertTime');        _w('tb_insertKey')
        _w('tb_insertDuration')
        _w('tb_insertTaste');       _w('tb_insertFingering')
        _w('tb_insertDefine')
        _w('tb_insertImage');       _w('tb_insertTransposerImage')
        _w('tb_insertMusicalSymbol')
        self.config.SetPath('/')

    def SanitizeFilename(self, path):
        """Se l'opzione 'replaceSpacesInFilenames' è attiva, sostituisce ogni
        spazio bianco nel nome del file (non nella cartella) con '_'.
        Funziona allo stesso modo su Windows e Linux, perché opera solo
        sulla stringa del nome file, senza toccare i separatori di percorso.
        """
        if not path:
            return path
        if not getattr(self, 'replaceSpacesInFilenames', False):
            return path
        directory, filename = os.path.split(path)
        filename = re.sub(r'\s+', '_', filename)
        return os.path.join(directory, filename) if directory else filename

    def SetChorusLabel(self, c):
        self.chorusLabel = c
        self.decoratorFormat.SetChorusLabel(c)

    def SetChordsPosition(self, position):
        """Set chords position: 'above' or 'below'."""
        if position in ('above', 'below'):
            self.chordsPosition = position

    def SetDefaultNotation(self, notation):
        self.defaultNotation = notation
        self.notations = [x for x in self.notations if x.id == notation] + [x for x in self.notations if x.id != notation]

    def SetEasyChordsGroup(self, group, level):
        self.easyChordsGroup[group] = level
        self.easyChords = None

    def GetEasyChordsGroup(self, group):
        return self.easyChordsGroup[group]

    def GetEasyChords(self):
        if self.easyChords is None:
            self.easyChords = {'Eb': -1}
            for k in easyChords:
                chords = easyChords[k][1]
                l = self.easyChordsGroup[k] / 4.0
                for c in chords:
                    if c in self.easyChords:
                        self.easyChords[c] = max(self.easyChords[c], l)
                    else:
                        self.easyChords[c] = l

        return self.easyChords

    def _LoadSingleInstance(self):
        self.config.SetPath('/App')
        v = self.config.Read('singleInstance')
        self.singleInstance = bool(int(v)) if v != '' else True
        self.config.SetPath('/')

    def _SaveSingleInstance(self):
        self.config.SetPath('/App')
        self.config.Write('singleInstance', '1' if getattr(self, 'singleInstance', True) else '0')
        self.config.SetPath('/')

    def _LoadShowRestartMenuItem(self):
        self.config.SetPath('/App')
        v = self.config.Read('showRestartMenuItem')
        self.showRestartMenuItem = bool(int(v)) if v != '' else True
        self.config.SetPath('/')

    def _SaveShowRestartMenuItem(self):
        self.config.SetPath('/App')
        self.config.Write('showRestartMenuItem', '1' if getattr(self, 'showRestartMenuItem', True) else '0')
        self.config.SetPath('/')
