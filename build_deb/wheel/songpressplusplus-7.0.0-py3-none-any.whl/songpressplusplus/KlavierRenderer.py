###############################################################
# Name:         KlavierRenderer.py
# Purpose:      Draw piano keyboard diagrams for chords
# Author:       Denisov21
# Created:      2026-03-12
# Copyright:    Denisov21
# License:      GNU GPL v2
###############################################################


import wx
import re

try:
    from .Transpose import translateChord
    _has_transpose = True
except ImportError:
    _has_transpose = False

# Note italiane -> semitono (ordinate per lunghezza decrescente per match corretto)
_ITALIAN_NOTES = [
    ('sol#', 8), ('solb', 6), ('sol', 7),
    ('do#', 1),  ('dob', 11), ('do', 0),
    ('re#', 3),  ('reb', 1),  ('re', 2),
    ('mi#', 5),  ('mib', 3),  ('mi', 4),
    ('fa#', 6),  ('fab', 4),  ('fa', 5),
    ('la#', 10), ('lab', 8),  ('la', 9),
    ('si#', 0),  ('sib', 10), ('si', 11),
]

# Note inglesi -> semitono
_ENGLISH_NOTES = [
    ('c#', 1), ('cb', 11), ('c', 0),
    ('d#', 3), ('db', 1),  ('d', 2),
    ('e#', 5), ('eb', 3),  ('e', 4),
    ('f#', 6), ('fb', 4),  ('f', 5),
    ('g#', 8), ('gb', 6),  ('g', 7),
    ('a#', 10), ('ab', 8), ('a', 9),
    ('b#', 0), ('bb', 10), ('b', 11),
    ('h', 11),
]

# Suffissi accordo -> intervalli (ordinati per lunghezza decrescente)
_CHORD_INTERVALS = [
    ('maj7',  [0, 4, 7, 11]),
    ('maj',   [0, 4, 7]),
    ('m7b5',  [0, 3, 6, 10]),
    ('m7',    [0, 3, 7, 10]),
    ('min',   [0, 3, 7]),
    ('m',     [0, 3, 7]),
    ('dim7',  [0, 3, 6, 9]),
    ('dim',   [0, 3, 6]),
    ('aug',   [0, 4, 8]),
    ('sus4',  [0, 5, 7]),
    ('sus2',  [0, 2, 7]),
    ('7',     [0, 4, 7, 10]),
    ('5',     [0, 7]),
    ('-',     [0, 3, 7]),
    ('',      [0, 4, 7]),
]

# Tasti bianchi nell'ottava (semitoni)
_WHITE_KEYS = [0, 2, 4, 5, 7, 9, 11]
# Tasti neri: semitono -> indice spazio tra i bianchi
_BLACK_KEYS = {1: 0, 3: 1, 6: 3, 8: 4, 10: 5}


def parse_chord(chord_str):
    """
    Analizza una stringa accordo (notazione italiana o inglese).
    Restituisce (root_semitone, intervals) o None.
    """
    s = chord_str.strip()
    sl = s.lower()
    root = None
    rest = ''

    # Prova prima notazione italiana
    for note_str, semitone in _ITALIAN_NOTES:
        if sl.startswith(note_str):
            root = semitone
            rest = s[len(note_str):]
            break

    # Se non trovato prova inglese
    if root is None:
        for note_str, semitone in _ENGLISH_NOTES:
            if sl.startswith(note_str):
                root = semitone
                rest = s[len(note_str):]
                break

    if root is None:
        return None

    # Ignora il basso dopo /
    rest = rest.split('/')[0].strip()
    intervals = [0, 4, 7]  # default maggiore
    for suffix, ivs in _CHORD_INTERVALS:
        if rest.lower().startswith(suffix.lower()):
            intervals = ivs
            break

    return root, intervals


def get_chord_keys(chord_str):
    """Restituisce lista di semitoni (0-11) da evidenziare."""
    result = parse_chord(chord_str)
    if result is None:
        return None
    root, intervals = result
    return [(root + i) % 12 for i in intervals]


def _normalize_chord(chord_str, notations):
    """
    Converte l'accordo dalla notazione corrente verso l'italiano
    usando translateChord, così il parser funziona sempre.
    """
    if not _has_transpose or notations is None:
        return chord_str
    try:
        italian_notation = None
        for n in notations:
            if hasattr(n, 'id') and ('it' in n.id.lower() or 'italian' in n.id.lower()):
                italian_notation = n
                break
        if italian_notation is None:
            return chord_str
        current = notations[0] if notations else None
        if current is None:
            return chord_str
        return translateChord(chord_str, current, italian_notation)
    except Exception:
        return chord_str


def _note_name_to_semitone(note_str):
    """
    Converte un nome di nota (italiano o inglese) in semitono (0-11).
    Restituisce None se non riconosciuta.
    """
    s = note_str.strip().lower()
    for name, semi in _ITALIAN_NOTES:
        if s == name:
            return semi
    for name, semi in _ENGLISH_NOTES:
        if s == name:
            return semi
    return None


def parse_fingering(fingering_str):
    """
    Parsa la stringa del comando {fingering: ...}.

    Formati supportati:
        "Am"                               → accordo senza diteggiatura
        "Am hand=R 1=Do 2=Mi 3=La"        → mano destra
        "Am hand=L 1=Do 2=Mi 3=La"        → mano sinistra
        "Am 1=Do 2=Mi 3=La"               → senza indicazione di mano

    Restituisce:
        chord_name  : str  — il nome dell'accordo (prima parola)
        finger_map  : dict — {semitono: numero_dito}
        hand        : str  — 'R', 'L' o None
    """
    parts = fingering_str.strip().split()
    if not parts:
        return None, {}, None

    chord_name = parts[0]
    finger_map = {}
    hand = None

    for token in parts[1:]:
        # hand=R o hand=L
        m_hand = re.match(r'^hand=([RLrl])$', token, re.IGNORECASE)
        if m_hand:
            hand = m_hand.group(1).upper()
            continue
        # dito=nota
        m = re.match(r'^(\d+)=(.+)$', token)
        if not m:
            continue
        finger_num = int(m.group(1))
        note_name  = m.group(2)
        semi = _note_name_to_semitone(note_name)
        if semi is not None:
            finger_map[semi] = finger_num

    return chord_name, finger_map, hand


def keyboard_header_height(dc, label_font, chord_name, hand=None):
    """
    Restituisce l'altezza totale dello spazio necessario sopra la tastiera
    per le etichette (nome accordo + eventuale etichetta mano).

    Utile per chi chiama draw_keyboard direttamente (es. anteprima dialogo)
    per calcolare il valore corretto di `y`:
        header_h = keyboard_header_height(dc, label_font, chord_name, hand)
        draw_keyboard(dc, x, y + header_h, w, h, ...)
    """
    if label_font:
        dc.SetFont(label_font)
    _, chord_lh = dc.GetTextExtent(chord_name)
    total = chord_lh + 2  # spazio nome accordo + gap

    if hand in ('R', 'L'):
        hand_font = wx.Font(
            max(5, chord_lh - 3),
            wx.FONTFAMILY_DEFAULT,
            wx.FONTSTYLE_ITALIC,
            wx.FONTWEIGHT_NORMAL,
        )
        dc.SetFont(hand_font)
        try:
            hand_label = wx.GetTranslation(u"Right hand") if hand == 'R' else wx.GetTranslation(u"Left hand")
        except Exception:
            hand_label = u"Right hand" if hand == 'R' else u"Left hand"
        _, hand_lh = dc.GetTextExtent(hand_label)
        total += hand_lh + 2

    return total


def draw_keyboard(dc, x, y, w, h, chord_name, highlighted_keys,
                  label_font=None, highlight_color=None, finger_map=None,
                  finger_num_color=None, hand=None):
    """
    Disegna una tastiera di un'ottava su dc.

    highlighted_keys : lista di semitoni (0-11) da evidenziare.
    highlight_color  : wx.Colour per i tasti evidenziati (default rosso).
    finger_map       : dict {semitono: numero_dito}.
    hand             : 'R' = mano destra, 'L' = mano sinistra, None = non mostrato.
    """
    if highlight_color is None:
        highlight_color = wx.Colour(210, 60, 60)
    if finger_map is None:
        finger_map = {}

    white_w = w // 7
    black_w = max(4, int(white_w * 0.55))
    black_h = int(h * 0.62)
    kbd_w   = white_w * 7

    # ── Sfondo e bordo esterno ────────────────────────────────────
    dc.SetBrush(wx.WHITE_BRUSH)
    dc.SetPen(wx.Pen(wx.Colour(80, 80, 80), 1))
    dc.DrawRectangle(x, y, kbd_w, h)

    # ── Tasti bianchi ─────────────────────────────────────────────
    for i, semi in enumerate(_WHITE_KEYS):
        kx = x + i * white_w
        if semi in highlighted_keys:
            dc.SetBrush(wx.Brush(highlight_color))
        else:
            dc.SetBrush(wx.WHITE_BRUSH)
        dc.SetPen(wx.Pen(wx.Colour(80, 80, 80), 1))
        dc.DrawRectangle(kx, y, white_w, h)

    # ── Tasti neri ────────────────────────────────────────────────
    for semi, gap_idx in _BLACK_KEYS.items():
        kx = x + gap_idx * white_w + white_w - black_w // 2
        if semi in highlighted_keys:
            dc.SetBrush(wx.Brush(highlight_color))
        else:
            dc.SetBrush(wx.BLACK_BRUSH)
        dc.SetPen(wx.Pen(wx.Colour(40, 40, 40), 1))
        dc.DrawRectangle(kx, y, black_w, black_h)

    # ── Numeri delle dita sui tasti ───────────────────────────────
    if finger_map:
        finger_font = wx.Font(
            max(5, white_w - 4),
            wx.FONTFAMILY_DEFAULT,
            wx.FONTSTYLE_NORMAL,
            wx.FONTWEIGHT_BOLD,
        )
        dc.SetFont(finger_font)

        for semi, finger_num in finger_map.items():
            label = str(finger_num)
            lw, lh = dc.GetTextExtent(label)

            is_black = semi in _BLACK_KEYS

            if is_black:
                # Tasto nero: numero nella parte bassa del tasto nero
                gap_idx = _BLACK_KEYS[semi]
                kx = x + gap_idx * white_w + white_w - black_w // 2
                cx = kx + black_w // 2
                cy = y + black_h - lh - 2
                # Colore custom o bianco di default (contrasto su nero)
                dc.SetTextForeground(finger_num_color if finger_num_color else wx.WHITE)
            else:
                # Tasto bianco: numero nella parte bassa del tasto
                white_idx = _WHITE_KEYS.index(semi)
                kx = x + white_idx * white_w
                cx = kx + white_w // 2
                cy = y + h - lh - 3
                # Colore custom o nero di default (contrasto su bianco)
                dc.SetTextForeground(finger_num_color if finger_num_color else wx.BLACK)

            dc.DrawText(label, cx - lw // 2, cy)

    # ── Etichette sopra la tastiera: mano (facoltativa) + nome accordo ───
    # Calcola prima tutte le altezze, poi disegna dall'alto verso il basso.

    # 1) Misura nome accordo con label_font
    if label_font:
        dc.SetFont(label_font)
    chord_lw, chord_lh = dc.GetTextExtent(chord_name)

    if hand in ('R', 'L'):
        # 2) Font mano e misura
        hand_font = wx.Font(
            max(5, chord_lh - 3),
            wx.FONTFAMILY_DEFAULT,
            wx.FONTSTYLE_ITALIC,
            wx.FONTWEIGHT_NORMAL,
        )
        dc.SetFont(hand_font)
        try:
            hand_label = wx.GetTranslation(u"Right hand") if hand == 'R' else wx.GetTranslation(u"Left hand")
        except Exception:
            hand_label = u"Right hand" if hand == 'R' else u"Left hand"
        hand_lw, hand_lh = dc.GetTextExtent(hand_label)

        # 3) Nome accordo direttamente sopra la tastiera, mano una riga più su
        chord_ty = y - chord_lh - 2
        hand_ty  = chord_ty - hand_lh - 2

        dc.SetTextForeground(wx.Colour(90, 90, 90))
        dc.DrawText(hand_label, x + (kbd_w - hand_lw) // 2, hand_ty)

        if label_font:
            dc.SetFont(label_font)
        dc.SetTextForeground(wx.BLACK)
        dc.DrawText(chord_name, x + (kbd_w - chord_lw) // 2, chord_ty)
    else:
        dc.SetTextForeground(wx.BLACK)
        dc.DrawText(chord_name, x + (kbd_w - chord_lw) // 2, y - chord_lh - 3)


def draw_klavier_section(dc, klavier_list, start_x, start_y, base_font,
                         pen_scale=1.0, notations=None, highlight_color=None,
                         finger_num_color=None, content_w=None):
    """
    Disegna tutte le tastiere in klavier_list in fondo alla canzone.
    Ogni elemento può essere una stringa accordo semplice ("Am")
    oppure una stringa con diteggiatura ("Am 1=Do 2=Mi 3=La").

    content_w : larghezza utile disponibile (in px logici, senza start_x).
                Se None usa 560 come fallback per retrocompatibilità.

    Restituisce (total_h, used_w):
        total_h : altezza totale occupata
        used_w  : larghezza massima effettivamente disegnata (da start_x)
    """
    if not klavier_list:
        return 0, 0

    white_w  = 16
    kbd_w    = white_w * 7
    kbd_h    = 44
    padding_x = 22
    padding_y = 14
    # label_h aumentato per ospitare sia il nome accordo sia l'etichetta mano sopra
    label_h   = 34
    row_h     = label_h + kbd_h + padding_y

    # Larghezza massima della riga: usa content_w se fornito, altrimenti 560px
    row_max_w = int(content_w) if content_w and content_w > kbd_w else 560
    max_x = start_x + row_max_w

    label_font = wx.Font(
        max(7, int(base_font.GetPointSize() * 0.85)),
        wx.FONTFAMILY_DEFAULT,
        wx.FONTSTYLE_NORMAL,
        wx.FONTWEIGHT_BOLD,
        False,
        base_font.GetFaceName()
    )

    # ── Linea separatrice (lunga quanto il contenuto effettivo) ───
    sep_y = start_y + 10
    dc.SetPen(wx.Pen(wx.Colour(180, 180, 180),
                     max(1, round(1 / pen_scale)), wx.PENSTYLE_DOT))
    dc.DrawLine(start_x, sep_y, start_x + row_max_w, sep_y)

    # ── Titolo sezione ────────────────────────────────────────────
    title_font = wx.Font(
        max(7, int(base_font.GetPointSize() * 0.8)),
        wx.FONTFAMILY_DEFAULT,
        wx.FONTSTYLE_ITALIC,
        wx.FONTWEIGHT_NORMAL,
        False,
        base_font.GetFaceName()
    )
    dc.SetFont(title_font)
    dc.SetPen(wx.NullPen)
    dc.SetTextForeground(wx.Colour(110, 110, 110))
    dc.DrawText("Accordi", start_x, sep_y + 4)
    dc.SetTextForeground(wx.BLACK)

    cur_x = start_x
    cur_y = sep_y + 26
    max_drawn_x = start_x  # tiene traccia della x destra massima usata

    for entry in klavier_list:
        # Parsa: potrebbe essere "Am" oppure "Am hand=R 1=Do 2=Mi 3=La"
        chord_name, finger_map, hand = parse_fingering(entry)
        if chord_name is None:
            continue

        normalized = _normalize_chord(chord_name, notations)
        keys = get_chord_keys(normalized)
        if keys is None:
            keys = get_chord_keys(chord_name)   # fallback
        if keys is None:
            continue

        if cur_x + kbd_w > max_x:
            cur_x = start_x
            cur_y += row_h

        draw_keyboard(
            dc, cur_x, cur_y + label_h, kbd_w, kbd_h,
            chord_name, keys, label_font, highlight_color,
            finger_map=finger_map,
            finger_num_color=finger_num_color,
            hand=hand,
        )
        cur_x += kbd_w + padding_x
        max_drawn_x = max(max_drawn_x, cur_x)

    total_h = (cur_y + row_h) - start_y + 10
    used_w  = max_drawn_x - start_x
    return total_h, used_w


def draw_fingering_section(dc, fingering_list, start_x, start_y, base_font,
                           pen_scale=1.0, notations=None, highlight_color=None,
                           finger_num_color=None, content_w=None):
    """
    Identico a draw_klavier_section ma destinato alle tastiere {fingering:}.
    Non mostra titolo di sezione.

    content_w : larghezza utile disponibile (in px logici, senza start_x).
                Se None usa 560 come fallback per retrocompatibilità.

    Restituisce (total_h, used_w).
    """
    if not fingering_list:
        return 0, 0

    white_w   = 16
    kbd_w     = white_w * 7
    kbd_h     = 44
    padding_x = 22
    padding_y = 14
    # label_h aumentato per ospitare sia il nome accordo sia l'etichetta mano sopra
    label_h   = 34
    row_h     = label_h + kbd_h + padding_y

    row_max_w = int(content_w) if content_w and content_w > kbd_w else 560
    max_x = start_x + row_max_w

    label_font = wx.Font(
        max(7, int(base_font.GetPointSize() * 0.85)),
        wx.FONTFAMILY_DEFAULT,
        wx.FONTSTYLE_NORMAL,
        wx.FONTWEIGHT_BOLD,
        False,
        base_font.GetFaceName()
    )

    # ── Linea separatrice ─────────────────────────────────────────
    sep_y = start_y + 10
    dc.SetPen(wx.Pen(wx.Colour(180, 180, 180),
                     max(1, round(1 / pen_scale)), wx.PENSTYLE_DOT))
    dc.DrawLine(start_x, sep_y, start_x + row_max_w, sep_y)

    cur_x = start_x
    cur_y = sep_y + 8
    max_drawn_x = start_x

    for entry in fingering_list:
        chord_name, finger_map, hand = parse_fingering(entry)
        if chord_name is None:
            continue

        normalized = _normalize_chord(chord_name, notations)
        keys = get_chord_keys(normalized)
        if keys is None:
            keys = get_chord_keys(chord_name)
        if keys is None:
            continue

        if cur_x + kbd_w > max_x:
            cur_x = start_x
            cur_y += row_h

        draw_keyboard(
            dc, cur_x, cur_y + label_h, kbd_w, kbd_h,
            chord_name, keys, label_font, highlight_color,
            finger_map=finger_map,
            finger_num_color=finger_num_color,
            hand=hand,
        )
        cur_x += kbd_w + padding_x
        max_drawn_x = max(max_drawn_x, cur_x)

    total_h = (cur_y + row_h) - start_y + 10
    used_w  = max_drawn_x - start_x
    return total_h, used_w
