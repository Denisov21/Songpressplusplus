###############################################################
# Name:             SongpressFrame.py
# Purpose:     Main frame for Songpress++
# Author:         Luca Allulli (webmaster@roma21.it)
# Modified by:  Denisov21
# Created:     2009-01-16
# Copyright: Luca Allulli (https://www.skeed.it/songpress)
# Copyright: Modifications © 2026 Denisov21
# License:     GNU GPL v2
##############################################################

##############################################################
#Note: wx.FontDialog è un wrapper del dialog nativo di Windows, e SetTitle()
#potrebbe non funzionare su tutte le versioni di wxPython/Windows
#perché il titolo viene gestito dal sistema. 
#Però funziona bene Windows 11 e wxFormBuilder 4.2.1!
###############################################################


import subprocess
import sys
import os
import os.path
import platform

# import wx.aui as aui
import wx.adv
from wx import xrc

from .Editor import *
from .PreviewCanvas import *
from .Renderer import *
from .FontComboBox import FontComboBox
from .FontFaceDialog import FontFaceDialog
from .MyPreferencesDialog import MyPreferencesDialog
from .HTML import HtmlExporter, TabExporter
from . import PdfExporter
from . import SongbookExporter
from . import CanzonatorDialog
from .MyTransposeDialog import *
from .MyNotationDialog import *
from .MyNormalizeDialog import *
from .MyListDialog import MyListDialog
from .Globals import glb
from .Preferences import Preferences
from . import i18n
from .utils import temp_dir, undo_action
from .SyntaxChecker import check as syntax_check
from .SyntaxCheckerDialog import SyntaxCheckerDialog, EVT_SYNTAX_GOTO
from .MusicalSymbolDialog import MusicalSymbolDialog
from . import KlavierRenderer
from .PrintDialog import SongpressPrintout, PrintManager
from .CopyAIBeatsPrompt import CopyAIBeatsPromptMixin
from .SongpressToolbars import SongpressToolbarsMixin
from . import ChordProDirectives

_ = wx.GetTranslation


if platform.system() == 'Windows':
    import wx.msw


class SongpressFindReplaceDialog(object):
    """Dialogo Trova/Sostituisci unificato con due tab (Trova e Sostituisci)."""

    def __init__(self, owner, replace=False):
        object.__init__(self)
        self.owner = owner
        self.replace = replace

        self.dialog = wx.Dialog(
            owner.frame, title=_(u"Find / Replace"),
            style=wx.DEFAULT_DIALOG_STYLE | wx.STAY_ON_TOP
        )

        init_find = self.owner.text.GetSelectedText() or ''

        outer = wx.BoxSizer(wx.VERTICAL)

        # ── Notebook ──────────────────────────────────────────────────
        self.notebook = wx.Notebook(self.dialog)

        # ── Tab 1: Trova ──────────────────────────────────────────────
        pg_find = wx.Panel(self.notebook)
        sz_find = wx.BoxSizer(wx.VERTICAL)

        row_f = wx.BoxSizer(wx.HORIZONTAL)
        row_f.Add(wx.StaticText(pg_find, label=_(u"Find:")),
                  0, wx.ALIGN_CENTER_VERTICAL | wx.RIGHT, 4)
        self.txtFind = wx.ComboBox(pg_find, value=init_find,
                                   size=(240, -1), style=wx.CB_DROPDOWN | wx.TE_PROCESS_ENTER)
        row_f.Add(self.txtFind, 1, wx.EXPAND)
        sz_find.Add(row_f, 0, wx.EXPAND | wx.ALL, 8)

        mid_f = wx.BoxSizer(wx.HORIZONTAL)
        opts_f = wx.BoxSizer(wx.VERTICAL)
        self.cbWholeWord  = wx.CheckBox(pg_find, label=_(u"Whole words only"))
        self.cbMatchCase  = wx.CheckBox(pg_find, label=_(u"Match case"))
        self.cbRegex      = wx.CheckBox(pg_find, label=_(u"Regular expressions"))
        self.cbWrapAroundF = wx.CheckBox(pg_find, label=_(u"Silent wrap-around"))
        opts_f.Add(self.cbWholeWord,   0, wx.BOTTOM, 4)
        opts_f.Add(self.cbMatchCase,   0, wx.BOTTOM, 4)
        opts_f.Add(self.cbRegex,       0, wx.BOTTOM, 4)
        opts_f.Add(self.cbWrapAroundF, 0)
        mid_f.Add(opts_f, 0, wx.RIGHT, 20)
        dir_box = wx.StaticBoxSizer(
            wx.StaticBox(pg_find, label=_(u"Direction")), wx.HORIZONTAL)
        self.rbUp   = wx.RadioButton(pg_find, label=_(u"Up"), style=wx.RB_GROUP)
        self.rbDown = wx.RadioButton(pg_find, label=_(u"Down"))
        self.rbDown.SetValue(True)
        dir_box.Add(self.rbUp,   0, wx.ALL | wx.ALIGN_CENTER_VERTICAL, 4)
        dir_box.Add(self.rbDown, 0, wx.ALL | wx.ALIGN_CENTER_VERTICAL, 4)
        mid_f.Add(dir_box, 0)
        sz_find.Add(mid_f, 0, wx.LEFT | wx.RIGHT | wx.BOTTOM, 8)
        pg_find.SetSizer(sz_find)
        self.notebook.AddPage(pg_find, _(u"Find"))

        # ── Tab 2: Sostituisci ────────────────────────────────────────
        pg_repl = wx.Panel(self.notebook)
        sz_repl = wx.BoxSizer(wx.VERTICAL)
        lbl_w = 110

        row_rf = wx.BoxSizer(wx.HORIZONTAL)
        row_rf.Add(wx.StaticText(pg_repl, label=_(u"Find:"),
                   size=(lbl_w, -1)), 0, wx.ALIGN_CENTER_VERTICAL | wx.RIGHT, 4)
        self.txtFindR = wx.ComboBox(pg_repl, value=init_find,
                                    size=(240, -1), style=wx.CB_DROPDOWN | wx.TE_PROCESS_ENTER)
        row_rf.Add(self.txtFindR, 1, wx.EXPAND)
        sz_repl.Add(row_rf, 0, wx.EXPAND | wx.ALL, 8)

        row_rr = wx.BoxSizer(wx.HORIZONTAL)
        row_rr.Add(wx.StaticText(pg_repl, label=_(u"Replace with:"),
                   size=(lbl_w, -1)), 0, wx.ALIGN_CENTER_VERTICAL | wx.RIGHT, 4)
        self.txtReplace = wx.ComboBox(pg_repl, size=(240, -1),
                                      style=wx.CB_DROPDOWN | wx.TE_PROCESS_ENTER)
        row_rr.Add(self.txtReplace, 1, wx.EXPAND)
        sz_repl.Add(row_rr, 0, wx.EXPAND | wx.LEFT | wx.RIGHT | wx.BOTTOM, 8)

        mid_r = wx.BoxSizer(wx.HORIZONTAL)
        opts_r = wx.BoxSizer(wx.VERTICAL)
        self.cbWholeWordR  = wx.CheckBox(pg_repl, label=_(u"Whole words only"))
        self.cbMatchCaseR  = wx.CheckBox(pg_repl, label=_(u"Match case"))
        self.cbRegexR      = wx.CheckBox(pg_repl, label=_(u"Regular expressions"))
        self.cbWrapAround  = wx.CheckBox(pg_repl, label=_(u"Silent wrap-around"))
        opts_r.Add(self.cbWholeWordR,  0, wx.BOTTOM, 4)
        opts_r.Add(self.cbMatchCaseR,  0, wx.BOTTOM, 4)
        opts_r.Add(self.cbRegexR,      0, wx.BOTTOM, 4)
        opts_r.Add(self.cbWrapAround,  0)
        mid_r.Add(opts_r, 0, wx.RIGHT, 20)
        dir_box_r = wx.StaticBoxSizer(
            wx.StaticBox(pg_repl, label=_(u"Direction")), wx.HORIZONTAL)
        self.rbUpR   = wx.RadioButton(pg_repl, label=_(u"Up"),   style=wx.RB_GROUP)
        self.rbDownR = wx.RadioButton(pg_repl, label=_(u"Down"))
        self.rbDownR.SetValue(True)
        dir_box_r.Add(self.rbUpR,   0, wx.ALL | wx.ALIGN_CENTER_VERTICAL, 4)
        dir_box_r.Add(self.rbDownR, 0, wx.ALL | wx.ALIGN_CENTER_VERTICAL, 4)
        mid_r.Add(dir_box_r, 0, wx.ALIGN_TOP)
        sz_repl.Add(mid_r, 0, wx.LEFT | wx.RIGHT | wx.BOTTOM, 8)
        pg_repl.SetSizer(sz_repl)
        self.notebook.AddPage(pg_repl, _(u"Replace"))

        # ── Bottoni colonna verticale a destra ───────────────────────
        self.btnFindNext   = wx.Button(self.dialog, label=_(u"Find next"))
        self.btnReplace    = wx.Button(self.dialog, label=_(u"Replace"))
        self.btnReplaceAll = wx.Button(self.dialog, label=_(u"Replace all"))
        self.btnCount      = wx.Button(self.dialog, label=_(u"Count matches"))
        self.btnCancel     = wx.Button(self.dialog, wx.ID_ANY, _(u"Close"))
        self.btnFindNext.SetDefault()

        btn_col = wx.BoxSizer(wx.VERTICAL)
        btn_col.Add(self.btnFindNext,   0, wx.EXPAND | wx.BOTTOM, 4)
        btn_col.Add(self.btnReplace,    0, wx.EXPAND | wx.BOTTOM, 4)
        btn_col.Add(self.btnReplaceAll, 0, wx.EXPAND | wx.BOTTOM, 4)
        btn_col.Add(self.btnCount,      0, wx.EXPAND | wx.BOTTOM, 4)
        btn_col.AddStretchSpacer()
        btn_col.Add(self.btnCancel,     0, wx.EXPAND)

        # ── Notebook + bottoni affiancati ────────────────────────────
        nb_and_btns = wx.BoxSizer(wx.HORIZONTAL)

        # Notebook con etichetta count sotto
        left_col = wx.BoxSizer(wx.VERTICAL)
        left_col.Add(self.notebook, 1, wx.EXPAND)
        self.lblCount = wx.StaticText(self.dialog, label=u"")
        self.lblCount.SetForegroundColour(wx.Colour(0, 100, 180))
        left_col.Add(self.lblCount, 0, wx.LEFT | wx.TOP, 4)

        nb_and_btns.Add(left_col,  1, wx.EXPAND | wx.ALL, 6)
        nb_and_btns.Add(btn_col,   0, wx.EXPAND | wx.TOP | wx.RIGHT | wx.BOTTOM, 8)

        outer.Add(nb_and_btns, 1, wx.EXPAND)

        # ── Riga inferiore: scope evidenziazione + colore ─────────────
        bottom_row = wx.BoxSizer(wx.HORIZONTAL)

        # Radio: solo editor / editor + preview
        hl_scope_box = wx.StaticBoxSizer(
            wx.StaticBox(self.dialog, label=_(u"Highlight")), wx.HORIZONTAL)
        self.rbHlEditor  = wx.RadioButton(self.dialog,
                                          label=_(u"'Editor' only"),
                                          style=wx.RB_GROUP)
        self.rbHlBoth    = wx.RadioButton(self.dialog,
                                          label=_(u"'Editor' + 'Songpress++ Preview'"))
        self.rbHlBoth.SetValue(True)
        hl_scope_box.Add(self.rbHlEditor, 0, wx.ALL | wx.ALIGN_CENTER_VERTICAL, 4)
        hl_scope_box.Add(self.rbHlBoth,   0, wx.ALL | wx.ALIGN_CENTER_VERTICAL, 4)
        bottom_row.Add(hl_scope_box, 0, wx.RIGHT | wx.ALIGN_CENTER_VERTICAL, 8)

        # Colore evidenziazione: pulsante Pick + Default + swatch
        hl_col_box = wx.StaticBoxSizer(
            wx.StaticBox(self.dialog, label=_(u"Highlight colour")), wx.HORIZONTAL)
        self.btnHlColour   = wx.Button(self.dialog, label=_(u"Pick\u2026"))
        self.btnHlDefault  = wx.Button(self.dialog, label=_(u"Default"))
        self._hl_colour  = self._load_find_colour()
        self.swatchHl    = wx.Panel(self.dialog, size=(24, 24),
                                    style=wx.BORDER_SIMPLE)
        self.swatchHl.SetBackgroundColour(self._hl_colour)
        hl_col_box.Add(self.btnHlColour,  0, wx.ALL | wx.ALIGN_CENTER_VERTICAL, 4)
        hl_col_box.Add(self.btnHlDefault, 0, wx.ALL | wx.ALIGN_CENTER_VERTICAL, 4)
        hl_col_box.Add(self.swatchHl,     0, wx.ALL | wx.ALIGN_CENTER_VERTICAL, 4)
        bottom_row.Add(hl_col_box, 0, wx.ALIGN_CENTER_VERTICAL)

        outer.Add(bottom_row, 0, wx.LEFT | wx.RIGHT | wx.BOTTOM, 8)

        self.dialog.SetSizerAndFit(outer)
        self.dialog.CentreOnParent()

        # Seleziona la tab giusta
        self.notebook.SetSelection(1 if replace else 0)
        self._UpdateButtons()

        # ── Bind ─────────────────────────────────────────────────────
        self.btnFindNext.Bind(wx.EVT_BUTTON,    self._OnFindNext)
        self.btnReplace.Bind(wx.EVT_BUTTON,     self._OnReplace)
        self.btnReplaceAll.Bind(wx.EVT_BUTTON,  self._OnReplaceAll)
        self.btnCount.Bind(wx.EVT_BUTTON,       self._OnCount)
        self.btnCancel.Bind(wx.EVT_BUTTON,      self._OnCancel)
        self.txtFind.Bind(wx.EVT_TEXT_ENTER,    self._OnFindNext)
        self.txtFind.Bind(wx.EVT_TEXT,          self._OnFindTextChanged)
        self.txtFind.Bind(wx.EVT_TEXT,          self._SyncFindText)
        self.txtFindR.Bind(wx.EVT_TEXT_ENTER,   self._OnFindNext)
        self.txtFindR.Bind(wx.EVT_TEXT,         self._OnFindTextChanged)
        self.txtFindR.Bind(wx.EVT_TEXT,         self._SyncFindTextR)
        self.txtReplace.Bind(wx.EVT_TEXT_ENTER, self._OnReplace)
        self.cbWholeWord.Bind(wx.EVT_CHECKBOX,  self._SyncCheckboxes)
        self.cbMatchCase.Bind(wx.EVT_CHECKBOX,  self._SyncCheckboxes)
        self.cbRegex.Bind(wx.EVT_CHECKBOX,      self._SyncCheckboxes)
        self.cbWholeWordR.Bind(wx.EVT_CHECKBOX, self._SyncCheckboxes)
        self.cbMatchCaseR.Bind(wx.EVT_CHECKBOX, self._SyncCheckboxes)
        self.cbRegexR.Bind(wx.EVT_CHECKBOX,     self._SyncCheckboxes)
        self.cbWrapAroundF.Bind(wx.EVT_CHECKBOX, self._SyncCheckboxes)
        self.cbWrapAround.Bind(wx.EVT_CHECKBOX,  self._SyncCheckboxes)
        self.notebook.Bind(wx.EVT_NOTEBOOK_PAGE_CHANGED, self._OnTabChanged)
        self.dialog.Bind(wx.EVT_CLOSE,      self._OnClose)
        self.dialog.Bind(wx.EVT_CHAR_HOOK,  self._OnCharHook)
        self.btnHlColour.Bind(wx.EVT_BUTTON,  self._OnPickHlColour)
        self.btnHlDefault.Bind(wx.EVT_BUTTON, self._OnDefaultHlColour)

        # Applica il colore caricato subito all'apertura
        self._apply_hl_colour(self._hl_colour)

        # Carica la history persistente nei ComboBox
        self._load_history(self.txtFind,    self._CFG_FIND_PATH)
        self._load_history(self.txtFindR,   self._CFG_FIND_PATH)
        self._load_history(self.txtReplace, self._CFG_REPLACE_PATH)
        # Ripristina il testo iniziale (selezione corrente o vuoto) sopra la history
        if init_find:
            self.txtFind.SetValue(init_find)
            self.txtFindR.SetValue(init_find)

        self.dialog.Show()
        self._FocusFindField()

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    def _IsReplaceTab(self):
        return self.notebook.GetSelection() == 1

    def _ActiveFindCtrl(self):
        return self.txtFindR if self._IsReplaceTab() else self.txtFind

    def _FocusFindField(self):
        ctrl = self._ActiveFindCtrl()
        ctrl.SetFocus()
        ctrl.SetInsertionPointEnd()

    def _UpdateButtons(self):
        on_replace = self._IsReplaceTab()
        self.btnReplace.Show(on_replace)
        self.btnReplaceAll.Show(on_replace)
        self.dialog.Layout()
        self.dialog.Fit()

    def _SyncCheckboxes(self, evt):
        if getattr(self, '_syncing', False):
            evt.Skip()
            return
        self._syncing = True
        try:
            src = evt.GetEventObject()
            v = src.GetValue()
            if src in (self.cbWholeWord, self.cbWholeWordR):
                self.cbWholeWord.SetValue(v)
                self.cbWholeWordR.SetValue(v)
            elif src in (self.cbMatchCase, self.cbMatchCaseR):
                self.cbMatchCase.SetValue(v)
                self.cbMatchCaseR.SetValue(v)
            elif src in (self.cbRegex, self.cbRegexR):
                self.cbRegex.SetValue(v)
                self.cbRegexR.SetValue(v)
            elif src in (self.cbWrapAroundF, self.cbWrapAround):
                self.cbWrapAroundF.SetValue(v)
                self.cbWrapAround.SetValue(v)
        finally:
            self._syncing = False
        evt.Skip()

    def _SyncFindText(self, evt):
        v = self.txtFind.GetValue()
        if self.txtFindR.GetValue() != v:
            self.txtFindR.ChangeValue(v)
        evt.Skip()

    def _SyncFindTextR(self, evt):
        v = self.txtFindR.GetValue()
        if self.txtFind.GetValue() != v:
            self.txtFind.ChangeValue(v)
        evt.Skip()

    def _OnTabChanged(self, evt):
        self._UpdateButtons()
        wx.CallAfter(self._FocusFindField)
        evt.Skip()

    def _OnFindTextChanged(self, evt):
        self.lblCount.SetLabel(u"")
        evt.Skip()

    def _OnCharHook(self, evt):
        if evt.GetKeyCode() == wx.WXK_ESCAPE:
            self._OnCancel(evt)
        else:
            evt.Skip()

    def _get_flags(self):
        flags = 0
        if self.cbWholeWord.GetValue():
            flags |= wx.stc.STC_FIND_WHOLEWORD
        if self.cbMatchCase.GetValue():
            flags |= wx.stc.STC_FIND_MATCHCASE
        if self.cbRegex.GetValue():
            flags |= wx.stc.STC_FIND_REGEXP
        return flags

    def _get_down(self):
        if self._IsReplaceTab():
            return self.rbDownR.GetValue()
        return self.rbDown.GetValue()

    def _get_wrap_around(self):
        """Restituisce True se 'Silent wrap-around' è attivo nella tab corrente."""
        if self._IsReplaceTab():
            return self.cbWrapAround.GetValue()
        return self.cbWrapAroundF.GetValue()

    _MAX_HISTORY = 10

    def _AddToHistory(self, combo, value):
        """Aggiunge value allo storico del ComboBox (max 10, senza duplicati)."""
        if not value:
            return
        items = list(combo.GetItems())
        if value in items:
            items.remove(value)
        items.insert(0, value)
        items = items[:self._MAX_HISTORY]
        combo.SetItems(items)
        combo.SetValue(value)

    # ------------------------------------------------------------------
    # Azioni
    # ------------------------------------------------------------------

    def _OnFindNext(self, evt, silent_wrap=False):
        st = self._ActiveFindCtrl().GetValue()
        if not st:
            return
        flags = self._get_flags()
        down  = self._get_down()
        self.owner._lastFindSt    = st
        self.owner._lastFindFlags = flags
        self.owner._lastFindDown  = down
        self._AddToHistory(self.txtFind,  st)
        self._AddToHistory(self.txtFindR, st)
        text = self.owner.text
        if down:
            s, e = text.GetSelection()
            text.SetSelection(e, e)
            from_start = s == 0
            text.SearchAnchor()
            p = text.SearchNext(flags, st)
        else:
            s, e = text.GetSelection()
            text.SetSelection(s, s)
            from_start = s == text.GetLength()
            text.SearchAnchor()
            p = text.SearchPrev(flags, st)
        if p != -1:
            text.SetSelection(p, p + len(st))
            text.EnsureCaretVisible()
            self.lblCount.SetLabel(u"")
            self.lblCount.SetForegroundColour(wx.Colour(0, 100, 180))
            # Evidenzia nell'editor sempre; nel preview solo se rbHlBoth è attivo
            self.owner.text.SetFindHighlight(st, flags)
            if self.rbHlBoth.GetValue():
                self.owner.previewCanvas.SetFindWord(st, flags)
            else:
                self.owner.previewCanvas.ClearFindWord()
        else:
            if not from_start:
                if down:
                    wherefrom, where, newStart = _(u"Reached the end"), _(u"beginning"), 0
                else:
                    wherefrom, where, newStart = _(u"Reached the beginning"), _(u"end"), text.GetLength()
                wrap_msg = _(u"%s of the song, restarting search from the %s?") % (wherefrom, where)
                do_wrap = silent_wrap or self._get_wrap_around()
                if do_wrap:
                    text.SetSelection(newStart, newStart)
                    self._OnFindNext(evt, silent_wrap=True)
                else:
                    d = wx.MessageDialog(
                        self.dialog,
                        wrap_msg,
                        self.owner.appName, wx.YES_NO | wx.ICON_INFORMATION
                    )
                    if d.ShowModal() == wx.ID_YES:
                        text.SetSelection(newStart, newStart)
                        self._OnFindNext(evt, silent_wrap=True)
            else:
                # Messaggio inline invece di MessageDialog modale
                self.lblCount.SetLabel(_(u"The specified text was not found"))
                self.lblCount.SetForegroundColour(wx.Colour(180, 0, 0))
                self.dialog.Layout()
                self.dialog.Fit()


    def _OnCount(self, evt):
        st = self._ActiveFindCtrl().GetValue()
        if not st:
            self.lblCount.SetLabel(u"")
            return
        flags = self._get_flags()
        text  = self.owner.text
        total = text.GetLength()
        count = 0
        p = 0
        while True:
            result = text.FindText(p, total, st, flags)
            pos = result[0] if isinstance(result, tuple) else result
            if pos == -1:
                break
            count += 1
            p = pos + max(1, len(st))
        msg = _(u"%d match found") % count if count == 1 else _(u"%d matches found") % count
        self.lblCount.SetLabel(msg)
        self.dialog.Layout()
        self.dialog.Fit()

    def _OnReplace(self, evt):
        st = self.txtFindR.GetValue()
        r  = self.txtReplace.GetValue()
        if not st:
            return
        self._AddToHistory(self.txtFindR,  st)
        self._AddToHistory(self.txtFind,   st)
        self._AddToHistory(self.txtReplace, r)
        flags = self._get_flags()
        text  = self.owner.text
        sel_text = text.GetSelectedText()
        use_regex = bool(flags & wx.stc.STC_FIND_REGEXP)
        if use_regex:
            # In modalità regex confrontiamo solo la lunghezza del match
            # (il testo selezionato è il risultato del match, non il pattern).
            # Usiamo SetTarget + ReplaceTarget per essere coerenti con ReplaceAll.
            s, e = text.GetSelection()
            if s != e:
                text.SetTargetStart(s)
                text.SetTargetEnd(e)
                text.ReplaceTarget(r)
        else:
            if sel_text == st or (
                    not (flags & wx.stc.STC_FIND_MATCHCASE) and
                    sel_text.lower() == st.lower()):
                text.ReplaceSelection(r)
        self._OnFindNext(evt, silent_wrap=True)

    def _OnReplaceAll(self, evt):
        st = self.txtFindR.GetValue()
        r  = self.txtReplace.GetValue()
        if not st:
            return
        self._AddToHistory(self.txtFindR,   st)
        self._AddToHistory(self.txtFind,    st)
        self._AddToHistory(self.txtReplace, r)
        flags = self._get_flags()
        text  = self.owner.text
        with undo_action(text):
            text.SetSelection(0, 0)
            c = 0
            p = 0
            while True:
                result = text.FindText(p, text.GetLength(), st, flags)
                pos = result[0] if isinstance(result, tuple) else result
                if pos == -1:
                    break
                # result[1] contiene la fine del match (fondamentale per regex,
                # dove la lunghezza del match può differire da len(st)).
                match_end = result[1] if isinstance(result, tuple) else pos + len(st)
                text.SetTargetStart(pos)
                text.SetTargetEnd(match_end)
                p = pos + text.ReplaceTarget(r)
                c += 1
        wx.MessageDialog(
            self.dialog,
            _(u"%d text occurrences have been replaced") % (c,),
            self.owner.appName, wx.OK | wx.ICON_INFORMATION
        ).ShowModal()

    def _OnCancel(self, evt):
        self._save_history(self.txtFind,    self._CFG_FIND_PATH)
        self._save_history(self.txtReplace, self._CFG_REPLACE_PATH)
        if self.dialog is not None:
            self.dialog.Destroy()
            self.dialog = None
        self.owner.findReplaceDialog = None

    def _OnClose(self, evt):
        # Salva la history prima di distruggere il dialogo
        try:
            self._save_history(self.txtFind,    self._CFG_FIND_PATH)
            self._save_history(self.txtReplace, self._CFG_REPLACE_PATH)
        except Exception:
            pass
        # Rimuove le evidenziazioni da editor e preview alla chiusura del dialogo
        try:
            self.owner.text.ClearFindHighlight()
            self.owner.previewCanvas.ClearFindWord()
        except Exception:
            pass
        self.dialog = None
        self.owner.findReplaceDialog = None
        evt.Skip()

    # --- History persistente (ricerca e sostituzione) ----------------------

    _CFG_FIND_PATH    = '/FindHistory/Find'
    _CFG_REPLACE_PATH = '/FindHistory/Replace'

    def _load_history(self, combo, cfg_path):
        """Carica la history da wx.Config e la popola nel ComboBox."""
        try:
            cfg = wx.Config.Get()
            cfg.SetPath(cfg_path)
            items = []
            i = 0
            while True:
                # wx.Config.Read restituisce il default se la chiave non esiste
                val = cfg.Read(f'item{i}', '\x00')
                if val == '\x00':
                    break
                items.append(val)
                i += 1
                if i >= self._MAX_HISTORY:
                    break
            cfg.SetPath('/')
            if items:
                combo.SetItems(items)
        except Exception:
            pass

    def _save_history(self, combo, cfg_path):
        """Salva la history del ComboBox in wx.Config."""
        try:
            cfg = wx.Config.Get()
            # Risale al gruppo padre e cancella il sottogruppo per nome relativo
            parent, _, group_name = cfg_path.rstrip('/').rpartition('/')
            cfg.SetPath(parent if parent else '/')
            cfg.DeleteGroup(group_name)
            cfg.SetPath(cfg_path)
            items = list(combo.GetItems())[:self._MAX_HISTORY]
            for i, val in enumerate(items):
                cfg.Write(f'item{i}', val)
            cfg.SetPath('/')
            cfg.Flush()
        except Exception:
            pass

    # --- Colore evidenziazione: load / save / pick -------------------------

    _DEFAULT_HL_HEX = '#FFDC00'   # giallo default

    def _load_find_colour(self):
        """Legge il colore salvato in wx.Config; restituisce wx.Colour."""
        try:
            cfg = wx.Config.Get()
            cfg.SetPath('/FindHighlight')
            h = cfg.Read('colourHex')
            cfg.SetPath('/')
            if h:
                h = h.strip().lstrip('#')
                if len(h) == 6:
                    return wx.Colour(int(h[0:2], 16),
                                     int(h[2:4], 16),
                                     int(h[4:6], 16))
        except Exception:
            pass
        h = self._DEFAULT_HL_HEX.lstrip('#')
        return wx.Colour(int(h[0:2], 16), int(h[2:4], 16), int(h[4:6], 16))

    def _save_find_colour(self, colour):
        """Salva il colore in wx.Config."""
        try:
            cfg = wx.Config.Get()
            cfg.SetPath('/FindHighlight')
            cfg.Write('colourHex', '#%02X%02X%02X' % (
                colour.Red(), colour.Green(), colour.Blue()))
            cfg.SetPath('/')
            cfg.Flush()
        except Exception:
            pass

    def _apply_hl_colour(self, colour):
        """Propaga il colore all'editor e al preview decorator."""
        try:
            self.owner.text.SetFindHighlightColour(colour)
        except Exception:
            pass
        try:
            self.owner.previewCanvas.SetFindHighlightColour(colour)
        except Exception:
            pass

    def _OnPickHlColour(self, evt):
        """Apre wx.ColourDialog per scegliere il colore di evidenziazione."""
        data = wx.ColourData()
        data.SetColour(self._hl_colour)
        data.SetChooseFull(True)
        dlg = wx.ColourDialog(self.dialog, data)
        if dlg.ShowModal() == wx.ID_OK:
            chosen = dlg.GetColourData().GetColour()
            self._hl_colour = chosen
            self.swatchHl.SetBackgroundColour(chosen)
            self.swatchHl.Refresh()
            self._apply_hl_colour(chosen)
            self._save_find_colour(chosen)
            # Riapplica l'highlight con il nuovo colore se c'è una parola cercata
            st    = self._ActiveFindCtrl().GetValue()
            flags = self._get_flags()
            if st:
                self.owner.text.SetFindHighlight(st, flags)
                if self.rbHlBoth.GetValue():
                    self.owner.previewCanvas.SetFindWord(st, flags, colour=chosen)
        dlg.Destroy()

    def _OnDefaultHlColour(self, evt):
        """Ripristina il colore di evidenziazione al default (#FFDC00)."""
        h = self._DEFAULT_HL_HEX.lstrip('#')
        default = wx.Colour(int(h[0:2], 16), int(h[2:4], 16), int(h[4:6], 16))
        self._hl_colour = default
        self.swatchHl.SetBackgroundColour(default)
        self.swatchHl.Refresh()
        self._apply_hl_colour(default)
        self._save_find_colour(default)
        st    = self._ActiveFindCtrl().GetValue()
        flags = self._get_flags()
        if st:
            self.owner.text.SetFindHighlight(st, flags)
            if self.rbHlBoth.GetValue():
                self.owner.previewCanvas.SetFindWord(st, flags, colour=default)

    # -----------------------------------------------------------------------

    def OnClose(self, evt):
        if self.dialog:
            self.dialog.Destroy()
            self.dialog = None



if platform.system() == 'Linux':
    # Apparently there is a problem with linux FileOpen dialog box in wxPython:
    # it does not support multiple extensions in a filter.
    _import_formats = [
        (_("All supported files"), ["crd", "cho", "chordpro", "chopro", "tab", "cpm", "sng"]),
        #(_("Chordpro files (*.crd)"), ["crd"]),
        #(_("Tab files (*.tab)"), ["tab"]),
        #(_("Chordpro files (*.cho)"), ["cho"]),
        #(_("Chordpro files (*.chordpro)"), ["chordpro"]),
        #(_("Chordpro files (*.chopro)"), ["chopro"]),
        #(_("Chordpro files (*.pro)"), ["pro"]),
    ]
else:
    _import_formats = [
        (_("All supported files"), ["crd", "cho", "chordpro", "chopro", "pro", "tab", "sng"]),
        (_("Chordpro files (*.crd, *.cho, *.chordpro, *.chopro, *.pro)"), ["crd", "cho", "chordpro", "chopro", "pro"]),
        (_("Tab files (*.tab)"), ["tab"]),
        (_("Songpress files (*.sng)"), ["sng"]),
    ]


class SongpressFrame(SDIMainFrame, PrintManager, CopyAIBeatsPromptMixin, SongpressToolbarsMixin):
    def __init__(self, res):
        PrintManager.__init__(self)
        SDIMainFrame.__init__(
            self,
            res,
            'MainFrame',
            'Songpress++',
            'Skeed',
            _('song'),
            'crd',
            _('Songpress++ - The Song Editor'),
            glb.AddPath('img/songpress++.ico'),
            glb.VERSION,
            _("Original version website: http://www.skeed.it/songpress"),
            (_(u"Copyright (c) 2009-{year} Luca Allulli - Skeed\nLocalization:\n{translations}\n\nSongpress++ is a fork of Songpress by Luca Allulli - Skeed\n(http://www.skeed.it/songpress), maintained and extended by Denisov21.\n(https://github.com/Denisov21/Songpressplusplus)")).format(
                year=glb.YEAR,
                translations="\n".join([u"- {}: {}".format(glb.languages[x], glb.translators[x]) for x in glb.languages])
            ),
            _("Licensed under the terms and conditions of the GNU General Public License, version 2"),
            _(
                "Special thanks to:\n  * The Python programming language (http://www.python.org)\n  * wxWidgets (http://www.wxwidgets.org)\n  * wxPython (http://www.wxpython.org)\n  * python-pptx (for PowerPoint export)"),
            _import_formats,
        )
        self._LoadPageMargins()
        self.pref = Preferences()
        if not hasattr(self.pref, 'tempoDisplay'):
            self.pref.tempoDisplay = 0
        if not hasattr(self.pref, 'timeDisplay'):
            self.pref.timeDisplay = True
        if not hasattr(self.pref, 'keyDisplay'):
            self.pref.keyDisplay = True
        if not hasattr(self.pref, 'tempoIconSize'):
            self.pref.tempoIconSize = 24
        if not hasattr(self.pref, 'klavierHighlightHex'):
            self.pref.klavierHighlightHex = '#D23C3C'
        self.SetDefaultExtension(self.pref.defaultExtension)
        self.statusBar = self.frame.GetStatusBar()
        if self.statusBar:
            self.statusBar.SetFieldsCount(3)
            self.statusBar.SetStatusWidths([-1, 160, 110])
        self._statusTimer = wx.Timer(self.frame)
        self.frame.Bind(wx.EVT_TIMER, self._OnStatusTimerExpired, self._statusTimer)
        # Timer per aggiornare NUM / CAPS / SCR nella status bar (campo 2)
        self._lockKeysTimer = wx.Timer(self.frame)
        self.frame.Bind(wx.EVT_TIMER, self._OnLockKeysTimer, self._lockKeysTimer)
        self._lockKeysTimer.Start(300)
        # Workaround: wx.lib.agw.aui framemanager crashes with a wxAssertionError
        # in BufferedDC when the frame is resized to zero (e.g. minimised).
        # Skip the event before AUI can attempt to repaint with invalid dimensions.
        def _OnFrameSize(evt):
            w, h = evt.GetSize()
            if w > 0 and h > 0:
                evt.Skip()
        self.frame.Bind(wx.EVT_SIZE, _OnFrameSize)
        self.text = Editor(self)
        dt = SDIDropTarget(self)
        self.text.SetDropTarget(dt)
        self.frame.Bind(wx.stc.EVT_STC_UPDATEUI, self.OnUpdateUI, self.text)
        self.text.Bind(wx.EVT_KEY_DOWN, self.OnTextKeyDown, self.text)
        self.text.Bind(wx.stc.EVT_STC_AUTOCOMP_SELECTION, self._OnIntellisenseSelection, self.text)
        self._RegisterIntellisenseImages()
        # Other objects
        self.previewCanvas = PreviewCanvas(self.frame, self.pref.format, self.pref.notations, self.pref.decorator)
        # Registra la callback doppio-click: naviga alla riga sorgente nell'editor
        self.previewCanvas.SetClickCallback(self._OnPreviewClick)
        self._mgr.AddPane(
            self.text,
            aui.AuiPaneInfo()
                .Center()
                .Name('_main')
                .Caption(_('Editor'))
                .CaptionVisible(True)
                .CloseButton(False)
                .MaximizeButton(False)
                .Floatable(False)
                .Movable(False)
                .PaneBorder(False)
        )
        _preview_min = wx.Size(370, 520) if getattr(self.pref, 'previewMinSize', True) else wx.Size(-1, -1)
        self.AddPane(self.previewCanvas.main_panel,
                     aui.AuiPaneInfo().Right().BestSize(370, 520).MinSize(_preview_min),
                     _('Songpress++ Preview'), 'preview')
        self.previewCanvas.main_panel.Bind(wx.adv.EVT_HYPERLINK, self.OnCopyAsImage, self.previewCanvas.link)

        # ── Caption bar personalizzata per Editor e Anteprima ──────────
        class _SongpressDockArt(aui.AuiDefaultDockArt):
            """Colora la caption bar in base al nome del pannello:
               - '_main'   (Editor)    → colore pref.captionEditorActiveHex
               - 'preview' (Anteprima) → colore pref.captionPreviewActiveHex
            I colori attivo/inattivo sono calcolati automaticamente dal colore base.
            """

            def __init__(self, pref):
                super().__init__()
                self._pref = pref

            @staticmethod
            def _hex_to_colour(h, fallback):
                try:
                    h = h.strip().lstrip('#')
                    if len(h) == 6:
                        return wx.Colour(int(h[0:2], 16), int(h[2:4], 16), int(h[4:6], 16))
                except Exception:
                    pass
                return fallback

            @staticmethod
            def _darken(c, f=0.75):
                return wx.Colour(int(c.Red()*f), int(c.Green()*f), int(c.Blue()*f))

            @staticmethod
            def _lighten(c, f=1.5):
                return wx.Colour(min(255, int(c.Red()*f)), min(255, int(c.Green()*f)), min(255, int(c.Blue()*f)))

            def DrawCaption(self, dc, window, text, rect, pane):
                name = pane.name if pane else ''
                active = bool(pane and pane.HasFlag(pane.optionActive))
                if name == '_main':
                    base = self._hex_to_colour(
                        getattr(self._pref, 'captionEditorActiveHex', '#4682C8'),
                        wx.Colour(70, 130, 200)
                    )
                elif name == 'preview':
                    base = self._hex_to_colour(
                        getattr(self._pref, 'captionPreviewActiveHex', '#329B82'),
                        wx.Colour(50, 155, 130)
                    )
                else:
                    super().DrawCaption(dc, window, text, rect, pane)
                    return
                if active:
                    c1, c2 = base, self._darken(base)
                else:
                    c1, c2 = self._lighten(base), base
                dc.GradientFillLinear(rect, c1, c2, wx.SOUTH)
                dc.SetTextForeground(wx.WHITE if active else wx.Colour(40, 40, 40))
                dc.SetFont(self._caption_font)
                w, h = dc.GetTextExtent(text)
                dc.DrawText(text, rect.x + 4, rect.y + (rect.height - h) // 2)

        self._dockArt = _SongpressDockArt(self.pref)
        self._mgr.SetArtProvider(self._dockArt)
        # ───────────────────────────────────────────────────────────────

        # ── Toolbars (Standard, Format, Insert) ──────────────────────
        self._BuildToolbars()
        self._ApplyMainToolBarVisibility()
        self._ApplyFormatToolBarVisibility()
        self._ApplyInsertToolBarVisibility()
        self._ApplyViewToolBarVisibility()
        # ─────────────────────────────────────────────────────────────

        self.BindMyMenu()
        self._BuildNewFromTemplateMenu()
        self.frame.Bind(EVT_TEXT_CHANGED, self.OnTextChanged)
        self.frame.Bind(wx.EVT_CHAR_HOOK, self._OnGlobalCharHook)
        self.exportMenuId = xrc.XRCID('export')
        self.saveMenuId = xrc.XRCID('save')
        self.exportToClipboardAsAVectorImage = xrc.XRCID('exportToClipboardAsAVectorImage')
        self.exportAsEmfMenuId = xrc.XRCID('exportAsEmf')
        self.cutMenuId = xrc.XRCID('cut')
        self.copyMenuId = xrc.XRCID('copy')
        self.copyAsImageMenuId = xrc.XRCID('copyAsImage')
        self.pasteMenuId = xrc.XRCID('paste')
        self.pasteChordsMenuId = xrc.XRCID('pasteChords')
        self.undoMenuId = xrc.XRCID('undo')
        self.redoMenuId = xrc.XRCID('redo')
        self.propagateVerseChordsMenuId = xrc.XRCID('propagateVerseChords')
        self.propagateChorusChordsMenuId = xrc.XRCID('propagateChorusChords')
        self.removeChordsMenuId = xrc.XRCID('removeChords')
        self.labelVersesMenuId = xrc.XRCID('labelVerses')
        self.noChordsMenuId = xrc.XRCID('noChords')
        self.oneVerseForEachChordPatternMenuId = xrc.XRCID('oneVerseForEachChordPattern')
        self.wholeSongMenuId = xrc.XRCID('wholeSong')
        self.chordsAboveMenuId = xrc.XRCID('chordsAbove')
        self.chordsBelowMenuId = xrc.XRCID('chordsBelow')
        if platform.system() != 'Windows':
            self.menuBar.GetMenu(0).FindItemById(self.exportMenuId).GetSubMenu().Delete(self.exportAsEmfMenuId)
        self._chord_dialog_pinned = False   # True = keep insert-chord dialog open after OK
        self._showPageBreakLines = True
        self._showColumnBreakLines = True
        self._showDurationBeats = True
        self._showPageBreakLinesMenuId = xrc.XRCID('showPageBreakLines')
        self._showColumnBreakLinesMenuId = xrc.XRCID('showColumnBreakLines')
        self._showDurationBeatsMenuId = xrc.XRCID('showDurationBeats')
        self._restartMenuId = xrc.XRCID('restart')
        self._ApplyRestartMenuVisibility()
        self.findReplaceDialog = None
        self._lastFindSt    = ''
        self._lastFindFlags = 0
        self._lastFindDown  = True
        self.CheckLabelVerses()
        self.CheckChordsPosition()
        self.SetFont()
        self.text.SetFont(self.pref.editorFace, self.pref.editorSize)
        self.text.SetBgColour(getattr(self.pref, 'editorBgHex', '#FFFFFF'))
        self.text.SetSelColour(getattr(self.pref, 'selColourHex', '#3399FF'))
        self.text.SetCaretColour(getattr(self.pref, 'caretColourHex', '#000000'))
        _sc = getattr(self.pref, 'syntaxColours', {})
        for _k, _sid in [('normal', 11), ('chorus', 15), ('chord', 12), ('command', 13), ('attr', 14), ('comment', 16), ('tabgrid', 17)]:
            if _k in _sc:
                self.text.SetSyntaxColour(_sid, _sc[_k])
        self.text.ApplyMultiCursor(getattr(self.pref, 'multiCursor', False))
        self._applyKlavierHighlightColor()
        self._applyFingerNumColor()
        self._UpdateStatusIndicators()
        # Se la perspective è stata salvata prima dell'introduzione della barra
        # "Editor" sul pannello centrale, va resettata una volta sola.
        self.config.SetPath('/SDIMainFrame')
        if not self.config.ReadBool('EditorCaptionPane', False):
            self.config.DeleteEntry('Perspective', False)
            self.config.WriteBool('EditorCaptionPane', True)
        self.FinalizePaneInitialization()
        # Reassign caption value to override caption saved in preferences (it could be another language)
        self._mgr.GetPane('_main').caption = _('Editor')
        self._mgr.GetPane('preview').caption = _('Songpress++ Preview')
        self._mgr.GetPane('standard').caption = _('Standard')
        self._mgr.GetPane('format').caption = _('Format')
        self._mgr.GetPane('insert').caption = _('Insert')
        # LoadPerspective sovrascrive MinSize: lo reimponiamo sempre dopo
        self._ApplyPreviewMinSize()
        self._mgr.Update()
        self._UpdateBreakLinesMenuState()
        wx.CallAfter(self._SyncPreviewToggleButton)
        self.RestoreWindowGeometry()
        # Thaw corrisponde al Freeze chiamato in FinalizePaneInitialization()
        # prima di frame.Show(). A questo punto posizione e dimensione sono
        # già corrette: il primo repaint mostra la finestra già definitiva.
        try:
            self.frame.Thaw()
        except Exception:
            pass
        if 'firstTimeEasyKey' in self.pref.notices:
            msg = _(
                "You are not a skilled guitarist? Songpress++ can help you: when you open a song, it can detect if chords are difficult. If this is the case, Songpress++ will alert you, and offer to transpose your song to the easiest key, automatically.\n\nDo you want to turn this option on?")
            d = wx.MessageDialog(self.frame, msg, _("Songpress++"), wx.YES_NO | wx.ICON_QUESTION)
            if d.ShowModal() == wx.ID_YES:
                self.pref.autoAdjustEasyKey = True
                msg = _(
                    "Please take a minute to set up your skill as a guitarist. For each group of chords, tell Songpress++ how much you like them.")
                d = wx.MessageDialog(self.frame, msg, _("Songpress++"), wx.OK)
                d.ShowModal()
                f = MyPreferencesDialog(self.frame, self.pref, easyChords,
                                            previewCanvas=self.previewCanvas)
                f.notebook.SetSelection(1)
                if f.ShowModal() == wx.ID_OK:
                    self.text.SetFont(self.pref.editorFace, int(self.pref.editorSize))
                    self.SetDefaultExtension(self.pref.defaultExtension)

    def OnClose(self, evt):
        if hasattr(self, '_lockKeysTimer') and self._lockKeysTimer.IsRunning():
            self._lockKeysTimer.Stop()
        self.SaveWindowGeometry()
        self._SavePageMargins()
        self._SaveTempoDisplay()
        self._SaveGuidePrefs()
        self._SaveKlavierColour()
        self._SaveCustomColours()
        self.pref.Save()
        self.config.Flush()
        super().OnClose(evt)

    def _ApplyRestartMenuVisibility(self):
        """Mostra o nasconde la voce 'Riavvia Songpress++' nel menu File
        in base alla preferenza showRestartMenuItem.

        wxWidgets non supporta Show/Hide diretto sulle voci di menu:
        si rimuove la voce (e il separatore sopra) e la si reinserisce
        nella posizione originale quando torna visibile.
        """
        show = getattr(self.pref, 'showRestartMenuItem', True)
        file_menu = self.menuBar.GetMenu(0)

        # Cerca la posizione attuale dell'item restart (se presente)
        restart_pos = None
        for i in range(file_menu.GetMenuItemCount()):
            if file_menu.FindItemByPosition(i).GetId() == self._restartMenuId:
                restart_pos = i
                break

        if show and restart_pos is None:
            # Era nascosta: la reinseriamo appena prima della voce 'exit'
            exit_id = xrc.XRCID('exit')
            exit_pos = None
            for i in range(file_menu.GetMenuItemCount()):
                if file_menu.FindItemByPosition(i).GetId() == exit_id:
                    exit_pos = i
                    break
            if exit_pos is not None:
                # Reinserisce il separatore e la voce
                file_menu.InsertSeparator(exit_pos)
                item = wx.MenuItem(file_menu, self._restartMenuId,
                                   _("Restart Songpress++"), _("Close and restart Songpress++"))
                _icon_path = glb.AddPath('img/restart.png')
                if os.path.isfile(_icon_path):
                    item.SetBitmap(wx.Bitmap(_icon_path, wx.BITMAP_TYPE_PNG))
                file_menu.Insert(exit_pos + 1, item)
                self.frame.Bind(wx.EVT_MENU, self.OnRestart, id=self._restartMenuId)

        elif not show and restart_pos is not None:
            # Rimuove la voce e il separatore immediatamente sopra
            file_menu.Remove(self._restartMenuId)
            # Controlla se la posizione precedente era un separatore
            if restart_pos > 0:
                prev = file_menu.FindItemByPosition(restart_pos - 1)
                if prev is not None and prev.IsSeparator():
                    file_menu.Remove(prev)

    def OnRestart(self, evt):
        """Salva le preferenze, chiude la finestra e riavvia Songpress++.

        Strategia di rilevamento del comando di avvio:

        1. Modalita' installata (uv tool install):
           La struttura su disco e':
             <INSTDIR>\\bin\\SongPressPlusPlus.exe   <- exe wrapper
             <INSTDIR>\\Scripts\\python.exe           <- sys.executable
           Si risale da Scripts\\ al padre (<INSTDIR>) e si cerca
           bin\\SongPressPlusPlus.exe.
           Se trovato, si usa quello come comando (nessun argomento extra).

        2. Modalita' sviluppo Thonny / script diretto:
           sys.argv[0] e' il percorso assoluto del .py
           -> [sys.executable, sys.argv[0]] + sys.argv[1:]

        3. Modalita' uv run / python -m:
           sys.argv[0] e' lo script o '-m ...'
           -> [sys.executable] + sys.argv
        """
        # --- 1. Cerca l'exe wrapper installato ---
        # Struttura uv tool install:
        #   <INSTDIR>\bin\SongPressPlusPlus.exe
        #   <INSTDIR>\tools\songpressplusplus\Scripts\python.exe  <- sys.executable
        # Risale: Scripts -> tools\songpressplusplus -> tools -> <INSTDIR> (3 livelli)
        exe_name = 'SongPressPlusPlus.exe'
        scripts_dir = os.path.dirname(os.path.abspath(sys.executable))
        install_root = os.path.dirname(os.path.dirname(os.path.dirname(scripts_dir)))
        installed_exe = os.path.join(install_root, 'bin', exe_name)
        if os.path.isfile(installed_exe):
            cmd = [installed_exe]
        else:
            # --- 2/3. Modalita' sviluppo (Thonny, uv run, python -m) ---
            cmd = [sys.executable] + sys.argv

        subprocess.Popen(cmd)
        wx.CallAfter(self.frame.Close)

    def _SaveTempoDisplay(self):
        """Salva le modalità di visualizzazione di tempo, misura e tonalità nel config."""
        try:
            self.config.SetPath('/TempoDisplay')
            self.config.Write('tempoDisplay', str(getattr(self.pref, 'tempoDisplay', 0)))
            self.config.SetPath('/TimeDisplay')
            self.config.Write('timeDisplay', '1' if getattr(self.pref, 'timeDisplay', True) else '0')
            self.config.SetPath('/KeyDisplay')
            self.config.Write('keyDisplay', '1' if getattr(self.pref, 'keyDisplay', True) else '0')
        except Exception:
            pass

    def _LoadTempoDisplay(self):
        """Ripristina le modalità di visualizzazione di tempo, misura e tonalità dal config."""
        try:
            self.config.SetPath('/TempoDisplay')
            val = self.config.Read('tempoDisplay')
            if val:
                self.pref.tempoDisplay = int(val)
            self.config.SetPath('/TimeDisplay')
            val = self.config.Read('timeDisplay')
            if val:
                self.pref.timeDisplay = (val == '1')
            self.config.SetPath('/KeyDisplay')
            val = self.config.Read('keyDisplay')
            if val:
                self.pref.keyDisplay = (val == '1')
        except Exception:
            pass

    def _SaveGuidePrefs(self):
        """Salva le preferenze della guida rapida (zoom e tema) nel config."""
        try:
            self.config.SetPath('/GuidePrefs')
            self.config.Write('zoom', str(getattr(self.pref, 'guideZoom', 100)))
            self.config.Write('darkMode', '1' if getattr(self.pref, 'guideDarkMode', False) else '0')
        except Exception:
            pass

    def _LoadGuidePrefs(self):
        """Ripristina le preferenze della guida rapida (zoom e tema) dal config."""
        try:
            self.config.SetPath('/GuidePrefs')
            val = self.config.Read('zoom')
            if val:
                self.pref.guideZoom = max(50, min(200, int(val)))
            else:
                self.pref.guideZoom = 100
            val = self.config.Read('darkMode')
            self.pref.guideDarkMode = (val == '1')
        except Exception:
            self.pref.guideZoom = 100
            self.pref.guideDarkMode = False

    def _SaveKlavierColour(self):
        """Salva il colore dei tasti klavier nel config."""
        try:
            self.config.SetPath('/KlavierColour')
            self.config.Write('highlightHex', getattr(self.pref, 'klavierHighlightHex', '#D23C3C'))
        except Exception:
            pass

    def _LoadKlavierColour(self):
        """Ripristina il colore dei tasti klavier dal config."""
        try:
            self.config.SetPath('/KlavierColour')
            val = self.config.Read('highlightHex')
            if val:
                self.pref.klavierHighlightHex = val
        except Exception:
            pass

    def _SaveCustomColours(self):
        """Salva i colori personalizzati dei due ColourDialog nel config."""
        try:
            self.config.SetPath('/CustomColoursKlavier')
            for i, hex_str in enumerate(getattr(self.pref, 'customColoursKlavier', [])[:16]):
                self.config.Write('colour%d' % i, hex_str)
            self.config.SetPath('/CustomColoursEditorBg')
            for i, hex_str in enumerate(getattr(self.pref, 'customColoursEditorBg', [])[:16]):
                self.config.Write('colour%d' % i, hex_str)
            self.config.SetPath('/CustomColoursSelColour')
            for i, hex_str in enumerate(getattr(self.pref, 'customColoursSelColour', [])[:16]):
                self.config.Write('colour%d' % i, hex_str)
            self.config.SetPath('/CustomColoursCapEditor')
            for i, hex_str in enumerate(getattr(self.pref, 'customColoursCapEditor', [])[:16]):
                self.config.Write('colour%d' % i, hex_str)
            self.config.SetPath('/CustomColoursCapPreview')
            for i, hex_str in enumerate(getattr(self.pref, 'customColoursCapPreview', [])[:16]):
                self.config.Write('colour%d' % i, hex_str)
        except Exception:
            pass

    def _LoadCustomColours(self):
        """Ripristina i colori personalizzati dei due ColourDialog dal config."""
        try:
            self.config.SetPath('/CustomColoursKlavier')
            self.pref.customColoursKlavier = [
                self.config.Read('colour%d' % i) or '#FFFFFF' for i in range(16)
            ]
        except Exception:
            self.pref.customColoursKlavier = ['#FFFFFF'] * 16
        try:
            self.config.SetPath('/CustomColoursEditorBg')
            self.pref.customColoursEditorBg = [
                self.config.Read('colour%d' % i) or '#FFFFFF' for i in range(16)
            ]
        except Exception:
            self.pref.customColoursEditorBg = ['#FFFFFF'] * 16
        try:
            self.config.SetPath('/CustomColoursSelColour')
            self.pref.customColoursSelColour = [
                self.config.Read('colour%d' % i) or '#FFFFFF' for i in range(16)
            ]
        except Exception:
            self.pref.customColoursSelColour = ['#FFFFFF'] * 16
        try:
            self.config.SetPath('/CustomColoursCapEditor')
            self.pref.customColoursCapEditor = [
                self.config.Read('colour%d' % i) or '#FFFFFF' for i in range(16)
            ]
        except Exception:
            self.pref.customColoursCapEditor = ['#FFFFFF'] * 16
        try:
            self.config.SetPath('/CustomColoursCapPreview')
            self.pref.customColoursCapPreview = [
                self.config.Read('colour%d' % i) or '#FFFFFF' for i in range(16)
            ]
        except Exception:
            self.pref.customColoursCapPreview = ['#FFFFFF'] * 16

    def SaveWindowGeometry(self):
        """Save window size, position and maximized state to config."""
        if not getattr(self.pref, 'saveWindowGeometry', True):
            return
        try:
            maximized = self.frame.IsMaximized()
            self.config.SetPath('/Window')
            self.config.Write('maximized', '1' if maximized else '0')
            if not maximized:
                x, y = self.frame.GetPosition()
                w, h = self.frame.GetSize()
                self.config.Write('x', str(x))
                self.config.Write('y', str(y))
                self.config.Write('w', str(w))
                self.config.Write('h', str(h))
        except Exception:
            pass

    def RestoreWindowGeometry(self):
        """Restore window size and position from config, with multimonitor safety."""
        if not getattr(self.pref, 'saveWindowGeometry', True):
            return
        try:
            self.config.SetPath('/Window')
            maximized = self.config.Read('maximized')
            x = self.config.Read('x')
            y = self.config.Read('y')
            w = self.config.Read('w')
            h = self.config.Read('h')
            if w and h:
                w, h = int(w), int(h)
                # Enforce minimum size
                w = max(w, 400)
                h = max(h, 300)
                if x and y:
                    x, y = int(x), int(y)
                    # Verify that the saved position is visible on at least one connected display
                    visible = False
                    for i in range(wx.Display.GetCount()):
                        display = wx.Display(i)
                        client_rect = display.GetClientArea()
                        # The window is considered visible if at least its top-left
                        # 100x50 px area falls inside the display's client area
                        if (client_rect.Contains(wx.Point(x + 100, y + 50)) or
                                client_rect.Contains(wx.Point(x, y))):
                            visible = True
                            break
                    if visible:
                        self.frame.SetPosition(wx.Point(x, y))
                    else:
                        # Off-screen: centre on primary display
                        self.frame.Centre()
                self.frame.SetSize(wx.Size(w, h))
            if maximized == '1':
                self.frame.Maximize(True)
        except Exception:
            pass

    def BindMyMenu(self):
        """Bind a menu item, by xrc name, to a handler"""

        def Bind(handler, xrcname):
            self.Bind(wx.EVT_MENU, handler, xrcname)

        Bind(self.OnCopyAsImage, 'exportToClipboardAsAVectorImage')
        Bind(self.OnExportAsSvg, 'exportAsSvg')
        Bind(self.OnExportAsEmf, 'exportAsEmf')
        Bind(self.OnExportAsPng, 'exportAsPng')
        Bind(self.OnExportAsHtml, 'exportAsHtml')
        Bind(self.OnExportAsTab, 'exportAsTab')
        Bind(self.OnExportAsPptx, 'exportAsPptx')
        Bind(self.OnExportAsPdf, 'exportAsPdf')
        Bind(self.OnSongbook, 'songbook')
        Bind(self.OnCanzonatore, 'canzonatore')
        Bind(self.OnPrint, 'print')
        Bind(self.OnPrintPreview, 'printPreview')
        Bind(self.OnPageSetup, 'pageSetup')
        Bind(self.OnUndo, 'undo')
        Bind(self.OnRedo, 'redo')
        Bind(self.OnCut, 'cut')
        Bind(self.OnCopy, 'copy')
        Bind(self.OnCopyAsImage, 'copyAsImage')
        Bind(self.OnCopyOnlyText, 'copyOnlyText')
        Bind(self.OnPaste, 'paste')
        Bind(self.OnPasteChords, 'pasteChords')
        Bind(self.OnPropagateVerseChords, 'propagateVerseChords')
        Bind(self.OnPropagateChorusChords, 'propagateChorusChords')
        Bind(self.OnFind, 'find')
        Bind(self.OnFindNext, 'findNext')
        Bind(self.OnFindPrevious, 'findPrevious')
        Bind(self.OnReplace, 'replace')
        Bind(self.OnSelectAll, 'selectAll')
        Bind(self.OnSelectNextChord, 'selectNextChord')
        Bind(self.OnSelectPreviousChord, 'selectPreviousChord')
        Bind(self.OnMoveChordRight, 'moveChordRight')
        Bind(self.OnMoveChordLeft, 'moveChordLeft')
        Bind(self.OnRemoveChords, 'removeChords')
        Bind(self.OnIntegrateChords, 'integrateChords')
        Bind(self.OnTitle, 'title')
        Bind(self.OnSubtitle, 'subtitle')
        Bind(self.OnChord, 'chord')
        Bind(self.OnChorus, 'chorus')
        Bind(self.OnVerse, 'verseWithCustomLabelOrWithoutLabel')
        Bind(self.OnComment, 'comment')
        Bind(self.OnFormatFont, 'songFont')
        Bind(self.OnTextFont, 'textFont')
        Bind(self.OnChordFont, 'chordFont')
        Bind(self.OnLabelVerses, 'labelVerses')
        Bind(self.OnChorusLabel, 'chorusLabel')
        Bind(self.OnNoChords, 'noChords')
        Bind(self.OnOneVerseForEachChordPattern, 'oneVerseForEachChordPattern')
        Bind(self.OnWholeSong, 'wholeSong')
        Bind(self.OnChordsAbove, 'chordsAbove')
        Bind(self.OnChordsBelow, 'chordsBelow')
        Bind(self.OnTogglePageBreakLines, 'showPageBreakLines')
        Bind(self.OnToggleColumnBreakLines, 'showColumnBreakLines')
        Bind(self.OnToggleDurationBeats, 'showDurationBeats')
        Bind(self.OnTranspose, 'transpose')
        Bind(self.OnSimplifyChords, 'simplifyChords')
        Bind(self.OnChangeChordNotation, 'changeChordNotation')
        Bind(self.OnNormalizeChords, 'cleanupChords')
        Bind(self.OnConvertTabToChordpro, 'convertTabToChordpro')
        Bind(self.OnRemoveSpuriousBlankLines, 'removeSpuriousBlankLines')
        Bind(self.OnOptions, 'options')
        Bind(self.OnGuide, 'guide')
        Bind(self.OnGuideMarkdown, 'guideMarkdown')
        Bind(self.OnGuideCommandsMarkdown, 'guideCommandsMarkdown')
        Bind(self.OnCheckDependencies, 'checkDependencies')
        # --- NUOVO: Normalizza spazi multipli ---
        Bind(self.OnNormalizeSpaces, 'normalizeSpaces')
        # --- NUOVO: Formato => Altro ---
        Bind(self.OnInsertLinespacing, 'insertLinespacing')
        Bind(self.OnInsertChordtopspacing, 'insertChordtopspacing')
        Bind(self.OnInsertPageBreak, 'insertPageBreak')
        Bind(self.OnInsertColumnBreak, 'insertColumnBreak')
        # --- NEW: Insert => Other (structured blocks) ---
        Bind(self.OnInsertVerse, 'insertVerse')
        Bind(self.OnInsertVerseNum, 'insertVerseNum')
        Bind(self.OnInsertChorusBlock, 'insertChorusBlock')
        Bind(self.OnInsertChordBlock, 'insertChordBlock')
        Bind(self.OnInsertBridge, 'insertBridge')
        Bind(self.OnInsertGrid, 'insertGrid')
        Bind(self.OnInsertTempo, 'insertTempo')
        Bind(self.OnInsertTempoLabel, 'insertTempoLabel')
        Bind(self.OnInsertTime, 'insertTime')
        Bind(self.OnInsertKey, 'insertKey')
        Bind(self.OnInsertBeatsTime, 'insertDuration')
        Bind(self.OnCopyAIBeatsPrompt, 'copyAIBeatsPrompt')
        Bind(self.OnInsertCapo, 'insertCapo')
        Bind(self.OnInsertArtist, 'insertArtist')
        Bind(self.OnInsertComposer, 'insertComposer')
        Bind(self.OnInsertAlbum, 'insertAlbum')
        Bind(self.OnInsertYear, 'insertYear')
        Bind(self.OnInsertCopyright, 'insertCopyright')
        # --- Insert => Chord keyboard (klavier) ---
        Bind(self.OnInsertKlavierChord, 'insertTaste')
        Bind(self.OnInsertDefine, 'insertDefine')
        Bind(self.OnInsertFingering, 'insertFingering')
        Bind(self.OnInsertImage, 'insertImage')
        Bind(self.OnInsertTransposerImage, 'insertTransposerImage')
        Bind(self.OnInsertMusicalSymbol, 'insertMusicalSymbol')
        # --- File => Importa da PDF ---
        Bind(self.OnImportFromPdf, 'importFromPdf')
        # --- Verifica sintattica ---
        Bind(self.OnSyntaxCheck, 'syntaxCheck')
        Bind(self.OnSongStatistics, 'songStatistics')
        self.frame.Bind(EVT_SYNTAX_GOTO, self.OnSyntaxGoto)
        # --- Riavvia applicazione ---
        Bind(self.OnRestart, 'restart')

    # ------------------------------------------------------------------
    # Template "Nuovo da template"
    # ------------------------------------------------------------------

    def _BuildNewFromTemplateMenu(self):
        """Popola dinamicamente il sottomenu 'Nuovo da template'
        con i file .crd trovati in templates/songs.

        Scansiona in modo difensivo due cartelle distinte:
          - glb.path/templates/songs/      (package, globale)
          - glb.data_path/templates/songs/ (dati utente, locale)
        Se una delle due non esiste viene ignorata silenziosamente.
        I file utente sovrascrivono omonimi globali (stessa logica
        di ListLocalGlobalDir, ma senza crash su cartella mancante).
        Viene chiamato una sola volta durante l'inizializzazione.
        """
        template_rel = os.path.join('templates', 'songs')
        search_roots = [glb.path]
        if getattr(glb, 'data_path', None):
            search_roots.append(glb.data_path)

        found = {}  # nome_base_lower -> percorso assoluto
        for root in search_roots:
            folder = os.path.join(root, template_rel)
            if not os.path.isdir(folder):
                continue
            try:
                for fname in sorted(os.listdir(folder)):
                    if fname.lower().endswith('.crd'):
                        key = os.path.splitext(fname)[0].lower()
                        found[key] = os.path.join(folder, fname)
            except OSError:
                pass

        # Ordina alfabeticamente per nome visualizzato
        template_paths = [found[k] for k in sorted(found)]

        # Recupera il sottomenu dall'XRC tramite XRCID — robusto rispetto alla lingua,
        # usa lo stesso meccanismo degli altri ID di menu nel codice.
        file_menu = self.menuBar.GetMenu(0)
        submenu = None
        nft_id = xrc.XRCID('newFromTemplate')
        menu_item = file_menu.FindItemById(nft_id)
        if menu_item is not None:
            submenu = menu_item.GetSubMenu()

        if submenu is None:
            # Sottomenu non trovato nell'XRC: niente da fare
            return

        # Svuota eventuali voci residue
        for old_item in submenu.GetMenuItems():
            submenu.Delete(old_item)

        self._template_paths = {}  # id voce di menu -> percorso assoluto

        if not template_paths:
            placeholder = submenu.Append(wx.ID_ANY, _("(no template available)"))
            submenu.Enable(placeholder.GetId(), False)
            return

        for path in template_paths:
            name = os.path.splitext(os.path.basename(path))[0]
            item = submenu.Append(wx.ID_ANY, name)
            self._template_paths[item.GetId()] = path
            self.frame.Bind(wx.EVT_MENU, self._OnNewFromTemplate, id=item.GetId())

    def _OnNewFromTemplate(self, evt):
        """Carica il template come nuovo documento non salvato.

        Il file template non viene mai modificato: il suo contenuto
        viene copiato in un nuovo documento 'senza nome' che l'utente
        dovrà salvare con 'Salva con nome'.
        """
        path = getattr(self, '_template_paths', {}).get(evt.GetId())
        if path is None or not os.path.isfile(path):
            wx.MessageBox(
                _("Template not found:\n%s") % (path or ''),
                _("Songpress++"),
                wx.OK | wx.ICON_ERROR,
                self.frame,
            )
            return

        # Se il documento corrente ha modifiche non salvate, chiede conferma
        # (usa AskSaveModified() di SDIMainFrame, identico a OnNew)
        if not self.AskSaveModified():
            return

        # Legge il contenuto del template
        try:
            with open(path, 'r', encoding='utf-8') as f:
                content = f.read()
        except Exception as exc:
            wx.MessageBox(
                str(exc),
                _("Error opening template"),
                wx.OK | wx.ICON_ERROR,
                self.frame,
            )
            return

        # Replica esattamente OnNew di SDIMainFrame, poi inserisce il template.
        # document='', modified=True → 'Salva' aprirà 'Salva con nome',
        # il file template originale non viene mai toccato.
        self.document = ''
        self.text.AutoChangeMode(True)
        self.text.New()
        self.text.SetText(content)
        self.text.AutoChangeMode(False)
        self.modified = True
        self.UpdateTitle()
        self.UpdateEverything()
        self.previewCanvas.Refresh(self._get_display_text())

    def OnNormalizeSpaces(self, evt):
        """
        Mostra un dialogo con opzioni di normalizzazione, poi applica
        le operazioni selezionate al testo corrente o alla selezione.
        """
        import re

        # ── Dialogo opzioni ──────────────────────────────────────────────
        dlg = wx.Dialog(
            self.frame,
            title=_(u"Normalize multiple spaces"),
            style=wx.DEFAULT_DIALOG_STYLE,
        )

        outer = wx.BoxSizer(wx.VERTICAL)

        # Checkbox opzioni
        opts_box = wx.StaticBoxSizer(
            wx.StaticBox(dlg, label=_(u"Operations to perform")), wx.VERTICAL
        )
        cb_spaces = wx.CheckBox(dlg, label=_(u"Normalize multiple spaces (replace 2+ spaces with one)"))
        cb_spaces.SetValue(True)

        cb_underscore = wx.CheckBox(dlg, label=_(u"Remove '_' characters from text"))
        cb_underscore.SetValue(False)

        cb_dash = wx.CheckBox(dlg, label=_(u"Remove '-' characters from text"))
        cb_dash.SetValue(False)

        cb_leading = wx.CheckBox(dlg, label=_(u"Remove leading whitespace from each line"))
        cb_leading.SetValue(False)

        opts_box.Add(cb_spaces,     0, wx.ALL, 6)
        opts_box.Add(cb_underscore, 0, wx.LEFT | wx.RIGHT | wx.BOTTOM, 6)
        opts_box.Add(cb_dash,       0, wx.LEFT | wx.RIGHT | wx.BOTTOM, 6)
        opts_box.Add(cb_leading,    0, wx.LEFT | wx.RIGHT | wx.BOTTOM, 6)

        outer.Add(opts_box, 0, wx.EXPAND | wx.ALL, 10)

        # Bottoni OK / Annulla
        btn_sizer = dlg.CreateButtonSizer(wx.OK | wx.CANCEL)
        outer.Add(btn_sizer, 0, wx.EXPAND | wx.LEFT | wx.RIGHT | wx.BOTTOM, 10)

        dlg.SetSizerAndFit(outer)
        dlg.CentreOnParent()

        if dlg.ShowModal() != wx.ID_OK:
            dlg.Destroy()
            return

        do_spaces     = cb_spaces.GetValue()
        do_underscore = cb_underscore.GetValue()
        do_dash       = cb_dash.GetValue()
        do_leading    = cb_leading.GetValue()
        dlg.Destroy()

        if not do_spaces and not do_underscore and not do_dash and not do_leading:
            return  # nulla da fare

        # ── Applica le operazioni ────────────────────────────────────────
        s, e = self.text.GetSelection()
        use_selection = (s != e)
        text = self.text.GetTextRange(s, e) if use_selection else self.text.GetText()

        new_text = text
        if do_spaces:
            new_text = re.sub(r' {2,}', ' ', new_text)
        if do_underscore:
            new_text = new_text.replace('_', '')
        if do_dash:
            new_text = new_text.replace('-', '')
        if do_leading:
            new_text = '\n'.join(line.lstrip() for line in new_text.split('\n'))

        if new_text == text:
            return  # nessuna modifica, evita undo inutile

        if use_selection:
            self.text.ReplaceSelection(new_text)
        else:
            self.text.SetText(new_text)

    def OnSyntaxCheck(self, evt):
        """Esegue la verifica sintattica ChordPro e mostra il dialogo con i risultati."""
        text = self.text.GetText()
        result = syntax_check(text)
        dlg = SyntaxCheckerDialog(self.frame, result)
        dlg.ShowModal()
        dlg.Destroy()

    # ------------------------------------------------------------------
    # Song statistics
    # ------------------------------------------------------------------

    def OnSongStatistics(self, evt):
        """Analizza il brano (o i brani separati da {title:}) e mostra un dialogo con
        statistiche e valutazione. Se il file contiene più direttive {title:}, le
        statistiche vengono calcolate per ogni sezione e mostrate in tab separate;
        la prima tab riporta i totali aggregati dell'intero file."""
        import re, math

        full_text = self.text.GetText()

        # ── Notazione accordi ─────────────────────────────────────────
        _notation = self.pref.notations[0] if self.pref.notations else None

        def _is_valid_chord(raw):
            if not raw.strip():
                return False
            if _notation is None:
                return True
            root, _ = splitChord(raw.strip(), _notation)
            return bool(root)

        def _chord_root(raw):
            c = raw.strip().split('/')[0].strip()
            if _notation is None:
                return c
            root, suffix = splitChord(c, _notation)
            return (root + suffix) if root else c

        hard_pat = re.compile(
            r'(?:7|9|11|13|dim|aug|sus|add|maj|°|\+)', re.IGNORECASE)

        # ── Funzione che calcola le statistiche di un blocco di testo ─
        def _compute_stats(text):
            """Restituisce un dizionario con tutte le statistiche del blocco."""

            def _meta(key):
                m = re.search(r'\{\s*' + key + r'\s*:\s*([^}]+)\}', text, re.IGNORECASE)
                return m.group(1).strip() if m else ''

            title   = _meta('title') or _meta('t')
            key     = _meta('key')
            tempo   = _meta('tempo') or _meta('tempo_s') or _meta('tempo_m')
            time_   = _meta('time')
            capo    = _meta('capo')
            artist  = _meta('artist')

            lines_all    = text.splitlines()
            lines_active = [l for l in lines_all
                            if l.strip() and not l.strip().startswith('#')
                            and not re.match(r'\s*\{[^}]+\}\s*$', l)]

            all_chords_raw = re.findall(r'\[([^\]]+)\]', text)
            all_chords     = [c.strip() for c in all_chords_raw
                              if c.strip() and _is_valid_chord(c)]
            unique_chords  = set(_chord_root(c) for c in all_chords)
            n_chords_total  = len(all_chords)
            n_chords_unique = len(unique_chords)

            n_verses = len(re.findall(
                r'\{\s*(?:start_of_verse|start_verse(?:_num)?|sov|verse)\b[^}]*\}',
                text, re.IGNORECASE))
            n_chorus = len(re.findall(
                r'\{\s*(?:start_of_chorus|start_chorus|soc|chorus)\b[^}]*\}',
                text, re.IGNORECASE))
            n_bridge = len(re.findall(
                r'\{\s*(?:start_of_bridge|start_bridge|sob|bridge)\b[^}]*\}',
                text, re.IGNORECASE))

            # Fallback: se non ci sono direttive {verse} esplicite, conta le strofe
            # implicite come blocchi di righe liriche separati da righe vuote,
            # escludendo le righe dentro blocchi chorus/bridge già riconosciuti.
            if n_verses == 0:
                _lyric_line = re.compile(r'(?:\[[^\]]*\]|[\w\u00C0-\u024F])')
                _sec_open  = re.compile(
                    r'\{\s*(?:start_of_chorus|start_chorus|soc|chorus'
                    r'|start_of_bridge|start_bridge|sob|bridge)\b[^}]*\}',
                    re.IGNORECASE)
                _sec_close = re.compile(
                    r'\{\s*(?:end_of_chorus|end_chorus|eoc'
                    r'|end_of_bridge|end_bridge|eob)\b[^}]*\}',
                    re.IGNORECASE)
                _implicit_blocks = 0
                _in_block   = False
                _in_section = False
                for _ln in lines_all:
                    _ls = _ln.strip()
                    if _sec_open.search(_ls):
                        _in_section = True
                        _in_block   = False
                        continue
                    if _sec_close.search(_ls):
                        _in_section = False
                        _in_block   = False
                        continue
                    if _in_section:
                        continue
                    if not _ls or _ls.startswith('#') or re.match(r'^\{[^}]+\}\s*$', _ls):
                        _in_block = False
                    elif _lyric_line.search(_ls):
                        if not _in_block:
                            _implicit_blocks += 1
                            _in_block = True
                n_verses = _implicit_blocks
            n_pages  = len(re.findall(
                r'\{\s*(?:new_page|np)\s*\}', text, re.IGNORECASE)) + 1

            text_no_chords = re.sub(r'\[[^\]]*\]', '', text)
            text_no_dir    = re.sub(r'\{[^}]*\}', '', text_no_chords)
            text_no_comm   = re.sub(r'^#.*$', '', text_no_dir, flags=re.MULTILINE)
            words  = re.findall(r"[\w'\u00C0-\u024F]+", text_no_comm)
            n_words = len(words)
            n_lines = len(lines_active)

            n_hard   = sum(1 for c in unique_chords if hard_pat.search(c))
            pct_hard = (n_hard / n_chords_unique * 100) if n_chords_unique else 0

            # Durata: esplicita {duration:} oppure stima automatica
            duration_str        = ''
            duration_is_explicit = False
            _dur_explicit = None
            for _line in lines_all:
                _ls = _line.strip()
                if _ls.startswith('#'):
                    continue
                _m = re.search(r'\{\s*duration\s*:\s*(\d{1,2}:\d{2})\s*\}',
                               _ls, re.IGNORECASE)
                if _m:
                    _dur_explicit = _m.group(1)
                    break
            if _dur_explicit:
                duration_str        = _dur_explicit
                duration_is_explicit = True
            else:
                try:
                    bpm   = int(re.search(r'\d+', tempo).group()) if tempo else 0
                    num_m = int(re.search(r'(\d+)/', time_).group(1)) if time_ else 0
                    if bpm > 0 and num_m > 0 and n_chords_total > 0:
                        secs = n_chords_total * num_m / bpm * 60
                        duration_str = '%d:%02d' % (int(secs) // 60, int(secs) % 60)
                except Exception:
                    pass

            # Valutazione
            score = 100
            if n_chords_unique > 12:
                score -= min(30, (n_chords_unique - 12) * 3)
            score -= int(pct_hard * 0.4)
            if n_verses + n_chorus > 8:
                score -= 10
            if n_chords_total == 0:
                score = 0
            score = max(0, min(100, score))

            if score >= 85:
                stars, verdict = '★★★★★', _('Excellent for beginners')
            elif score >= 70:
                stars, verdict = '★★★★☆', _('Accessible')
            elif score >= 50:
                stars, verdict = '★★★☆☆', _('Intermediate')
            elif score >= 30:
                stars, verdict = '★★☆☆☆', _('Advanced')
            else:
                stars, verdict = '★☆☆☆☆', _('Very difficult')

            return dict(
                title=title, key=key, tempo=tempo, time_=time_, capo=capo,
                artist=artist, n_verses=n_verses, n_chorus=n_chorus,
                n_bridge=n_bridge, n_pages=n_pages, n_lines=n_lines,
                n_words=n_words, n_chords_total=n_chords_total,
                n_chords_unique=n_chords_unique, n_hard=n_hard, pct_hard=pct_hard,
                duration_str=duration_str, duration_is_explicit=duration_is_explicit,
                score=score, stars=stars, verdict=verdict,
            )

        # ── Suddividi il file in blocchi per {title:} ─────────────────
        # Trova le posizioni di ogni direttiva {title:} o {t:} nel testo
        title_positions = [m.start() for m in re.finditer(
            r'\{\s*(?:title|t)\s*:[^}]*\}', full_text, re.IGNORECASE)]

        if len(title_positions) <= 1:
            # Nessuna suddivisione: comportamento originale (un solo blocco)
            sections = [_compute_stats(full_text)]
            multi = False
        else:
            # Più titoli: ogni sezione va dalla sua {title:} alla prossima
            blocks = []
            for i, pos in enumerate(title_positions):
                end = title_positions[i + 1] if i + 1 < len(title_positions) else len(full_text)
                blocks.append(full_text[pos:end])
            sections = [_compute_stats(b) for b in blocks]
            multi = True

        # ── Costanti colori ───────────────────────────────────────────
        BG      = wx.Colour(250, 250, 252)
        HDR     = wx.Colour(52, 101, 164)
        STAR_ON = wx.Colour(255, 180, 0)

        # ── Costruzione dialogo ───────────────────────────────────────
        dlg = wx.Dialog(
            self.frame,
            title=_('Song Statistics'),
            style=wx.DEFAULT_DIALOG_STYLE | wx.RESIZE_BORDER,
        )
        dlg.SetMinSize(wx.Size(420, 320))

        outer_panel = wx.Panel(dlg)
        outer_panel.SetBackgroundColour(BG)
        outer_sz = wx.BoxSizer(wx.VERTICAL)

        # ── Intestazione ──────────────────────────────────────────────
        hdr_panel = wx.Panel(outer_panel)
        hdr_panel.SetBackgroundColour(HDR)
        hdr_sz = wx.BoxSizer(wx.VERTICAL)

        if multi:
            # Mostra il numero di brani nel file
            header_title = _('%d songs in this file') % len(sections)
        else:
            s0 = sections[0]
            header_title = s0['title'] if s0['title'] else _('(untitled)')

        lbl_name = wx.StaticText(hdr_panel, label=header_title)
        f = lbl_name.GetFont()
        f.SetWeight(wx.FONTWEIGHT_BOLD)
        f.SetPointSize(f.GetPointSize() + 3)
        lbl_name.SetFont(f)
        lbl_name.SetForegroundColour(wx.WHITE)
        hdr_sz.Add(lbl_name, 0, wx.ALL, 10)

        if not multi and sections[0]['artist']:
            lbl_artist = wx.StaticText(hdr_panel, label=sections[0]['artist'])
            lbl_artist.SetForegroundColour(wx.Colour(200, 220, 255))
            hdr_sz.Add(lbl_artist, 0, wx.LEFT | wx.BOTTOM, 10)

        hdr_panel.SetSizer(hdr_sz)
        outer_sz.Add(hdr_panel, 0, wx.EXPAND)

        # ── Corpo: Notebook se multi, singolo scroll altrimenti ───────
        if multi:
            # Calcola i totali aggregati per la prima tab "Totale"
            def _aggregate(sections):
                agg = dict(
                    title=_('Total (%d songs)') % len(sections),
                    key='', tempo='', time_='', capo='', artist='',
                    n_verses  = sum(s['n_verses']        for s in sections),
                    n_chorus  = sum(s['n_chorus']        for s in sections),
                    n_bridge  = sum(s['n_bridge']        for s in sections),
                    n_pages   = sum(s['n_pages']         for s in sections),
                    n_lines   = sum(s['n_lines']         for s in sections),
                    n_words   = sum(s['n_words']         for s in sections),
                    n_chords_total  = sum(s['n_chords_total']  for s in sections),
                    n_chords_unique = 0,   # non aggregabile con semplice somma
                    n_hard   = 0,
                    pct_hard = 0.0,
                    duration_str='', duration_is_explicit=False,
                    score=0, stars='', verdict='',
                )
                # Accordi unici del file intero (unione)
                return agg

            agg = _aggregate(sections)
            all_tabs = [agg] + sections  # tab 0 = totale, tab 1..N = brani

            notebook = wx.Notebook(outer_panel, style=wx.NB_MULTILINE)
            notebook.SetBackgroundColour(BG)

            for tab_idx, st in enumerate(all_tabs):
                page = wx.ScrolledWindow(notebook, style=wx.VSCROLL | wx.HSCROLL | wx.BORDER_NONE)
                page.SetScrollRate(12, 12)
                page.SetBackgroundColour(BG)
                body = wx.BoxSizer(wx.VERTICAL)

                def _section(label, _body=body, _page=page):
                    lbl = wx.StaticText(_page, label=label)
                    f2 = lbl.GetFont()
                    f2.SetWeight(wx.FONTWEIGHT_BOLD)
                    f2.SetPointSize(f2.GetPointSize() + 1)
                    lbl.SetFont(f2)
                    lbl.SetForegroundColour(HDR)
                    _body.Add(lbl, 0, wx.LEFT | wx.TOP, 12)
                    _body.Add(wx.StaticLine(_page), 0,
                              wx.EXPAND | wx.LEFT | wx.RIGHT | wx.BOTTOM, 12)

                def _row(key, value, _body=body, _page=page):
                    hz = wx.BoxSizer(wx.HORIZONTAL)
                    k_lbl = wx.StaticText(_page, label=key)
                    v_lbl = wx.StaticText(_page, label=str(value))
                    fv = v_lbl.GetFont()
                    fv.SetWeight(wx.FONTWEIGHT_BOLD)
                    v_lbl.SetFont(fv)
                    hz.Add(k_lbl, 1, wx.ALIGN_CENTER_VERTICAL)
                    hz.Add(v_lbl, 0, wx.ALIGN_CENTER_VERTICAL)
                    _body.Add(hz, 0, wx.EXPAND | wx.LEFT | wx.RIGHT, 16)
                    _body.AddSpacer(3)

                is_total_tab = (tab_idx == 0)

                # Valutazione stelle (solo per i brani singoli, non il totale)
                if not is_total_tab and st['stars']:
                    eval_panel = wx.Panel(page)
                    eval_panel.SetBackgroundColour(wx.Colour(240, 245, 255))
                    eval_sz = wx.BoxSizer(wx.HORIZONTAL)
                    lbl_stars = wx.StaticText(eval_panel, label=st['stars'])
                    f_s = lbl_stars.GetFont()
                    f_s.SetPointSize(f_s.GetPointSize() + 6)
                    lbl_stars.SetFont(f_s)
                    lbl_stars.SetForegroundColour(STAR_ON)
                    lbl_verdict = wx.StaticText(eval_panel, label='  ' + st['verdict'])
                    f_v = lbl_verdict.GetFont()
                    f_v.SetWeight(wx.FONTWEIGHT_BOLD)
                    lbl_verdict.SetFont(f_v)
                    eval_sz.Add(lbl_stars,   0, wx.ALIGN_CENTER_VERTICAL | wx.LEFT, 12)
                    eval_sz.Add(lbl_verdict, 0, wx.ALIGN_CENTER_VERTICAL)
                    eval_panel.SetSizer(eval_sz)
                    body.Add(eval_panel, 0, wx.EXPAND | wx.TOP | wx.BOTTOM, 6)
                    gauge = wx.Gauge(page, range=100, size=(-1, 8))
                    gauge.SetValue(st['score'])
                    body.Add(gauge, 0, wx.EXPAND | wx.LEFT | wx.RIGHT, 12)
                    body.AddSpacer(10)

                # Titolo del singolo brano (dentro la tab)
                if not is_total_tab and st['title']:
                    lbl_t = wx.StaticText(page, label=st['title'])
                    f_t = lbl_t.GetFont()
                    f_t.SetWeight(wx.FONTWEIGHT_BOLD)
                    lbl_t.SetFont(f_t)
                    body.Add(lbl_t, 0, wx.LEFT | wx.TOP, 12)
                    if st['artist']:
                        lbl_ar = wx.StaticText(page, label=st['artist'])
                        lbl_ar.SetForegroundColour(wx.Colour(100, 100, 160))
                        body.Add(lbl_ar, 0, wx.LEFT | wx.BOTTOM, 4)
                    body.AddSpacer(4)

                _section(_('Structure'))
                _row(_('Verses'),          st['n_verses'] if st['n_verses'] else '—')
                _row(_('Choruses'),        st['n_chorus'] if st['n_chorus'] else '—')
                _row(_('Bridges'),         st['n_bridge'] if st['n_bridge'] else '—')
                if not is_total_tab:
                    _row(_('Estimated pages'), st['n_pages'])

                _section(_('Lyrics'))
                _row(_('Lyrics lines'), st['n_lines'])
                _row(_('Words'),        st['n_words'])

                _section(_('Chords'))
                _row(_('Total chords'), st['n_chords_total'])
                if not is_total_tab:
                    _row(_('Unique chords'), st['n_chords_unique'])
                    _row(_('Of which complex'),
                         '%d  (%.0f%%)' % (st['n_hard'], st['pct_hard'])
                         if st['n_chords_unique'] else '—')

                if not is_total_tab:
                    _section(_('Metadata'))
                    if st['key']:    _row(_('Key'),           st['key'])
                    if st['tempo']:  _row(_('Tempo'),         st['tempo'] + ' BPM')
                    if st['time_']:  _row(_('Time signature'), st['time_'])
                    if st['capo']:   _row(_('Capo'),          st['capo'])
                    if st['duration_str']:
                        label = _('Duration') if st['duration_is_explicit'] \
                                else _('Estimated duration')
                        _row(label, st['duration_str'])
                    if not any([st['key'], st['tempo'], st['time_'], st['capo']]):
                        body.Add(wx.StaticText(page,
                            label=_('  (no musical metadata found)')),
                            0, wx.LEFT | wx.BOTTOM, 16)

                body.AddSpacer(10)
                page.SetSizer(body)
                body.FitInside(page)

                # Etichetta della tab: "Totale" oppure numero + titolo troncato
                if is_total_tab:
                    tab_label = _('Total')
                else:
                    short = st['title'] if st['title'] else _('(untitled)')
                    if len(short) > 18:
                        short = short[:16] + '…'
                    tab_label = '%d. %s' % (tab_idx, short)

                notebook.AddPage(page, tab_label)

            outer_sz.Add(notebook, 1, wx.EXPAND | wx.ALL, 4)

        else:
            # ── Singolo brano: layout originale con ScrolledWindow ────
            st = sections[0]
            scroll = wx.ScrolledWindow(outer_panel, style=wx.VSCROLL | wx.BORDER_NONE)
            scroll.SetScrollRate(0, 12)
            scroll.SetBackgroundColour(BG)
            body = wx.BoxSizer(wx.VERTICAL)

            def _section(label):
                lbl = wx.StaticText(scroll, label=label)
                f2 = lbl.GetFont()
                f2.SetWeight(wx.FONTWEIGHT_BOLD)
                f2.SetPointSize(f2.GetPointSize() + 1)
                lbl.SetFont(f2)
                lbl.SetForegroundColour(HDR)
                body.Add(lbl, 0, wx.LEFT | wx.TOP, 12)
                body.Add(wx.StaticLine(scroll), 0,
                         wx.EXPAND | wx.LEFT | wx.RIGHT | wx.BOTTOM, 12)

            def _row(key, value):
                hz = wx.BoxSizer(wx.HORIZONTAL)
                k_lbl = wx.StaticText(scroll, label=key)
                v_lbl = wx.StaticText(scroll, label=str(value))
                fv = v_lbl.GetFont()
                fv.SetWeight(wx.FONTWEIGHT_BOLD)
                v_lbl.SetFont(fv)
                hz.Add(k_lbl, 1, wx.ALIGN_CENTER_VERTICAL)
                hz.Add(v_lbl, 0, wx.ALIGN_CENTER_VERTICAL)
                body.Add(hz, 0, wx.EXPAND | wx.LEFT | wx.RIGHT, 16)
                body.AddSpacer(3)

            # Valutazione
            eval_panel = wx.Panel(scroll)
            eval_panel.SetBackgroundColour(wx.Colour(240, 245, 255))
            eval_sz = wx.BoxSizer(wx.HORIZONTAL)
            lbl_stars = wx.StaticText(eval_panel, label=st['stars'])
            f_s = lbl_stars.GetFont()
            f_s.SetPointSize(f_s.GetPointSize() + 6)
            lbl_stars.SetFont(f_s)
            lbl_stars.SetForegroundColour(STAR_ON)
            lbl_verdict = wx.StaticText(eval_panel, label='  ' + st['verdict'])
            f_v = lbl_verdict.GetFont()
            f_v.SetWeight(wx.FONTWEIGHT_BOLD)
            lbl_verdict.SetFont(f_v)
            eval_sz.Add(lbl_stars,   0, wx.ALIGN_CENTER_VERTICAL | wx.LEFT, 12)
            eval_sz.Add(lbl_verdict, 0, wx.ALIGN_CENTER_VERTICAL)
            eval_panel.SetSizer(eval_sz)
            body.Add(eval_panel, 0, wx.EXPAND | wx.TOP | wx.BOTTOM, 6)

            gauge = wx.Gauge(scroll, range=100, size=(-1, 8))
            gauge.SetValue(st['score'])
            body.Add(gauge, 0, wx.EXPAND | wx.LEFT | wx.RIGHT, 12)
            body.AddSpacer(10)

            _section(_('Structure'))
            _row(_('Verses'),          st['n_verses'] if st['n_verses'] else '—')
            _row(_('Choruses'),        st['n_chorus'] if st['n_chorus'] else '—')
            _row(_('Bridges'),         st['n_bridge'] if st['n_bridge'] else '—')
            _row(_('Estimated pages'), st['n_pages'])

            _section(_('Lyrics'))
            _row(_('Lyrics lines'), st['n_lines'])
            _row(_('Words'),        st['n_words'])

            _section(_('Chords'))
            _row(_('Total chords'),   st['n_chords_total'])
            _row(_('Unique chords'),  st['n_chords_unique'])
            _row(_('Of which complex'),
                 '%d  (%.0f%%)' % (st['n_hard'], st['pct_hard'])
                 if st['n_chords_unique'] else '—')

            _section(_('Metadata'))
            if st['key']:    _row(_('Key'),            st['key'])
            if st['tempo']:  _row(_('Tempo'),          st['tempo'] + ' BPM')
            if st['time_']:  _row(_('Time signature'), st['time_'])
            if st['capo']:   _row(_('Capo'),           st['capo'])
            if st['duration_str']:
                label = _('Duration') if st['duration_is_explicit'] \
                        else _('Estimated duration')
                _row(label, st['duration_str'])
            if not any([st['key'], st['tempo'], st['time_'], st['capo']]):
                body.Add(wx.StaticText(scroll,
                    label=_('  (no musical metadata found)')),
                    0, wx.LEFT | wx.BOTTOM, 16)

            body.AddSpacer(10)
            scroll.SetSizer(body)
            body.FitInside(scroll)
            outer_sz.Add(scroll, 1, wx.EXPAND)

        # ── Fondo: pulsante Espandi + OK (solo per singolo brano) ─────
        btn_expand = wx.Button(outer_panel, label=_('Show all ▼')) if not multi else None
        btn = wx.Button(outer_panel, wx.ID_OK, 'OK')
        btn.SetDefault()

        bottom_sz = wx.BoxSizer(wx.HORIZONTAL)
        if btn_expand:
            bottom_sz.Add(btn_expand, 0,
                          wx.ALIGN_CENTER_VERTICAL | wx.LEFT | wx.TOP | wx.BOTTOM, 12)
        bottom_sz.AddStretchSpacer(1)
        bottom_sz.Add(btn, 0,
                      wx.ALIGN_CENTER_VERTICAL | wx.RIGHT | wx.TOP | wx.BOTTOM, 12)
        outer_sz.Add(bottom_sz, 0, wx.EXPAND)

        outer_panel.SetSizer(outer_sz)
        dlg_sz = wx.BoxSizer(wx.VERTICAL)
        dlg_sz.Add(outer_panel, 1, wx.EXPAND)
        dlg.SetSizer(dlg_sz)

        # ── Altezza ideale ────────────────────────────────────────────
        dlg.Fit()
        dlg.Layout()
        screen_h = wx.Display().GetClientArea().GetHeight()
        max_h    = int(screen_h * 0.90)

        if not multi:
            body_min_h = body.GetMinSize().GetHeight()
            fixed_h    = (dlg.GetSize().GetHeight()
                          - scroll.GetSize().GetHeight()
                          + body_min_h)
            ideal_h  = fixed_h
            final_h  = min(ideal_h, max_h)
            dlg.SetSize(wx.Size(dlg.GetSize().GetWidth(), final_h))
            dlg.SetMinSize(wx.Size(400, 300))

            _needs_expand = (ideal_h > max_h)
            if not _needs_expand:
                btn_expand.Hide()

            _expanded = [False]

            def _on_expand(evt):
                if not _expanded[0]:
                    max_full = int(screen_h * 0.95)
                    full_h   = min(ideal_h, max_full)
                    dlg.SetSize(wx.Size(dlg.GetSize().GetWidth(), full_h))
                    scroll.SetScrollRate(0, 0)
                    scroll.FitInside()
                    btn_expand.SetLabel(_('Collapse ▲'))
                    _expanded[0] = True
                else:
                    dlg.SetSize(wx.Size(dlg.GetSize().GetWidth(), final_h))
                    scroll.SetScrollRate(0, 12)
                    body.FitInside(scroll)
                    btn_expand.SetLabel(_('Show all ▼'))
                    _expanded[0] = False
                dlg.Layout()

            btn_expand.Bind(wx.EVT_BUTTON, _on_expand)
        else:
            # Per il notebook multi-brano usa un'altezza fissa ragionevole
            ideal_h = min(int(screen_h * 0.80), 600)
            dlg.SetSize(wx.Size(460, ideal_h))
            dlg.SetMinSize(wx.Size(420, 320))

        dlg.ShowModal()
        dlg.Destroy()

    def OnSyntaxGoto(self, evt):
        """Sposta il cursore alla riga/colonna dell'errore selezionato nel dialogo."""
        text = self.text.GetText()
        lines = text.splitlines(keepends=True)
        target_line = evt.line - 1    # 0-based
        target_col  = evt.column - 1  # 0-based
        pos = sum(len(l) for l in lines[:target_line]) + target_col
        pos = max(0, min(pos, len(text)))
        self.text.SetInsertionPoint(pos)
        self.text.SetFocus()

    def OnInsertLinespacing(self, evt):
        """Inserisce la direttiva {linespacing: <valore>}."""
        msg = _("Enter the line spacing value (e.g. 0 to remove extra space):")
        d = wx.NumberEntryDialog(self.frame, msg, _("Value:"), _("Line spacing"), 13, 0, 100)
        if d.ShowModal() == wx.ID_OK:
            val = d.GetValue()
            self.InsertWithCaret("{linespacing: %s}" % val) #modifica qui con x_linespacing

    def OnInsertChordtopspacing(self, evt):
        """Inserisce la direttiva {chordtopspacing: <valore>}."""
        msg = _("Enter the space above chords value (e.g. 0 to remove extra space):")
        d = wx.NumberEntryDialog(self.frame, msg, _("Value:"), _("Space above chords"), 0, 0, 100)
        if d.ShowModal() == wx.ID_OK:
            val = d.GetValue()
            self.InsertWithCaret("{chordtopspacing: %s}" % val)

    def OnInsertVerse(self, evt):
        """Inserisce una strofa non numerata: {start_verse} ... {end_verse}"""
        self.InsertWithCaret("{start_verse}\n|\n{end_verse}\n")

    def OnInsertVerseNum(self, evt):
        """Inserisce una strofa numerata: {start_verse_num} ... {end_verse_num}"""
        self.InsertWithCaret("{start_verse_num}\n|\n{end_verse_num}\n")

    def OnInsertChorusBlock(self, evt):
        """Insert a chorus block: {start_chorus} ... {end_chorus}"""
        default = self.pref.decoratorFormat.GetChorusLabel()
        label = wx.GetTextFromUser(
            _("Enter a label for the chorus, or press Cancel to omit the label."),
            _("Chorus label"),
            default,
            self.frame,
        )
        if label == default or not label.strip():
            self.InsertWithCaret("{start_chorus}\n|\n{end_chorus}\n")
        else:
            self.InsertWithCaret("{start_chorus:%s}\n|\n{end_chorus}\n" % label)

    def OnInsertChordBlock(self, evt):
        """Insert an intro chord block: {start_chord} ... {end_chord}"""
        default = _("Intro")
        label = wx.GetTextFromUser(
            _("Enter a label for the intro chords, or press Cancel to use '%s'.") % default,
            _("Intro chords label"),
            default,
            self.frame,
        )
        if label.strip():
            self.InsertWithCaret("{start_chord:%s}\n|\n{end_chord}\n" % label)
        else:
            self.InsertWithCaret("{start_chord}\n|\n{end_chord}\n")

    def OnInsertBridge(self, evt):
        """Insert a bridge block: {start_bridge} ... {end_bridge}"""
        default = _("Bridge")
        label = wx.GetTextFromUser(
            _("Enter a label for the bridge, or press Cancel to use '%s'.") % default,
            _("Bridge label"),
            default,
            self.frame,
        )
        if label.strip():
            self.InsertWithCaret("{start_bridge:%s}\n|\n{end_bridge}\n" % label)
        else:
            self.InsertWithCaret("{start_bridge}\n|\n{end_bridge}\n")

    def OnInsertGrid(self, evt):
        """Insert a grid block: {start_of_grid} ... {end_of_grid}"""
        default = getattr(self.pref, 'gridDefaultLabel', _("Grid"))
        label = wx.GetTextFromUser(
            _("Enter a label for the grid, or press Cancel to omit the label."),
            _("Grid label"),
            default,
            self.frame,
        )
        if label == default or not label.strip():
            block = "{start_of_grid}\n| | | |\n{end_of_grid}\n"
        else:
            block = "{start_of_grid:%s}\n| | | |\n{end_of_grid}\n" % label
        # Inserisce il blocco e posiziona il cursore dentro la prima cella (dopo "| ")
        self.StripSelection()
        s, _e = self.text.GetSelection()
        self.text.ReplaceSelection(block)
        # La prima riga è "{start_of_grid...}\n", la seconda inizia con "| "
        # Il cursore deve stare dopo "| " (2 caratteri) dentro la prima cella
        header = block[:block.index('\n') + 1]   # es. "{start_of_grid}\n"
        caret = s + len(header) + 2              # dopo "| " della riga griglia
        self.text.SetSelection(caret, caret)

    def OnInsertTime(self, evt):
        """Inserisce la direttiva {time: <numeratore>/<denominatore>}."""
        d = wx.Dialog(self.frame, title=_("Time signature"))
        vbox = wx.BoxSizer(wx.VERTICAL)

        vbox.Add(wx.StaticText(d, -1, _("Enter the time signature (e.g. 4/4, 3/4, 6/8):")), 0, wx.ALL, 8)
        txt = wx.TextCtrl(d, -1, "4/4")
        vbox.Add(txt, 0, wx.EXPAND | wx.LEFT | wx.RIGHT, 8)

        cb_meta = wx.CheckBox(d, -1, _("Metadata"))
        vbox.Add(cb_meta, 0, wx.LEFT | wx.TOP | wx.BOTTOM, 8)

        is_meta = not getattr(self.pref, 'timeDisplay', True)
        cb_meta.SetValue(is_meta)
        txt.Enable(not is_meta)

        def on_meta(e):
            txt.Enable(not cb_meta.GetValue())
        cb_meta.Bind(wx.EVT_CHECKBOX, on_meta)

        btn_sizer = d.CreateButtonSizer(wx.OK | wx.CANCEL)
        vbox.Add(btn_sizer, 0, wx.ALL | wx.ALIGN_RIGHT, 8)
        d.SetSizer(vbox)
        vbox.Fit(d)

        if d.ShowModal() == wx.ID_OK:
            self.pref.timeDisplay = not cb_meta.GetValue()
            self.previewCanvas.SetTimeDisplay(self.pref.timeDisplay)
            val = txt.GetValue().strip()
            if val:
                self.InsertWithCaret("{time:%s}" % val)
            else:
                self.InsertWithCaret("{time:|}")
            self.previewCanvas.Refresh(self._get_display_text())
        d.Destroy()

    def OnInsertTempo(self, evt):
        """Inserisce la direttiva {tempo: <valore>}."""
        d = wx.Dialog(self.frame, title=_("Tempo"))
        vbox = wx.BoxSizer(wx.VERTICAL)

        vbox.Add(wx.StaticText(d, -1, _("Enter the song tempo (e.g. 120):")), 0, wx.ALL, 8)
        txt = wx.TextCtrl(d, -1, "")
        vbox.Add(txt, 0, wx.EXPAND | wx.LEFT | wx.RIGHT, 8)

        vbox.Add(wx.StaticText(d, -1, _("Display as:")), 0, wx.LEFT | wx.TOP, 8)

        _icon_sz = getattr(self.pref, 'tempoIconSize', 24)
        _note_img = wx.Image(glb.AddPath("img/tempo_note.png"))
        _note_img = _note_img.Scale(_icon_sz, _icon_sz, wx.IMAGE_QUALITY_HIGH)
        note_bmp = wx.Bitmap(_note_img)
        _metro_img = wx.Image(glb.AddPath("img/metronomeWindows.png"))
        _metro_img = _metro_img.Scale(_icon_sz, _icon_sz, wx.IMAGE_QUALITY_HIGH)
        metro_bmp = wx.Bitmap(_metro_img)

        # ── Griglia 2×2 dentro un StaticBox ────────────────────────────
        rb_box = wx.StaticBoxSizer(wx.StaticBox(d), wx.VERTICAL)
        grid = wx.FlexGridSizer(rows=2, cols=2, vgap=6, hgap=20)
        grid.AddGrowableCol(0, 1)
        grid.AddGrowableCol(1, 1)

        # Cella (0,0): Testo "Tempo: "
        rb_none = wx.RadioButton(d, -1, _("Tempo:"), style=wx.RB_GROUP)
        cell_none = wx.BoxSizer(wx.HORIZONTAL)
        cell_none.Add(rb_none, 0, wx.ALIGN_CENTER_VERTICAL)
        grid.Add(cell_none, 0, wx.ALIGN_CENTER_VERTICAL)

        # Cella (0,1): BPM
        rb_bpm = wx.RadioButton(d, -1, "BPM")
        cell_bpm = wx.BoxSizer(wx.HORIZONTAL)
        cell_bpm.Add(rb_bpm, 0, wx.ALIGN_CENTER_VERTICAL)
        grid.Add(cell_bpm, 0, wx.ALIGN_CENTER_VERTICAL)

        # Cella (1,0): Nota musicale (♩)
        rb_note = wx.RadioButton(d, -1, "")
        note_icon = wx.StaticBitmap(d, -1, note_bmp)
        note_icon.Bind(wx.EVT_LEFT_DOWN, lambda e: rb_note.SetValue(True))
        cell_note = wx.BoxSizer(wx.HORIZONTAL)
        cell_note.Add(rb_note,   0, wx.ALIGN_CENTER_VERTICAL | wx.RIGHT, 4)
        cell_note.Add(note_icon, 0, wx.ALIGN_CENTER_VERTICAL)
        grid.Add(cell_note, 0, wx.ALIGN_CENTER_VERTICAL)

        # Cella (1,1): Metronomo
        rb_metro = wx.RadioButton(d, -1, "")
        metro_icon = wx.StaticBitmap(d, -1, metro_bmp)
        metro_icon.Bind(wx.EVT_LEFT_DOWN, lambda e: rb_metro.SetValue(True))
        cell_metro = wx.BoxSizer(wx.HORIZONTAL)
        cell_metro.Add(rb_metro,   0, wx.ALIGN_CENTER_VERTICAL | wx.RIGHT, 4)
        cell_metro.Add(metro_icon, 0, wx.ALIGN_CENTER_VERTICAL)
        grid.Add(cell_metro, 0, wx.ALIGN_CENTER_VERTICAL)

        rb_box.Add(grid, 0, wx.ALL, 8)
        vbox.Add(rb_box, 0, wx.EXPAND | wx.LEFT | wx.RIGHT | wx.TOP, 8)

        cb_meta = wx.CheckBox(d, -1, _("Metadata"))
        vbox.Add(cb_meta, 0, wx.LEFT | wx.TOP | wx.BOTTOM, 8)

        td = getattr(self.pref, 'tempoDisplay', 0)
        is_meta = (td == -1)
        cb_meta.SetValue(is_meta)
        rb_none.SetValue(td == 0)
        rb_note.SetValue(td == 1)
        rb_bpm.SetValue(td == 2)
        rb_metro.SetValue(td == 3)
        for ctrl in (rb_none, rb_note, rb_bpm, note_icon, rb_metro, metro_icon):
            ctrl.Enable(not is_meta)

        def on_meta(e):
            enabled = not cb_meta.GetValue()
            for ctrl in (rb_none, rb_note, rb_bpm, note_icon, rb_metro, metro_icon):
                ctrl.Enable(enabled)
        cb_meta.Bind(wx.EVT_CHECKBOX, on_meta)

        btn_sizer = d.CreateButtonSizer(wx.OK | wx.CANCEL)
        vbox.Add(btn_sizer, 0, wx.ALL | wx.ALIGN_RIGHT, 8)
        d.SetSizer(vbox)
        vbox.Fit(d)

        if d.ShowModal() == wx.ID_OK:
            val = txt.GetValue().strip()
            if cb_meta.GetValue():
                self.pref.tempoDisplay = -1
            elif rb_note.GetValue():
                self.pref.tempoDisplay = 1
            elif rb_bpm.GetValue():
                self.pref.tempoDisplay = 2
            elif rb_metro.GetValue():
                self.pref.tempoDisplay = 3
            else:
                self.pref.tempoDisplay = 0
            self.previewCanvas.SetTempoDisplay(self.pref.tempoDisplay)
            self.previewCanvas.SetTempoIconSize(getattr(self.pref, 'tempoIconSize', 24))
            self._SaveTempoDisplay()
            if val:
                self.InsertWithCaret("{tempo:%s}" % val)
            else:
                self.InsertWithCaret("{tempo:|}")
            self.previewCanvas.Refresh(self._get_display_text())
        d.Destroy()

    def OnInsertTempoLabel(self, evt):
        """Inserisce la direttiva {tempo_label: <indicazione agogica>}."""

        # Indicazioni agogiche standard, dalla più lenta alla più veloce
        _AGOGIC_LABELS = [
            "Grave",
            "Largo",
            "Larghetto",
            "Lento",
            "Adagio",
            "Adagietto",
            "Andante",
            "Andantino",
            "Moderato",
            "Allegretto",
            "Allegro",
            "Vivace",
            "Presto",
            "Prestissimo",
        ]

        d = wx.Dialog(self.frame, title=_("Tempo marking"))
        vbox = wx.BoxSizer(wx.VERTICAL)

        vbox.Add(
            wx.StaticText(d, -1, _("Select or type a tempo marking:")),
            0, wx.ALL, 8
        )

        combo = wx.ComboBox(
            d, -1,
            value="",
            choices=_AGOGIC_LABELS,
            style=wx.CB_DROPDOWN
        )
        vbox.Add(combo, 0, wx.EXPAND | wx.LEFT | wx.RIGHT, 8)

        vbox.Add(
            wx.StaticText(
                d, -1,
                _("You can also type a custom expression (e.g. \"Allegretto moderato\").")
            ),
            0, wx.LEFT | wx.RIGHT | wx.TOP, 8
        )

        btn_sizer = d.CreateButtonSizer(wx.OK | wx.CANCEL)
        vbox.Add(btn_sizer, 0, wx.ALL | wx.ALIGN_RIGHT, 8)
        d.SetSizer(vbox)
        vbox.Fit(d)
        combo.SetFocus()

        if d.ShowModal() == wx.ID_OK:
            val = combo.GetValue().strip()
            if val:
                self.InsertWithCaret("{tempo_label:%s}" % val)
            else:
                self.InsertWithCaret("{tempo_label:|}")
            self.previewCanvas.Refresh(self._get_display_text())
        d.Destroy()

    def OnInsertKey(self, evt):
        """Inserisce la direttiva {key: <tonalità>}."""
        d = wx.Dialog(self.frame, title=_(u"Key"))
        vbox = wx.BoxSizer(wx.VERTICAL)

        vbox.Add(wx.StaticText(d, -1, _(u"Enter the song key (e.g. Am, C, G, F#m):")), 0, wx.ALL, 8)
        txt = wx.TextCtrl(d, -1, u"")
        vbox.Add(txt, 0, wx.EXPAND | wx.LEFT | wx.RIGHT, 8)

        # --- Rileva automaticamente ---
        cb_detect = wx.CheckBox(d, -1, _(u"Detect automatically from chords"))
        cb_detect.SetToolTip(_(
            u"Analyses the chords in the song (text between [ ]) "
            u"and fills in the most likely key automatically."))
        vbox.Add(cb_detect, 0, wx.LEFT | wx.TOP, 8)
        lbl_detect = wx.StaticText(d, -1, u"")
        lbl_detect.SetForegroundColour(wx.Colour(0, 100, 0))
        vbox.Add(lbl_detect, 0, wx.LEFT | wx.BOTTOM, 8)

        cb_meta = wx.CheckBox(d, -1, _("Metadata"))
        vbox.Add(cb_meta, 0, wx.LEFT | wx.TOP | wx.BOTTOM, 8)

        is_meta = not getattr(self.pref, 'keyDisplay', True)
        cb_meta.SetValue(is_meta)
        txt.Enable(not is_meta)

        def _do_detect():
            """Rileva la tonalità dagli accordi del brano corrente.

            Usa solo il testo dal cursore fino al prossimo {new_song} (o fine
            documento), in modo da non inglobare accordi di brani precedenti o
            successivi quando il file contiene più canzoni concatenate.
            """
            try:
                full = self.text.GetText()
                cur  = self.text.GetCurrentPos()
                # Testo dal cursore in poi
                t_from_cursor = full[cur:]
                # Tronca al prossimo {new_song} se presente
                import re as _re
                m = _re.search(r'\{new_song\}', t_from_cursor, _re.IGNORECASE)
                t = t_from_cursor[:m.start()] if m else t_from_cursor
                notation = autodetectNotation(t, self.pref.notations)
                count, detected_key, dc, easiest_key, de = findEasiestKey(
                    t, self.pref.GetEasyChords(), notation)
                if count > 0 and detected_key:
                    # Converti nella notazione preferita dall'utente
                    key_str = translateChord(detected_key, notation, notation)
                    txt.SetValue(key_str)
                    lbl_detect.SetLabel(
                        _(u"✔ Detected: %s (from %d chords)") % (key_str, count))
                    lbl_detect.SetForegroundColour(wx.Colour(0, 120, 0))
                else:
                    txt.SetValue(u"")
                    lbl_detect.SetLabel(_(u"⚠ No chords found in the document"))
                    lbl_detect.SetForegroundColour(wx.Colour(180, 80, 0))
            except Exception:
                lbl_detect.SetLabel(_(u"⚠ Detection failed"))
                lbl_detect.SetForegroundColour(wx.Colour(180, 0, 0))
            d.Layout()
            d.Fit()

        def on_detect(e):
            if cb_detect.GetValue():
                txt.Enable(False)
                _do_detect()
            else:
                lbl_detect.SetLabel(u"")
                txt.SetValue(u"")
                txt.Enable(not cb_meta.GetValue())
                d.Layout()
                d.Fit()

        def on_meta(e):
            if not cb_detect.GetValue():
                txt.Enable(not cb_meta.GetValue())

        cb_detect.Bind(wx.EVT_CHECKBOX, on_detect)
        cb_meta.Bind(wx.EVT_CHECKBOX, on_meta)

        btn_sizer = d.CreateButtonSizer(wx.OK | wx.CANCEL)
        vbox.Add(btn_sizer, 0, wx.ALL | wx.ALIGN_RIGHT, 8)
        d.SetSizer(vbox)
        vbox.Fit(d)

        if d.ShowModal() == wx.ID_OK:
            self.pref.keyDisplay = not cb_meta.GetValue()
            self.previewCanvas.SetKeyDisplay(self.pref.keyDisplay)
            val = txt.GetValue().strip()
            if val:
                self.InsertWithCaret(u"{key:%s}" % val)
            else:
                self.InsertWithCaret(u"{key:|}")
            self.previewCanvas.Refresh(self._get_display_text())
        d.Destroy()

    def _InsertSimpleDirective(self, directive, label, example):
        """Helper generico: chiede un testo e inserisce {directive:testo}."""
        d = wx.TextEntryDialog(self.frame, label, directive, example)
        if d.ShowModal() == wx.ID_OK:
            val = d.GetValue().strip()
            if val:
                self.InsertWithCaret(u"{%s:%s}" % (directive, val))
            else:
                self.InsertWithCaret(u"{%s:|}" % directive)
        d.Destroy()

    def OnInsertCapo(self, evt):
        """Inserisce la direttiva {capo: <n>}."""
        self._InsertSimpleDirective('capo', _(u"Enter the capo fret number (e.g. 2, 3):"), u"2")

    def OnInsertArtist(self, evt):
        """Inserisce la direttiva {artist: <nome>}."""
        self._InsertSimpleDirective('artist', _(u"Enter the artist / performer name:"), u"")

    def OnInsertComposer(self, evt):
        """Inserisce la direttiva {composer: <nome>}."""
        self._InsertSimpleDirective('composer', _(u"Enter the composer name:"), u"")

    def OnInsertAlbum(self, evt):
        """Inserisce la direttiva {album: <titolo>}."""
        self._InsertSimpleDirective('album', _(u"Enter the album title:"), u"")

    def OnInsertYear(self, evt):
        """Inserisce la direttiva {year: <anno>}."""
        self._InsertSimpleDirective('year', _(u"Enter the year (e.g. 1975):"), u"")

    def OnInsertBeatsTime(self, evt):
        """Inserisce la direttiva {beats_time: }.

        Supporta cursore singolo, multicursore (Alt+Clic, Ctrl+D) e
        selezione di testo su una o più righe.

        Modalità selezione (start != end su almeno una selezione):
          - Raccoglie tutti gli accordi unici dalle righe coperte dalla selezione
            (ordine di prima apparizione nel testo).
          - Al click OK inserisce {beats_time} prima di OGNI riga con accordi
            nell'intervallo selezionato (come _do_insert_song ma limitato alla
            selezione), usando i valori degli SpinCtrl.

        Modalità cursore (selezioni puntiformi):
          - Comportamento originale: cerca la riga accordi vicina a ogni cursore.
        """
        import re

        stc         = self.text
        total_lines = stc.GetLineCount()
        n_sel       = stc.GetSelections()   # numero di cursori/selezioni attivi

        def _extract_roots(line_text):
            raw = re.findall(r'\[([^\]]+)\]', line_text)
            return [c.strip() for c in raw if c.strip()]

        # ── Rileva se almeno una selezione è estesa (non puntiforme) ──────
        _sel_ranges = [(stc.GetSelectionNStart(i), stc.GetSelectionNEnd(i))
                       for i in range(n_sel)]
        _has_range_sel = any(s != e for s, e in _sel_ranges)

        # ════════════════════════════════════════════════════════════════
        # MODALITÀ SELEZIONE: raccoglie tutti gli accordi nelle righe
        # coperte dalle selezioni estese
        # ════════════════════════════════════════════════════════════════
        if _has_range_sel:
            # Raccoglie gli indici di riga coperti da ogni selezione estesa
            _selected_line_indices = []
            for s, e in _sel_ranges:
                if s == e:
                    continue
                l_start = stc.LineFromPosition(s)
                l_end   = stc.LineFromPosition(e)
                # Se la fine della selezione è esattamente all'inizio di una riga,
                # non include quella riga (il cursore è fermo all'inizio)
                if stc.PositionFromLine(l_end) == e and l_end > l_start:
                    l_end -= 1
                for ln in range(l_start, l_end + 1):
                    if ln not in _selected_line_indices:
                        _selected_line_indices.append(ln)
            _selected_line_indices.sort()

            # Raccoglie accordi unici (ordine di prima apparizione) dalle righe selezionate
            _seen_roots = []
            for ln in _selected_line_indices:
                for r in _extract_roots(stc.GetLine(ln)):
                    if r not in _seen_roots:
                        _seen_roots.append(r)
            all_roots = _seen_roots

            # Costruisce per ogni riga selezionata la lista di roots propria
            # (usata da _do_insert per applicare per-riga nella modalità selezione)
            _sel_line_roots = {}
            for ln in _selected_line_indices:
                roots = _extract_roots(stc.GetLine(ln))
                if roots:
                    _sel_line_roots[ln] = roots

            per_cursor_roots       = [all_roots]
            _all_same              = True
            cursor_positions       = []   # non usato in modalità selezione
            per_cursor_chord_lines = []   # non usato in modalità selezione

        # ════════════════════════════════════════════════════════════════
        # MODALITÀ CURSORE: comportamento originale
        # ════════════════════════════════════════════════════════════════
        else:
            _sel_line_roots = None   # non in modalità selezione

            # Helper: data una riga del cursore, trova il TESTO della riga con accordi
            # Priorità: riga corrente → successiva → precedente
            def _find_chord_line(cur_line):
                candidates = []
                candidates.append(stc.GetLine(cur_line))
                if cur_line + 1 < total_lines:
                    candidates.append(stc.GetLine(cur_line + 1))
                if cur_line - 1 >= 0:
                    candidates.append(stc.GetLine(cur_line - 1))
                for ln in candidates:
                    if re.search(r'\[([^\]]+)\]', ln):
                        return ln
                return u""

            # Helper: ritorna l'INDICE della riga accordi vicina a cur_line, o -1
            def _find_chord_line_idx(cur_line):
                for candidate in [cur_line, cur_line + 1, cur_line - 1]:
                    if 0 <= candidate < total_lines:
                        if re.search(r'\[([^\]]+)\]', stc.GetLine(candidate)):
                            return candidate
                return -1

            # 1. Raccogli le posizioni di tutti i cursori (ordine inverso)
            if n_sel > 1:
                cursor_positions = sorted(
                    [stc.GetSelectionNStart(i) for i in range(n_sel)],
                    reverse=True
                )
            else:
                cursor_positions = [stc.GetCurrentPos()]

            # 2. Determina all_roots dalla riga del cursore principale
            main_line  = stc.LineFromPosition(cursor_positions[-1])  # cursore più in alto
            chord_line = _find_chord_line(main_line)
            all_roots  = _extract_roots(chord_line)

            # 2b. Raccoglie roots e indici riga per ogni cursore (top→bottom)
            if n_sel > 1:
                per_cursor_roots = []
                per_cursor_chord_lines = []
                for pos in reversed(cursor_positions):   # ordine top→bottom
                    cl = stc.LineFromPosition(pos)
                    per_cursor_roots.append(_extract_roots(_find_chord_line(cl)))
                    per_cursor_chord_lines.append(_find_chord_line_idx(cl))
                _all_same = all(r == per_cursor_roots[0] for r in per_cursor_roots)
            else:
                per_cursor_roots = [all_roots]
                per_cursor_chord_lines = [_find_chord_line_idx(main_line)]
                _all_same = True

        # ── 3a. Nessun accordo: avvisa e non inserisce nulla ────────────
        if not all_roots:
            wx.MessageBox(
                _(u"No chord line found near the cursor.\n"
                  u"Place the cursor on or next to a line containing chords."),
                _(u"Beats_time — beats per chord"),
                wx.OK | wx.ICON_INFORMATION,
                self.frame
            )
            return

        # ── 3b. Accordi trovati: dialogo per i battiti ───────────────────
        dlg = wx.Dialog(
            self.frame,
            title=_(u"Beats_time — beats per chord"),
            style=wx.DEFAULT_DIALOG_STYLE | wx.RESIZE_BORDER,
        )

        outer = wx.BoxSizer(wx.VERTICAL)

        # Intestazione
        intro_text = _(u"Assign the number of beats to each chord.\n"
                       u"Put 0 to omit a chord from the directive.")
        lbl_intro = wx.StaticText(dlg, label=intro_text)
        outer.Add(lbl_intro, 0, wx.ALL, 10)

        # Hint: icona informazione + suggerimento posizionamento cursore
        hint_row = wx.BoxSizer(wx.HORIZONTAL)
        lbl_hint_icon = wx.StaticText(dlg, label=u"\u2139")   # ℹ
        _icon_font = lbl_hint_icon.GetFont()
        _icon_font.SetPointSize(_icon_font.GetPointSize() + 1)
        _icon_font.SetWeight(wx.FONTWEIGHT_BOLD)
        lbl_hint_icon.SetFont(_icon_font)
        lbl_hint_icon.SetForegroundColour(wx.Colour(0, 100, 180))
        lbl_hint_text = wx.StaticText(
            dlg,
            label=_(u"Place the cursor on the line with chords to insert the directive.")
        )
        _hint_font = lbl_hint_text.GetFont()
        _hint_font.SetPointSize(max(_hint_font.GetPointSize() - 1, 7))
        _hint_font.SetStyle(wx.FONTSTYLE_ITALIC)
        lbl_hint_text.SetFont(_hint_font)
        lbl_hint_text.SetForegroundColour(wx.Colour(90, 90, 90))
        hint_row.Add(lbl_hint_icon,  0, wx.ALIGN_CENTER_VERTICAL | wx.LEFT, 10)
        hint_row.Add(lbl_hint_text,  0, wx.ALIGN_CENTER_VERTICAL | wx.LEFT, 5)
        outer.Add(hint_row, 0, wx.BOTTOM, 8)

        # Badge modalità: selezione estesa o multicursore
        if _has_range_sel:
            _n_chord_lines = len(_sel_line_roots) if _sel_line_roots else 0
            badge_panel = wx.Panel(dlg, style=wx.BORDER_NONE)
            badge_panel.SetBackgroundColour(wx.Colour(0, 100, 180))
            badge_sizer = wx.BoxSizer(wx.HORIZONTAL)
            badge_lbl = wx.StaticText(
                badge_panel,
                label=u"  \u25cf  " + _(u"Selection mode: %d chord lines selected") % _n_chord_lines + u"  "
            )
            badge_lbl.SetForegroundColour(wx.Colour(255, 255, 255))
            f = badge_lbl.GetFont()
            f.SetWeight(wx.FONTWEIGHT_BOLD)
            badge_lbl.SetFont(f)
            badge_sizer.Add(badge_lbl, 0, wx.TOP | wx.BOTTOM, 4)
            badge_panel.SetSizer(badge_sizer)
            badge_panel.Fit()
            outer.Add(badge_panel, 0, wx.LEFT | wx.RIGHT | wx.BOTTOM, 10)
        elif n_sel > 1:
            badge_panel = wx.Panel(dlg, style=wx.BORDER_NONE)
            badge_panel.SetBackgroundColour(wx.Colour(0, 130, 60))
            badge_sizer = wx.BoxSizer(wx.HORIZONTAL)
            badge_lbl = wx.StaticText(
                badge_panel,
                label=u"  \u25cf  " + _(u"Multi-cursor active: %d positions") % n_sel + u"  "
            )
            badge_lbl.SetForegroundColour(wx.Colour(255, 255, 255))
            f = badge_lbl.GetFont()
            f.SetWeight(wx.FONTWEIGHT_BOLD)
            badge_lbl.SetFont(f)
            badge_sizer.Add(badge_lbl, 0, wx.TOP | wx.BOTTOM, 4)
            badge_panel.SetSizer(badge_sizer)
            badge_panel.Fit()
            outer.Add(badge_panel, 0, wx.LEFT | wx.RIGHT | wx.BOTTOM, 10)

        # ── Helper: costruisce una griglia SpinCtrl per una lista di roots ──
        def _make_grid(parent, roots):
            """Ritorna (sizer_or_scroll, spin_list) per i roots dati."""
            _spin_list = []
            use_scroll = len(roots) > 8
            if use_scroll:
                sw = wx.ScrolledWindow(parent, style=wx.VSCROLL)
                sw.SetScrollRate(0, 12)
                gp = sw
            else:
                sw = None
                gp = parent
            g = wx.FlexGridSizer(cols=2, hgap=8, vgap=6)
            g.AddGrowableCol(1)
            for root in roots:
                g.Add(wx.StaticText(gp, label=root), 0, wx.ALIGN_CENTER_VERTICAL)
                sp = wx.SpinCtrl(gp, min=0, max=32, size=(70, -1))
                sp.SetValue(1)
                sp.SetToolTip(_(u"0 = omit this chord"))
                g.Add(sp, 0, wx.EXPAND)
                _spin_list.append((root, sp))
            if use_scroll:
                sw.SetSizer(g)
                g.Fit(sw)
                sw.SetMinSize((-1, min(g.GetMinSize().height, 8 * 30)))
                return sw, _spin_list
            return g, _spin_list

        # ── Griglia: singola se sequenze identiche, Notebook se eterogenee ──
        # spin_lists è una lista di liste: una per ogni "tab" (o una sola se uniforme)
        # spin_list (compatibilità con il resto del codice) = prima tab
        MAX_CURSOR_TABS = 5

        if n_sel <= 1 or _all_same:
            # Caso semplice: un'unica griglia
            grid_widget, spin_list = _make_grid(dlg, all_roots)
            if isinstance(grid_widget, wx.ScrolledWindow):
                outer.Add(grid_widget, 1, wx.EXPAND | wx.LEFT | wx.RIGHT | wx.BOTTOM, 10)
            else:
                outer.Add(grid_widget, 0, wx.LEFT | wx.RIGHT | wx.BOTTOM, 10)
            spin_lists = [spin_list]
            _notebook_grids = None
            cb_highlight = None   # non in modalità notebook
        else:
            # Multicursore eterogeneo: Notebook con una tab per cursore (max 5)
            tabs_roots = per_cursor_roots[:MAX_CURSOR_TABS]
            nb = wx.Notebook(dlg)
            spin_lists = []
            for idx, roots in enumerate(tabs_roots):
                page = wx.Panel(nb)
                page_sizer = wx.BoxSizer(wx.VERTICAL)
                if roots:
                    gw, sl = _make_grid(page, roots)
                    if isinstance(gw, wx.ScrolledWindow):
                        page_sizer.Add(gw, 1, wx.EXPAND | wx.ALL, 6)
                    else:
                        page_sizer.Add(gw, 0, wx.ALL, 6)
                else:
                    page_sizer.Add(
                        wx.StaticText(page, label=_(u"(no chords found)")),
                        0, wx.ALL, 10
                    )
                    sl = []
                page.SetSizer(page_sizer)
                nb.AddPage(page, _(u"Cursor %d") % (idx + 1))
                spin_lists.append(sl)
            if len(per_cursor_roots) > MAX_CURSOR_TABS:
                lbl_trunc = wx.StaticText(
                    dlg,
                    label=u"⚠ " + (_(u"Showing first %d cursors of %d") % (MAX_CURSOR_TABS, n_sel))
                )
                lbl_trunc.SetForegroundColour(wx.Colour(160, 100, 0))
                outer.Add(lbl_trunc, 0, wx.LEFT | wx.RIGHT | wx.BOTTOM, 4)
            outer.Add(nb, 0, wx.EXPAND | wx.LEFT | wx.RIGHT | wx.BOTTOM, 10)
            _notebook_grids = nb
            spin_list = spin_lists[0]  # compatibilità

            # ── Checkbox + ColourPicker "Evidenzia riga nell'editor" ────
            # Usa i marker STC per evidenziare nel testo le righe degli accordi
            # a cui si riferisce ciascun cursore, sincronizzato con la tab attiva.
            # Il colore attivo è scelto dall'utente; le righe secondarie usano
            # la stessa tinta schiarita automaticamente verso il bianco (blend 30%).
            _hl_key     = 'beatsTimeHighlightRow'
            _hl_col_key = 'beatsTimeHighlightColour'
            _hl_init    = self.config.ReadBool(_hl_key, True)
            _hl_col_str = self.config.Read(_hl_col_key, u'#00C850')
            _MARKER_NUM = 8   # marker STC: riga cursore attivo
            _MARKER_ALL = 9   # marker STC: righe altri cursori

            def _parse_colour(hex_str):
                """Converte '#RRGGBB' in wx.Colour; fallback verde se invalido."""
                try:
                    c = wx.Colour(hex_str)
                    return c if c.IsOk() else wx.Colour(0, 200, 80)
                except Exception:
                    return wx.Colour(0, 200, 80)

            def _dim_colour(c, factor=0.30):
                """Schiarisce wx.Colour verso il bianco con il fattore dato (0–1)."""
                r = int(c.Red()   + (255 - c.Red())   * (1 - factor))
                g = int(c.Green() + (255 - c.Green()) * (1 - factor))
                b = int(c.Blue()  + (255 - c.Blue())  * (1 - factor))
                return wx.Colour(r, g, b)

            def _redefine_markers(active_colour):
                """(Re)definisce entrambi i marker STC con il colore corrente."""
                dim = _dim_colour(active_colour)
                stc.MarkerDefine(_MARKER_NUM, wx.stc.STC_MARK_BACKGROUND,
                                 background=active_colour)
                stc.MarkerDefine(_MARKER_ALL, wx.stc.STC_MARK_BACKGROUND,
                                 background=dim)

            _current_colour = _parse_colour(_hl_col_str)
            _redefine_markers(_current_colour)

            # Riga: [✓ Highlight chord rows in editor]  [■ colore]
            hl_row = wx.BoxSizer(wx.HORIZONTAL)
            cb_highlight = wx.CheckBox(
                dlg, label=_(u"Highlight chord rows in editor"))
            cb_highlight.SetValue(_hl_init)
            cb_highlight.SetToolTip(
                _(u"Highlight in the editor the chord line each cursor refers to.\n"
                  u"Active cursor: chosen colour  |  Other cursors: lighter tint"))
            colour_picker = wx.ColourPickerCtrl(dlg, colour=_current_colour)
            colour_picker.SetToolTip(_(u"Choose the highlight colour for the active cursor"))
            colour_picker.Enable(_hl_init)
            hl_row.Add(cb_highlight,   0, wx.ALIGN_CENTER_VERTICAL | wx.RIGHT, 8)
            hl_row.Add(colour_picker,  0, wx.ALIGN_CENTER_VERTICAL)
            outer.Add(hl_row, 0, wx.LEFT | wx.RIGHT | wx.BOTTOM, 10)

            def _apply_editor_highlight():
                """Aggiorna i marker STC sull'editor in base allo stato checkbox."""
                stc.MarkerDeleteAll(_MARKER_NUM)
                stc.MarkerDeleteAll(_MARKER_ALL)
                if not cb_highlight.GetValue():
                    return
                active_tab = nb.GetSelection()
                for idx, line_idx in enumerate(per_cursor_chord_lines):
                    if line_idx < 0:
                        continue
                    marker = _MARKER_NUM if idx == active_tab else _MARKER_ALL
                    stc.MarkerAdd(line_idx, marker)

            def _on_nb_page_changed(_evt):
                _apply_editor_highlight()
                _evt.Skip()

            def _on_highlight_toggle(_evt):
                self.config.WriteBool(_hl_key, cb_highlight.GetValue())
                colour_picker.Enable(cb_highlight.GetValue())
                _apply_editor_highlight()

            def _on_colour_changed(_evt):
                nonlocal _current_colour
                _current_colour = colour_picker.GetColour()
                self.config.Write(_hl_col_key,
                                  _current_colour.GetAsString(wx.C2S_HTML_SYNTAX))
                _redefine_markers(_current_colour)
                _apply_editor_highlight()

            nb.Bind(wx.EVT_NOTEBOOK_PAGE_CHANGED, _on_nb_page_changed)
            cb_highlight.Bind(wx.EVT_CHECKBOX,            _on_highlight_toggle)
            colour_picker.Bind(wx.EVT_COLOURPICKER_CHANGED, _on_colour_changed)
            _apply_editor_highlight()   # stato iniziale

            # Rimuove i marker quando il dialogo viene chiuso
            def _cleanup_markers(_evt):
                stc.MarkerDeleteAll(_MARKER_NUM)
                stc.MarkerDeleteAll(_MARKER_ALL)
                _evt.Skip()
            dlg.Bind(wx.EVT_CLOSE,          _cleanup_markers)
            dlg.Bind(wx.EVT_WINDOW_DESTROY, _cleanup_markers)

        # ── Riga "Tutti" — allineata a destra ──────────────────────────
        all_row = wx.BoxSizer(wx.HORIZONTAL)
        lbl_all = wx.StaticText(dlg, label=_(u"All:"))
        spin_all = wx.SpinCtrl(dlg, min=0, max=32, size=(70, -1))
        spin_all.SetValue(1)
        spin_all.SetToolTip(_(u"Set this value on all chords"))
        btn_apply_all = wx.Button(dlg, label=_(u"Apply to all"), size=(-1, -1))
        all_row.AddStretchSpacer()
        all_row.Add(lbl_all,       0, wx.ALIGN_CENTER_VERTICAL | wx.RIGHT, 8)
        all_row.Add(spin_all,      0, wx.ALIGN_CENTER_VERTICAL | wx.RIGHT, 6)
        all_row.Add(btn_apply_all, 0, wx.ALIGN_CENTER_VERTICAL)
        outer.Add(all_row, 0, wx.EXPAND | wx.LEFT | wx.RIGHT | wx.BOTTOM, 10)

        # ── Anteprima: una per tab (Notebook eterogeneo) o unica ────────────
        if _notebook_grids is not None:
            # Inserisce un'etichetta anteprima in ogni tab del notebook
            _preview_labels = []
            for idx, page in enumerate([nb.GetPage(i) for i in range(nb.GetPageCount())]):
                sep = wx.StaticLine(page)
                page.GetSizer().Add(sep, 0, wx.EXPAND | wx.LEFT | wx.RIGHT | wx.BOTTOM, 6)
                lp_title = wx.StaticText(page, label=_(u"Preview:"))
                page.GetSizer().Add(lp_title, 0, wx.LEFT | wx.RIGHT, 6)
                lp = wx.StaticText(page, label=u"",
                                   style=wx.ST_NO_AUTORESIZE | wx.ST_ELLIPSIZE_END)
                lp.SetForegroundColour(wx.Colour(0, 110, 0))
                fp = lp.GetFont()
                fp.SetFamily(wx.FONTFAMILY_TELETYPE)
                lp.SetFont(fp)
                lp.SetMinSize((lp.GetCharWidth() * 50, -1))
                page.GetSizer().Add(lp, 0, wx.EXPAND | wx.LEFT | wx.RIGHT | wx.BOTTOM, 6)
                page.Layout()
                _preview_labels.append(lp)
            # Separatore e anteprima globale (cursore 1) sotto il notebook
            outer.Add(wx.StaticLine(dlg), 0, wx.EXPAND | wx.LEFT | wx.RIGHT | wx.BOTTOM, 6)
            lbl_preview_title = wx.StaticText(dlg, label=_(u"Preview (cursor 1):"))
            outer.Add(lbl_preview_title, 0, wx.LEFT | wx.RIGHT, 10)
            lbl_preview = wx.StaticText(dlg, label=u"",
                                        style=wx.ST_NO_AUTORESIZE | wx.ST_ELLIPSIZE_END)
            lbl_preview.SetForegroundColour(wx.Colour(0, 110, 0))
            font_preview = lbl_preview.GetFont()
            font_preview.SetFamily(wx.FONTFAMILY_TELETYPE)
            lbl_preview.SetFont(font_preview)
            lbl_preview.SetMinSize((lbl_preview.GetCharWidth() * 60, -1))
            outer.Add(lbl_preview, 0, wx.EXPAND | wx.LEFT | wx.RIGHT | wx.BOTTOM, 10)
        else:
            _preview_labels = None
            # Separatore visivo
            outer.Add(wx.StaticLine(dlg), 0, wx.EXPAND | wx.LEFT | wx.RIGHT | wx.BOTTOM, 6)
            lbl_preview_title = wx.StaticText(dlg, label=_(u"Preview:"))
            outer.Add(lbl_preview_title, 0, wx.LEFT | wx.RIGHT, 10)
            lbl_preview = wx.StaticText(dlg, label=u"",
                                        style=wx.ST_NO_AUTORESIZE | wx.ST_ELLIPSIZE_END)
            lbl_preview.SetForegroundColour(wx.Colour(0, 110, 0))
            font_preview = lbl_preview.GetFont()
            font_preview.SetFamily(wx.FONTFAMILY_TELETYPE)
            lbl_preview.SetFont(font_preview)
            char_w = lbl_preview.GetCharWidth()
            lbl_preview.SetMinSize((char_w * 60, -1))
            outer.Add(lbl_preview, 0, wx.EXPAND | wx.LEFT | wx.RIGHT | wx.BOTTOM, 10)

        # ── Sezione "Apply to whole song" — separata visivamente dai bottoni modali ──
        outer.Add(wx.StaticLine(dlg), 0, wx.EXPAND | wx.LEFT | wx.RIGHT, 8)
        song_row = wx.BoxSizer(wx.HORIZONTAL)
        lbl_song_hint = wx.StaticText(
            dlg,
            label=_(u"Batch mode: inserts the directive before every chord line in the file.")
        )
        _hint_font = lbl_song_hint.GetFont()
        _hint_font.SetPointSize(max(_hint_font.GetPointSize() - 1, 7))
        _hint_font.SetStyle(wx.FONTSTYLE_ITALIC)
        lbl_song_hint.SetFont(_hint_font)
        lbl_song_hint.SetForegroundColour(wx.Colour(100, 100, 100))
        btn_song = wx.Button(dlg, wx.ID_ANY, _(u"Apply to whole song\u2026"))
        btn_song.SetToolTip(_(u"Insert {beats_time} before every chord line in the whole song"))
        song_row.Add(lbl_song_hint, 1, wx.ALIGN_CENTER_VERTICAL | wx.LEFT, 8)
        song_row.Add(btn_song,      0, wx.ALIGN_CENTER_VERTICAL | wx.LEFT | wx.RIGHT, 8)
        outer.Add(song_row, 0, wx.EXPAND | wx.TOP | wx.BOTTOM, 6)

        # ── Bottoni modali: [OK] [OK + Ns ↕] [Cancel] ───────────────────
        _delay_key   = 'beatsTimeReopenDelay'
        _delay_saved = self.config.Read(_delay_key, u'5')
        try:
            _delay_init = max(1, min(60, int(_delay_saved)))
        except ValueError:
            _delay_init = 5

        ID_OK_REOPEN = wx.NewIdRef()
        btn_row      = wx.BoxSizer(wx.HORIZONTAL)
        btn_ok       = wx.Button(dlg, wx.ID_OK,     _(u"OK"))

        # Contenitore [OK +] [↕ spin] [s] affiancati
        reopen_box = wx.BoxSizer(wx.HORIZONTAL)
        btn_reopen = wx.Button(dlg, ID_OK_REOPEN, _(u"OK +"))
        _sw_path = glb.AddPath('img/stopwatch.png')
        if os.path.isfile(_sw_path):
            _sw_img = wx.Image(_sw_path, wx.BITMAP_TYPE_PNG)
            _sw_img = _sw_img.Scale(16, 16, wx.IMAGE_QUALITY_HIGH)
            btn_reopen.SetBitmap(wx.Bitmap(_sw_img))
            btn_reopen.SetBitmapMargins(2, 0)
        spin_delay = wx.SpinCtrl(dlg, min=1, max=60,
                                 size=(52, -1), style=wx.SP_ARROW_KEYS)
        spin_delay.SetValue(_delay_init)
        lbl_sec = wx.StaticText(dlg, label=_(u"s"))
        spin_delay.SetToolTip(_(u"Delay in seconds before the dialog reopens (1-60)"))
        reopen_box.Add(btn_reopen, 0, wx.ALIGN_CENTER_VERTICAL | wx.RIGHT, 2)
        reopen_box.Add(spin_delay, 0, wx.ALIGN_CENTER_VERTICAL | wx.RIGHT, 1)
        reopen_box.Add(lbl_sec,    0, wx.ALIGN_CENTER_VERTICAL)

        btn_cancel = wx.Button(dlg, wx.ID_CANCEL, _(u"Cancel"))
        btn_ok.SetDefault()
        btn_reopen.SetToolTip(_(u"Insert directive and reopen dialog after the chosen delay"))
        btn_row.AddStretchSpacer()
        btn_row.Add(btn_ok,      0, wx.RIGHT, 4)
        btn_row.Add(reopen_box,  0, wx.ALIGN_CENTER_VERTICAL | wx.RIGHT, 4)
        btn_row.Add(btn_cancel,  0)
        outer.Add(btn_row, 0, wx.EXPAND | wx.ALL, 8)

        def _on_delay_changed(_evt=None):
            self.config.Write(_delay_key, str(spin_delay.GetValue()))
        spin_delay.Bind(wx.EVT_SPINCTRL,   _on_delay_changed)
        spin_delay.Bind(wx.EVT_TEXT_ENTER, _on_delay_changed)

        def _on_ok_reopen(_evt):
            _on_delay_changed()   # salva il valore corrente prima di chiudere
            dlg.EndModal(ID_OK_REOPEN)

        dlg.SetSizerAndFit(outer)
        dlg.CentreOnParent()

        def _build_parts(sl=None):
            """Costruisce la lista 'ROOT=N' dalla spin_list indicata (default: prima tab)."""
            if sl is None:
                sl = spin_lists[0]
            parts = []
            for root, sp in sl:
                v = sp.GetValue()
                if v > 0:
                    parts.append(u"%s=%d" % (root, v))
            return parts

        def _update_preview(_evt=None):
            # Aggiorna l'anteprima nella/e tab
            if _preview_labels is not None:
                for idx, (lp, sl) in enumerate(zip(_preview_labels, spin_lists)):
                    parts = _build_parts(sl)
                    directive = u"{beats_time: %s}" % u" ".join(parts) if parts else u"{beats_time: }"
                    lp.SetLabel(directive)
                    lp.GetParent().Layout()
            # Anteprima principale (sempre aggiornata con la prima tab / tab unica)
            parts = _build_parts(spin_lists[0])
            directive = u"{beats_time: %s}" % u" ".join(parts) if parts else u"{beats_time: }"
            lbl_preview.SetLabel(directive)
            dlg.Layout()

        def _apply_all(_evt=None):
            v = spin_all.GetValue()
            # Applica a tutte le tab
            for sl in spin_lists:
                for _r, sp in sl:
                    sp.SetValue(v)
            _update_preview()

        def _do_insert():
            """Inserisce {beats_time} PRIMA della riga degli accordi relativa a ogni cursore.

            In modalità selezione: agisce su tutte le righe con accordi coperte dalla
            selezione (bottom→top). Se la riga precedente ha già {beats_time}, la sostituisce.
            In modalità cursore: comportamento originale per cursore singolo/multicursore.
            Tutto in un unico blocco undo.
            """
            bt_pat = re.compile(r'^\s*\{beats_time[^}]*\}', re.IGNORECASE)

            # ── Costruisce la mappa accordo→valore dallo SpinList ──────────
            spin_val = {root: sp.GetValue() for root, sp in spin_lists[0]}
            _all_zero = all(v == 0 for v in spin_val.values()) if spin_val else False
            _default_val = 0 if _all_zero else 1

            def _build_directive_for_roots(roots):
                """Costruisce {beats_time: X=N Y=N} per una lista di roots."""
                parts = []
                for r in roots:
                    v = spin_val.get(r, _default_val)
                    if v > 0:
                        parts.append(u"%s=%d" % (r, v))
                return u"{beats_time: %s}" % u" ".join(parts) if parts else u"{beats_time: }"

            # ── MODALITÀ SELEZIONE ──────────────────────────────────────
            if _has_range_sel and _sel_line_roots:
                # Agisce bottom→top per non invalidare gli offset delle righe superiori
                sorted_lines = sorted(_sel_line_roots.keys(), reverse=True)
                with undo_action(stc):
                    for chord_idx in sorted_lines:
                        roots = _sel_line_roots[chord_idx]
                        directive = _build_directive_for_roots(roots)
                        prev_idx = chord_idx - 1
                        if prev_idx >= 0 and bt_pat.match(stc.GetLine(prev_idx).rstrip(u"\r\n")):
                            # Sostituisce la direttiva esistente
                            line_start = stc.PositionFromLine(prev_idx)
                            line_end   = stc.GetLineEndPosition(prev_idx)
                            stc.SetSelection(line_start, line_end)
                            stc.ReplaceSelection(directive)
                        else:
                            target_idx = chord_idx
                            while target_idx > 0 and stc.GetLine(target_idx - 1).strip() == u"":
                                target_idx -= 1
                            insert_pos = stc.PositionFromLine(target_idx)
                            stc.SetSelection(insert_pos, insert_pos)
                            stc.ReplaceSelection(directive + u"\n")
                return

            # ── MODALITÀ CURSORE (comportamento originale) ──────────────
            def _find_chord_line_idx(cur_line):
                """Ritorna l'indice della riga degli accordi vicina a cur_line, o -1.
                Priorità: riga corrente → precedente → successiva."""
                for candidate in [cur_line, cur_line - 1, cur_line + 1]:
                    if 0 <= candidate < stc.GetLineCount():
                        if re.search(r'\[([^\]]+)\]', stc.GetLine(candidate)):
                            return candidate
                return -1

            cur_n_sel = stc.GetSelections()
            if cur_n_sel > 1:
                cur_positions = sorted(
                    [stc.GetSelectionNStart(i) for i in range(cur_n_sel)],
                    reverse=True   # bottom→top per non invalidare gli offset
                )
            else:
                cur_positions = [stc.GetCurrentPos()]

            with undo_action(stc):
                for idx, pos in enumerate(cur_positions):
                    real_idx = (len(cur_positions) - 1 - idx) if cur_n_sel > 1 else 0
                    sl = spin_lists[real_idx] if real_idx < len(spin_lists) else spin_lists[0]
                    parts = _build_parts(sl)
                    directive = u"{beats_time: %s}" % u" ".join(parts) if parts else u"{beats_time: }"

                    chord_idx = _find_chord_line_idx(stc.LineFromPosition(pos))

                    if chord_idx < 0:
                        # Nessuna riga di accordi trovata: fallback al cursore
                        stc.SetSelection(pos, pos)
                        stc.ReplaceSelection(directive)
                        continue

                    prev_idx = chord_idx - 1
                    if prev_idx >= 0 and bt_pat.match(stc.GetLine(prev_idx).rstrip(u"\r\n")):
                        # La riga precedente è già un {beats_time}: sostituiscila in-place
                        line_start = stc.PositionFromLine(prev_idx)
                        line_end   = stc.GetLineEndPosition(prev_idx)
                        stc.SetSelection(line_start, line_end)
                        stc.ReplaceSelection(directive)
                    else:
                        # Risale sopra eventuali righe vuote che precedono gli accordi,
                        # così la direttiva viene inserita senza creare riga vuota visiva.
                        target_idx = chord_idx
                        while target_idx > 0 and stc.GetLine(target_idx - 1).strip() == u"":
                            target_idx -= 1
                        insert_pos = stc.PositionFromLine(target_idx)
                        stc.SetSelection(insert_pos, insert_pos)
                        stc.ReplaceSelection(directive + u"\n")

        def _do_insert_song(_evt=None):
            """Inserisce {beats_time: ...} prima di ogni riga con accordi nel brano intero.

            Regole:
            - Agisce solo sulle righe che contengono almeno un accordo [...]
            - Salta le righe già precedute da una direttiva {beats_time ...}
            - Usa un unico blocco undo per tutta l'operazione
            - Usa il valore degli SpinCtrl per ogni accordo come nella direttiva locale,
              ma mappa accordo→battiti per nome (non posizionale): ogni accordo della riga
              ottiene il numero di battiti corrispondente nella spin_map locale, oppure 1
              se non presente nel dialogo corrente.
            """
            parts_default = _build_parts(spin_lists[0])
            directive_default = (u"{beats_time: %s}" % u" ".join(parts_default)
                                 if parts_default else u"{beats_time: }")

            # Mappa nome accordo → valore spin (per righe con accordi diversi)
            spin_val = {root: sp.GetValue() for root, sp in spin_lists[0]}
            # Default per accordi non presenti nel dialogo:
            # se tutti i valori sono 0 (utente ha azzerato tutto) usa 0,
            # altrimenti usa 1 (comportamento normale)
            _all_zero = all(v == 0 for v in spin_val.values()) if spin_val else False
            _default_val = 0 if _all_zero else 1

            chord_pat    = re.compile(r'\[([^\]]+)\]')
            bt_pat       = re.compile(r'\{\s*beats_time[^}]*\}', re.IGNORECASE)
            directive_pat= re.compile(r'\{[^}]+\}')   # qualsiasi direttiva

            full_text = stc.GetText()
            lines     = full_text.splitlines(keepends=True)
            n_lines   = len(lines)

            # Costruisce il nuovo testo scorrendo le righe dal basso verso l'alto
            # per non invalidare gli offset — oppure ricostruisce l'intero testo.
            new_lines = []
            inserted  = 0
            for i, line in enumerate(lines):
                # La riga ha accordi?
                chords_in_line = chord_pat.findall(line)
                if not chords_in_line:
                    new_lines.append(line)
                    continue

                # La riga precedente (già processata) è già un {beats_time}?
                prev = new_lines[-1] if new_lines else u""
                if bt_pat.search(prev):
                    new_lines.append(line)
                    continue

                # Costruisce la direttiva per questa riga specifica
                # usando i valori dello spin per ogni accordo trovato
                row_roots = [c.strip() for c in chords_in_line if c.strip()]
                row_parts = []
                for r in row_roots:
                    v = spin_val.get(r, _default_val)   # default 0 se tutto azzerato, altrimenti 1
                    if v > 0:
                        row_parts.append(u"%s=%d" % (r, v))
                directive = (u"{beats_time: %s}" % u" ".join(row_parts)
                             if row_parts else u"{beats_time: }")

                # Inserisce la direttiva nella riga precedente a quella degli accordi,
                # preservando l'indentazione della riga degli accordi
                indent = u""
                new_lines.append(indent + directive + u"\n")
                new_lines.append(line)
                inserted += 1

            if inserted == 0:
                wx.MessageBox(
                    _(u"No chord lines found without {beats_time} already set."),
                    _(u"Beats_time — beats per chord"),
                    wx.OK | wx.ICON_INFORMATION,
                    dlg
                )
                return

            new_text = u"".join(new_lines)
            with undo_action(stc):
                stc.SetText(new_text)

            wx.MessageBox(
                _(u"%d {beats_time} directives inserted.") % inserted,
                _(u"Beats_time — beats per chord"),
                wx.OK | wx.ICON_INFORMATION,
                dlg
            )

        btn_song.Bind(wx.EVT_BUTTON,      _do_insert_song)
        btn_apply_all.Bind(wx.EVT_BUTTON, _apply_all)
        spin_all.Bind(wx.EVT_SPINCTRL,    _apply_all)   # frecce aggiornano subito
        spin_all.Bind(wx.EVT_TEXT_ENTER,  _apply_all)   # Invio da tastiera
        btn_reopen.Bind(wx.EVT_BUTTON,    _on_ok_reopen)

        for sl in spin_lists:
            for _root, sp in sl:
                sp.Bind(wx.EVT_SPINCTRL, _update_preview)
                sp.Bind(wx.EVT_TEXT,     _update_preview)

        _update_preview()
        result = dlg.ShowModal()
        # Rimuove sempre i marker di evidenziazione dall'editor (OK, Cancel, X)
        stc.MarkerDeleteAll(8)
        stc.MarkerDeleteAll(9)
        # ── Salvataggio garantito alla chiusura del dialogo ──────────────
        # config.Write scrive solo in memoria; config.Flush() porta su disco.
        # Lo facciamo qui indipendentemente dal risultato (OK / Cancel / X)
        # perché i singoli handler (toggle, colour_changed, delay_changed)
        # potrebbero non essere stati chiamati se l'utente ha chiuso il picker
        # senza confermare o ha premuto Annulla senza toccare nulla.
        if _notebook_grids is not None and cb_highlight is not None:
            self.config.WriteBool('beatsTimeHighlightRow', cb_highlight.GetValue())
            self.config.Write('beatsTimeHighlightColour',
                              colour_picker.GetColour().GetAsString(wx.C2S_HTML_SYNTAX))
        self.config.Write('beatsTimeReopenDelay', str(spin_delay.GetValue()))
        self.config.Flush()
        if result in (wx.ID_OK, ID_OK_REOPEN):
            _do_insert()
        dlg.Destroy()
        if result == ID_OK_REOPEN:
            _reopen_ms = int(self.config.Read('beatsTimeReopenDelay', u'5'))
            _reopen_ms = max(1, min(60, _reopen_ms)) * 1000
            wx.CallLater(_reopen_ms, self.OnInsertBeatsTime, None)

    def OnInsertMusicalSymbol(self, evt):
        """Apre la Symbol Map musicale e inserisce il carattere scelto nel cursore."""
        scale_enabled  = getattr(self.pref, 'symbolScaleEnabled', False)
        font_size      = getattr(self.pref, 'symbolFontSize', 24)
        insert_verse   = getattr(self.pref, 'symbolInsertVerse', False)

        dlg = MusicalSymbolDialog(self.frame,
                                  scale_enabled=scale_enabled,
                                  font_size=font_size,
                                  insert_verse=insert_verse)
        if dlg.ShowModal() == wx.ID_OK:
            sym = dlg.GetSymbol()
            if sym:
                self.InsertWithCaret(sym)

        # Aggiorna pref in memoria (senza salvare su disco: ci pensa pref.Save() in OnOK)
        self.pref.symbolScaleEnabled = dlg.GetScaleEnabled()
        self.pref.symbolFontSize     = dlg.GetFontSize()
        self.pref.symbolInsertVerse  = dlg.GetInsertVerse()
        dlg.Destroy()

    def OnAbout(self, evt):
        """Mostra la finestra About con link cliccabili."""
        translations = "\n".join([
            u"- {}: {}".format(glb.languages[x], glb.translators[x])
            for x in glb.languages
        ])
        dlg = wx.Dialog(self.frame, title=_("About Songpress++ - The Song Editor"))
        dlg.SetBackgroundColour(wx.WHITE)
        panel = wx.Panel(dlg)
        panel.SetBackgroundColour(wx.WHITE)
        vbox = wx.BoxSizer(wx.VERTICAL)

        # Icona + titolo
        try:
            icon_path = glb.AddPath('img/songpress++.ico')
            icon_bmp = wx.StaticBitmap(panel, bitmap=wx.Bitmap(icon_path, wx.BITMAP_TYPE_ICO))
            hbox_title = wx.BoxSizer(wx.HORIZONTAL)
            hbox_title.Add(icon_bmp, 0, wx.ALIGN_CENTER_VERTICAL | wx.RIGHT, 10)
            title_lbl = wx.StaticText(panel, label=u"Songpress++ - The Song Editor {}".format(glb.VERSION))
            font_title = title_lbl.GetFont()
            font_title.SetWeight(wx.FONTWEIGHT_BOLD)
            font_title.SetPointSize(font_title.GetPointSize() + 2)
            title_lbl.SetFont(font_title)
            hbox_title.Add(title_lbl, 0, wx.ALIGN_CENTER_VERTICAL)
            vbox.Add(hbox_title, 0, wx.ALIGN_CENTER | wx.ALL, 10)
        except Exception:
            title_lbl = wx.StaticText(panel, label=u"Songpress++ - The Song Editor {}".format(glb.VERSION))
            vbox.Add(title_lbl, 0, wx.ALIGN_CENTER | wx.ALL, 10)

        def add_text(text):
            lbl = wx.StaticText(panel, label=text)
            vbox.Add(lbl, 0, wx.ALIGN_CENTER | wx.LEFT | wx.RIGHT, 15)

        def add_link(label, url):
            lnk = wx.adv.HyperlinkCtrl(panel, label=label, url=url)
            vbox.Add(lnk, 0, wx.ALIGN_CENTER | wx.LEFT | wx.RIGHT, 15)

        add_text(u"Copyright \u00a9 2009-{} Luca Allulli - Skeed".format(glb.YEAR))
        add_text(u"Copyright \u00a9 2026-{} Denisov21".format(glb.YEAR))
        add_text(u"Localization:\n{}".format(translations))
        vbox.AddSpacer(8)
        add_text(_(u"Songpress++ is a fork of Songpress by Luca Allulli - Skeed,"))
        add_text(_(u"maintained and extended by Denisov21."))
        vbox.AddSpacer(4)
        add_link(_(u"Original version website: http://www.skeed.it/songpress"), "http://www.skeed.it/songpress")
        add_link(_(u"Fork repository: https://github.com/Denisov21/Songpressplusplus"), "https://github.com/Denisov21/Songpressplusplus")
        vbox.AddSpacer(8)
        add_text(_(u"Licensed under the terms and conditions of the GNU General Public License, version 2"))
        vbox.AddSpacer(8)
        add_text(_(
            u"Special thanks to:\n"
            u"  * The Python programming language (http://www.python.org)\n"
            u"  * wxWidgets (http://www.wxwidgets.org)\n"
            u"  * wxPython (http://www.wxpython.org)\n"
            u"  * python-pptx (for PowerPoint export)"
        ))
        vbox.AddSpacer(10)

        btn_ok = wx.Button(panel, wx.ID_OK, "OK")
        vbox.Add(btn_ok, 0, wx.ALIGN_CENTER | wx.BOTTOM, 10)

        panel.SetSizer(vbox)
        vbox.Fit(panel)
        dlg_sizer = wx.BoxSizer(wx.VERTICAL)
        dlg_sizer.Add(panel, 1, wx.EXPAND)
        dlg.SetSizer(dlg_sizer)
        dlg_sizer.Fit(dlg)
        dlg.ShowModal()
        dlg.Destroy()

    def OnInsertCopyright(self, evt):
        """Inserisce la direttiva {copyright: <testo>}."""
        self._InsertSimpleDirective('copyright', _(u"Enter the copyright text:"), u"")

    def OnInsertKlavierChord(self, evt):
        """Inserts the {taste:<chord>} directive for a chord keyboard display (klavier)."""
        d = wx.TextEntryDialog(
            self.frame,
            _("Enter the chord name (e.g. C, G, Am, D7):"), 
            _("Chord keys"),
            "",
        )
        if d.ShowModal() == wx.ID_OK:
            chord = d.GetValue().strip()
            if chord:
                self.InsertWithCaret("{taste:%s}" % chord)
            else:
                self.InsertWithCaret("{taste:|}")
        d.Destroy()

    def OnInsertDefine(self, evt):
        """Inserts the {define:} directive for a guitar chord diagram."""
        d = wx.TextEntryDialog(
            self.frame,
            _("Enter chord definition (e.g. C base-fret 1 frets X 3 2 0 1 0):"),
            _("Guitar chord diagram"),
            "",
        )
        if d.ShowModal() == wx.ID_OK:
            value = d.GetValue().strip()
            if value:
                self.InsertWithCaret("{define: %s}" % value)
            else:
                self.InsertWithCaret("{define: |}")
        d.Destroy()

    def OnInsertFingering(self, evt):
        """Dialog per {fingering:} — accordo + numero dito per ogni nota."""

        # ── Notazione corrente dalle preferenze ───────────────────────
        _cur_notation = self.pref.notations[0] if self.pref.notations else None

        # Notazione italiana di riferimento (usata da KlavierRenderer)
        _it_notation = None
        for _n in self.pref.notations:
            if hasattr(_n, 'id') and ('it' in _n.id.lower() or 'italian' in _n.id.lower()):
                _it_notation = _n
                break

        # Mappa semitono → nome nota nella notazione italiana (base per KlavierRenderer)
        _IT_12 = ['Do', 'Do#', 'Re', 'Re#', 'Mi', 'Fa',
                  'Fa#', 'Sol', 'Sol#', 'La', 'La#', 'Si']

        def _semi_to_note(semi):
            """Restituisce il nome della nota (semitono 0-11) nella notazione corrente."""
            it_name = _IT_12[semi % 12]
            if _cur_notation is None or _it_notation is None:
                return it_name
            try:
                return translateChord(it_name, _it_notation, _cur_notation)
            except Exception:
                return it_name

        def _chord_to_it(chord_str):
            """Converte un accordo dalla notazione corrente all'italiana per il parser."""
            if _cur_notation is None or _it_notation is None:
                return chord_str
            try:
                return translateChord(chord_str, _cur_notation, _it_notation)
            except Exception:
                return chord_str

        # Note italiane -> semitono (per il parser interno)
        _IT_SEMITONE = {
            'do': 0,  'do#': 1, 'dob': 11,
            're': 2,  're#': 3, 'reb': 1,
            'mi': 4,  'mi#': 5, 'mib': 3,
            'fa': 5,  'fa#': 6, 'fab': 4,
            'sol': 7, 'sol#': 8,'solb': 6,
            'la': 9,  'la#': 10,'lab': 8,
            'si': 11, 'si#': 0, 'sib': 10,
        }
        _CHORD_INTERVALS = [
            ('maj7', [0,4,7,11]), ('maj', [0,4,7]),
            ('m7b5', [0,3,6,10]), ('m7',  [0,3,7,10]),
            ('min',  [0,3,7]),    ('m',   [0,3,7]),
            ('dim7', [0,3,6,9]), ('dim',  [0,3,6]),
            ('aug',  [0,4,8]),   ('sus4', [0,5,7]),
            ('sus2', [0,2,7]),   ('7',    [0,4,7,10]),
            ('5',    [0,7]),     ('-',    [0,3,7]),
            ('',     [0,4,7]),
        ]

        def chord_semitones(chord_str):
            """
            Parsa chord_str nella notazione corrente, restituisce i nomi delle
            note dell'accordo nella notazione corrente (per la griglia dita).
            """
            # Normalizza verso italiano per il parser
            it_chord = _chord_to_it(chord_str.strip())
            sl = it_chord.lower()
            root = None; rest = ''
            for name, semi in sorted(_IT_SEMITONE.items(), key=lambda x: -len(x[0])):
                if sl.startswith(name):
                    root = semi; rest = it_chord[len(name):]; break
            if root is None:
                return []
            rest = rest.split('/')[0].strip()
            ivs = [0, 4, 7]
            for suffix, intervals in _CHORD_INTERVALS:
                if rest.lower().startswith(suffix.lower()):
                    ivs = intervals; break
            # Restituisce i nomi nella notazione corrente
            return [_semi_to_note((root + i) % 12) for i in ivs]

        # ── Costruisce il dialog ──────────────────────────────────────
        dlg = wx.Dialog(self.frame, title=_(u"First chord fingering"),
                        style=wx.DEFAULT_DIALOG_STYLE)
        vbox = wx.BoxSizer(wx.VERTICAL)

        # Campo accordo
        hbox_chord = wx.BoxSizer(wx.HORIZONTAL)
        hbox_chord.Add(wx.StaticText(dlg, -1, _(u"Chord:")),
                       0, wx.ALIGN_CENTER_VERTICAL | wx.RIGHT, 6)
        txt_chord = wx.TextCtrl(dlg, -1, u"", size=(120, -1))
        hbox_chord.Add(txt_chord, 0)
        vbox.Add(hbox_chord, 0, wx.ALL, 10)

        # Mano destra / sinistra
        hbox_hand = wx.BoxSizer(wx.HORIZONTAL)
        hbox_hand.Add(wx.StaticText(dlg, -1, _(u"Hand:")),
                      0, wx.ALIGN_CENTER_VERTICAL | wx.RIGHT, 6)
        rb_right = wx.RadioButton(dlg, -1, _(u"Right"), style=wx.RB_GROUP)
        rb_left  = wx.RadioButton(dlg, -1, _(u"Left"))
        rb_right.SetValue(True)
        hbox_hand.Add(rb_right, 0, wx.ALIGN_CENTER_VERTICAL | wx.RIGHT, 10)
        hbox_hand.Add(rb_left,  0, wx.ALIGN_CENTER_VERTICAL)
        vbox.Add(hbox_hand, 0, wx.LEFT | wx.RIGHT | wx.BOTTOM, 10)

        # Istruzione
        lbl_info = wx.StaticText(
            dlg, -1,
            _(u"Assign a finger number to each note of the chord.\n"
              u"(1=thumb  2=index  3=middle  4=ring  5=little)\n"
              u"Leave '\u2014' for fingers not used."))
        vbox.Add(lbl_info, 0, wx.LEFT | wx.RIGHT | wx.BOTTOM, 10)

        # Pannello contenitore per la griglia — viene ricostruita dinamicamente
        grid_panel = wx.Panel(dlg, -1)
        grid_panel.SetSizer(wx.BoxSizer(wx.VERTICAL))   # sizer vuoto iniziale
        vbox.Add(grid_panel, 0, wx.LEFT | wx.RIGHT | wx.BOTTOM, 10)

        # Anteprima direttiva
        vbox.Add(wx.StaticLine(dlg), 0, wx.EXPAND | wx.LEFT | wx.RIGHT, 8)
        vbox.Add(wx.StaticText(dlg, -1, _(u"Directive preview:")),
                 0, wx.LEFT | wx.TOP, 10)
        txt_preview = wx.TextCtrl(dlg, -1, u"{fingering: }",
                                  style=wx.TE_READONLY)
        txt_preview.SetBackgroundColour(
            wx.SystemSettings.GetColour(wx.SYS_COLOUR_BTNFACE))
        vbox.Add(txt_preview, 0, wx.EXPAND | wx.ALL, 10)

        # ── Checkbox anteprima tastiera ───────────────────────────────
        cb_kbd = wx.CheckBox(dlg, -1, _(u"Show keyboard preview"))
        vbox.Add(cb_kbd, 0, wx.LEFT | wx.BOTTOM, 10)

        # Pannello di anteprima tastiera (visibile solo se checkbox attiva)
        _KBD_WHITE_W = 18
        _KBD_W       = _KBD_WHITE_W * 7   # 126 px
        _KBD_H       = 50
        _LABEL_H     = 34   # spazio per due righe: mano (riga 1) + nome accordo (riga 2)
        _PANEL_W     = _KBD_W + 40
        _PANEL_H     = _LABEL_H + _KBD_H + 10

        kbd_panel = wx.Panel(dlg, -1, size=(_PANEL_W, _PANEL_H))
        kbd_panel.SetBackgroundColour(wx.WHITE)
        kbd_panel.Show(False)
        vbox.Add(kbd_panel, 0, wx.LEFT | wx.BOTTOM, 10)

        def _draw_kbd_preview(event=None):
            """Ridisegna il mini-pannello tastiera con la diteggiatura attuale."""
            dc = wx.PaintDC(kbd_panel) if event is not None else wx.ClientDC(kbd_panel)
            dc.Clear()

            chord = txt_chord.GetValue().strip()
            if not chord:
                return

            # Ricava semitoni accordo e finger_map dalla direttiva corrente
            directive_text = txt_preview.GetValue()
            # Estrae la parte interna di {fingering: ...}
            import re as _re
            m = _re.match(r'\{fingering:\s*(.*)\}', directive_text)
            inner = m.group(1).strip() if m else chord
            chord_name, finger_map, _hand = KlavierRenderer.parse_fingering(inner)
            if chord_name is None:
                chord_name = chord
                finger_map = {}

            keys = KlavierRenderer.get_chord_keys(chord_name)
            if keys is None:
                return

            ox = 14   # offset x

            # ── Etichetta mano (riga 1, in alto) ─────────────────────
            hand_font = wx.Font(
                8, wx.FONTFAMILY_DEFAULT,
                wx.FONTSTYLE_ITALIC, wx.FONTWEIGHT_NORMAL)
            dc.SetFont(hand_font)
            dc.SetTextForeground(wx.Colour(80, 80, 80))
            hand_str = _(u"Right hand") if rb_right.GetValue() else _(u"Left hand")
            hw, hh = dc.GetTextExtent(hand_str)
            dc.DrawText(hand_str, ox + (_KBD_W - hw) // 2, 2)

            # ── Etichetta accordo in grassetto (riga 2) ───────────────
            label_font = wx.Font(
                8, wx.FONTFAMILY_DEFAULT,
                wx.FONTSTYLE_NORMAL, wx.FONTWEIGHT_BOLD)
            dc.SetFont(label_font)
            cw, ch = dc.GetTextExtent(chord_name)
            dc.SetTextForeground(wx.BLACK)
            dc.DrawText(chord_name, ox + (_KBD_W - cw) // 2, 2 + hh + 2)

            # ── Tastiera sotto le due etichette ───────────────────────
            oy = 2 + hh + 2 + ch + 4   # mano + accordo + gap
            highlight_color  = self._getKlavierHighlightColour()
            finger_num_color = self._getFingerNumColour()
            KlavierRenderer.draw_keyboard(
                dc, ox, oy, _KBD_W, _KBD_H,
                chord_name, keys, label_font,
                highlight_color, finger_map=finger_map,
                finger_num_color=finger_num_color,
                hand=None,
            )

        kbd_panel.Bind(wx.EVT_PAINT, _draw_kbd_preview)

        def _refresh_kbd(e=None):
            if kbd_panel.IsShown():
                kbd_panel.Refresh()

        def _on_cb_kbd(e=None):
            kbd_panel.Show(cb_kbd.GetValue())
            vbox.Layout()
            vbox.Fit(dlg)
            if cb_kbd.GetValue():
                kbd_panel.Refresh()

        cb_kbd.Bind(wx.EVT_CHECKBOX, _on_cb_kbd)

        btn_sizer = dlg.CreateButtonSizer(wx.OK | wx.CANCEL)
        vbox.Add(btn_sizer, 0, wx.ALL | wx.ALIGN_RIGHT, 8)
        dlg.SetSizer(vbox)

        # ── Stato dinamico ────────────────────────────────────────────
        finger_choices = [u"\u2014", u"1", u"2", u"3", u"4", u"5"]
        current_notes  = []   # note attuali
        note_rows      = []   # (StaticText, Choice) correnti

        def _build():
            chord = txt_chord.GetValue().strip()
            if not chord:
                return u"{fingering: }"
            hand = u"R" if rb_right.GetValue() else u"L"
            parts = [chord, u"hand=%s" % hand]
            for i, (lbl, ch) in enumerate(note_rows):
                sel = ch.GetSelection()
                if sel > 0:
                    parts.append(u"%d=%s" % (sel, current_notes[i]))
            return u"{fingering: %s}" % u" ".join(parts)

        def _update_preview(e=None):
            txt_preview.SetValue(_build())
            _refresh_kbd()

        def _rebuild_grid(notes):
            """Distrugge e ricrea la griglia nel grid_panel con le note date."""
            note_rows.clear()
            # Rimuovi tutti i figli esistenti
            for child in grid_panel.GetChildren():
                child.Destroy()

            if not notes:
                grid_panel.GetSizer().Layout()
                return

            # FlexGridSizer: 2 colonne, righe variabili
            fgs = wx.FlexGridSizer(cols=2, vgap=6, hgap=12)
            fgs.Add(wx.StaticText(grid_panel, -1, _(u"Note")),
                    0, wx.ALIGN_CENTER)
            fgs.Add(wx.StaticText(grid_panel, -1, _(u"Finger")),
                    0, wx.ALIGN_CENTER)
            for note in notes:
                lbl = wx.StaticText(grid_panel, -1, note)
                ch  = wx.Choice(grid_panel, -1, choices=finger_choices)
                ch.SetSelection(0)
                ch.Bind(wx.EVT_CHOICE, _update_preview)
                fgs.Add(lbl, 0, wx.ALIGN_CENTER_VERTICAL | wx.LEFT, 4)
                fgs.Add(ch,  0, wx.ALIGN_CENTER_VERTICAL)
                note_rows.append((lbl, ch))

            # Sostituisce il sizer del panel
            grid_panel.SetSizer(fgs)
            fgs.Layout()

        def _on_chord_change(e=None):
            chord = txt_chord.GetValue().strip()
            notes = chord_semitones(chord) if chord else []
            current_notes.clear()
            current_notes.extend(notes)
            _rebuild_grid(notes)
            # Ricalcola il layout dell'intero dialog
            vbox.Layout()
            vbox.Fit(dlg)
            _update_preview()

        txt_chord.Bind(wx.EVT_TEXT, _on_chord_change)
        rb_right.Bind(wx.EVT_RADIOBUTTON, lambda e: (_update_preview(), _refresh_kbd()))
        rb_left.Bind(wx.EVT_RADIOBUTTON,  lambda e: (_update_preview(), _refresh_kbd()))

        vbox.Fit(dlg)
        dlg.CentreOnParent()

        if dlg.ShowModal() == wx.ID_OK:
            directive = _build()
            if directive != u"{fingering: }":
                self.InsertWithCaret(directive)
            else:
                self.InsertWithCaret(u"{fingering: |}")
        dlg.Destroy()

    def OnImportFromPdf(self, evt):
        """Import text from a PDF file (selectable text only, no OCR)."""
        try:
            from pypdf import PdfReader
        except ImportError:
            wx.MessageBox(
                _("The pypdf library is not installed.\nInstall with:  pip install pypdf"),
                _("pypdf not found"),
                wx.OK | wx.ICON_ERROR,
                self.frame,
            )
            return

        with wx.FileDialog(
            self.frame,
            _("Import text from PDF"),
            wildcard=_("PDF files (*.pdf)|*.pdf"),
            style=wx.FD_OPEN | wx.FD_FILE_MUST_EXIST,
        ) as dlg:
            if dlg.ShowModal() != wx.ID_OK:
                return
            path = dlg.GetPath()

        try:
            reader = PdfReader(path)
            pages = [page.extract_text() or "" for page in reader.pages]
            text = "\n".join(pages).strip()
        except Exception as e:
            wx.MessageBox(
                _("Error reading the PDF:\n%s") % str(e),
                _("Import error"),
                wx.OK | wx.ICON_ERROR,
                self.frame,
            )
            return

        if not text:
            wx.MessageBox(
                _("The PDF contains no extractable text.\nIt may be a scanned (image-only) PDF."),
                _("No text found"),
                wx.OK | wx.ICON_WARNING,
                self.frame,
            )
            return

        if not self.AskSaveModified():
            return

        self.document = ''
        self.text.AutoChangeMode(True)
        self.text.New()
        self.text.SetText(text)
        self.text.AutoChangeMode(False)
        self.SetModified()

    def OnInsertImage(self, evt):
        """Dialog per inserire {image: ...} con selezione file e parametri."""
        doc = getattr(self, 'document', '') or ''
        default_dir = os.path.dirname(os.path.abspath(doc)) if doc else ''
        # Estensione del file documento corrente (dalle preferenze)
        doc_ext = getattr(getattr(self, 'pref', None), 'defaultExtension', None) or 'crd'''

        d = wx.Dialog(self.frame, title=_("Insert image"), style=wx.DEFAULT_DIALOG_STYLE | wx.RESIZE_BORDER)
        vbox = wx.BoxSizer(wx.VERTICAL)

        # --- File ---
        vbox.Add(wx.StaticText(d, -1, _("Image file:")), 0, wx.LEFT | wx.TOP, 8)
        hbox_file = wx.BoxSizer(wx.HORIZONTAL)
        txt_path = wx.TextCtrl(d, -1, "", size=(300, -1))
        btn_browse = wx.Button(d, -1, _("Browse..."))
        hbox_file.Add(txt_path, 1, wx.EXPAND | wx.RIGHT, 4)
        hbox_file.Add(btn_browse, 0)
        vbox.Add(hbox_file, 0, wx.EXPAND | wx.LEFT | wx.RIGHT | wx.BOTTOM, 8)

        # --- Dimensioni ---
        gb = wx.GridBagSizer(4, 8)

        # Width — SpinCtrlDouble: solo interi (step=1), vuoto = non specificato
        gb.Add(wx.StaticText(d, -1, _("Width:")), pos=(0, 0), flag=wx.ALIGN_CENTER_VERTICAL)
        txt_w = wx.SpinCtrlDouble(d, -1, "", min=0, max=9999, inc=1, size=(70, -1))
        txt_w.SetDigits(0)
        txt_w.SetValue(0)
        gb.Add(txt_w, pos=(0, 1), flag=wx.EXPAND)
        ch_w_unit = wx.Choice(d, -1, choices=["pt", "%"])
        ch_w_unit.SetSelection(0)   # default: pt
        gb.Add(ch_w_unit, pos=(0, 2), flag=wx.ALIGN_CENTER_VERTICAL)

        # Height — SpinCtrlDouble: solo interi
        gb.Add(wx.StaticText(d, -1, _("Height:")), pos=(1, 0), flag=wx.ALIGN_CENTER_VERTICAL)
        txt_h = wx.SpinCtrlDouble(d, -1, "", min=0, max=9999, inc=1, size=(70, -1))
        txt_h.SetDigits(0)
        txt_h.SetValue(0)
        gb.Add(txt_h, pos=(1, 1), flag=wx.EXPAND)
        ch_h_unit = wx.Choice(d, -1, choices=["pt", "%"])
        ch_h_unit.SetSelection(0)   # default: pt
        gb.Add(ch_h_unit, pos=(1, 2), flag=wx.ALIGN_CENTER_VERTICAL)

        # Scale — SpinCtrlDouble: valori decimali 1–500, step 1
        gb.Add(wx.StaticText(d, -1, _("Scale:")), pos=(2, 0), flag=wx.ALIGN_CENTER_VERTICAL)
        txt_scale = wx.SpinCtrlDouble(d, -1, "", min=1, max=500, inc=1, size=(70, -1))
        txt_scale.SetDigits(1)
        txt_scale.SetValue(100)
        gb.Add(txt_scale, pos=(2, 1), flag=wx.EXPAND)
        gb.Add(wx.StaticText(d, -1, "%"), pos=(2, 2), flag=wx.ALIGN_CENTER_VERTICAL)

        vbox.Add(gb, 0, wx.LEFT | wx.RIGHT | wx.BOTTOM, 8)

        # --- Allineamento ---
        hbox_align = wx.BoxSizer(wx.HORIZONTAL)
        hbox_align.Add(wx.StaticText(d, -1, _("Align:")), 0, wx.ALIGN_CENTER_VERTICAL | wx.RIGHT, 6)
        rb_left   = wx.RadioButton(d, -1, _("Left"),   style=wx.RB_GROUP)
        rb_center = wx.RadioButton(d, -1, _("Center"))
        rb_right  = wx.RadioButton(d, -1, _("Right"))
        rb_center.SetValue(True)
        hbox_align.Add(rb_left,   0, wx.RIGHT, 8)
        hbox_align.Add(rb_center, 0, wx.RIGHT, 8)
        hbox_align.Add(rb_right,  0)
        vbox.Add(hbox_align, 0, wx.LEFT | wx.RIGHT | wx.BOTTOM, 8)

        # --- Bordo ---
        hbox_border = wx.BoxSizer(wx.HORIZONTAL)
        cb_border = wx.CheckBox(d, -1, _("Border (pt):"))
        txt_border = wx.SpinCtrlDouble(d, -1, "", min=0, max=50, inc=0.5, size=(60, -1))
        txt_border.SetDigits(1)
        txt_border.SetValue(1)
        txt_border.Enable(False)
        hbox_border.Add(cb_border, 0, wx.ALIGN_CENTER_VERTICAL | wx.RIGHT, 6)
        hbox_border.Add(txt_border, 0)
        vbox.Add(hbox_border, 0, wx.LEFT | wx.RIGHT | wx.BOTTOM, 8)

        # --- Incorpora nel file ---
        vbox.Add(wx.StaticLine(d), 0, wx.EXPAND | wx.LEFT | wx.RIGHT, 8)
        cb_embed = wx.CheckBox(d, -1, _("Embed image in file (base64, no external dependency)"))
        cb_embed.SetToolTip(
            _("If checked, the image data is encoded in base64 and stored directly "
              "inside the .crd file. The song becomes self-contained but the file "
              "size grows. If unchecked, only the file path is stored (link)."
            ).replace(".crd", ".%s" % doc_ext))
        vbox.Add(cb_embed, 0, wx.LEFT | wx.RIGHT | wx.TOP, 8)
        lbl_embed_warn = wx.StaticText(d, -1, "")
        lbl_embed_warn.SetForegroundColour(wx.Colour(160, 100, 0))
        vbox.Add(lbl_embed_warn, 0, wx.LEFT | wx.BOTTOM, 8)

        # --- Anteprima direttiva ---
        vbox.Add(wx.StaticLine(d), 0, wx.EXPAND | wx.LEFT | wx.RIGHT, 8)
        vbox.Add(wx.StaticText(d, -1, _("Directive preview:")), 0, wx.LEFT | wx.TOP, 8)
        txt_preview = wx.TextCtrl(d, -1, "{image: }", style=wx.TE_READONLY)
        txt_preview.SetBackgroundColour(wx.SystemSettings.GetColour(wx.SYS_COLOUR_BTNFACE))
        vbox.Add(txt_preview, 0, wx.EXPAND | wx.LEFT | wx.RIGHT | wx.BOTTOM, 8)

        btn_sizer = d.CreateButtonSizer(wx.OK | wx.CANCEL)
        vbox.Add(btn_sizer, 0, wx.ALL | wx.ALIGN_RIGHT, 8)
        d.SetSizer(vbox)
        vbox.Fit(d)

        # --- Funzione aggiornamento anteprima ---
        def _build_options():
            """Restituisce la lista delle opzioni (width, height, scale, align, border)
            come lista di stringhe, indipendentemente dal path/token dell'immagine.
            Condivisa tra anteprima e inserimento finale."""
            opts = []
            w = int(txt_w.GetValue())
            if w > 0:
                unit = ch_w_unit.GetStringSelection()
                opts.append("width=%d%s" % (w, "%" if unit == "%" else ""))
            h = int(txt_h.GetValue())
            if h > 0:
                unit = ch_h_unit.GetStringSelection()
                opts.append("height=%d%s" % (h, "%" if unit == "%" else ""))
            sc = txt_scale.GetValue()
            if sc != 100.0:
                opts.append("scale=%g%%" % sc)
            if rb_left.GetValue():
                opts.append("align=left")
            elif rb_right.GetValue():
                opts.append("align=right")
            # center è il default, non serve scriverlo
            if cb_border.GetValue():
                bv = txt_border.GetValue()
                opts.append("border=%g" % bv if bv != 1.0 else "border")
            return opts

        def _build_directive(for_insert=False):
            """Costruisce la stringa della direttiva {image: ...}.

            Se for_insert=True e la checkbox 'incorpora' è attiva, il file viene
            letto, codificato in base64 e incorporato direttamente come data: URI.
            Altrimenti viene usato il percorso (relativo se nella stessa cartella).
            """
            path = txt_path.GetValue().strip()
            if not path:
                return "{image: }"

            embed = cb_embed.GetValue()

            # Risolve il path relativo rispetto alla cartella del documento,
            # così os.path.isfile() funziona anche quando path è solo il basename
            # (es. 'intro.png') e la working dir del processo è diversa.
            abs_path = (path if os.path.isabs(path)
                        else os.path.join(default_dir, path) if default_dir
                        else path)

            if for_insert and embed and os.path.isfile(abs_path):
                # ── Incorpora come data: URI base64 ──────────────────────
                import base64, mimetypes
                mime = mimetypes.guess_type(abs_path)[0] or "image/png"
                with open(abs_path, "rb") as _f:
                    b64 = base64.b64encode(_f.read()).decode("ascii")
                path_token = "data:%s;base64,%s" % (mime, b64)
            else:
                # ── Percorso file (relativo o assoluto) ──────────────────
                if default_dir and os.path.isabs(path):
                    try:
                        if os.path.dirname(os.path.abspath(path)) == default_dir:
                            path = os.path.basename(path)
                    except Exception:
                        pass
                if ' ' in path or '\\' in path:
                    path_token = '"%s"' % path.replace('"', '\\"')
                else:
                    path_token = path

            return "{image: %s}" % " ".join([path_token] + _build_options())

        def _update_embed_warn(e=None):
            """Aggiorna il label con la stima dei KB aggiunti al file."""
            if not cb_embed.GetValue():
                lbl_embed_warn.SetLabel("")
                lbl_embed_warn.GetParent().Layout()
                return
            path = txt_path.GetValue().strip()
            abs_path = (path if os.path.isabs(path)
                        else os.path.join(default_dir, path) if default_dir
                        else path)
            if path and os.path.isfile(abs_path):
                size_kb = os.path.getsize(abs_path) / 1024
                est_kb  = size_kb * 1.34   # base64 aumenta di ~33%
                if est_kb >= 1024:
                    lbl_embed_warn.SetLabel(
                        (_(u"⚠ Approx. %.1f MB will be added to the .crd file") % (est_kb / 1024)
                         ).replace(".crd", ".%s" % doc_ext))
                else:
                    lbl_embed_warn.SetLabel(
                        (_(u"⚠ Approx. %.0f KB will be added to the .crd file") % est_kb
                         ).replace(".crd", ".%s" % doc_ext))
            else:
                lbl_embed_warn.SetLabel("")
            lbl_embed_warn.GetParent().Layout()

        def _update_preview(e=None):
            embed = cb_embed.GetValue()
            path  = txt_path.GetValue().strip()
            abs_path = (path if os.path.isabs(path)
                        else os.path.join(default_dir, path) if default_dir
                        else path)
            if embed and path and os.path.isfile(abs_path):
                # Il dato base64 è illeggibile nell'anteprima: mostra
                # "<embedded>" al posto del token, ma include tutte le
                # opzioni reali (width, height, scale, align, border)
                # così l'utente può vedere e modificare le impostazioni.
                opts = _build_options()
                tokens = ["data:<embedded>"] + opts
                txt_preview.SetValue("{image: %s}" % " ".join(tokens))
            else:
                txt_preview.SetValue(_build_directive(for_insert=False))
            _update_embed_warn()

        def _on_browse(e):
            fd = wx.FileDialog(
                d,
                _("Select image"),
                default_dir,
                "",
                _("Image files (*.png;*.jpg;*.jpeg;*.gif;*.bmp;*.tiff;*.tif)|*.png;*.jpg;*.jpeg;*.gif;*.bmp;*.tiff;*.tif|All files (*.*)|*.*"),
                wx.FD_OPEN | wx.FD_FILE_MUST_EXIST,
            )
            if fd.ShowModal() == wx.ID_OK:
                path = fd.GetPath()
                # Usa solo il nome se è nella stessa cartella del documento
                if default_dir and os.path.dirname(os.path.abspath(path)) == default_dir:
                    path = os.path.basename(path)
                txt_path.SetValue(path)
            fd.Destroy()

        # ── Bind aggiornamento anteprima ─────────────────────────────────
        txt_path.Bind(wx.EVT_TEXT, _update_preview)
        for ctrl in (txt_w, txt_h, txt_scale, txt_border):
            ctrl.Bind(wx.EVT_SPINCTRLDOUBLE, _update_preview)
        for ctrl in (ch_w_unit, ch_h_unit):
            ctrl.Bind(wx.EVT_CHOICE, _update_preview)
        def _on_radio(e):
            # wx.CallAfter garantisce che GetValue() di tutti i radio button
            # sia già aggiornato quando _update_preview legge rb_left/rb_right.
            wx.CallAfter(_update_preview)
            e.Skip()
        for ctrl in (rb_left, rb_center, rb_right):
            ctrl.Bind(wx.EVT_RADIOBUTTON, _on_radio)
        cb_border.Bind(wx.EVT_CHECKBOX,
                       lambda e: (txt_border.Enable(cb_border.GetValue()), _update_preview()))
        cb_embed.Bind(wx.EVT_CHECKBOX, _update_preview)

        btn_browse.Bind(wx.EVT_BUTTON, _on_browse)

        if d.ShowModal() == wx.ID_OK:
            directive = _build_directive(for_insert=True)
            if directive != "{image: }":
                self.InsertWithCaret(directive)
        d.Destroy()

    # ------------------------------------------------------------------
    # Inserisci immagine Transposer con selezione posizione schematica
    # ------------------------------------------------------------------

    def OnInsertTransposerImage(self, evt):
        """Dialog per inserire la rappresentazione testuale del Transposer.
        Produce due {comment:} con pallini ○/● allineati alle note.

        Esempio (Gb selezionata):
            {comment: ●  ○  ○  ○  ○  ○}
            {comment: Gb  G Ab  A A♯  B}
        """

        # Note con larghezza fissa 2 caratteri per allineamento colonne
        # Note per la riga etichette (ASCII, max 2 char)
        NOTES       = [u"Gb", u"G", u"Ab", u"A", u"A♯", u"B"]
        NOTES_DISP  = [u"G♭", u"G", u"A♭", u"A", u"A♯", u"B"]
        # Simboli disponibili per il tasto premuto (scelta utente nel dialog)
        # Ogni voce: (label, char_premuto, char_libero, col_width)
        # I simboli Unicode (•, ●, ◉, ⬤, ○, ·) vengono renderizzati come double-width
        # in Courier New su Windows, ma str.center() li conta come 1 carattere.
        # Aggiungendo uno spazio dopo ogni simbolo (rendendolo 2 char) e aumentando
        # cw di 1 rispetto a prima, le due righe (pallini e note) rimangono allineate.
        # I simboli Unicode (●, ◉, ⬤, ○, •, ·) sono double-width in Courier New su Windows:
        # occupano 2 colonne tipografiche anche se Python li conta come 1 carattere.
        # _build_text usa il formato fisso " sym " (spazio + simbolo + spazio) che produce
        # 4 colonne visive indipendentemente dal conteggio Python, allineandosi a "Gb".center(4).
        # Per questo cw non è più necessario: ogni voce è solo (label, sym_premuto, sym_libero).
        BULLET_OPTIONS = [
            (u"•  (U+2022 bullet)",          u"•", u"·"),
            (u"●  (U+25CF black circle)",     u"●", u"·"),
            (u"◉  (U+25C9 fisheye)",          u"◉", u"○"),
            (u"⬤  (U+2B24 large circle)",     u"⬤", u"○"),
        ]
        # Selezione corrente (indice in BULLET_OPTIONS) — mutabile tramite _refs
        _refs = {'bullet_idx': 0}   # default: • U+2022

        # ── Carica preferenze salvate ─────────────────────────────────
        _cfg = wx.Config.Get()
        _cfg.SetPath('/Transposer')
        _saved_note  = int(_cfg.Read('noteIndex',  '3'))   # default: A (indice 3)
        _saved_pos   = int(_cfg.Read('posIndex',   '2'))   # default: cursor (indice 2)
        _saved_sym   = int(_cfg.Read('symIndex',   '0'))   # default: bullet (indice 0)
        _cfg.SetPath('/')
        # Clamp ai range validi
        _saved_note = max(0, min(_saved_note, len(NOTES) - 1))
        _saved_pos  = max(0, min(_saved_pos,  3))
        _saved_sym  = max(0, min(_saved_sym,  len(BULLET_OPTIONS) - 1))
        _refs['bullet_idx'] = _saved_sym

        # ── Callback aggiornamento anteprima (definita prima del Panel) ──
        # _refs già inizializzato sopra con bullet_idx; altri widget aggiunti dopo.

        def _build_text(idx):
            # I simboli Unicode (•, ●, ◉, ⬤, ○, ·) sono SINGLE-width in Courier New su Windows:
            # ogni colonna della riga pallini = " sym " = 1+1+1 = 3 caratteri = 3W pixel.
            # La riga delle note deve usare la stessa larghezza di colonna: cw=3.
            # Con cw=4 (come prima) la riga note era più larga (6×4=24W vs 6×3=18W),
            # causando lo spostamento progressivo verso destra delle etichette.
            _, bf, be = BULLET_OPTIONS[_refs.get('bullet_idx', 0)]
            cw = 3  # larghezza colonna = uguale alla colonna simbolo " x " (3 chars)
            row_dots = u"".join(
                u" " + (bf if i == idx else be) + u" "
                for i in range(len(NOTES))
            ).rstrip()
            row_lbls = u"".join(
                n.center(cw) for n in NOTES
            ).rstrip()
            return (
                u"{start_of_tab: TP}\n"
                u"%s\n"
                u"%s\n"
                u"{end_of_tab}"
            ) % (row_dots, row_lbls)

        def _refresh(idx):
            """Aggiorna lbl_note e txt_preview. Chiamata dal Panel via wx.CallAfter."""
            w = _refs.get('lbl_note')
            p = _refs.get('txt_preview')
            if w:
                w.SetLabel(_(u"Selected note:  ") + NOTES_DISP[idx])
            if p:
                p.SetValue(_build_text(idx))

        # ── Dialog principale ─────────────────────────────────────────
        d = wx.Dialog(
            self.frame,
            title=_(u"Insert Transposer indicator"),
            style=wx.DEFAULT_DIALOG_STYLE,
        )
        vbox = wx.BoxSizer(wx.VERTICAL)

        # ── Pannello grafico: tastiera Transposer cliccabile ──────────
        preview_box = wx.StaticBoxSizer(
            wx.StaticBox(d, label=_(u"Click the button to press on the Transposer")),
            wx.VERTICAL,
        )

        class TransposerPanel(wx.Panel):
            _NOTES_DISP = NOTES_DISP
            _BLACK      = {0, 2, 4}   # G♭, A♭, A#

            def __init__(self, parent):
                super().__init__(parent, size=(420, 155))
                self.selected = _saved_note
                self.SetBackgroundStyle(wx.BG_STYLE_PAINT)
                self.Bind(wx.EVT_PAINT, self.OnPaint)
                self.Bind(wx.EVT_LEFT_DOWN, self.OnClick)
                self.Bind(wx.EVT_MOTION, self.OnMotion)
                self.Bind(wx.EVT_LEAVE_WINDOW, self.OnLeave)
                self._hover = -1

            def _gradient_rect(self, dc, x, y, w, h, r, col_top, col_bot, border_col, border_w=1):
                """Rettangolo arrotondato con gradiente verticale corretto."""
                # Fill centrale (corpo senza le zone di raggio)
                inner_y = y + r
                inner_h = h - 2 * r
                if inner_h > 0:
                    for s in range(inner_h):
                        t = s / max(inner_h - 1, 1)
                        rc = int(col_top.Red()   + (col_bot.Red()   - col_top.Red())   * t)
                        gc = int(col_top.Green() + (col_bot.Green() - col_top.Green()) * t)
                        bc = int(col_top.Blue()  + (col_bot.Blue()  - col_top.Blue())  * t)
                        dc.SetPen(wx.Pen(wx.Colour(rc, gc, bc), 1))
                        dc.DrawLine(x + 1, inner_y + s, x + w - 1, inner_y + s)
                # Zona superiore (arrotondata): fill col_top
                dc.SetBrush(wx.Brush(col_top))
                dc.SetPen(wx.TRANSPARENT_PEN)
                dc.DrawRectangle(x + r, y, w - 2 * r, r + 1)
                # Zona inferiore: fill col_bot
                dc.SetBrush(wx.Brush(col_bot))
                dc.DrawRectangle(x + r, y + h - r - 1, w - 2 * r, r + 1)
                # Angoli arrotondati superiori
                dc.SetBrush(wx.Brush(col_top))
                dc.DrawRoundedRectangle(x, y, w, r * 2, r)
                # Angoli arrotondati inferiori
                dc.SetBrush(wx.Brush(col_bot))
                dc.DrawRoundedRectangle(x, y + h - r * 2, w, r * 2, r)
                # Bordo esterno sopra tutto
                dc.SetBrush(wx.TRANSPARENT_BRUSH)
                dc.SetPen(wx.Pen(border_col, border_w))
                dc.DrawRoundedRectangle(x, y, w, h, r)

            def _key_layout(self, W):
                n   = len(self._NOTES_DISP)
                pad = 14
                gap = 7
                kw  = (W - pad * 2 - gap * (n - 1)) // n
                x0  = (W - (kw * n + gap * (n - 1))) // 2
                return n, kw, gap, x0

            def OnPaint(self, evt):
                dc = wx.AutoBufferedPaintDC(self)
                W, H = self.GetClientSize()

                # ── Sfondo legno: gradiente caldo multi-stop + venature ──
                # Colori legno noce/mogano: chiaro in alto, medio al centro, scuro in basso
                wood_stops = [
                    (0.00, wx.Colour(138,  82,  32)),   # noce dorato in cima
                    (0.25, wx.Colour(115,  65,  22)),   # mogano medio
                    (0.55, wx.Colour( 88,  48,  14)),   # scuro caldo
                    (0.80, wx.Colour( 72,  38,  10)),   # quasi-ebano
                    (1.00, wx.Colour( 52,  26,   6)),   # base scura
                ]
                def _wood_colour(t):
                    for j in range(len(wood_stops) - 1):
                        t0, c0 = wood_stops[j]
                        t1, c1 = wood_stops[j + 1]
                        if t0 <= t <= t1:
                            f = (t - t0) / (t1 - t0)
                            return (
                                int(c0.Red()   + (c1.Red()   - c0.Red())   * f),
                                int(c0.Green() + (c1.Green() - c0.Green()) * f),
                                int(c0.Blue()  + (c1.Blue()  - c0.Blue())  * f),
                            )
                    c = wood_stops[-1][1]
                    return c.Red(), c.Green(), c.Blue()

                for row in range(H):
                    t = row / max(H - 1, 1)
                    rc, gc, bc = _wood_colour(t)
                    dc.SetPen(wx.Pen(wx.Colour(rc, gc, bc), 1))
                    dc.DrawLine(0, row, W, row)

                # Venature orizzontali sottili (legno)
                import random as _rnd
                _rnd.seed(42)   # seed fisso: venature sempre uguali
                for _ in range(18):
                    vy = _rnd.randint(2, H - 3)
                    vx1 = _rnd.randint(0, W // 4)
                    vx2 = _rnd.randint(W * 3 // 4, W)
                    t   = vy / max(H - 1, 1)
                    rc, gc, bc = _wood_colour(t)
                    alpha = _rnd.choice([18, 22, 28])
                    # schiarita o scurita aleatoria
                    if _rnd.random() > 0.5:
                        vc = wx.Colour(min(255, rc + 22), min(255, gc + 16), min(255, bc + 8))
                    else:
                        vc = wx.Colour(max(0, rc - 18), max(0, gc - 12), max(0, bc - 6))
                    dc.SetPen(wx.Pen(vc, 1))
                    dc.DrawLine(vx1, vy, vx2, vy)

                # ── Bordo pannello: filo dorato ───────────────────────
                dc.SetBrush(wx.TRANSPARENT_BRUSH)
                dc.SetPen(wx.Pen(wx.Colour(160, 108, 42), 1))
                dc.DrawRoundedRectangle(0, 0, W, H, 4)
                dc.SetPen(wx.Pen(wx.Colour(60, 32, 8), 1))
                dc.DrawRoundedRectangle(1, 1, W - 2, H - 2, 4)

                # ── Titolo TRANSPOSER ──────────────────────────────────
                # Lettera per lettera con spacing manuale per effetto "inciso"
                title_font = wx.Font(9, wx.FONTFAMILY_DEFAULT,
                                     wx.FONTSTYLE_NORMAL, wx.FONTWEIGHT_BOLD,
                                     faceName="Arial")
                dc.SetFont(title_font)
                # Spaziatura tra lettere simulata inserendo spazi sottili
                lbl_chars = u"T R A N S P O S E R"
                tw, th = dc.GetTextExtent(lbl_chars)
                tx0 = (W - tw) // 2
                ty0 = 5

                # Linee decorative laterali (segmento orizzontale dorato sottile)
                line_y   = ty0 + th // 2
                line_col = wx.Colour(100, 72, 28)
                gap_from_text = 8
                dc.SetPen(wx.Pen(line_col, 1))
                dc.DrawLine(8, line_y, tx0 - gap_from_text, line_y)
                dc.DrawLine(tx0 + tw + gap_from_text, line_y, W - 8, line_y)

                # Ombra testo
                dc.SetTextForeground(wx.Colour(8, 4, 0))
                dc.DrawText(lbl_chars, tx0 + 1, ty0 + 1)
                # Glow morbido (colore intermedio leggermente più largo)
                dc.SetTextForeground(wx.Colour(80, 155, 195))
                dc.DrawText(lbl_chars, tx0 - 1, ty0)
                dc.DrawText(lbl_chars, tx0 + 1, ty0)
                # Testo principale: bianco-azzurro luminoso
                dc.SetTextForeground(wx.Colour(195, 228, 252))
                dc.DrawText(lbl_chars, tx0, ty0)

                n, kw, gap, x0 = self._key_layout(W)
                y0 = 26
                kh = H - y0 - 8   # altezza tasto: lascia 8px di padding in basso
                r  = 10            # raggio angoli tasto

                for i, note in enumerate(self._NOTES_DISP):
                    x      = x0 + i * (kw + gap)
                    is_sel = (i == self.selected)
                    is_blk = i in self._BLACK
                    is_hov = (i == self._hover and not is_sel)
                    is_A   = (i == 3)

                    # ── Colori tasto ───────────────────────────────────
                    if is_sel:
                        ct = wx.Colour(175, 225, 255)
                        cb = wx.Colour(80, 160, 235)
                        bc = wx.Colour(10, 110, 210)
                        bw = 2
                    elif is_hov:
                        if is_blk:
                            ct = wx.Colour(95, 100, 124)
                            cb = wx.Colour(62, 65, 85)
                        else:
                            # Hover tasto chiaro: legno acero leggermente più chiaro
                            ct = wx.Colour(232, 210, 168)
                            cb = wx.Colour(195, 165, 115)
                        bc = wx.Colour(148, 105, 50)
                        bw = 1
                    elif is_blk:
                        ct = wx.Colour(75, 78, 100)
                        cb = wx.Colour(38, 40, 56)
                        bc = wx.Colour(18, 18, 36)
                        bw = 1
                    else:
                        # Legno chiaro: acero/frassino — caldo giallo-avorio in cima,
                        # ambra dorata in basso
                        ct = wx.Colour(220, 195, 148)   # acero chiaro
                        cb = wx.Colour(175, 140,  88)   # ambra dorata
                        bc = wx.Colour(130,  90,  38)   # bordo noce medio
                        bw = 1

                    if is_A and not is_sel:
                        bc = wx.Colour(210, 45, 45)
                        bw = 2

                    # ── Ombra portante ─────────────────────────────────
                    dc.SetBrush(wx.Brush(wx.Colour(0, 0, 0)))
                    dc.SetPen(wx.TRANSPARENT_PEN)
                    dc.DrawRoundedRectangle(x + 3, y0 + 4, kw, kh, r)

                    # ── Corpo tasto con gradiente ──────────────────────
                    self._gradient_rect(dc, x, y0, kw, kh, r, ct, cb, bc, bw)

                    # ── Shine: striscia lucida sottile solo in cima ────
                    shine_h = max(3, kh // 6)
                    shine_c = wx.Colour(
                        min(255, ct.Red() + 40),
                        min(255, ct.Green() + 38),
                        min(255, ct.Blue() + 30),
                    )
                    dc.SetBrush(wx.Brush(shine_c))
                    dc.SetPen(wx.TRANSPARENT_PEN)
                    # Solo nei pixel centrali (evita di coprire le curve del bordo)
                    dc.DrawRectangle(x + r, y0 + 2, kw - 2 * r, shine_h)

                    # ── Indicatore circolare (centro del tasto) ────────
                    cx = x + kw // 2
                    # Posizione verticale: zona centrale, sopra all'etichetta
                    label_reserve = 36   # spazio riservato in basso per il testo grande
                    cy = y0 + (kh - label_reserve) // 2
                    if is_sel:
                        dc.SetBrush(wx.Brush(wx.Colour(15, 70, 160)))
                        dc.SetPen(wx.Pen(wx.Colour(0, 35, 100), 1))
                        dc.DrawCircle(cx, cy, 9)
                        dc.SetBrush(wx.Brush(wx.Colour(55, 135, 235)))
                        dc.SetPen(wx.TRANSPARENT_PEN)
                        dc.DrawCircle(cx, cy, 6)
                        dc.SetBrush(wx.Brush(wx.Colour(190, 225, 255)))
                        dc.DrawCircle(cx - 2, cy - 2, 2)
                    else:
                        ring_c = (wx.Colour(105, 108, 132) if is_blk
                                  else wx.Colour(155, 158, 178))
                        if is_hov:
                            ring_c = wx.Colour(185, 190, 215)
                        dc.SetBrush(wx.TRANSPARENT_BRUSH)
                        dc.SetPen(wx.Pen(ring_c, 1))
                        dc.DrawCircle(cx, cy, 7)

                    # ── Etichetta nota: font grande, alto contrasto ────
                    # 22pt per note singole (G, A, B), 18pt per doppie (G♭, A♭, A♯)
                    fs = 22 if len(note) == 1 else 18
                    note_font = wx.Font(fs, wx.FONTFAMILY_DEFAULT,
                                        wx.FONTSTYLE_NORMAL, wx.FONTWEIGHT_BOLD,
                                        faceName="Arial")
                    dc.SetFont(note_font)
                    tw, th = dc.GetTextExtent(note)
                    tx = x + (kw - tw) // 2
                    ty = y0 + kh - th - 5

                    if is_sel:
                        # Ombra scura
                        dc.SetTextForeground(wx.Colour(0, 25, 70))
                        dc.DrawText(note, tx + 1, ty + 1)
                        # Testo blu scuro ben leggibile sul tasto chiaro
                        dc.SetTextForeground(wx.Colour(0, 50, 130))
                    elif is_blk:
                        # Testo bianco su tasto scuro: massimo contrasto
                        dc.SetTextForeground(wx.Colour(230, 234, 250))
                    else:
                        # Testo marrone scuro su tasto legno chiaro: alto contrasto
                        dc.SetTextForeground(wx.Colour(48, 24, 6))
                    dc.DrawText(note, tx, ty)

            def _hit_index(self, mx):
                W, _ = self.GetClientSize()
                n, kw, gap, x0 = self._key_layout(W)
                for i in range(n):
                    xi = x0 + i * (kw + gap)
                    if xi <= mx < xi + kw:
                        return i
                return -1

            def OnMotion(self, evt):
                idx = self._hit_index(evt.GetX())
                if idx != self._hover:
                    self._hover = idx
                    self.Refresh()
                evt.Skip()

            def OnLeave(self, evt):
                if self._hover != -1:
                    self._hover = -1
                    self.Refresh()
                evt.Skip()

            def OnClick(self, evt):
                idx = self._hit_index(evt.GetX())
                if 0 <= idx < len(self._NOTES_DISP):
                    self.selected = idx
                    self.Refresh()
                    wx.CallAfter(_refresh, idx)

            def GetIndex(self):
                return self.selected

        tp = TransposerPanel(d)
        preview_box.Add(tp, 0, wx.ALL | wx.EXPAND, 6)

        lbl_note = wx.StaticText(d, label=_(u"Selected note:  ") + NOTES_DISP[_saved_note])
        lbl_note.SetForegroundColour(wx.Colour(0, 80, 160))
        preview_box.Add(lbl_note, 0, wx.LEFT | wx.BOTTOM, 8)
        vbox.Add(preview_box, 0, wx.EXPAND | wx.ALL, 8)

        # ── Posizione nel documento ───────────────────────────────────
        pos_box = wx.StaticBoxSizer(
            wx.StaticBox(d, label=_(u"Position in document")),
            wx.VERTICAL,
        )
        positions = [
            ('before_title', _(u"Before title"),
             u"\u250c\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2510\n"
             u"\u2502  [\u25cb \u25cf \u25cb]       \u2502\n"
             u"\u2502  Title           \u2502\n"
             u"\u2502  Verse...        \u2502\n"
             u"\u2514\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2518"),
            ('after_title',  _(u"After title"),
             u"\u250c\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2510\n"
             u"\u2502  Title           \u2502\n"
             u"\u2502  [\u25cb \u25cf \u25cb]       \u2502\n"
             u"\u2502  Verse...        \u2502\n"
             u"\u2514\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2518"),
            ('cursor',       _(u"At cursor position"),
             u"\u250c\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2510\n"
             u"\u2502  Title           \u2502\n"
             u"\u2502  Verse...        \u2502\n"
             u"\u2502\u25ba [\u25cb \u25cf \u25cb]       \u2502\n"
             u"\u2514\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2518"),
            ('end_of_song',  _(u"End of song"),
             u"\u250c\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2510\n"
             u"\u2502  Title           \u2502\n"
             u"\u2502  Verse...        \u2502\n"
             u"\u2502  [\u25cb \u25cf \u25cb]       \u2502\n"
             u"\u2514\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2518"),
        ]

        rb_group = []
        pos_grid = wx.GridSizer(cols=2, hgap=12, vgap=4)
        for i, (pos_id, pos_lbl, _schema) in enumerate(positions):
            style = wx.RB_GROUP if i == 0 else 0
            rb = wx.RadioButton(d, label=pos_lbl, style=style)
            rb._pos_id = pos_id
            rb._schema = _schema
            rb_group.append(rb)
            pos_grid.Add(rb, 0, wx.ALIGN_CENTER_VERTICAL)
        pos_box.Add(pos_grid, 0, wx.ALL, 6)

        lbl_schema = wx.StaticText(d, label="", style=wx.ST_NO_AUTORESIZE)
        lbl_schema.SetFont(wx.Font(8, wx.FONTFAMILY_TELETYPE,
                                   wx.FONTSTYLE_NORMAL, wx.FONTWEIGHT_NORMAL))
        lbl_schema.SetForegroundColour(wx.Colour(55, 80, 55))
        pos_box.Add(lbl_schema, 0, wx.LEFT | wx.BOTTOM, 8)
        vbox.Add(pos_box, 0, wx.EXPAND | wx.LEFT | wx.RIGHT | wx.BOTTOM, 8)

        def _update_schema(e=None):
            for rb in rb_group:
                if rb.GetValue():
                    lbl_schema.SetLabel(rb._schema)
                    d.Layout()
                    break
        for rb in rb_group:
            rb.Bind(wx.EVT_RADIOBUTTON, _update_schema)
        rb_group[_saved_pos].SetValue(True)
        _update_schema()

        # ── Selezione simbolo tasto premuto ──────────────────────────
        sym_box = wx.StaticBoxSizer(
            wx.StaticBox(d, label=_(u"Symbol for pressed key")),
            wx.VERTICAL,
        )
        sym_grid = wx.GridSizer(rows=2, cols=2, hgap=8, vgap=4)
        sym_rbs = []
        for i, (lbl, _bf, _be) in enumerate(BULLET_OPTIONS):
            style = wx.RB_GROUP if i == 0 else 0
            rb_s = wx.RadioButton(d, label=_(lbl), style=style)
            rb_s.SetFont(wx.Font(9, wx.FONTFAMILY_TELETYPE,
                                 wx.FONTSTYLE_NORMAL, wx.FONTWEIGHT_NORMAL))
            sym_rbs.append(rb_s)
            sym_grid.Add(rb_s, 0, wx.ALIGN_CENTER_VERTICAL)
        sym_rbs[_saved_sym].SetValue(True)
        sym_box.Add(sym_grid, 0, wx.ALL, 4)
        vbox.Add(sym_box, 0, wx.EXPAND | wx.LEFT | wx.RIGHT | wx.BOTTOM, 8)

        def _on_sym(e=None):
            for i, rb_s in enumerate(sym_rbs):
                if rb_s.GetValue():
                    _refs['bullet_idx'] = i
                    break
            # aggiorna anteprima
            p = _refs.get('txt_preview')
            if p:
                p.SetValue(_build_text(tp.GetIndex()))
        for rb_s in sym_rbs:
            rb_s.Bind(wx.EVT_RADIOBUTTON, _on_sym)

        # ── Anteprima testo che verrà inserito ────────────────────────
        vbox.Add(wx.StaticLine(d), 0, wx.EXPAND | wx.LEFT | wx.RIGHT, 8)
        vbox.Add(wx.StaticText(d, label=_(u"Text preview (inserted in document):")),
                 0, wx.LEFT | wx.TOP, 8)
        txt_preview = wx.TextCtrl(
            d, style=wx.TE_READONLY | wx.TE_MULTILINE | wx.TE_NO_VSCROLL,
            size=(400, 92),
        )
        txt_preview.SetFont(wx.Font(9, wx.FONTFAMILY_TELETYPE,
                                    wx.FONTSTYLE_NORMAL, wx.FONTWEIGHT_NORMAL))
        txt_preview.SetBackgroundColour(
            wx.SystemSettings.GetColour(wx.SYS_COLOUR_BTNFACE))
        vbox.Add(txt_preview, 0, wx.EXPAND | wx.LEFT | wx.RIGHT | wx.BOTTOM, 8)

        btn_sizer = d.CreateButtonSizer(wx.OK | wx.CANCEL)
        vbox.Add(btn_sizer, 0, wx.ALL | wx.ALIGN_RIGHT, 8)
        d.SetSizer(vbox)
        vbox.Fit(d)
        # Forza un'altezza minima totale leggermente maggiore
        cur_w, cur_h = d.GetSize()
        d.SetMinSize(wx.Size(cur_w, cur_h))
        d.SetSize(wx.Size(cur_w, cur_h))

        # Popola _refs ora che tutti i widget esistono, poi inizializza
        _refs['lbl_note']   = lbl_note
        _refs['txt_preview'] = txt_preview
        _refresh(tp.GetIndex())

        if d.ShowModal() != wx.ID_OK:
            d.Destroy()
            return

        text_to_insert = _build_text(tp.GetIndex())

        # ── Salva preferenze in wx.Config ────────────────────────────
        _pos_idx = next((i for i, rb in enumerate(rb_group) if rb.GetValue()), 2)
        _sym_idx = _refs.get('bullet_idx', 0)
        _cfg2 = wx.Config.Get()
        _cfg2.SetPath('/Transposer')
        _cfg2.Write('noteIndex', str(tp.GetIndex()))
        _cfg2.Write('posIndex',  str(_pos_idx))
        _cfg2.Write('symIndex',  str(_sym_idx))
        _cfg2.SetPath('/')
        _cfg2.Flush()

        d.Destroy()

        # ── Inserimento nella posizione scelta ────────────────────────
        def _get_selected_pos():
            for rb in rb_group:
                if rb.GetValue():
                    return rb._pos_id
            return 'cursor'

        pos   = _get_selected_pos()
        stc   = self.text
        orig  = stc.GetCurrentPos()
        block = text_to_insert + u"\n"

        if pos == 'cursor':
            self.InsertWithCaret(block)

        elif pos == 'before_title':
            stc.InsertText(0, block)
            stc.GotoPos(orig + len(block.encode('utf-8')))

        elif pos == 'after_title':
            import re as _re
            text_all = stc.GetText()
            m = _re.search(r'\{(?:title|t)\s*:[^}]*\}', text_all, _re.IGNORECASE)
            if m:
                insert_at = m.end()
                if insert_at < len(text_all) and text_all[insert_at] == '\n':
                    insert_at += 1
                stc.InsertText(insert_at, block)
                stc.GotoPos(orig + len(block.encode('utf-8')))
            else:
                stc.InsertText(0, block)
                stc.GotoPos(orig + len(block.encode('utf-8')))

        elif pos == 'end_of_song':
            text_all     = stc.GetText()
            stripped_end = len(text_all.rstrip())
            stc.InsertText(stripped_end, u"\n" + text_to_insert)
            stc.GotoPos(stripped_end + len((u"\n" + text_to_insert).encode('utf-8')))


    def AddTool(self, toolbar, resource_string, icon_path, label, help):
        tool = wx.xrc.XRCID(resource_string)
        toolbar.AddTool(
            tool,
            label,
            wx.Bitmap(wx.Image(glb.AddPath(icon_path))),
            wx.NullBitmap,
            wx.ITEM_NORMAL,
            label,
            help,
            None
        )
        return tool

    def New(self):
        self.text.AutoChangeMode(True)
        self.text.New()
        self.text.AutoChangeMode(False)
        self.UpdateEverything()

    def Open(self):
        self.text.AutoChangeMode(True)
        self.text.Open()
        self.text.AutoChangeMode(False)
        self.UpdateEverything()
        self.AutoAdjust(0, self.text.GetLength())

    def Save(self):
        self.text.Save()
        # UpdateEverything() viene chiamato da SDIMainFrame.SaveFile() tramite Save(),
        # ma a quel punto self.modified è ancora True (viene azzerato subito dopo da
        # SaveFile()). Usiamo wx.CallAfter per posticipare l'aggiornamento dell'UI
        # al momento in cui self.modified è già False, così il pulsante Salva
        # viene disabilitato correttamente con un solo salvataggio.
        wx.CallAfter(self.UpdateEverything)

    def SavePreferences(self):
        self.pref.Save()

    def UpdateUndoRedo(self):
        can_undo = self.text.CanUndo()
        can_redo = self.text.CanRedo()
        self.mainToolBar.EnableTool(self.undoTool, can_undo)
        self.mainToolBar.EnableTool(self.redoTool, can_redo)
        self.menuBar.Enable(self.undoMenuId, can_undo)
        self.menuBar.Enable(self.redoMenuId, can_redo)

    def UpdateCutCopyPaste(self):
        s, e = self.text.GetSelection()
        self.mainToolBar.EnableTool(self.cutTool, s != e)
        self.menuBar.Enable(self.cutMenuId, s != e)
        self.mainToolBar.EnableTool(self.copyTool, s != e)
        self.menuBar.Enable(self.copyOnlyTextTool, s != e)
        self.menuBar.Enable(self.copyMenuId, s != e)
        if platform.system() == 'Windows':
            cp = self.text.CanPaste()
        else:
            # Workaround for weird error in wxGTK
            cp = True
        self.mainToolBar.EnableTool(self.pasteTool, cp)
        self.menuBar.Enable(self.pasteMenuId, cp)
        self.mainToolBar.EnableTool(self.pasteChordsTool, cp)
        self.menuBar.Enable(self.pasteChordsMenuId, cp)
        self.menuBar.Enable(self.removeChordsMenuId, s != e)

    @staticmethod
    def _strip_hash_commands(text):
        """
        Rimuove le righe della forma  # {comando}  (con spazi opzionali),
        es.  # {new_page}  # {linespacing: 13}  #{np}
        Tali righe non devono comparire ne nell'anteprima ne in stampa.
        Le normali righe di commento libero  # testo  vengono lasciate invariate.
        """
        import re
        pattern = re.compile(r'^\s*#\s*\{[^}]*\}\s*$')
        lines = text.split('\n')
        filtered = [l for l in lines if not pattern.match(l)]
        return '\n'.join(filtered)

    def _get_display_text(self, ignore_selection=False):
        """Restituisce il testo del documento con i comandi # {...} rimossi.
        Se è attiva una selezione (non vuota e non multiriga singola-selezione
        col cursore), restituisce solo il testo selezionato, così l'anteprima
        mostra esattamente ciò che verrà stampato.
        Aggiorna anche la directory del documento nel renderer, in modo che
        i percorsi relativi di {image: ...} vengono risolti correttamente.
        Quando showChords == 0 (Nessun accordo) e le relative preferenze sono
        attive, rimuove anche i blocchi {start_chord}, {start_bridge},
        {start_of_grid} con il loro contenuto.

        ignore_selection=True: usa sempre il testo completo del documento,
        ignorando la selezione corrente. Da usare quando il refresh è causato
        da una modifica alle opzioni (e non da una selezione volontaria
        dell'utente), per evitare che una selezione residua da Trova/Sostituisci
        faccia mostrare nell'anteprima solo il testo trovato.
        """
        self.previewCanvas.SetDocumentDir(self.document)
        start, end = self.text.GetSelection()
        if not ignore_selection and start != end:
            raw = self.text.GetTextRange(start, end)
        else:
            raw = self.text.GetText()
        text = self._strip_hash_commands(raw)
        if getattr(self.pref.format, 'showChords', 2) == 0:
            text = self._strip_nochords_blocks(text)
        return text

    def _strip_nochords_blocks(self, text):
        """Rimuove dal testo i blocchi paired la cui checkbox e' attiva
        nelle preferenze 'Nessun accordo'.
        Usa un approccio linea-per-linea per evitare backtracking catastrofico.

        Blocchi gestiti:
            hideIntroChord : {start_chord}  ... {end_chord}
            hideBridge     : {start_bridge} / {start_of_bridge} ... {end_bridge}
            hideGrid       : {start_of_grid} / {sog} / {grid} ... {end_of_grid}
            hideTempo      : {tempo_m} / {tempo_s} / {tempo_sp} / {tempo_c} / {tempo_cp}
            hideTime       : {time}
        """
        import re

        # Costruisce i set di tag di apertura e chiusura da rimuovere
        open_tags  = set()
        close_tags = set()

        if getattr(self.pref, 'hideIntroChord', False):
            open_tags.add('start_chord')
            close_tags.add('end_chord')
        if getattr(self.pref, 'hideBridge', False):
            open_tags.update(('start_bridge', 'start_of_bridge', 'sob'))
            close_tags.update(('end_bridge', 'end_of_bridge'))
        if getattr(self.pref, 'hideGrid', False):
            open_tags.update(('start_of_grid', 'sog', 'grid'))
            close_tags.add('end_of_grid')

        # Tag singoli (direttive non-paired) da rimuovere riga per riga
        single_tags = set()
        if getattr(self.pref, 'hideTempo', False):
            single_tags.update(('tempo_m', 'tempo_s', 'tempo_sp', 'tempo_c', 'tempo_cp'))
        if getattr(self.pref, 'hideTime', False):
            single_tags.add('time')

        if not open_tags and not single_tags:
            return text

        # Regex che riconosce qualsiasi direttiva ChordPro: {tag} o {tag:label}
        _tag_re = re.compile(r'\{(\w+)(?:[:/][^}]*)?\}', re.IGNORECASE)

        result = []
        inside = False  # True quando siamo dentro un blocco da rimuovere
        depth  = 0      # conta aperture annidate dello stesso tipo (raro ma sicuro)

        for line in text.splitlines(keepends=True):
            m = _tag_re.search(line)
            tag = m.group(1).lower() if m else None

            if not inside:
                if tag in open_tags:
                    inside = True
                    depth = 1
                    # la riga di apertura viene scartata
                elif tag in single_tags:
                    pass  # riga con direttiva singola viene scartata
                else:
                    result.append(line)
            else:
                if tag in open_tags:
                    depth += 1          # apertura annidata (ignorata)
                elif tag in close_tags:
                    depth -= 1
                    if depth <= 0:
                        inside = False  # riga di chiusura viene scartata
                # tutte le righe interne al blocco vengono scartate

        return ''.join(result)

    def UpdateSave(self):
        """Abilita/disabilita il pulsante e la voce di menu Save in base allo stato
        'modified' e alla preferenza enableSaveOnModified."""
        try:
            enable_only_when_modified = getattr(self.pref, 'enableSaveOnModified', True)
            if enable_only_when_modified:
                is_modified = getattr(self, 'modified', False)
            else:
                is_modified = True   # sempre abilitato
            self.mainToolBar.EnableTool(self.saveTool, is_modified)
            if hasattr(self, 'saveMenuId'):
                self.menuBar.Enable(self.saveMenuId, is_modified)
            self.mainToolBar.Refresh()
        except Exception:
            pass

    def UpdateEverything(self):
        self.UpdateUndoRedo()
        self.UpdateCutCopyPaste()
        self.UpdateSave()

    def TextUpdated(self):
        self.previewCanvas.Refresh(self._get_display_text())

    # self.UpdateEverything()

    def DrawOnDC(self, dc):
        """
        Draw song on DC and return the tuple (width, height) of rendered song
        """
        if self.pref.labelVerses:
            import copy
            decorator = copy.copy(self.pref.decorator)
        else:
            decorator = SongDecorator()
        decorator.showKlavier = True
        decorator.showGuitarDiagrams = True
        decorator.exportMode = False
        decorator.showPageBreakLines = getattr(self, '_showPageBreakLines', True)
        decorator.showColumnBreakLines = getattr(self, '_showColumnBreakLines', True)
        decorator.showDurationBeats      = getattr(self, '_showDurationBeats', True)
        decorator.durationBeatsColourHex = getattr(self.pref, 'durationBeatsColourHex', '#6464C8')
        decorator.durationBeatsSizePct   = getattr(self.pref, 'durationBeatsSizePct', 60)
        decorator.durationBeatsBold      = getattr(self.pref, 'durationBeatsBold', False)
        decorator.durationBeatsAlign     = getattr(self.pref, 'durationBeatsAlign', 'right')
        decorator.durationBeatsMode     = getattr(self.pref, 'durationBeatsMode', 'number')
        decorator.klavierHighlightColor = self._getKlavierHighlightColour()
        decorator.fingerNumColor = self._getFingerNumColour()
        r = Renderer(self.pref.format, decorator, self.pref.notations)
        r.tempoDisplay = getattr(self.pref, 'tempoDisplay', 0)
        r.timeDisplay = getattr(self.pref, 'timeDisplay', True)
        r.keyDisplay = getattr(self.pref, 'keyDisplay', True)
        r.tempoIconSize = getattr(self.pref, 'tempoIconSize', 24)
        r.gridDisplayMode = getattr(self.pref, 'gridDisplayMode', 'pipe')
        r.gridDefaultLabel = getattr(self.pref, 'gridDefaultLabel', None)
        r.gridSizeDir = getattr(self.pref, 'gridSizeDir', 'both')
        # oppure rileva automaticamente {column_break} nel testo (come fa PreviewCanvas).
        import re
        song_text = self._strip_hash_commands(self.text.GetText())
        columns = getattr(self, '_columns_per_page', 1)
        if columns < 2:
            has_col_break = bool(re.search(r'\{\s*(?:column_break|colb)\s*\}', song_text, re.IGNORECASE))
            if has_col_break:
                columns = 2
        r.columns = columns
        r.columnHeight = 0  # nessun limite di altezza per colonna nell'export
        start, end = self.text.GetSelection()
        if start == end:
            w, h = r.Render(song_text, dc)
        else:
            w, h = r.Render(song_text, dc, self.text.LineFromPosition(start), self.text.LineFromPosition(end))
        return w, h

    def AskExportFileName(self, type, ext):
        """Ask the filename (without saving); return None if user cancels, the file name ow"""
        leave = False;
        consensus = False;
        while not leave:
            dlg = wx.FileDialog(
                self.frame,
                "Choose a name for the output file",
                "",
                os.path.splitext(self.document)[0],
                "%s files (*.%s)|*.%s|All files (*.*)|*.*" % (type, ext, ext),
                wx.FD_SAVE
            )

            if dlg.ShowModal() == wx.ID_OK:

                fn = dlg.GetPath()
                if os.path.isfile(fn):
                    msg = "File \"%s\" already exists. Do you want to overwrite it?" % (fn,)
                    d = wx.MessageDialog(
                        self.frame,
                        msg,
                        self.appLongName,
                        wx.YES_NO | wx.CANCEL | wx.ICON_QUESTION
                    )
                    res = d.ShowModal()
                    if res == wx.ID_CANCEL:
                        leave = True
                        consensus = False
                    elif res == wx.ID_NO:
                        leave = False
                        consensus = False
                    else:  # wxID_YES
                        leave = True
                        consensus = True
                else:
                    leave = True
                    consensus = True

            else:
                leave = True
                consensus = False

        if consensus:
            return fn
        else:
            return None

    def ComputeRenderedSize(self):
        """
        Compute and return rendered size as tuple (with, height)
        """
        dc = wx.MemoryDC(wx.Bitmap(1, 1))
        w, h = self.DrawOnDC(dc)
        return max(1, w), max(1, h)

    def RenderAsPng(self, scale=1, size=None):
        if size is None:
            size = self.ComputeRenderedSize()
        w, h = size
        b = wx.Bitmap(int(w * scale), int(h * scale))
        dc = wx.MemoryDC(b)
        dc.SetUserScale(scale, scale)
        dc.SetBackground(wx.WHITE_BRUSH)
        dc.Clear()
        self.DrawOnDC(dc)
        return b

    def OnExportAsPng(self, evt):
        n = self.AskExportFileName(_("PNG image"), "png")
        if n is not None:
            b = self.RenderAsPng()
            i = b.ConvertToImage()
            i.SaveFile(n, wx.BITMAP_TYPE_PNG)

    def OnExportAsHtml(self, evt):
        n = self.AskExportFileName(_("HTML file"), "html")
        if n is not None:
            h = HtmlExporter(self.pref.format)
            r = Renderer(self.pref.format, h, self.pref.notations)
            start, end = self.text.GetSelection()
            display_text = self._strip_hash_commands(self.text.GetText())
            if start == end:
                r.Render(display_text, None)
            else:
                r.Render(display_text, None, self.text.LineFromPosition(start), self.text.LineFromPosition(end))
            with open(n, "w", encoding='utf-8') as f:
                f.write(h.getHtml())

    def OnExportAsTab(self, evt):
        n = self.AskExportFileName(_("TAB file"), "tab")
        if n is not None:
            t = TabExporter(self.pref.format)
            r = Renderer(self.pref.format, t, self.pref.notations)
            start, end = self.text.GetSelection()
            display_text = self._strip_hash_commands(self.text.GetText())
            if start == end:
                r.Render(display_text, None)
            else:
                r.Render(display_text, None, self.text.LineFromPosition(start), self.text.LineFromPosition(end))
            with open(n, "w", encoding='utf-8') as f:
                f.write(t.getTab())

    def SaveSvg(self, filename, size=None):
        if size is None:
            size = self.ComputeRenderedSize()
        w, h = size
        dc = wx.SVGFileDC(filename, int(w), int(h))
        self.DrawOnDC(dc)

    def OnExportAsSvg(self, evt):
        n = self.AskExportFileName(_("SVG image"), "svg")
        if n is not None:
            self.SaveSvg(n)

    def OnExportAsEmf(self, evt):
        n = self.AskExportFileName(_("Enhanced Metafile"), "emf")
        if n is not None:
            dc = wx.msw.MetafileDC(n)
            self.DrawOnDC(dc)
            dc.Close()

    def OnExportAsEps(self, evt):
        n = self.AskExportFileName(_("EPS image"), "eps")
        if n is not None:
            pd = wx.PrintData()
            pd.SetPaperId(wx.PAPER_NONE)
            pd.SetPrintMode(wx.PRINT_MODE_FILE)
            pd.SetFilename(n)
            dc = wx.PostScriptDC(pd)
            dc.StartDoc(_("Exporting image as EPS..."))
            self.DrawOnDC(dc)
            dc.EndDoc()

    def OnExportAsPdf(self, evt):
        """Esporta la canzone come PDF. Delega a PdfExporter."""
        # Prima chiedi le impostazioni di pagina
        data = wx.PageSetupDialogData(self._print_data)
        data.SetMarginTopLeft(wx.Point(self._margin_left, self._margin_top))
        data.SetMarginBottomRight(wx.Point(self._margin_right, self._margin_bottom))
        dlg = wx.PageSetupDialog(self.frame, data)
        if dlg.ShowModal() != wx.ID_OK:
            dlg.Destroy()
            return
        result = dlg.GetPageSetupData()
        self._print_data = wx.PrintData(result.GetPrintData())
        tl = result.GetMarginTopLeft()
        br = result.GetMarginBottomRight()
        self._margin_left   = tl.x
        self._margin_top    = tl.y
        self._margin_right  = br.x
        self._margin_bottom = br.y
        dlg.Destroy()

        n = self.AskExportFileName(_("PDF"), "pdf")
        if n is None:
            return
        if not n.lower().endswith('.pdf'):
            n += '.pdf'
        title = os.path.splitext(os.path.basename(self.document))[0] if self.document else _("Song")
        PdfExporter.export_as_pdf(self, n, title)

    def OnSongbook(self, evt):
        """Crea un Songbook PDF da una cartella di brani."""
        SongbookExporter.create_songbook(self, self.frame)

    def OnCanzonatore(self, evt):
        """Unisce più file ChordPro in un unico file (Canzonatore)."""
        CanzonatorDialog.open_canzonatore(self, self.frame)

    def OnExportAsPptx(self, evt):
        try:
            from . import songimpress
        except ImportError:
            msg = _("Please install the python-pptx module to use this feature")
            d = wx.MessageDialog(self.frame, msg, "Songpress++", wx.OK | wx.ICON_ERROR)
            d.ShowModal()
            return
        text = replaceTitles(self.text.GetTextOrSelection(), '---')
        text = removeChordPro(text).strip()
        if text != '':
            template_rel = os.path.join('templates', 'slides')
            template_paths = [f for f in glb.ListLocalGlobalDir(template_rel) if f[-5:].upper() == '.PPTX']
            template_names = [os.path.split(f)[1][:-5] for f in template_paths]
            mld = MyListDialog(
                self.frame,
                _("Please select a template for your PowerPoint presentation:"),
                _("Export as PowerPoint"),
                template_names,
            )
            if mld.ShowModal() == wx.ID_OK:
                output_file = self.AskExportFileName(_("PPTX presentation"), "pptx")
                if output_file is not None:
                    i = mld.GetSelectedIndex()
                    songimpress.to_presentation(text.splitlines(), output_file, template_paths[i])

    def OnUpdateUI(self, evt):
        self.UpdateEverything()
        evt.Skip()

    def OnUndo(self, evt):
        if self.text.CanUndo():
            self.text.Undo()
            self.UpdateUndoRedo()

    def OnRedo(self, evt):
        if self.text.CanRedo():
            self.text.Redo()
            self.UpdateUndoRedo()

    def OnCut(self, evt):
        self.text.Cut()

    def OnTextCutCopy(self, evt):
        self.UpdateCutCopyPaste()
        evt.Skip()

    def OnTextKeyDown(self, evt):
        # 314: left
        # 316: right
        map = {
            (314, True, True, False): self.MoveChordLeft,
            (316, True, True, False): self.MoveChordRight,
            (ord('D'), False, False, True): self.CopyAsImage,
        }
        tp = (
            evt.GetKeyCode(),
            evt.ShiftDown(),
            evt.AltDown(),
            evt.ControlDown(),
        )

        # Ctrl+Space → intellisense direttive ChordPro
        if tp == (wx.WXK_SPACE, False, False, True):
            if getattr(self.pref, 'intellisense', True):
                self._ShowDirectiveIntellisense()
            evt.Skip(False)
            return

        # Dentro {start_of_grid}: Alt+Shift+← / → spostano la cella del grid
        if tp == (314, True, True, False):
            if self._GetGridContext() is not None:
                self._MoveGridCellLeft()
                evt.Skip(False)
                return
        if tp == (316, True, True, False):
            if self._GetGridContext() is not None:
                self._MoveGridCellRight()
                evt.Skip(False)
                return

        if (method := map.get(tp)) is not None:
            method()
            evt.Skip(False)
        else:
            evt.Skip()

    # ── Lista completa delle direttive ChordPro supportate da Songpress++ ──
    # Direttive proprietarie di Songpress++ (non standard ChordPro)
    # Direttive NON presenti nella specifica ufficiale chordpro.org → icona 🔧
    # Fonte: https://www.chordpro.org/chordpro/chordpro-directives/
    _SONGPRESSPLUSPLUS_DIRECTIVES = ChordProDirectives.SPPLUSPLUS_DIRECTIVES

    # ID immagine per AutoComp (Scintilla RegisterImage)
    # Tipo 1 -> icona verde "✅" = direttiva ChordPro standard ufficiale
    # Tipo 2 -> icona arancione "🔧" = direttiva esclusiva Songpress++
    _AUTOCOMP_IMG_CHORDPRO   = 1
    _AUTOCOMP_IMG_SPPLUSPLUS = 2

    def _RegisterIntellisenseImages(self):
        """Registra le icone 16x16 usate nel popup intellisense.

        Tipo 1 -> ✅ sfondo verde   = direttiva ChordPro ufficiale
                     (fonte: chordpro.org/chordpro/chordpro-directives/)
        Tipo 2 -> 🔧 sfondo arancione = direttiva esclusiva Songpress++
        """
        def _make_icon(label, bg, fg):
            """Crea bitmap 16x16 con label centrata (supporta emoji Unicode)."""
            bmp = wx.Bitmap(16, 16, 32)
            dc = wx.MemoryDC(bmp)
            dc.SetBackground(wx.Brush(wx.Colour(*bg)))
            dc.Clear()
            dc.SetTextForeground(wx.Colour(*fg))
            # Font leggermente più piccolo per lasciare spazio alle emoji
            font = wx.Font(wx.FontInfo(8).FaceName('Segoe UI Emoji')
                           if wx.Platform == '__WXMSW__'
                           else wx.FontInfo(8))
            dc.SetFont(font)
            tw, th = dc.GetTextExtent(label)
            dc.DrawText(label, max(0, (16 - tw) // 2), max(0, (16 - th) // 2))
            dc.SelectObject(wx.NullBitmap)
            return bmp

        # ✅ verde scuro su bianco — ChordPro ufficiale
        img_cp = _make_icon(u'\u2705', bg=(235, 250, 235), fg=(30, 130, 30))
        # 🔧 chiave su arancione chiaro — Songpress++ esclusivo
        img_sp = _make_icon(u'\U0001F527', bg=(255, 240, 220), fg=(180, 90, 0))
        self.text.RegisterImage(self._AUTOCOMP_IMG_CHORDPRO,   img_cp)
        self.text.RegisterImage(self._AUTOCOMP_IMG_SPPLUSPLUS, img_sp)

    # Lista completa direttive mostrate nell'intellisense → ChordProDirectives.py
    _CHORDPRO_DIRECTIVES = ChordProDirectives.DIRECTIVES

    def _ShowDirectiveIntellisense(self):
        """Mostra il popup di completamento direttive ChordPro (Ctrl+Space).

        Logica:
        - Legge il testo della riga corrente dal primo carattere fino al cursore.
        - Se trova una '{' aperta (senza '}' successiva), estrae il prefisso
          digitato dopo '{' (solo la parte prima di ':' o ' ').
        - Filtra _CHORDPRO_DIRECTIVES con quel prefisso (case-insensitive).
        - Chiama AutoCompShow() con le corrispondenze ordinate.
        - Se la lista è già attiva (l'utente ha già aperto il popup), la aggiorna.
        """
        stc = self.text

        # Se c'è già un autocomplete attivo, lo chiudiamo per riaprirlo aggiornato
        if stc.AutoCompActive():
            stc.AutoCompCancel()

        pos      = stc.GetCurrentPos()
        line_num = stc.LineFromPosition(pos)
        line_start = stc.PositionFromLine(line_num)
        # Testo dalla riga fino alla posizione cursore
        text_before = stc.GetTextRange(line_start, pos)

        # Cerchiamo l'ultima '{' non chiusa nel testo prima del cursore
        brace_pos = text_before.rfind('{')
        if brace_pos == -1:
            # Nessuna parentesi graffa: mostriamo tutte le direttive
            prefix = ''
            typed_len = 0
        else:
            after_brace = text_before[brace_pos + 1:]
            # Se c'è già una '}' dopo l'ultima '{', siamo fuori da una direttiva
            if '}' in after_brace:
                prefix = ''
                typed_len = 0
            else:
                # Il prefisso è quello digitato dopo '{', fino a ':' o spazio
                prefix = after_brace.split(':')[0].split(' ')[0]
                typed_len = len(prefix)

        # Filtra la lista (case-insensitive)
        prefix_lower = prefix.lower()
        matches = sorted(
            d for d in self._CHORDPRO_DIRECTIVES
            if d.startswith(prefix_lower)
        )

        if not matches:
            return

        # Aggiunge il suffisso ?N per mostrare l'icona nel popup:
        #   ?1 = icona "C" azzurra  -> direttiva ChordPro standard
        #   ?2 = icona "S" arancione -> direttiva esclusiva Songpress++
        def _tagged(d):
            img_id = (self._AUTOCOMP_IMG_SPPLUSPLUS
                      if d in self._SONGPRESSPLUSPLUS_DIRECTIVES
                      else self._AUTOCOMP_IMG_CHORDPRO)
            return '%s?%d' % (d, img_id)

        # Scintilla vuole la lista separata da spazi (o da AutoCompSetSeparator)
        # NOTA: il separatore deve essere diverso da '?' usato per le immagini.
        stc.AutoCompSetSeparator(ord(' '))
        stc.AutoCompSetIgnoreCase(True)
        stc.AutoCompSetAutoHide(True)
        stc.AutoCompSetDropRestOfWord(False)
        stc.AutoCompShow(typed_len, ' '.join(_tagged(d) for d in matches))

    # Direttive che non accettano valore (si chiudono con '}' direttamente)
    _DIRECTIVES_NO_VALUE = ChordProDirectives.DIRECTIVES_NO_VALUE

    def _OnIntellisenseSelection(self, evt):
        """Gestisce la selezione dall'autocomplete ChordPro.

        EVT_STC_AUTOCOMP_SELECTION scatta PRIMA che Scintilla inserisca il testo
        selezionato. Usare wx.CallAfter garantisce che il suffisso venga aggiunto
        solo dopo che Scintilla ha completato l'inserimento.
        """
        directive = evt.GetText().lower()
        wx.CallAfter(self._ApplyDirectiveSuffix, directive)
        evt.Skip()   # lascia che Scintilla proceda con l'inserimento normale

    def _ApplyDirectiveSuffix(self, directive):
        """Aggiunge ':|}' o '}' dopo la direttiva appena inserita da Scintilla
        e posiziona il cursore nel punto giusto per digitare il valore.
        Chiamata tramite wx.CallAfter, quindi il testo è già aggiornato."""
        stc = self.text

        pos = stc.GetCurrentPos()
        char_after = stc.GetTextRange(pos, stc.PositionAfter(pos))

        # Se la direttiva è già seguita da ':' o '}' l'utente stava modificando
        # una direttiva esistente: non toccare nulla.
        if char_after == ':':
            return

        line_num   = stc.LineFromPosition(pos)
        line_start = stc.PositionFromLine(line_num)
        text_before = stc.GetTextRange(line_start, pos)
        has_open_brace = '{' in text_before and text_before.rfind('{') > text_before.rfind('}')

        if directive in self._DIRECTIVES_NO_VALUE:
            # Direttiva senza valore: chiude con '}'
            if char_after == '}':
                stc.GotoPos(stc.PositionAfter(pos))
            elif has_open_brace:
                stc.InsertText(pos, '}')
                stc.GotoPos(pos + 1)
            else:
                dir_len = len(directive)
                stc.SetTargetStart(pos - dir_len)
                stc.SetTargetEnd(pos)
                stc.ReplaceTarget('{' + directive + '}')
                stc.GotoPos(pos - dir_len + len('{' + directive + '}'))
        else:
            # Direttiva con valore: aggiunge ':|}' e seleziona il placeholder
            if char_after == '}':
                # '}' presente ma manca ':valore' — sostituisce '}' con ':|}'
                pos_close = stc.PositionAfter(pos)
                stc.SetTargetStart(pos)
                stc.SetTargetEnd(pos_close)
                stc.ReplaceTarget(':|')
                stc.InsertText(pos + 2, '}')
                stc.GotoPos(pos + 1)
                stc.SetSelection(pos + 1, pos + 2)
            elif has_open_brace:
                stc.InsertText(pos, ':|}')
                stc.GotoPos(pos + 1)
                stc.SetSelection(pos + 1, pos + 2)
            else:
                full = '{' + directive + ':|}' 
                dir_len = len(directive)
                stc.SetTargetStart(pos - dir_len)
                stc.SetTargetEnd(pos)
                stc.ReplaceTarget(full)
                cursor_pos = pos - dir_len + len('{' + directive + ':')
                stc.GotoPos(cursor_pos)
                stc.SetSelection(cursor_pos, cursor_pos + 1)

    def Copy(self):
        self.text.Copy()

    def OnCopy(self, evt):
        self.Copy()

    def OnCopyOnlyText(self, evt):
        self.text.CopyOnlyText()

    def CopyAsImage(self):
        if platform.system() == 'Windows':
            # Windows Metafile
            dc = wx.MetafileDC()
            self.DrawOnDC(dc)
            m = dc.Close()
            m.SetClipboard(dc.MaxX(), dc.MaxY())

        else:
            composite = wx.DataObjectComposite()
            size = self.ComputeRenderedSize()

            # 1. SVG
            with temp_dir() as path:
                svg_obj = wx.CustomDataObject("image/svg+xml")
                fp = os.path.join(path, 'temp.svg')
                self.SaveSvg(fp, size=size)
                with open(fp, 'rb') as f:
                    svg_obj.SetData(f.read())
                composite.Add(svg_obj, preferred=True)

            # 2. PNG
            bmp = self.RenderAsPng(scale=2, size=size)
            png_obj = wx.BitmapDataObject(bmp)
            composite.Add(png_obj)

            # Place on Clipboard
            if wx.TheClipboard.Open():
                wx.TheClipboard.SetData(composite)
                wx.TheClipboard.Close()

    def OnCopyAsImage(self, evt):
        self.CopyAsImage()

    def OnPaste(self, evt):
        self.text.Paste()

    def OnPasteChords(self, evt):
        self.text.PasteChords()

    # ------------------------------------------------------------------
    # Propagate chords from first verse / first chorus to all matching
    # blocks (same type, same number of content lines).
    #
    # Verse formats supported:
    #   1. Plain blocks separated by blank lines (no directive)
    #   2. {start_of_verse} ... {end_of_verse}  (also sov/eov)
    #   3. {verse}  (single-line tag: treats the following plain block
    #                as the verse body)
    # Chorus formats supported:
    #   {start_of_chorus} ... {end_of_chorus}  (also soc/eoc)
    # ------------------------------------------------------------------

    @staticmethod
    def _parse_chordpro_blocks(text):
        """
        Parse ChordPro text into a list of blocks.

        Each block is a dict with keys:
          'type'  : 'verse' | 'chorus' | 'header' | 'blank'
          'lines' : list of raw lines (newline stripped)
          'start' : index of first line in the full line list

        For tagged blocks ({sov}…{eov}, {soc}…{eoc}) the delimiter
        lines are included in 'lines' and excluded from the content
        count when building the chord map (see _propagate_chords).

        For plain verse blocks (no delimiter) all lines are content.

        For {verse}-tagged blocks the {verse} directive line is stored
        as a separate 'header' block immediately before the 'verse'
        block that follows it, so the verse content lines are plain.
        """
        import re
        lines = text.split('\n')
        blocks = []
        i = 0

        SOV = re.compile(r'^\s*\{s(?:ov|tart_of_verse)[^}]*\}',   re.IGNORECASE)
        EOV = re.compile(r'^\s*\{e(?:ov|nd_of_verse)[^}]*\}',     re.IGNORECASE)
        SOC = re.compile(r'^\s*\{s(?:oc|tart_of_chorus)[^}]*\}',  re.IGNORECASE)
        EOC = re.compile(r'^\s*\{e(?:oc|nd_of_chorus)[^}]*\}',    re.IGNORECASE)
        # {verse} or {verse:label}
        VERSE_TAG  = re.compile(r'^\s*\{verse(?:[:\s][^}]*)?\}',   re.IGNORECASE)
        # {chorus} single-tag (without soc/eoc)
        CHORUS_TAG = re.compile(r'^\s*\{chorus(?:[:\s][^}]*)?\}',  re.IGNORECASE)
        DIRECTIVE  = re.compile(r'^\s*\{[^}]+\}',                  re.IGNORECASE)
        COMMENT    = re.compile(r'^\s*#')
        # paired block delimiters whose content must NOT be treated as verse
        # (start_chord/end_chord, grid/end_grid, tab/end_tab, bridge, etc.)
        SOB = re.compile(
            r'^\s*\{(?:start_chord|start_bridge|start_of_bridge|sob|start_of_tab|sot'
            r'|start_of_grid|sog|grid)[^}]*\}',
            re.IGNORECASE,
        )
        EOB = re.compile(
            r'^\s*\{(?:end_chord|end_bridge|end_of_bridge|eob|end_of_tab|eot'
            r'|end_of_grid|eog)\s*\}',
            re.IGNORECASE,
        )

        while i < len(lines):
            line = lines[i]

            # --- paired non-verse blocks (start_chord/end_chord, grid, tab, bridge…) ---
            # treat their entire content as header so it is never mistaken for a verse
            if SOB.match(line):
                block_lines = [line]
                i += 1
                while i < len(lines):
                    block_lines.append(lines[i])
                    if EOB.match(lines[i]):
                        i += 1
                        break
                    i += 1
                blocks.append({'type': 'header', 'lines': block_lines,
                                'start': i - len(block_lines), 'tagged': False})
                continue

            # --- {start_of_verse} … {end_of_verse} ---
            if SOV.match(line):
                block_lines = [line]
                i += 1
                while i < len(lines):
                    block_lines.append(lines[i])
                    if EOV.match(lines[i]):
                        i += 1
                        break
                    i += 1
                blocks.append({'type': 'verse', 'lines': block_lines,
                                'start': i - len(block_lines),
                                'tagged': True})
                continue

            # --- {start_of_chorus} … {end_of_chorus} ---
            if SOC.match(line):
                block_lines = [line]
                i += 1
                while i < len(lines):
                    block_lines.append(lines[i])
                    if EOC.match(lines[i]):
                        i += 1
                        break
                    i += 1
                blocks.append({'type': 'chorus', 'lines': block_lines,
                                'start': i - len(block_lines),
                                'tagged': True})
                continue

            # --- {verse} single tag: emit header, then collect following plain lines ---
            if VERSE_TAG.match(line):
                blocks.append({'type': 'header', 'lines': [line], 'start': i, 'tagged': False})
                i += 1
                # collect the plain-text verse body that follows
                body = []
                while i < len(lines):
                    l = lines[i]
                    if (l.strip() == '' or SOV.match(l) or SOC.match(l)
                            or VERSE_TAG.match(l) or CHORUS_TAG.match(l)
                            or EOV.match(l) or EOC.match(l)
                            or DIRECTIVE.match(l) or COMMENT.match(l)):
                        break
                    body.append(l)
                    i += 1
                if body:
                    blocks.append({'type': 'verse', 'lines': body,
                                   'start': i - len(body),
                                   'tagged': False})
                continue

            # --- {chorus} single tag (treat similarly to {verse}) ---
            if CHORUS_TAG.match(line):
                blocks.append({'type': 'header', 'lines': [line], 'start': i, 'tagged': False})
                i += 1
                body = []
                while i < len(lines):
                    l = lines[i]
                    if (l.strip() == '' or SOV.match(l) or SOC.match(l)
                            or VERSE_TAG.match(l) or CHORUS_TAG.match(l)
                            or EOV.match(l) or EOC.match(l)
                            or DIRECTIVE.match(l) or COMMENT.match(l)):
                        break
                    body.append(l)
                    i += 1
                if body:
                    blocks.append({'type': 'chorus', 'lines': body,
                                   'start': i - len(body),
                                   'tagged': False})
                continue

            # --- blank line(s) ---
            if line.strip() == '':
                block_lines = [line]
                i += 1
                while i < len(lines) and lines[i].strip() == '':
                    block_lines.append(lines[i])
                    i += 1
                blocks.append({'type': 'blank', 'lines': block_lines,
                                'start': i - len(block_lines), 'tagged': False})
                continue

            # --- generic directive / comment → header ---
            if DIRECTIVE.match(line) or COMMENT.match(line):
                blocks.append({'type': 'header', 'lines': [line], 'start': i, 'tagged': False})
                i += 1
                continue

            # --- plain verse block (no delimiter) ---
            block_lines = [line]
            i += 1
            while i < len(lines):
                l = lines[i]
                if (l.strip() == '' or SOV.match(l) or SOC.match(l)
                        or VERSE_TAG.match(l) or CHORUS_TAG.match(l)
                        or DIRECTIVE.match(l) or COMMENT.match(l)):
                    break
                block_lines.append(l)
                i += 1
            blocks.append({'type': 'verse', 'lines': block_lines,
                            'start': i - len(block_lines),
                            'tagged': False})

        return blocks, lines

    @staticmethod
    def _strip_chords_from_line(line):
        import re
        return re.sub(r'\[[^\]]*\]', '', line)

    @staticmethod
    def _visible_len(s):
        """Length of s excluding ChordPro soft-hyphen '_' characters."""
        return sum(1 for c in s if c != '_')

    @staticmethod
    def _visible_pos(s, raw_pos):
        """Convert a raw string index to a visible-character index (ignoring '_')."""
        return sum(1 for c in s[:raw_pos] if c != '_')

    @staticmethod
    def _raw_pos_from_visible(s, vis_pos):
        """
        Convert a visible-character index back to a raw string index.
        Returns the raw index where the vis_pos-th non-'_' character starts.
        If vis_pos >= number of visible chars, returns len(s).
        """
        count = 0
        for idx, c in enumerate(s):
            if c != '_':
                if count == vis_pos:
                    return idx
                count += 1
        return len(s)

    @staticmethod
    def _extract_chord_map(lines):
        """
        Return a list parallel to `lines`; each element is a list of
        (visible_position, chord_name) tuples.
        Visible position counts characters excluding ChordPro '_' (soft hyphen).
        """
        import re
        CHORD_RE = re.compile(r'\[([^\]]*)\]')
        result = []
        for line in lines:
            positions = []
            clean_pos = 0   # visible chars so far (excluding '_')
            raw_pos   = 0
            for m in CHORD_RE.finditer(line):
                segment = line[raw_pos:m.start()]
                clean_pos += sum(1 for c in segment if c != '_')
                positions.append((clean_pos, m.group(1)))
                raw_pos = m.end()
            result.append(positions)
        return result

    @staticmethod
    def _apply_chord_map(lines, chord_map):
        """
        Re-insert chords from chord_map into lines (already stripped of chords).
        Positions are visible-character indices (ignoring '_').
        """
        result = []
        for i, line in enumerate(lines):
            if i >= len(chord_map) or not chord_map[i]:
                result.append(line)
                continue
            out      = []
            raw_src  = 0
            for vis_pos, chord in chord_map[i]:
                # find the raw index corresponding to vis_pos visible chars
                count = 0
                insert_at = len(line)
                for idx, c in enumerate(line):
                    if c != '_':
                        if count == vis_pos:
                            insert_at = idx
                            break
                        count += 1
                out.append(line[raw_src:insert_at])
                out.append('[' + chord + ']')
                raw_src = insert_at
            out.append(line[raw_src:])
            result.append(''.join(out))
        return result

    def _propagate_chords(self, block_type):
        """
        Propagate chords from the first block of `block_type` ('verse' or
        'chorus') to all subsequent blocks of the same type that have the
        same number of content lines.

        For tagged blocks ({sov}…{eov}, {soc}…{eoc}) the delimiter lines
        are excluded from the content used for the chord map.
        Returns the modified full text, or None if nothing was done.
        """
        text = self.text.GetText()
        blocks, all_lines = self._parse_chordpro_blocks(text)

        typed = [b for b in blocks if b['type'] == block_type]
        if len(typed) < 2:
            return None

        source = typed[0]
        tagged = source.get('tagged', False)

        if tagged:
            # delimiter lines are first and last; content is in between
            src_content = source['lines'][1:-1]
            src_offset  = source['start'] + 1
        else:
            src_content = source['lines']
            src_offset  = source['start']

        chord_map      = self._extract_chord_map(src_content)
        src_line_count = len(src_content)

        result_lines = list(all_lines)
        modified     = False

        for target in typed[1:]:
            t_tagged = target.get('tagged', False)
            if t_tagged:
                tgt_content = target['lines'][1:-1]
                tgt_offset  = target['start'] + 1
            else:
                tgt_content = target['lines']
                tgt_offset  = target['start']

            if len(tgt_content) != src_line_count:
                continue   # metrica diversa, salta

            stripped    = [self._strip_chords_from_line(l) for l in tgt_content]
            new_content = self._apply_chord_map(stripped, chord_map)

            for j, new_line in enumerate(new_content):
                result_lines[tgt_offset + j] = new_line

            modified = True

        return '\n'.join(result_lines) if modified else None

    def OnPropagateVerseChords(self, evt):
        """Copy chords from the first verse to all verses with the same number of lines."""
        result = self._propagate_chords('verse')
        if result is None:
            wx.MessageBox(
                _("No compatible verse found.\n"
                  "Make sure the song has at least two verses with the same number of lines."),
                _("Propagate verse chords"),
                wx.OK | wx.ICON_INFORMATION,
                self.frame,
            )
            return
        with undo_action(self.text):
            self.text.SetSelection(0, self.text.GetLength())
            self.text.ReplaceSelection(result)

    def OnPropagateChorusChords(self, evt):
        """Copy chords from the first chorus to all choruses with the same number of lines."""
        result = self._propagate_chords('chorus')
        if result is None:
            wx.MessageBox(
                _("No compatible chorus found.\n"
                  "Make sure the song has at least two choruses with the same number of lines."),
                _("Propagate chorus chords"),
                wx.OK | wx.ICON_INFORMATION,
                self.frame,
            )
            return
        with undo_action(self.text):
            self.text.SetSelection(0, self.text.GetLength())
            self.text.ReplaceSelection(result)

    def _OnGlobalCharHook(self, evt):
        """F3 = trova successivo, Shift+F3 = trova precedente, anche a dialogo chiuso."""
        kc = evt.GetKeyCode()
        if kc == wx.WXK_F3:
            if evt.ShiftDown():
                self.OnFindPrevious(evt)
            else:
                self.OnFindNext(evt)
        else:
            evt.Skip()

    def OnFind(self, evt):
        if self.findReplaceDialog is not None and self.findReplaceDialog.dialog is not None:
            self.findReplaceDialog.notebook.SetSelection(0)
            self.findReplaceDialog._UpdateButtons()
            self.findReplaceDialog._FocusFindField()
            self.findReplaceDialog.dialog.Raise()
        else:
            self.findReplaceDialog = SongpressFindReplaceDialog(self, replace=False)

    def OnFindNext(self, evt):
        dlg = self.findReplaceDialog
        if dlg is not None and dlg.dialog is not None:
            # Forza direzione giù sul radio della tab attiva
            if dlg._IsReplaceTab():
                dlg.rbDownR.SetValue(True)
            else:
                dlg.rbDown.SetValue(True)
            dlg._OnFindNext(evt)
        else:
            self._FindInEditor(down=True)

    def OnFindPrevious(self, evt):
        dlg = self.findReplaceDialog
        if dlg is not None and dlg.dialog is not None:
            # Forza direzione su sul radio della tab attiva
            if dlg._IsReplaceTab():
                dlg.rbUpR.SetValue(True)
            else:
                dlg.rbUp.SetValue(True)
            dlg._OnFindNext(evt)
        else:
            self._FindInEditor(down=False)

    def _FindInEditor(self, down=True):
        """Cerca nel testo usando l'ultimo termine e flags memorizzati."""
        st    = getattr(self, '_lastFindSt', '')
        flags = getattr(self, '_lastFindFlags', 0)
        if not st:
            return
        text = self.text
        if down:
            s, e = text.GetSelection()
            text.SetSelection(e, e)
            text.SearchAnchor()
            p = text.SearchNext(flags, st)
        else:
            s, e = text.GetSelection()
            text.SetSelection(s, s)
            text.SearchAnchor()
            p = text.SearchPrev(flags, st)
        if p != -1:
            text.SetSelection(p, p + len(st))
            text.EnsureCaretVisible()
        else:
            # Ricomincia dall'inizio/fine
            if down:
                newStart, wherefrom, where = 0, _("Reached the end"), _("beginning")
            else:
                newStart, wherefrom, where = text.GetLength(), _("Reached the beginning"), _("end")
            d = wx.MessageDialog(
                self.frame,
                _("%s of the song, restarting search from the %s?") % (wherefrom, where),
                self.appName,
                wx.YES_NO | wx.ICON_INFORMATION
            )
            if d.ShowModal() == wx.ID_YES:
                text.SetSelection(newStart, newStart)
                self._FindInEditor(down=down)

    def OnReplace(self, evt):
        if self.findReplaceDialog is not None and self.findReplaceDialog.dialog is not None:
            self.findReplaceDialog.notebook.SetSelection(1)
            self.findReplaceDialog._UpdateButtons()
            self.findReplaceDialog._FocusFindField()
            self.findReplaceDialog.dialog.Raise()
        else:
            self.findReplaceDialog = SongpressFindReplaceDialog(self, replace=True)

    def OnSelectAll(self, evt):
        self.text.SelectAll()

    def OnSelectNextChord(self, evt):
        self.text.SelectNextChord()

    def OnSelectPreviousChord(self, evt):
        self.text.SelectPreviousChord()

    def _GetGridContext(self):
        """Se il cursore è dentro un blocco {start_of_grid}...{end_of_grid},
        restituisce (line_num, line_text, col_in_line). Altrimenti None.
        """
        import re
        pos = self.text.GetCurrentPos()
        cur_line = self.text.LineFromPosition(pos)
        SOG = re.compile(r'^\s*\{(?:start_of_grid|sog|grid)[^}]*\}', re.IGNORECASE)
        EOG = re.compile(r'^\s*\{(?:end_of_grid|eog)[^}]*\}',        re.IGNORECASE)
        for ln in range(cur_line - 1, -1, -1):
            txt = self.text.GetLine(ln).rstrip('\r\n')
            if EOG.match(txt):
                return None   # siamo dopo una chiusura: non nel grid
            if SOG.match(txt):
                line_txt = self.text.GetLine(cur_line).rstrip('\r\n')
                col = pos - self.text.PositionFromLine(cur_line)
                return (cur_line, line_txt, col)
        return None

    def _MoveGridCellRight(self):
        """Dentro {start_of_grid}: gestisce la barra spaziatrice in modalità pipe.

        - Nessun pipe sulla riga: inserisce '| ' davanti al testo corrente
          e posiziona il cursore dopo il pipe (pronto a digitare il primo accordo).
        - Pipe già presente a sinistra del cursore: inserisce '  |' prima della
          cella corrente (sposta l'accordo a destra) e posiziona il cursore
          nella nuova cella vuota appena creata.
        """
        ctx = self._GetGridContext()
        if ctx is None:
            return False
        cur_line, line_txt, col = ctx
        line_start = self.text.PositionFromLine(cur_line)

        pipe_pos = line_txt.rfind('|', 0, col)

        if pipe_pos == -1:
            # Nessun pipe sulla riga: inizia la struttura pipe all'inizio della riga.
            # Inserisce '| ' prima del testo esistente, cursore subito dopo il pipe.
            with undo_action(self.text):
                self.text.SetSelection(line_start, line_start)
                self.text.ReplaceSelection('| ')
            new_pos = line_start + 2   # dopo '| ', pronto a digitare l'accordo
            self.text.SetSelection(new_pos, new_pos)
        else:
            # Pipe già presente: inserisce '  |' dopo il pipe sinistro,
            # spostando la cella corrente di 3 posizioni a destra.
            insert_at = line_start + pipe_pos + 1
            with undo_action(self.text):
                self.text.SetSelection(insert_at, insert_at)
                self.text.ReplaceSelection('  |')
            # Cursore nella nuova cella vuota (un carattere dopo il pipe originale)
            new_pos = insert_at + 1
            self.text.SetSelection(new_pos, new_pos)

        return True

    def _MoveGridCellLeft(self):
        """Dentro {start_of_grid}: rimuove la cella vuota precedente a quella corrente,
        spostando l'accordo di una posizione verso sinistra.
        Stesso effetto visivo di MoveChordLeft in {start_chord}.
        """
        ctx = self._GetGridContext()
        if ctx is None:
            return False
        cur_line, line_txt, col = ctx
        pipe_pos = line_txt.rfind('|', 0, col)
        if pipe_pos == -1:
            return False
        prev_pipe = line_txt.rfind('|', 0, pipe_pos)
        if prev_pipe == -1:
            return False
        between = line_txt[prev_pipe + 1: pipe_pos]
        if between.strip() != '':
            return False   # cella precedente non vuota: impossibile spostare
        line_start = self.text.PositionFromLine(cur_line)
        remove_start = line_start + prev_pipe + 1
        remove_end   = line_start + pipe_pos + 1
        with undo_action(self.text):
            self.text.SetSelection(remove_start, remove_end)
            self.text.ReplaceSelection('')
        return True

    def MoveChordRight(self, position=None):
        """
        Move the chord 1 position to the right, hooking its neighbords

        Apply to the chord at `position`, or under the cursor if `position`
        is not specified.

        :return: `False` if the chord is at the end of the song and cannot be moved,
            `True` otherwise
        """

        r = self.text.GetChordUnderCursor(position)
        if r is None:
            return True
        n = self.text.GetLength()
        s, e, c = r

        if e >= n:
            return False
        with undo_action(self.text):
            # Recursively push to the right the next adjacent chord (if any)
            if not self.MoveChordRight(e + 1):
                return False

            e1 = self.text.PositionAfter(e)
            self.text.SetSelection(e, e1)
            l = self.text.GetTextRange(e, e1)
            self.text.ReplaceSelection('')
            self.text.SetSelection(s, s)
            self.text.ReplaceSelection(l)
            s2 = self.text.PositionAfter(self.text.PositionAfter(s))
            self.text.SetSelection(s2, s2)
            return True

    def OnMoveChordRight(self, evt):
        self.MoveChordRight()

    def MoveChordLeft(self, position=None):
        """
        Move the chord 1 position to the left, hooking its neighbords

        Apply to the chord at `position`, or under the cursor if `position`
        is not specified.

        :return: `False` if the chord is at the beginnig of the song and cannot be moved,
            `True` otherwise
        """
        r = self.text.GetChordUnderCursor(position)
        if r is None:
            return True
        s, e, c = r
        if s == 0:
            return False
        with undo_action(self.text):
            # Recursively push to the left the previous adjacent chord (if any)
            if not self.MoveChordLeft(s - 1):
                return False

            s1 = self.text.PositionBefore(s)
            l = self.text.GetTextRange(s1, s)
            self.text.SetSelection(e, e)
            self.text.ReplaceSelection(l)
            self.text.SetSelection(s1, s)
            self.text.ReplaceSelection('')
            s = self.text.PositionAfter(s1)
            self.text.SetSelection(s, s)
            return True

    def OnMoveChordLeft(self, evt):
        self.MoveChordLeft()

    def OnRemoveChords(self, evt):
        self.text.RemoveChordsInSelection()

    def _OnStatusTimerExpired(self, evt):
        if self.statusBar:
            self.statusBar.SetStatusText("")

    def _UpdateStatusIndicators(self):
        """Aggiorna il campo 1 della status bar con gli indicatori Intellisense/Multicursore."""
        if not self.statusBar:
            return
        parts = []
        if getattr(self.pref, 'intellisense', True):
            parts.append(_(u"Intellisense"))
        if getattr(self.pref, 'multiCursor', False):
            parts.append(_(u"Multicursor"))
        self.statusBar.SetStatusText(u"  ● " + u"  ● ".join(parts) if parts else u"", 1)

    def _UpdateLockKeys(self):
        """Aggiorna il campo 2 della status bar con lo stato di CAPS / NUM / SCR."""
        if not self.statusBar:
            return
        caps = wx.GetKeyState(wx.WXK_CAPITAL)
        num  = wx.GetKeyState(wx.WXK_NUMLOCK)
        scr  = wx.GetKeyState(wx.WXK_SCROLL)
        parts = []
        if caps: parts.append(u"CAPS")
        if num:  parts.append(u"NUM")
        if scr:  parts.append(u"SCR")
        self.statusBar.SetStatusText(u"  ".join(parts), 2)

    def _OnLockKeysTimer(self, evt):
        """Callback del timer periodico per aggiornare gli indicatori lock-keys."""
        self._UpdateLockKeys()

    def OnIntegrateChords(self, evt):
        ln = self.text.GetCurrentLine()
        if ln < self.text.GetLineCount() - 1:
            chords = self.text.GetLine(ln).strip("\r\n")
            text = self.text.GetLine(ln + 1).strip("\r\n")
            chordpro = integrateChords(chords, text)
            self.text.SetSelectionStart(self.text.PositionFromLine(ln))
            self.text.SetSelectionEnd(self.text.GetLineEndPosition(ln + 1))
            self.text.ReplaceSelection(chordpro)
        else:
            if self.statusBar:
                self.statusBar.SetStatusText(_("Command 'Paste chords': Select 1st chord line, 2nd text line"))
                self._statusTimer.StartOnce(10000)

    def OnFontSelected(self, evt):
        font = self.fontChooser.GetValue()
        showChords = self.showChordsChooser.GetValue()
        self.pref.SetFont(font, showChords)
        self.SetFont(True)
        evt.Skip()

    def OnCheckDependencies(self, evt):
        """Mostra una finestra con le dipendenze richieste e il loro stato."""
        import importlib
        import sys

        # (nome_visualizzato, nome_modulo, note)
        DEPS = [
            ("wxPython",        "wx",           ""),
            ("requests",        "requests",     ""),
            ("python-pptx",     "pptx",         ""),
            ("pyshortcuts",     "pyshortcuts",  ""),
            ("reportlab",       "reportlab",    ""),
            ("pypdf",           "pypdf",        ""),
            ("markdown",        "markdown",     ""),
            ("mistune",         "mistune",      ""),
            ("pywin32",         "win32print",   _("Windows only")),
        ]

        rows = []
        all_ok = True
        for display, module, note in DEPS:
            try:
                mod = importlib.import_module(module)
                ver = getattr(mod, '__version__', None) or getattr(mod, 'VERSION', None) or "?"
                status = u"\u2705"   # ✅
                ver_str = str(ver)
            except ImportError:
                status = u"\u274c"   # ❌
                ver_str = _("not installed")
                if not note:          # obbligatoria
                    all_ok = False
            rows.append((display, status, ver_str, note))

        # --- dialog ---
        dlg = wx.Dialog(
            self.frame,
            title=_("Check dependencies — Songpress++"),
            style=wx.DEFAULT_DIALOG_STYLE | wx.RESIZE_BORDER,
        )
        outer = wx.BoxSizer(wx.VERTICAL)

        # Riepilogo in cima
        summary_text = (
            _("All required dependencies are installed correctly.")
            if all_ok
            else _("One or more required dependencies are missing.")
        )
        summary_icon = u"\u2705 " if all_ok else u"\u274c "
        summary_lbl = wx.StaticText(dlg, label=summary_icon + summary_text)
        font = summary_lbl.GetFont()
        font.SetWeight(wx.FONTWEIGHT_BOLD)
        summary_lbl.SetFont(font)
        outer.Add(summary_lbl, 0, wx.ALL, 12)

        # Griglia
        grid = wx.FlexGridSizer(cols=4, vgap=4, hgap=12)
        grid.AddGrowableCol(0)
        grid.AddGrowableCol(2)

        def _hdr(text):
            lbl = wx.StaticText(dlg, label=text)
            f = lbl.GetFont()
            f.SetWeight(wx.FONTWEIGHT_BOLD)
            lbl.SetFont(f)
            return lbl

        grid.Add(_hdr(_("Package")),  0, wx.ALIGN_CENTER_VERTICAL)
        grid.Add(_hdr(_("Status")),   0, wx.ALIGN_CENTER_VERTICAL)
        grid.Add(_hdr(_("Version")),  0, wx.ALIGN_CENTER_VERTICAL)
        grid.Add(_hdr(_("Notes")),    0, wx.ALIGN_CENTER_VERTICAL)

        for display, status, ver_str, note in rows:
            grid.Add(wx.StaticText(dlg, label=display),  0, wx.ALIGN_CENTER_VERTICAL)
            grid.Add(wx.StaticText(dlg, label=status),   0, wx.ALIGN_CENTER_VERTICAL)
            grid.Add(wx.StaticText(dlg, label=ver_str),  0, wx.ALIGN_CENTER_VERTICAL)
            grid.Add(wx.StaticText(dlg, label=note),     0, wx.ALIGN_CENTER_VERTICAL)

        outer.Add(grid, 0, wx.EXPAND | wx.LEFT | wx.RIGHT | wx.BOTTOM, 12)

        # Python / wxPython info
        outer.Add(wx.StaticLine(dlg), 0, wx.EXPAND | wx.LEFT | wx.RIGHT, 12)
        py_info = wx.StaticText(
            dlg,
            label=u"Python {}    wxPython {}".format(
                sys.version.split()[0],
                wx.__version__,
            ),
        )
        outer.Add(py_info, 0, wx.ALL, 10)

        # Bottone OK
        btn_ok = wx.Button(dlg, wx.ID_OK, _("Close"))
        btn_ok.SetDefault()
        outer.Add(btn_ok, 0, wx.ALIGN_RIGHT | wx.ALL, 10)

        dlg.SetSizerAndFit(outer)
        dlg.CentreOnParent()
        dlg.ShowModal()
        dlg.Destroy()

    def OnGuide(self, evt):
        wx.LaunchDefaultBrowser(_("http://www.skeed.it/songpress-manual"))

    def OnGuideMarkdown(self, evt):
        import os
        import wx.html

        # Determina il codice lingua dalla locale wx attiva
        locale = wx.GetLocale()
        lang_code = ''
        if locale:
            canonical = locale.GetCanonicalName()   # es. "it_IT"
            if canonical:
                lang_code = canonical.split('_')[0].lower()  # → "it", "en", "fr"

        base_dir = os.path.dirname(__file__)
        _img_guide_url = 'file:///' + os.path.abspath(os.path.join(base_dir, 'img', 'GUIDE')).replace('\\', '/').lstrip('/') + '/'

        # Priorità: guida_<lang>.md  →  guida.md  →  errore
        candidates = []
        if lang_code:
            candidates.append(os.path.join(base_dir, 'guida_%s.md' % lang_code))
        candidates.append(os.path.join(base_dir, 'guida.md'))

        guide_path = None
        for path in candidates:
            if os.path.exists(path):
                guide_path = path
                break

        if guide_path is None:
            wx.MessageBox(
                _("Guide file not found in the program folder."),
                _("Help"),
                wx.ICON_ERROR,
            )
            return

        try:
            with open(guide_path, 'r', encoding='utf-8') as f:
                md_text = f.read()
        except Exception as e:
            wx.MessageBox(str(e), _("Error"), wx.ICON_ERROR)
            return

        # Riscrittura percorsi immagini (normalizza tutte le varianti)
        import re
        # Pattern che cattura qualsiasi variante del percorso verso img/GUIDE/
        _guide_pat = re.compile(
            r'(!\[[^\]]*\]\()(?:[^()]*?/)?img/GUIDE/'
        )
        if getattr(self.pref, 'guideMarkdownImgPath', False):
            # Typora: percorso assoluto relativo alla root del progetto
            md_text = _guide_pat.sub(r'\1../src/songpressPlusPlus/img/GUIDE/', md_text)
        else:
            # App: percorso relativo al file .md in src/songpress/
            md_text = _guide_pat.sub(lambda m: m.group(1) + _img_guide_url, md_text)

        html = self._md_to_html(md_text)

        dlg = wx.Dialog(
            self.frame,
            title=_("Quick guide - Songpress++"),
            size=(760, 620),
            style=wx.DEFAULT_DIALOG_STYLE | wx.RESIZE_BORDER | wx.MAXIMIZE_BOX,
        )
        dlg.SetMinSize(wx.Size(550, 400))

        sizer = wx.BoxSizer(wx.VERTICAL)

        hw = wx.html.HtmlWindow(dlg, style=wx.html.HW_SCROLLBAR_AUTO)

        # ── Stato ricerca nella guida ─────────────────────────────────
        _search_state = {'term': '', 'matches': [], 'idx': -1, 'html_orig': '', 'html_themed': ''}

        def _guide_search_open():
            """Apre un mini-dialogo di ricerca testuale nella guida."""
            import re as _re2

            sdlg = wx.Dialog(
                dlg, title=_("Find in guide"),
                style=wx.DEFAULT_DIALOG_STYLE | wx.STAY_ON_TOP,
            )
            vsz = wx.BoxSizer(wx.VERTICAL)

            # ── Riga 1: etichetta + campo testo ───────────────────────
            row_find = wx.BoxSizer(wx.HORIZONTAL)
            row_find.Add(
                wx.StaticText(sdlg, label=_("Find:")),
                0, wx.ALIGN_CENTER_VERTICAL | wx.RIGHT, 6,
            )
            txt = wx.TextCtrl(
                sdlg, value=_search_state['term'],
                size=(260, -1), style=wx.TE_PROCESS_ENTER,
            )
            row_find.Add(txt, 1, wx.EXPAND)
            vsz.Add(row_find, 0, wx.EXPAND | wx.ALL, 10)

            # ── Riga 2: bottoni navigazione + contatore + Chiudi ──────
            row_btns = wx.BoxSizer(wx.HORIZONTAL)

            # Frecce: stesse icone wx usate dalla toolbar di anteprima stampa
            def _make_arrow_btn(parent, art_id, img_name, label_fallback):
                """
                Crea un BitmapButton con l'icona wx.ArtProvider (stessa usata
                dal PreviewControlBar). Fallback: PNG img/, poi testo puro.
                """
                bmp = wx.ArtProvider.GetBitmap(art_id, wx.ART_BUTTON, (24, 24))
                if not bmp.IsOk():
                    img = wx.Image(glb.AddPath('img/' + img_name))
                    bmp = wx.Bitmap(img) if img.IsOk() else wx.NullBitmap
                if bmp.IsOk():
                    btn = wx.BitmapButton(parent, bitmap=bmp,
                                         style=wx.BU_AUTODRAW)
                    btn.SetToolTip(label_fallback)
                else:
                    btn = wx.Button(parent, label=label_fallback)
                return btn

            btn_prev = _make_arrow_btn(sdlg, wx.ART_GO_BACK,    'arrow_left.png',  _("Previous"))
            btn_next = _make_arrow_btn(sdlg, wx.ART_GO_FORWARD,  'arrow_right.png', _("Next"))
            btn_next.SetDefault()

            lbl_count = wx.StaticText(sdlg, label='', size=(90, -1))
            lbl_count.SetForegroundColour(wx.Colour(80, 80, 80))

            btn_close = wx.Button(sdlg, wx.ID_CANCEL, _("Close"))

            row_btns.Add(btn_prev,  0, wx.ALIGN_CENTER_VERTICAL | wx.RIGHT, 4)
            row_btns.Add(btn_next,  0, wx.ALIGN_CENTER_VERTICAL | wx.RIGHT, 12)
            row_btns.Add(lbl_count, 0, wx.ALIGN_CENTER_VERTICAL | wx.RIGHT, 8)
            row_btns.AddStretchSpacer()
            row_btns.Add(btn_close, 0, wx.ALIGN_CENTER_VERTICAL)
            vsz.Add(row_btns, 0, wx.EXPAND | wx.LEFT | wx.RIGHT | wx.BOTTOM, 10)

            sdlg.SetSizer(vsz)
            vsz.Fit(sdlg)
            # Larghezza minima per evitare tagli del contatore
            cur_w, cur_h = sdlg.GetSize()
            sdlg.SetMinSize(wx.Size(max(cur_w, 440), cur_h))
            sdlg.SetSize(wx.Size(max(cur_w, 440), cur_h))

            # ── Logica di ricerca ─────────────────────────────────────
            def _do_search(term, goto_idx=0):
                """Evidenzia tutte le occorrenze di *term* nell'HtmlWindow.
                Il match attivo è in yellowgreen; gli altri in giallo chiaro.
                Un anchor <a name="__active__"> sul match attivo permette
                a wx.html.HtmlWindow di scorrere automaticamente fino ad esso."""
                _search_state['term'] = term
                orig = _search_state.get('html_orig', '')
                if not orig:
                    return
                themed = _search_state.get('html_themed', '') or orig
                if not term:
                    hw.SetPage(themed)
                    _search_state['matches'] = []
                    _search_state['idx'] = -1
                    lbl_count.SetLabel('')
                    return
                escaped = _re2.escape(term)
                # Conta le occorrenze nel testo plain (prima di applicare l'HTML)
                plain = _re2.sub(r'<[^>]+>', '', orig)
                matches = [m.start() for m in _re2.finditer(
                    escaped, plain, _re2.IGNORECASE)]
                n = len(matches)
                if n == 0:
                    hw.SetPage(themed)
                    lbl_count.SetLabel(_("Not found"))
                    lbl_count.SetForegroundColour(wx.Colour(180, 0, 0))
                    _search_state['matches'] = matches
                    _search_state['idx'] = -1
                    lbl_count.GetParent().Layout()
                    return
                idx = max(0, min(goto_idx, n - 1))
                _search_state['matches'] = matches
                _search_state['idx'] = idx
                lbl_count.SetLabel(_("%d of %d") % (idx + 1, n))
                lbl_count.SetForegroundColour(wx.Colour(80, 80, 80))
                lbl_count.GetParent().Layout()
                # Costruisce l'HTML con tutti i match evidenziati;
                # il match attivo riceve bgcolor yellowgreen + anchor navigabile.
                counter = [0]
                def _replace_match(m):
                    i = counter[0]
                    counter[0] += 1
                    text = m.group(1)
                    if i == idx:
                        return ('<a name="__active__"></a>'
                                '<font bgcolor="#9ACD32" color="#000000"><b>' + text + '</b></font>')
                    return '<font bgcolor="#FFFF99" color="#000000">' + text + '</font>'
                highlighted = _re2.sub(r'(?i)(%s)' % escaped, _replace_match, themed)
                hw.SetPage(highlighted)
                # Scorre fino al match attivo tramite l'ancora __active__
                # wx.LogNull sopprime il warning "Ancora HTML __active__ non esistente"
                # che wx emette se SetPage non ha ancora completato il parsing
                _log_null = wx.LogNull()
                hw.ScrollToAnchor("__active__")
                del _log_null

            def _on_next(e):
                term = txt.GetValue().strip()
                if not term:
                    return
                idx = _search_state['idx']
                n   = len(_search_state['matches'])
                _do_search(term, (idx + 1) % n if n else 0)

            def _on_prev(e):
                term = txt.GetValue().strip()
                if not term:
                    return
                idx = _search_state['idx']
                n   = len(_search_state['matches'])
                _do_search(term, (idx - 1) % n if n else 0)

            def _on_close_search(e):
                # Ripristina la pagina con il tema corrente (non l'HTML grezzo)
                _rebuild_page(_dark_mode[0])
                _apply_zoom(_zoom_pct[0])
                _search_state['matches'] = []
                _search_state['idx'] = -1
                sdlg.EndModal(wx.ID_CANCEL)

            btn_next.Bind(wx.EVT_BUTTON, _on_next)
            btn_prev.Bind(wx.EVT_BUTTON, _on_prev)
            btn_close.Bind(wx.EVT_BUTTON, _on_close_search)
            txt.Bind(wx.EVT_TEXT_ENTER, _on_next)
            sdlg.Bind(wx.EVT_CLOSE, _on_close_search)

            txt.SetFocus()
            txt.SetSelection(-1, -1)   # seleziona tutto il testo preesistente
            if _search_state['term']:
                _do_search(_search_state['term'])

            sdlg.ShowModal()
            sdlg.Destroy()

        # ── Menu contestuale tasto destro ──────────────────────────────
        def _on_hw_right_click(evt):
            menu = wx.Menu()

            # Icona copy.png dalla cartella img del progetto
            _copy_img = wx.Image(glb.AddPath('img/copy.png'))
            bmp_copy = wx.Bitmap(_copy_img) if _copy_img.IsOk() else wx.NullBitmap

            item_copy = wx.MenuItem(menu, wx.ID_COPY, _("Copy"))
            if bmp_copy.IsOk():
                item_copy.SetBitmap(bmp_copy)
            menu.Append(item_copy)

            # Abilita "Copia" solo se c'è testo selezionato
            sel = hw.SelectionToText()
            menu.Enable(wx.ID_COPY, bool(sel))

            def _copy(e):
                text = hw.SelectionToText()
                if text and wx.TheClipboard.Open():
                    wx.TheClipboard.SetData(wx.TextDataObject(text))
                    wx.TheClipboard.Close()

            menu.Bind(wx.EVT_MENU, _copy, id=wx.ID_COPY)

            menu.AppendSeparator()

            # ── Voce "Cerca" con icona img/search.png ─────────────────
            _id_search = wx.NewIdRef()
            _search_img = wx.Image(glb.AddPath('img/search.png'))
            _bmp_search = wx.Bitmap(_search_img) if _search_img.IsOk() \
                else wx.ArtProvider.GetBitmap(wx.ART_FIND, wx.ART_MENU, (16, 16))
            item_search = wx.MenuItem(menu, _id_search, _("Find in guide..."))
            if _bmp_search.IsOk():
                item_search.SetBitmap(_bmp_search)
            menu.Append(item_search)

            def _on_search(e):
                # Salva l'HTML corrente la prima volta (prima di ogni evidenziazione)
                if not _search_state.get('html_orig'):
                    _search_state['html_orig'] = hw.GetParser().GetSource() \
                        if hw.GetParser() else ''
                # Se c'è testo selezionato nella guida, lo usa come termine di ricerca
                sel = hw.SelectionToText().strip()
                if sel:
                    _search_state['term'] = sel
                _guide_search_open()

            menu.Bind(wx.EVT_MENU, _on_search, id=_id_search)

            hw.PopupMenu(menu)
            menu.Destroy()

        hw.Bind(wx.EVT_RIGHT_DOWN, _on_hw_right_click)
        # ── Fine menu contestuale ──────────────────────────────────────

        sizer.Add(hw, 1, wx.EXPAND | wx.ALL, 4)

        # ── Stato zoom e tema — ripristinati dalle preferenze ────────
        _zoom_pct = [max(50, min(200, getattr(self.pref, 'guideZoom', 100)))]
        _dark_mode = [bool(getattr(self.pref, 'guideDarkMode', False))]

        # Palette colori per i due temi
        _THEME = {
            False: {   # chiaro
                'bg':       '#ffffff',
                'text':     '#000000',
                'link':     '#0066cc',
                'pre_bg':   '#f4f4f4',
                'pre_fg':   '#000000',
                'th_bg':    '#e8e8e8',
                'td_border':'#cccccc',
                'bq_fg':    '#555555',
                'h_fg':     '#000000',
            },
            True: {    # scuro
                'bg':       '#1e1e1e',
                'text':     '#d4d4d4',
                'link':     '#4fc1ff',
                'pre_bg':   '#2d2d2d',
                'pre_fg':   '#ce9178',
                'th_bg':    '#3a3a3a',
                'td_border':'#555555',
                'bq_fg':    '#999999',
                'h_fg':     '#9cdcfe',
            },
        }

        import re as _re

        def _colorize_body(body_html, dark):
            """
            wx.html.HtmlWindow non applica CSS <style>: usa solo attributi HTML
            legacy. Sostituiamo quindi i tag rilevanti con versioni colorate via
            attributi bgcolor/color/text.
            """
            p = _THEME[dark]

            # <pre ...> → <pre bgcolor="..." color="...">
            body_html = _re.sub(
                r'<pre(\s[^>]*)?>',
                lambda m: '<pre bgcolor="%s"><font color="%s">' % (p['pre_bg'], p['pre_fg']),
                body_html, flags=_re.IGNORECASE,
            )
            body_html = _re.sub(r'</pre>', '</font></pre>', body_html, flags=_re.IGNORECASE)

            # <th ...> → <th bgcolor="...">
            body_html = _re.sub(
                r'<th(\s[^>]*)?>',
                lambda m: '<th bgcolor="%s">' % p['th_bg'],
                body_html, flags=_re.IGNORECASE,
            )

            # Colore intestazioni h1-h4
            for hn in ('h1', 'h2', 'h3', 'h4'):
                body_html = _re.sub(
                    r'<' + hn + r'(\s[^>]*)?>',
                    lambda m, _hn=hn: '<%s><font color="%s">' % (_hn, p['h_fg']),
                    body_html, flags=_re.IGNORECASE,
                )
                body_html = _re.sub(
                    r'</' + hn + r'>',
                    '</font></%s>' % hn,
                    body_html, flags=_re.IGNORECASE,
                )

            return body_html

        def _rebuild_page(dark):
            """Ricostruisce l'HTML con attributi colore compatibili con
            wx.html.HtmlWindow e aggiorna anche il colore di sfondo del widget."""
            p = _THEME[dark]
            body_colored = _colorize_body(html_body, dark)

            # base_href consente a wx.html.HtmlWindow di risolvere i percorsi
            # relativi delle immagini (img/GUIDE/...) sia in sviluppo che
            # quando il programma è installato.
            # Attributi <body> legacy: bgcolor, text, link
            styled = (
                '<html><head></head>'
                '<body bgcolor="%s" text="%s" link="%s">'
                '%s'
                '</body></html>'
            ) % (p['bg'], p['text'], p['link'], body_colored)

            # Colore di sfondo del widget wx (visibile durante lo scroll)
            hw.SetBackgroundColour(wx.Colour(
                int(p['bg'][1:3], 16),
                int(p['bg'][3:5], 16),
                int(p['bg'][5:7], 16),
            ))
            hw.SetPage(styled)
            _search_state['html_themed'] = styled

        # Estraiamo il body dall'HTML già generato per poterlo riciclare
        _body_m = _re.search(r'<body>(.*)</body>', html, _re.DOTALL | _re.IGNORECASE)
        html_body = _body_m.group(1) if _body_m else html

        # ── Inietta anchor <a name="..."> prima di ogni intestazione ──────
        # Necessario quando il parser esterno (python-markdown / mistune) non
        # genera anchor navigabili compatibili con wx.html.HtmlWindow.
        # Se il parser builtin li ha già inseriti, il controllo look-behind li salta.
        def _make_slug(text):
            import re as _rs
            slug = _rs.sub(r'[^\w\s-]', '', text.lower())
            slug = _rs.sub(r'[\s]+', '-', slug.strip())
            slug = _rs.sub(r'-+', '-', slug)
            return slug

        def _inject_anchors(body_html):
            import re as _ri
            def _add_anchor(m):
                level  = m.group(1)
                attrs  = m.group(2) or ''
                content = m.group(3)
                plain  = _ri.sub(r'<[^>]+>', '', content)
                slug   = _make_slug(plain)
                anchor = '<p style="margin:0;padding:0"><a name="%s"></a></p>' % slug
                return '%s<%s%s>%s</%s>' % (anchor, level, attrs, content, level)
            result = _ri.sub(
                r'<(h[1-4])(\s[^>]*)?>(.+?)</\1>',
                lambda m: (
                    m.group(0) if _ri.search(
                        r'<a\s+name=',
                        body_html[max(0, m.start() - 120):m.start()]
                    ) else _add_anchor(m)
                ),
                body_html,
                flags=_ri.DOTALL | _ri.IGNORECASE,
            )
            return result

        html_body = _inject_anchors(html_body)

        # ── Handler link: bindato UNA VOLTA SOLA (fuori da _rebuild_page) ─
        # _rebuild_page viene richiamato ad ogni cambio tema: definire e bindare
        # _on_link_clicked al suo interno accumulerebbe handler multipli.
        def _on_link_clicked(e):
            href = e.GetLinkInfo().GetHref()
            if href.startswith('#'):
                # Normalizza lo slug: collassa trattini multipli (--→-)
                # per allinearsi all'algoritmo di _make_slug
                anchor = _re.sub(r'-+', '-', href[1:])
                _log_null = wx.LogNull()
                hw.ScrollToAnchor(anchor)
                del _log_null
            else:
                wx.LaunchDefaultBrowser(href)
        hw.Bind(wx.html.EVT_HTML_LINK_CLICKED, _on_link_clicked)

        # Carichiamo la pagina iniziale con il tema salvato
        _rebuild_page(_dark_mode[0])

        # ── Barra inferiore ──────────────────────────────────────────
        btn_row = wx.BoxSizer(wx.HORIZONTAL)

        # Pulsante Schermo intero
        btn_max = wx.Button(dlg, wx.ID_ANY, _("Full screen"))
        btn_max.SetToolTip(_("Toggle full screen"))

        def _on_toggle_max(e):
            if dlg.IsMaximized():
                dlg.Restore()
                btn_max.SetLabel(_("Full screen"))
            else:
                dlg.Maximize()
                btn_max.SetLabel(_("Restore"))

        btn_max.Bind(wx.EVT_BUTTON, _on_toggle_max)

        def _fix_btn_max_size():
            dc = wx.ClientDC(btn_max)
            dc.SetFont(btn_max.GetFont())
            w1 = dc.GetTextExtent(_("Full screen"))[0]
            w2 = dc.GetTextExtent(_("Restore"))[0]
            best = btn_max.GetBestSize()
            cur_tw = dc.GetTextExtent(btn_max.GetLabel())[0]
            padding = best.width - cur_tw
            min_w = max(w1, w2) + max(padding, 20)
            btn_max.SetMinSize(wx.Size(min_w, best.height))
            btn_max.GetContainingSizer().Layout()
        wx.CallAfter(_fix_btn_max_size)

        # ── Zoom: pulsante −, slider, pulsante +, etichetta % ────────
        btn_zoom_out = wx.Button(dlg, wx.ID_ANY, u"−", size=(28, -1))
        btn_zoom_out.SetToolTip(_("Zoom out"))

        zoom_slider = wx.Slider(
            dlg, value=_zoom_pct[0], minValue=50, maxValue=200,
            size=(160, -1),
            style=wx.SL_HORIZONTAL,
        )
        zoom_slider.SetToolTip(_("Zoom (50% – 200%)"))

        btn_zoom_in = wx.Button(dlg, wx.ID_ANY, u"+", size=(28, -1))
        btn_zoom_in.SetToolTip(_("Zoom in"))

        lbl_zoom = wx.StaticText(dlg, label=u"%d%%" % _zoom_pct[0], size=(40, -1))

        def _apply_zoom(pct):
            _zoom_pct[0] = max(50, min(200, pct))
            zoom_slider.SetValue(_zoom_pct[0])
            lbl_zoom.SetLabel(u"%d%%" % _zoom_pct[0])
            # wx.html.HtmlWindow espone SetFonts per variare la dimensione
            # Il secondo argomento è il font fisso; i successivi sono le 7 taglie
            base = _zoom_pct[0] // 10   # 5‥20 per zoom 50‥200
            sizes = [base - 2, base - 1, base, base + 1,
                     base + 2, base + 4, base + 6]
            hw.SetFonts("", "", sizes)
            hw.Refresh()

        def _on_zoom_out(e):
            _apply_zoom(_zoom_pct[0] - 10)
        def _on_zoom_in(e):
            _apply_zoom(_zoom_pct[0] + 10)
        def _on_slider(e):
            _apply_zoom(zoom_slider.GetValue())

        btn_zoom_out.Bind(wx.EVT_BUTTON, _on_zoom_out)
        btn_zoom_in.Bind(wx.EVT_BUTTON,  _on_zoom_in)
        zoom_slider.Bind(wx.EVT_SLIDER,  _on_slider)

        # ── Radiobutton tema Chiaro / Scuro ──────────────────────────
        rb_light = wx.RadioButton(dlg, label=_(u"Chiaro"), style=wx.RB_GROUP)
        rb_dark  = wx.RadioButton(dlg, label=_(u"Scuro"))
        # Icone sole / luna
        _sun_bmp  = wx.Bitmap(wx.Image(glb.AddPath('img/sun.png')))
        _moon_bmp = wx.Bitmap(wx.Image(glb.AddPath('img/moon.png')))
        icon_light = wx.StaticBitmap(dlg, -1, _sun_bmp)
        icon_dark  = wx.StaticBitmap(dlg, -1, _moon_bmp)
        # Ripristina la selezione salvata
        rb_dark.SetValue(_dark_mode[0])
        rb_light.SetValue(not _dark_mode[0])

        def _on_theme(e):
            dark = rb_dark.GetValue()
            _dark_mode[0] = dark
            _rebuild_page(dark)
            _apply_zoom(_zoom_pct[0])   # riapplica lo zoom dopo il reload

        rb_light.Bind(wx.EVT_RADIOBUTTON, _on_theme)
        rb_dark.Bind(wx.EVT_RADIOBUTTON,  _on_theme)

        btn_close = wx.Button(dlg, wx.ID_OK, _("Close"))

        # Layout barra: [Schermo intero]  [−][slider][+][%]  [Chiaro ☀][Scuro ☾]  [Chiudi]
        btn_row.Add(btn_max,      0, wx.ALIGN_CENTER_VERTICAL | wx.RIGHT, 8)
        btn_row.AddStretchSpacer()
        btn_row.Add(btn_zoom_out, 0, wx.ALIGN_CENTER_VERTICAL | wx.RIGHT, 2)
        btn_row.Add(zoom_slider,  0, wx.ALIGN_CENTER_VERTICAL | wx.RIGHT, 2)
        btn_row.Add(btn_zoom_in,  0, wx.ALIGN_CENTER_VERTICAL | wx.RIGHT, 4)
        btn_row.Add(lbl_zoom,     0, wx.ALIGN_CENTER_VERTICAL | wx.RIGHT, 16)
        btn_row.Add(icon_light,   0, wx.ALIGN_CENTER_VERTICAL | wx.RIGHT, 2)
        btn_row.Add(rb_light,     0, wx.ALIGN_CENTER_VERTICAL | wx.RIGHT, 8)
        btn_row.Add(icon_dark,    0, wx.ALIGN_CENTER_VERTICAL | wx.RIGHT, 2)
        btn_row.Add(rb_dark,      0, wx.ALIGN_CENTER_VERTICAL | wx.RIGHT, 16)
        btn_row.Add(btn_close,    0, wx.ALIGN_CENTER_VERTICAL)

        sizer.Add(btn_row, 0, wx.EXPAND | wx.LEFT | wx.RIGHT | wx.BOTTOM, 8)

        dlg.SetSizer(sizer)
        dlg.Layout()

        # Applica zoom e tema iniziali (dopo che tutti i controlli sono creati)
        _apply_zoom(_zoom_pct[0])

        dlg.ShowModal()

        # Salva le preferenze in pref (su disco le scriverà OnClose/_SaveGuidePrefs)
        self.pref.guideZoom     = _zoom_pct[0]
        self.pref.guideDarkMode = _dark_mode[0]

        dlg.Destroy()

    def _md_to_html(self, md_text):
        """Converte Markdown in HTML per wx.html.HtmlWindow.
        Il viewer usato dipende dalla preferenza pref.guideViewer:
          'markdown' → python-markdown (fallback: mistune → builtin)
          'mistune'  → mistune (fallback: builtin)
          'builtin'  → parser interno sempre
        """
        viewer = getattr(self.pref, 'guideViewer', 'markdown')

        if viewer in ('markdown', 'auto'):
            try:
                import markdown as _markdown_lib
                body = _markdown_lib.markdown(
                    md_text,
                    extensions=['tables', 'fenced_code'],
                )
                return self._md_wrap_html(body)
            except ImportError:
                pass
            # fallthrough a mistune
            viewer = 'mistune'

        if viewer == 'mistune':
            try:
                import mistune as _mistune_lib
                body = _mistune_lib.html(md_text)
                return self._md_wrap_html(body)
            except ImportError:
                pass
            # fallthrough a builtin

        # Parser interno (sempre disponibile)
        return self._md_to_html_builtin(md_text)

    @staticmethod
    def _md_wrap_html(body):
        """Avvolge il corpo HTML con head e stili comuni."""
        return (
            '<html><head><style>'
            'body{font-family:Arial,sans-serif;margin:16px;font-size:13px;}'
            'a{color:#0066cc;}'
            'pre{background:#f4f4f4;padding:8px;border-radius:4px;}'
            'code{background:#f0f0f0;padding:1px 4px;}'
            'table{border-collapse:collapse;}'
            'th,td{border:1px solid #ccc;padding:4px 8px;}'
            'th{background:#e8e8e8;font-weight:bold;}'
            'blockquote{border-left:3px solid #ccc;margin:0 0 0 12px;padding-left:8px;color:#555;}'
            '</style></head>'
            f'<body>{body}</body></html>'
        )

    def _md_to_html_builtin(self, md_text):
        """Parser Markdown interno, usato quando nessuna libreria esterna è disponibile."""
        import re

        # ── Helper ────────────────────────────────────────────────────
        def esc(s):
            """Escape caratteri HTML speciali."""
            return s.replace('&', '&amp;').replace('<', '&lt;').replace('>', '&gt;')

        def inline(s):
            """Applica le sostituzioni inline (grassetto, corsivo, code, link, img).

            Ordine di protezione: prima salva come placeholder codice inline,
            immagini e link (che possono contenere underscore), poi applica
            grassetto e corsivo, infine ripristina i placeholder.
            """
            placeholders = []

            def _save(text):
                placeholders.append(text)
                return '\x00PH%d\x00' % (len(placeholders) - 1)

            def _restore(s):
                for i, ph in enumerate(placeholders):
                    s = s.replace('\x00PH%d\x00' % i, ph)
                return s

            # 1. Codice inline `...`
            s = re.sub(r'`(.+?)`',
                       lambda m: _save('<code>' + m.group(1) + '</code>'), s)
            # 2. Immagini cliccabili [![alt](src)](href)
            s = re.sub(r'!\[([^\]]*)\]\(([^)]+)\)',
                       lambda m: _save(
                           '<img src="%s" alt="%s" style="max-width:100%%;">' % (m.group(2), m.group(1))
                       ), s)
            # 3. Link [testo](url) — protegge underscore nel testo e nell'href
            s = re.sub(r'\[([^\]]+)\]\(([^)]+)\)',
                       lambda m: _save('<a href="%s">%s</a>' % (m.group(2), m.group(1))), s)
            # 4. Grassetto+corsivo: ***testo***
            s = re.sub(r'\*\*\*(.+?)\*\*\*', r'<b><i>\1</i></b>', s)
            # 5. Grassetto: **testo** o __testo__
            s = re.sub(r'\*\*(.+?)\*\*', r'<b>\1</b>', s)
            s = re.sub(r'__(.+?)__',     r'<b>\1</b>', s)
            # 6. Corsivo: *testo* o _testo_
            #    Link, immagini e codice sono già nei placeholder: gli underscore
            #    al loro interno non vengono intaccati dalla regex seguente.
            s = re.sub(r'\*(.+?)\*', r'<i>\1</i>', s)
            s = re.sub(r'_(.+?)_',   r'<i>\1</i>', s)
            # 7. Ripristina tutti i placeholder
            return _restore(s)

        def close_lists(html_lines, list_stack):
            """Chiude tutti i livelli di lista aperti."""
            while list_stack:
                html_lines.append('</' + list_stack.pop() + '>')

        lines = md_text.split('\n')
        html_lines = []
        in_code    = False
        in_table   = False
        table_header_done = False
        in_blockquote = False
        list_stack = []   # stack di 'ul' / 'ol' per liste annidate
        blank_count = 0   # righe vuote consecutive

        for line in lines:
            # ── Blocco codice ─────────────────────────────────────────
            if line.startswith('```'):
                close_lists(html_lines, list_stack)
                if in_table:
                    html_lines.append('</table>')
                    in_table = False
                if in_blockquote:
                    html_lines.append('</blockquote>')
                    in_blockquote = False
                if in_code:
                    html_lines.append('</pre>')
                    in_code = False
                else:
                    html_lines.append('<pre>')
                    in_code = True
                blank_count = 0
                continue

            if in_code:
                html_lines.append(esc(line))
                continue

            # ── Tabella ───────────────────────────────────────────────
            if line.startswith('|'):
                close_lists(html_lines, list_stack)
                if in_blockquote:
                    html_lines.append('</blockquote>')
                    in_blockquote = False
                if not in_table:
                    html_lines.append(
                        '<table border="1" cellpadding="4" cellspacing="0"'
                        ' style="border-collapse:collapse;">'
                    )
                    in_table = True
                    table_header_done = False
                # Riga separatrice (|---|---|) → segna fine intestazione
                if re.match(r'^\|[-| :]+\|$', line):
                    table_header_done = True
                    continue
                cells = [inline(esc(c.strip())) for c in line.strip('|').split('|')]
                if not table_header_done:
                    html_lines.append(
                        '<tr>' + ''.join(f'<th>{c}</th>' for c in cells) + '</tr>'
                    )
                else:
                    html_lines.append(
                        '<tr>' + ''.join(f'<td>{c}</td>' for c in cells) + '</tr>'
                    )
                blank_count = 0
                continue
            else:
                if in_table:
                    html_lines.append('</table>')
                    in_table = False

            # ── Riga vuota ────────────────────────────────────────────
            if line.strip() == '':
                blank_count += 1
                # Chiude blockquote alla prima riga vuota
                if in_blockquote:
                    html_lines.append('</blockquote>')
                    in_blockquote = False
                # Una sola riga vuota tra paragrafi è sufficiente
                if blank_count == 1:
                    html_lines.append('<p style="margin:4px 0"> </p>')
                continue
            blank_count = 0

            # ── Blockquote: > testo ───────────────────────────────────
            bq_match = re.match(r'^> ?(.*)', line)
            if bq_match:
                close_lists(html_lines, list_stack)
                if not in_blockquote:
                    html_lines.append('<blockquote>')
                    in_blockquote = False  # rimane False; il tag è già aperto
                    in_blockquote = True
                html_lines.append(f'<p style="margin:2px 0">{inline(esc(bq_match.group(1)))}</p>')
                continue
            else:
                if in_blockquote:
                    html_lines.append('</blockquote>')
                    in_blockquote = False

            # ── Intestazioni (fino a ######) ──────────────────────────
            h_match = re.match(r'^(#{1,6}) (.*)', line)
            if h_match:
                close_lists(html_lines, list_stack)
                level = len(h_match.group(1))
                text  = h_match.group(2)
                # Genera slug anchor compatibile GitHub:
                # lowercase, spazi→'-', rimuove tutto tranne [a-z0-9_-]
                slug = re.sub(r'[^\w\s-]', '', text.lower())
                slug = re.sub(r'[\s]+', '-', slug.strip())
                slug = re.sub(r'-+', '-', slug)
                # L'anchor va FUORI dall'heading e PRIMA di esso,
                # racchiuso in un <p> a margine zero per non creare spazio visivo.
                # NON va dentro <h> perché _colorize_body aggiunge <font> dentro <h>
                # producendo <h><font><a name> che wx.html.HtmlWindow non naviga.
                html_lines.append(
                    f'<p style="margin:0;padding:0"><a name="{slug}"></a></p>'
                    f'<h{level}>{inline(esc(text))}</h{level}>'
                )
                continue

            # ── Separatore orizzontale ────────────────────────────────
            if re.match(r'^(-{3,}|\*{3,}|_{3,})$', line.strip()):
                close_lists(html_lines, list_stack)
                html_lines.append('<hr/>')
                continue

            # ── Liste puntate (-, *, +) con indentazione ──────────────
            ul_match = re.match(r'^( *)[-*+] (.*)', line)
            if ul_match:
                indent = len(ul_match.group(1)) // 2  # livello 0-based
                content = inline(esc(ul_match.group(2)))
                # Aggiusta lo stack al livello corrente
                while len(list_stack) > indent + 1:
                    html_lines.append('</' + list_stack.pop() + '>')
                if len(list_stack) < indent + 1:
                    html_lines.append('<ul>')
                    list_stack.append('ul')
                elif list_stack and list_stack[-1] == 'ol':
                    html_lines.append('</ol>')
                    list_stack.pop()
                    html_lines.append('<ul>')
                    list_stack.append('ul')
                html_lines.append(f'<li>{content}</li>')
                continue

            # ── Liste numerate (1. 2. …) ──────────────────────────────
            ol_match = re.match(r'^( *)\d+\. (.*)', line)
            if ol_match:
                indent = len(ol_match.group(1)) // 2
                content = inline(esc(ol_match.group(2)))
                while len(list_stack) > indent + 1:
                    html_lines.append('</' + list_stack.pop() + '>')
                if len(list_stack) < indent + 1:
                    html_lines.append('<ol>')
                    list_stack.append('ol')
                elif list_stack and list_stack[-1] == 'ul':
                    html_lines.append('</ul>')
                    list_stack.pop()
                    html_lines.append('<ol>')
                    list_stack.append('ol')
                html_lines.append(f'<li>{content}</li>')
                continue

            # ── Paragrafo generico ────────────────────────────────────
            close_lists(html_lines, list_stack)
            html_lines.append(f'<p style="margin:2px 0">{inline(esc(line))}</p>')

        # ── Chiusura tag rimasti aperti ───────────────────────────────
        close_lists(html_lines, list_stack)
        if in_table:
            html_lines.append('</table>')
        if in_code:
            html_lines.append('</pre>')
        if in_blockquote:
            html_lines.append('</blockquote>')

        body = '\n'.join(html_lines)
        return self._md_wrap_html(body)

    def OnGuideCommandsMarkdown(self, evt):
        """Apre la guida comandi di Songpress++ (guida_comandi_songpress[_lang].md).
        Interfaccia identica a OnGuideMarkdown: ricerca avanzata, zoom, tema chiaro/scuro,
        menu contestuale, schermo intero.
        """
        import os
        import wx.html

        locale = wx.GetLocale()
        lang_code = ''
        if locale:
            canonical = locale.GetCanonicalName()
            if canonical:
                lang_code = canonical.split('_')[0].lower()

        base_dir = os.path.dirname(__file__)
        _img_guide_url = 'file:///' + os.path.abspath(os.path.join(base_dir, 'img', 'GUIDE')).replace('\\', '/').lstrip('/') + '/'

        # Priorità: guida_comandi_songpress_<lang>.md → guida_comandi_songpress.md → errore
        candidates = []
        if lang_code:
            candidates.append(
                os.path.join(base_dir, 'guida_comandi_songpress_%s.md' % lang_code))
        candidates.append(os.path.join(base_dir, 'guida_comandi_songpress.md'))

        guide_path = None
        for path in candidates:
            if os.path.exists(path):
                guide_path = path
                break

        if guide_path is None:
            wx.MessageBox(
                _("Commands guide file not found in the program folder."),
                _("Help"),
                wx.ICON_ERROR,
            )
            return

        try:
            with open(guide_path, 'r', encoding='utf-8') as f:
                md_text = f.read()
        except Exception as e:
            wx.MessageBox(str(e), _("Error"), wx.ICON_ERROR)
            return

        import re
        _guide_pat = re.compile(
            r'(!\[[^\]]*\]\()(?:[^()]*?/)?img/GUIDE/'
        )
        if getattr(self.pref, 'guideMarkdownImgPath', False):
            md_text = _guide_pat.sub(r'\1../src/songpressPlusPlus/img/GUIDE/', md_text)
        else:
            md_text = _guide_pat.sub(lambda m: m.group(1) + _img_guide_url, md_text)

        html = self._md_to_html(md_text)

        dlg = wx.Dialog(
            self.frame,
            title=_(u"Songpress++ Commands Guide"),
            size=(760, 620),
            style=wx.DEFAULT_DIALOG_STYLE | wx.RESIZE_BORDER | wx.MAXIMIZE_BOX,
        )
        dlg.SetMinSize(wx.Size(550, 400))

        sizer = wx.BoxSizer(wx.VERTICAL)
        hw = wx.html.HtmlWindow(dlg, style=wx.html.HW_SCROLLBAR_AUTO)

        # ── Stato ricerca nella guida ─────────────────────────────────
        _search_state = {'term': '', 'matches': [], 'idx': -1, 'html_orig': '', 'html_themed': ''}

        def _guide_search_open():
            """Apre un mini-dialogo di ricerca testuale nella guida."""
            import re as _re2

            sdlg = wx.Dialog(
                dlg, title=_("Find in guide"),
                style=wx.DEFAULT_DIALOG_STYLE | wx.STAY_ON_TOP,
            )
            vsz = wx.BoxSizer(wx.VERTICAL)

            row_find = wx.BoxSizer(wx.HORIZONTAL)
            row_find.Add(
                wx.StaticText(sdlg, label=_("Find:")),
                0, wx.ALIGN_CENTER_VERTICAL | wx.RIGHT, 6,
            )
            txt = wx.TextCtrl(
                sdlg, value=_search_state['term'],
                size=(260, -1), style=wx.TE_PROCESS_ENTER,
            )
            row_find.Add(txt, 1, wx.EXPAND)
            vsz.Add(row_find, 0, wx.EXPAND | wx.ALL, 10)

            row_btns = wx.BoxSizer(wx.HORIZONTAL)

            def _make_arrow_btn(parent, art_id, img_name, label_fallback):
                bmp = wx.ArtProvider.GetBitmap(art_id, wx.ART_BUTTON, (24, 24))
                if not bmp.IsOk():
                    img = wx.Image(glb.AddPath('img/' + img_name))
                    bmp = wx.Bitmap(img) if img.IsOk() else wx.NullBitmap
                if bmp.IsOk():
                    btn = wx.BitmapButton(parent, bitmap=bmp, style=wx.BU_AUTODRAW)
                    btn.SetToolTip(label_fallback)
                else:
                    btn = wx.Button(parent, label=label_fallback)
                return btn

            btn_prev = _make_arrow_btn(sdlg, wx.ART_GO_BACK,    'arrow_left.png',  _("Previous"))
            btn_next = _make_arrow_btn(sdlg, wx.ART_GO_FORWARD, 'arrow_right.png', _("Next"))
            btn_next.SetDefault()

            lbl_count = wx.StaticText(sdlg, label='', size=(90, -1))
            lbl_count.SetForegroundColour(wx.Colour(80, 80, 80))

            btn_close = wx.Button(sdlg, wx.ID_CANCEL, _("Close"))

            row_btns.Add(btn_prev,  0, wx.ALIGN_CENTER_VERTICAL | wx.RIGHT, 4)
            row_btns.Add(btn_next,  0, wx.ALIGN_CENTER_VERTICAL | wx.RIGHT, 12)
            row_btns.Add(lbl_count, 0, wx.ALIGN_CENTER_VERTICAL | wx.RIGHT, 8)
            row_btns.AddStretchSpacer()
            row_btns.Add(btn_close, 0, wx.ALIGN_CENTER_VERTICAL)
            vsz.Add(row_btns, 0, wx.EXPAND | wx.LEFT | wx.RIGHT | wx.BOTTOM, 10)

            sdlg.SetSizer(vsz)
            vsz.Fit(sdlg)
            cur_w, cur_h = sdlg.GetSize()
            sdlg.SetMinSize(wx.Size(max(cur_w, 440), cur_h))
            sdlg.SetSize(wx.Size(max(cur_w, 440), cur_h))

            def _do_search(term, goto_idx=0):
                _search_state['term'] = term
                orig = _search_state.get('html_orig', '')
                if not orig:
                    return
                themed = _search_state.get('html_themed', '') or orig
                if not term:
                    hw.SetPage(themed)
                    _search_state['matches'] = []
                    _search_state['idx'] = -1
                    lbl_count.SetLabel('')
                    return
                escaped = _re2.escape(term)
                plain = _re2.sub(r'<[^>]+>', '', orig)
                matches = [m.start() for m in _re2.finditer(escaped, plain, _re2.IGNORECASE)]
                n = len(matches)
                if n == 0:
                    hw.SetPage(themed)
                    lbl_count.SetLabel(_("Not found"))
                    lbl_count.SetForegroundColour(wx.Colour(180, 0, 0))
                    _search_state['matches'] = matches
                    _search_state['idx'] = -1
                    lbl_count.GetParent().Layout()
                    return
                idx = max(0, min(goto_idx, n - 1))
                _search_state['matches'] = matches
                _search_state['idx'] = idx
                lbl_count.SetLabel(_("%d of %d") % (idx + 1, n))
                lbl_count.SetForegroundColour(wx.Colour(80, 80, 80))
                lbl_count.GetParent().Layout()
                counter = [0]
                def _replace_match(m):
                    i = counter[0]
                    counter[0] += 1
                    text = m.group(1)
                    if i == idx:
                        return ('<a name="__active__"></a>'
                                '<font bgcolor="#9ACD32" color="#000000"><b>' + text + '</b></font>')
                    return '<font bgcolor="#FFFF99" color="#000000">' + text + '</font>'
                highlighted = _re2.sub(r'(?i)(%s)' % escaped, _replace_match, themed)
                hw.SetPage(highlighted)
                _log_null = wx.LogNull()
                hw.ScrollToAnchor("__active__")
                del _log_null

            def _on_next(e):
                term = txt.GetValue().strip()
                if not term:
                    return
                idx = _search_state['idx']
                n   = len(_search_state['matches'])
                _do_search(term, (idx + 1) % n if n else 0)

            def _on_prev(e):
                term = txt.GetValue().strip()
                if not term:
                    return
                idx = _search_state['idx']
                n   = len(_search_state['matches'])
                _do_search(term, (idx - 1) % n if n else 0)

            def _on_close_search(e):
                # Ripristina la pagina con il tema corrente (non l'HTML grezzo)
                _rebuild_page(_dark_mode[0])
                _apply_zoom(_zoom_pct[0])
                _search_state['matches'] = []
                _search_state['idx'] = -1
                sdlg.EndModal(wx.ID_CANCEL)

            btn_next.Bind(wx.EVT_BUTTON, _on_next)
            btn_prev.Bind(wx.EVT_BUTTON, _on_prev)
            btn_close.Bind(wx.EVT_BUTTON, _on_close_search)
            txt.Bind(wx.EVT_TEXT_ENTER, _on_next)
            sdlg.Bind(wx.EVT_CLOSE, _on_close_search)

            txt.SetFocus()
            txt.SetSelection(-1, -1)
            if _search_state['term']:
                _do_search(_search_state['term'])

            sdlg.ShowModal()
            sdlg.Destroy()

        # ── Menu contestuale tasto destro ──────────────────────────────
        def _on_hw_right_click(evt):
            menu = wx.Menu()

            _copy_img = wx.Image(glb.AddPath('img/copy.png'))
            bmp_copy = wx.Bitmap(_copy_img) if _copy_img.IsOk() else wx.NullBitmap

            item_copy = wx.MenuItem(menu, wx.ID_COPY, _("Copy"))
            if bmp_copy.IsOk():
                item_copy.SetBitmap(bmp_copy)
            menu.Append(item_copy)

            sel = hw.SelectionToText()
            menu.Enable(wx.ID_COPY, bool(sel))

            def _copy(e):
                text = hw.SelectionToText()
                if text and wx.TheClipboard.Open():
                    wx.TheClipboard.SetData(wx.TextDataObject(text))
                    wx.TheClipboard.Close()

            menu.Bind(wx.EVT_MENU, _copy, id=wx.ID_COPY)
            menu.AppendSeparator()

            _id_search = wx.NewIdRef()
            _search_img = wx.Image(glb.AddPath('img/search.png'))
            _bmp_search = wx.Bitmap(_search_img) if _search_img.IsOk() \
                else wx.ArtProvider.GetBitmap(wx.ART_FIND, wx.ART_MENU, (16, 16))
            item_search = wx.MenuItem(menu, _id_search, _("Find in guide..."))
            if _bmp_search.IsOk():
                item_search.SetBitmap(_bmp_search)
            menu.Append(item_search)

            def _on_search(e):
                if not _search_state.get('html_orig'):
                    _search_state['html_orig'] = hw.GetParser().GetSource() \
                        if hw.GetParser() else ''
                # Se c'è testo selezionato nella guida, lo usa come termine di ricerca
                sel = hw.SelectionToText().strip()
                if sel:
                    _search_state['term'] = sel
                _guide_search_open()

            menu.Bind(wx.EVT_MENU, _on_search, id=_id_search)
            hw.PopupMenu(menu)
            menu.Destroy()

        hw.Bind(wx.EVT_RIGHT_DOWN, _on_hw_right_click)

        sizer.Add(hw, 1, wx.EXPAND | wx.ALL, 4)

        # ── Stato zoom e tema — condivisi con OnGuideMarkdown ────────
        _zoom_pct  = [max(50, min(200, getattr(self.pref, 'guideZoom', 100)))]
        _dark_mode = [bool(getattr(self.pref, 'guideDarkMode', False))]

        _THEME = {
            False: {
                'bg':       '#ffffff', 'text':     '#000000', 'link':     '#0066cc',
                'pre_bg':   '#f4f4f4', 'pre_fg':   '#000000', 'th_bg':    '#e8e8e8',
                'td_border':'#cccccc', 'bq_fg':    '#555555', 'h_fg':     '#000000',
            },
            True: {
                'bg':       '#1e1e1e', 'text':     '#d4d4d4', 'link':     '#4fc1ff',
                'pre_bg':   '#2d2d2d', 'pre_fg':   '#ce9178', 'th_bg':    '#3a3a3a',
                'td_border':'#555555', 'bq_fg':    '#999999', 'h_fg':     '#9cdcfe',
            },
        }

        import re as _re

        def _colorize_body(body_html, dark):
            p = _THEME[dark]
            body_html = _re.sub(
                r'<pre(\s[^>]*)?>',
                lambda m: '<pre bgcolor="%s"><font color="%s">' % (p['pre_bg'], p['pre_fg']),
                body_html, flags=_re.IGNORECASE,
            )
            body_html = _re.sub(r'</pre>', '</font></pre>', body_html, flags=_re.IGNORECASE)
            body_html = _re.sub(
                r'<th(\s[^>]*)?>',
                lambda m: '<th bgcolor="%s">' % p['th_bg'],
                body_html, flags=_re.IGNORECASE,
            )
            for hn in ('h1', 'h2', 'h3', 'h4'):
                body_html = _re.sub(
                    r'<' + hn + r'(\s[^>]*)?>',
                    lambda m, _hn=hn: '<%s><font color="%s">' % (_hn, p['h_fg']),
                    body_html, flags=_re.IGNORECASE,
                )
                body_html = _re.sub(
                    r'</' + hn + r'>',
                    '</font></%s>' % hn,
                    body_html, flags=_re.IGNORECASE,
                )
            return body_html

        def _rebuild_page(dark):
            p = _THEME[dark]
            body_colored = _colorize_body(html_body, dark)
            styled = (
                '<html><head></head>'
                '<body bgcolor="%s" text="%s" link="%s">'
                '%s'
                '</body></html>'
            ) % (p['bg'], p['text'], p['link'], body_colored)
            hw.SetBackgroundColour(wx.Colour(
                int(p['bg'][1:3], 16),
                int(p['bg'][3:5], 16),
                int(p['bg'][5:7], 16),
            ))
            hw.SetPage(styled)
            _search_state['html_themed'] = styled

        _body_m = _re.search(r'<body>(.*)</body>', html, _re.DOTALL | _re.IGNORECASE)
        html_body = _body_m.group(1) if _body_m else html
        _search_state['html_orig'] = html

        # ── Inietta anchor prima di ogni intestazione (parser esterni non li aggiungono) ─
        def _make_slug(text):
            slug = _re.sub(r'[^\w\s-]', '', text.lower())
            slug = _re.sub(r'[\s]+', '-', slug.strip())
            slug = _re.sub(r'-+', '-', slug)
            return slug

        def _inject_anchors(body_html):
            def _add_anchor(m):
                level   = m.group(1)
                attrs   = m.group(2) or ''
                content = m.group(3)
                plain   = _re.sub(r'<[^>]+>', '', content)
                slug    = _make_slug(plain)
                anchor  = '<p style="margin:0;padding:0"><a name="%s"></a></p>' % slug
                return '%s<%s%s>%s</%s>' % (anchor, level, attrs, content, level)
            return _re.sub(
                r'<(h[1-4])(\s[^>]*)?>(.+?)</\1>',
                lambda m: (
                    m.group(0) if _re.search(r'<a\s+name=', body_html[max(0, m.start()-120):m.start()])
                    else _add_anchor(m)
                ),
                body_html,
                flags=_re.DOTALL | _re.IGNORECASE,
            )

        html_body = _inject_anchors(html_body)

        # ── Handler link: bindato UNA VOLTA SOLA (fuori da _rebuild_page) ─
        def _on_link_clicked(e):
            href = e.GetLinkInfo().GetHref()
            if href.startswith('#'):
                anchor = _re.sub(r'-+', '-', href[1:])
                _log_null = wx.LogNull()
                hw.ScrollToAnchor(anchor)
                del _log_null
            else:
                wx.LaunchDefaultBrowser(href)
        hw.Bind(wx.html.EVT_HTML_LINK_CLICKED, _on_link_clicked)

        _rebuild_page(_dark_mode[0])

        # ── Barra inferiore: identica a OnGuideMarkdown ───────────────
        btn_row = wx.BoxSizer(wx.HORIZONTAL)

        btn_max = wx.Button(dlg, wx.ID_ANY, _("Full screen"))
        btn_max.SetToolTip(_("Toggle full screen"))

        def _on_toggle_max(e):
            if dlg.IsMaximized():
                dlg.Restore()
                btn_max.SetLabel(_("Full screen"))
            else:
                dlg.Maximize()
                btn_max.SetLabel(_("Restore"))

        btn_max.Bind(wx.EVT_BUTTON, _on_toggle_max)

        def _fix_btn_max_size():
            dc = wx.ClientDC(btn_max)
            dc.SetFont(btn_max.GetFont())
            w1 = dc.GetTextExtent(_("Full screen"))[0]
            w2 = dc.GetTextExtent(_("Restore"))[0]
            best = btn_max.GetBestSize()
            cur_tw = dc.GetTextExtent(btn_max.GetLabel())[0]
            padding = best.width - cur_tw
            min_w = max(w1, w2) + max(padding, 20)
            btn_max.SetMinSize(wx.Size(min_w, best.height))
            btn_max.GetContainingSizer().Layout()
        wx.CallAfter(_fix_btn_max_size)

        btn_zoom_out = wx.Button(dlg, wx.ID_ANY, u"−", size=(28, -1))
        btn_zoom_out.SetToolTip(_("Zoom out"))

        zoom_slider = wx.Slider(
            dlg, value=_zoom_pct[0], minValue=50, maxValue=200,
            size=(160, -1), style=wx.SL_HORIZONTAL,
        )
        zoom_slider.SetToolTip(_("Zoom (50% – 200%)"))

        btn_zoom_in = wx.Button(dlg, wx.ID_ANY, u"+", size=(28, -1))
        btn_zoom_in.SetToolTip(_("Zoom in"))

        lbl_zoom = wx.StaticText(dlg, label=u"%d%%" % _zoom_pct[0], size=(40, -1))

        def _apply_zoom(pct):
            _zoom_pct[0] = max(50, min(200, pct))
            zoom_slider.SetValue(_zoom_pct[0])
            lbl_zoom.SetLabel(u"%d%%" % _zoom_pct[0])
            base  = _zoom_pct[0] // 10
            sizes = [base - 2, base - 1, base, base + 1, base + 2, base + 4, base + 6]
            hw.SetFonts("", "", sizes)
            hw.Refresh()

        btn_zoom_out.Bind(wx.EVT_BUTTON, lambda e: _apply_zoom(_zoom_pct[0] - 10))
        btn_zoom_in.Bind(wx.EVT_BUTTON,  lambda e: _apply_zoom(_zoom_pct[0] + 10))
        zoom_slider.Bind(wx.EVT_SLIDER,  lambda e: _apply_zoom(zoom_slider.GetValue()))

        rb_light = wx.RadioButton(dlg, label=_(u"Chiaro"), style=wx.RB_GROUP)
        rb_dark  = wx.RadioButton(dlg, label=_(u"Scuro"))
        _sun_bmp  = wx.Bitmap(wx.Image(glb.AddPath('img/sun.png')))
        _moon_bmp = wx.Bitmap(wx.Image(glb.AddPath('img/moon.png')))
        icon_light = wx.StaticBitmap(dlg, -1, _sun_bmp)
        icon_dark  = wx.StaticBitmap(dlg, -1, _moon_bmp)
        rb_dark.SetValue(_dark_mode[0])
        rb_light.SetValue(not _dark_mode[0])

        def _on_theme(e):
            dark = rb_dark.GetValue()
            _dark_mode[0] = dark
            _rebuild_page(dark)
            _apply_zoom(_zoom_pct[0])

        rb_light.Bind(wx.EVT_RADIOBUTTON, _on_theme)
        rb_dark.Bind(wx.EVT_RADIOBUTTON,  _on_theme)

        btn_close = wx.Button(dlg, wx.ID_OK, _("Close"))

        btn_row.Add(btn_max,      0, wx.ALIGN_CENTER_VERTICAL | wx.RIGHT, 8)
        btn_row.AddStretchSpacer()
        btn_row.Add(btn_zoom_out, 0, wx.ALIGN_CENTER_VERTICAL | wx.RIGHT, 2)
        btn_row.Add(zoom_slider,  0, wx.ALIGN_CENTER_VERTICAL | wx.RIGHT, 2)
        btn_row.Add(btn_zoom_in,  0, wx.ALIGN_CENTER_VERTICAL | wx.RIGHT, 4)
        btn_row.Add(lbl_zoom,     0, wx.ALIGN_CENTER_VERTICAL | wx.RIGHT, 16)
        btn_row.Add(icon_light,   0, wx.ALIGN_CENTER_VERTICAL | wx.RIGHT, 2)
        btn_row.Add(rb_light,     0, wx.ALIGN_CENTER_VERTICAL | wx.RIGHT, 8)
        btn_row.Add(icon_dark,    0, wx.ALIGN_CENTER_VERTICAL | wx.RIGHT, 2)
        btn_row.Add(rb_dark,      0, wx.ALIGN_CENTER_VERTICAL | wx.RIGHT, 16)
        btn_row.Add(btn_close,    0, wx.ALIGN_CENTER_VERTICAL)

        sizer.Add(btn_row, 0, wx.EXPAND | wx.LEFT | wx.RIGHT | wx.BOTTOM, 8)

        # ── Tasto destro apre la ricerca, Ctrl+F anche ────────────────
        def _on_key(event):
            if event.GetKeyCode() == ord('F') and event.ControlDown():
                _guide_search_open()
            event.Skip()
        hw.Bind(wx.EVT_KEY_DOWN, _on_key)
        dlg.Bind(wx.EVT_KEY_DOWN, _on_key)

        dlg.SetSizer(sizer)
        dlg.Layout()
        _apply_zoom(_zoom_pct[0])

        dlg.ShowModal()

        # Salva zoom e tema nelle preferenze (condivise con OnGuideMarkdown)
        self.pref.guideZoom     = _zoom_pct[0]
        self.pref.guideDarkMode = _dark_mode[0]

        dlg.Destroy()

    def OnIdle(self, evt):
        try:
            cp = self.text.CanPaste()
            self.mainToolBar.EnableTool(self.pasteTool, cp)
            self.menuBar.Enable(self.pasteMenuId, cp)
            self.mainToolBar.EnableTool(self.pasteChordsTool, cp)
            self.menuBar.Enable(self.pasteChordsMenuId, cp)
        except Exception:
            # When frame is closed, this method may still be executed, generating an exception
            # because UI elements have been destroyed. Simply ignore it.
            pass
        evt.Skip()

    def OnFormatFont(self, evt):
        f = FontFaceDialog(
            self.frame,
            wx.ID_ANY,
            _("Songpress++ Preview Text"),
            self.pref.format,
            self.pref.decorator,
            self.pref.decoratorFormat,
            greyBackground=getattr(self.pref, 'greyBackground', True)
        )
        if f.ShowModal() == wx.ID_OK:
            self.pref.SetFont(f.GetValue())
            self.SetFont()

    def OnTextFont(self, evt):
        data = wx.FontData()
        data.SetInitialFont(self.pref.format.wxFont)
        data.SetColour(self.pref.format.color)

        dialog = wx.FontDialog(self.frame, data)
        dialog.SetTitle(_("Songpress++ Editor Font"))
        if dialog.ShowModal() == wx.ID_OK:
            retData = dialog.GetFontData()
            font = retData.GetChosenFont()
            face = font.GetFaceName()
            size = font.GetPointSize()
            color = retData.GetColour().GetAsString(wx.C2S_HTML_SYNTAX)
            s = f"{{textfont:{face}}}{{textsize:{size}}}{{textcolour:{color}}}|"
            s += "{textfont}{textsize}{textcolour}"
            self.InsertWithCaret(s)

    def OnChordFont(self, evt):
        data = wx.FontData()
        data.SetInitialFont(self.pref.format.wxFont)
        data.SetColour(self.pref.format.color)

        dialog = wx.FontDialog(self.frame, data)
        dialog.SetTitle(_("Chord font - Songpress++"))
        if dialog.ShowModal() == wx.ID_OK:
            retData = dialog.GetFontData()
            font = retData.GetChosenFont()
            face = font.GetFaceName()
            size = font.GetPointSize()
            color = retData.GetColour().GetAsString(wx.C2S_HTML_SYNTAX)
            s = f"{{chordfont:{face}}}{{chordsize:{size}}}{{chordcolour:{color}}}|"
            s += "{chordfont}{chordsize}{chordcolour}"
            self.InsertWithCaret(s)

    def OnTranspose(self, evt):
        sel = self.text.GetSelectedText()
        selected_text = sel if sel else None
        full_text = self.text.GetText()
        t = MyTransposeDialog(self.frame, self.pref.notations, full_text, selected_text)
        if t.ShowModal() == wx.ID_OK:
            transposed = t.GetTransposed()
            if t.SelectionOnly():
                # Build the complete final document in one shot:
                # splice the transposed selection back and (if checked)
                # update all {beats_time:} directives — then write once.
                final = t.GetTransposedFullText(transposed)
                self.text.SetText(final)
            else:
                self.text.SetText(transposed)

    def OnSimplifyChords(self, evt):
        self.text.AutoChangeMode(True)
        t = self.text.GetTextOrSelection()
        notation = autodetectNotation(t, self.pref.notations)
        count, c, dc, e, de = findEasiestKey(t, self.pref.GetEasyChords(), notation)
        title = _("Simplify chords")
        if count > 0 and dc != de:
            msg = _("The key of your song, %s, is not the easiest to play (difficulty: %.1f/5.0).\n") % (c, 5 * dc)
            msg += _("Do you want to transpose the key %s, which is the easiest one (difficulty: %.1f/5.0)?") % (e, 5 * de)
            d = wx.MessageDialog(self.frame, msg, title, wx.YES_NO | wx.ICON_QUESTION)
            if d.ShowModal() == wx.ID_YES:
                t = transposeChordPro(translateChord(c, notation), translateChord(e, notation), t, notation)
                self.text.ReplaceTextOrSelection(t)
        else:
            if count > 0:
                msg = _("The key of your song, %s, is already the easiest to play (difficulty: %.1f/5.0).\n") % (c, 5 * dc)
            else:
                msg = _("Your song or current selection does not contain any chords.")
            d = wx.MessageDialog(self.frame, msg, title, wx.OK | wx.ICON_INFORMATION)
            d.ShowModal()
        self.text.AutoChangeMode(False)

    def OnChangeChordNotation(self, evt):
        t = MyNotationDialog(self.frame, self.pref.notations, self.text.GetTextOrSelection())
        if t.ShowModal() == wx.ID_OK:
            self.text.ReplaceTextOrSelection(t.ChangeChordNotation())

    def OnNormalizeChords(self, evt):
        t = MyNormalizeDialog(self.frame, self.pref.notations, self.text.GetTextOrSelection())
        if t.ShowModal() == wx.ID_OK:
            self.text.ReplaceTextOrSelection(t.NormalizeChords())

    def OnConvertTabToChordpro(self, evt):
        t = self.text.GetTextOrSelection()
        n = testTabFormat(t, self.pref.notations)
        if n is not None:
            self.text.ReplaceTextOrSelection(tab2ChordPro(t, n))

    def OnRemoveSpuriousBlankLines(self, evt):
        self.text.ReplaceTextOrSelection(removeSpuriousLines(self.text.GetTextOrSelection()))

    def OnOptions(self, evt):
        def _apply_prefs():
            self.text.SetFont(self.pref.editorFace, int(self.pref.editorSize))
            self.SetDefaultExtension(self.pref.defaultExtension)
            self.previewCanvas.SetLineWidths(self.pref.titleLineWidth, self.pref.verseBoxWidth)
            self._applyKlavierHighlightColor()
            self._applyFingerNumColor()
            self.text.SetBgColour(getattr(self.pref, 'editorBgHex', '#FFFFFF'))
            self.text.SetSelColour(getattr(self.pref, 'selColourHex', '#3399FF'))
            self.text.SetCaretColour(getattr(self.pref, 'caretColourHex', '#000000'))
            _sc = getattr(self.pref, 'syntaxColours', {})
            for _k, _sid in [('normal', 11), ('chorus', 15), ('chord', 12), ('command', 13), ('attr', 14), ('comment', 16), ('tabgrid', 17)]:
                if _k in _sc:
                    self.text.SetSyntaxColour(_sid, _sc[_k])
            self.text.ApplyMultiCursor(getattr(self.pref, 'multiCursor', False))
            self._UpdateStatusIndicators()
            self._SaveCustomColours()
            self.previewCanvas.SetTempoDisplay(getattr(self.pref, 'tempoDisplay', 0))
            self.previewCanvas.SetTempoIconSize(getattr(self.pref, 'tempoIconSize', 24))
            self.previewCanvas.SetGridDisplayMode(getattr(self.pref, 'gridDisplayMode', 'pipe'))
            self.previewCanvas.SetGridDefaultLabel(getattr(self.pref, 'gridDefaultLabel', None))
            self.previewCanvas.SetGridSizeDir(getattr(self.pref, 'gridSizeDir', 'both'))
            self.previewCanvas.SetPageMarginsMm(self._margin_top, self._margin_bottom)
            self.previewCanvas.SetDurationBeatsPrefs(
                getattr(self.pref, 'durationBeatsColourHex', '#6464C8'),
                getattr(self.pref, 'durationBeatsSizePct', 60),
                getattr(self.pref, 'durationBeatsBold', False),
                getattr(self.pref, 'durationBeatsAlign', 'right'),
                getattr(self.pref, 'durationBeatsMode', 'number'),
            )
            # Bug fix: usa ignore_selection=True per evitare che una selezione
            # residua da Trova/Sostituisci faccia mostrare nell'anteprima solo
            # il testo trovato (es. "ffffff") invece dell'intero documento.
            self.previewCanvas.Refresh(self._get_display_text(ignore_selection=True))
            # Aggiorna il MinSize del pane AUI in base alla preferenza corrente
            self._ApplyPreviewMinSize()
            # Aggiorna i colori delle caption bar con i nuovi valori da pref
            self._dockArt._pref = self.pref
            self._mgr.Update()
            self._ApplyRestartMenuVisibility()
            self._ApplyMainToolBarVisibility()
            self._ApplyFormatToolBarVisibility()
            self._ApplyInsertToolBarVisibility()
            self._ApplyViewToolBarVisibility()

        f = MyPreferencesDialog(self.frame, self.pref, easyChords, on_apply=_apply_prefs,
                                previewCanvas=self.previewCanvas)
        if f.ShowModal() == wx.ID_OK:
            _apply_prefs()
        if f.clearRecentFiles:
            self._ClearRecentFiles()
        if getattr(f, '_restart_requested', False):
            self.OnRestart(None)

    def _ClearRecentFiles(self):
        """Remove all entries from the recent files history."""
        self.ClearRecentFiles()

    def _applyKlavierHighlightColor(self):
        """Converte klavierHighlightHex in wx.Colour e lo applica al decorator."""
        self.pref.decorator.klavierHighlightColor = self._getKlavierHighlightColour()

    def _getKlavierHighlightColour(self):
        """Restituisce wx.Colour dal valore hex salvato nelle preferenze."""
        hex_str = getattr(self.pref, 'klavierHighlightHex', '#D23C3C')
        try:
            h = hex_str.strip().lstrip('#')
            r, g, b = int(h[0:2], 16), int(h[2:4], 16), int(h[4:6], 16)
            return wx.Colour(r, g, b)
        except Exception:
            return wx.Colour(210, 60, 60)

    def _getFingerNumColour(self):
        """Restituisce wx.Colour per i numeri delle dita sulla tastiera."""
        hex_str = getattr(self.pref, 'fingerNumColourHex', '#1A1A1A')
        try:
            h = hex_str.strip().lstrip('#')
            r, g, b = int(h[0:2], 16), int(h[2:4], 16), int(h[4:6], 16)
            return wx.Colour(r, g, b)
        except Exception:
            return wx.Colour(26, 26, 26)

    def _applyFingerNumColor(self):
        """Applica il colore dei numeri dita al decorator."""
        self.pref.decorator.fingerNumColor = self._getFingerNumColour()

    def StripSelection(self):
        """
        Update selection, moving blank characters out of it
        """
        s, e = self.text.GetSelection()
        mod = False
        while e > s and self.text.GetTextRange((ep := self.text.PositionBefore(e)), e).strip() == '':
            e = ep
            mod = True
        while s < e and self.text.GetTextRange(s, (sa := self.text.PositionAfter(s))).strip() == '':
            s = sa
            mod = True
        if mod:
            self.text.SetSelection(s, e)

    def InsertWithCaret(self, st):
        n = self.text.GetSelections()
        if n > 1:
            # --- Multicursore: inserisci su ogni selezione in ordine inverso ---
            # Raccoglie (start, end) di tutte le selezioni ordinate dalla più lontana
            # alla più vicina, così ogni modifica non sposta le posizioni successive.
            sels = sorted(
                [(self.text.GetSelectionNStart(i), self.text.GetSelectionNEnd(i))
                 for i in range(n)],
                reverse=True
            )
            c = st.find('|')
            for s, e in sels:
                self.text.SetSelection(s, e)
                self.StripSelection()
                s2, e2 = self.text.GetSelection()
                if c != -1:
                    sel_text = self.text.GetSelectedText()
                    self.text.ReplaceSelection(st[:c] + sel_text + st[c + 1:])
                    self.text.SetSelection(s2 + c, e2 + c)
                else:
                    self.text.ReplaceSelection(st)
                    self.text.SetSelection(s2 + len(st), s2 + len(st))
        else:
            # --- Cursore singolo: comportamento originale ---
            self.StripSelection()
            s, e = self.text.GetSelection()
            c = st.find('|')
            if c != -1:
                sel_text = self.text.GetSelectedText()
                self.text.ReplaceSelection(st[:c] + sel_text + st[c + 1:])
                self.text.SetSelection(s + c, e + c)
            else:
                self.text.ReplaceSelection(st)
                self.text.SetSelection(s + len(st), s + len(st))

    def OnTitle(self, evt):
        self.InsertWithCaret("{title:|}")

    def OnSubtitle(self, evt):
        self.InsertWithCaret("{subtitle:|}")

    def OnChord(self, evt):
        # Se il dialogo è già aperto (modalità pinnata), riportalo in primo piano
        if getattr(self, '_chord_dlg', None) is not None:
            try:
                self._chord_dlg.Raise()
                self._chord_dlg.SetFocus()
                return
            except Exception:
                self._chord_dlg = None

        PIN_OFF = u"📌"
        PIN_ON  = u"📍"

        # Dialogo non modale: il cursore dell'editor rimane raggiungibile con le frecce
        dlg = wx.Dialog(
            self.frame,
            title=_(u"Insert chord"),
            style=wx.DEFAULT_DIALOG_STYLE | wx.STAY_ON_TOP,
        )
        self._chord_dlg = dlg

        vbox = wx.BoxSizer(wx.VERTICAL)

        # Campo testo
        row = wx.BoxSizer(wx.HORIZONTAL)
        row.Add(wx.StaticText(dlg, label=_(u"Chord:")),
                0, wx.ALIGN_CENTER_VERTICAL | wx.RIGHT, 6)
        txt = wx.TextCtrl(dlg, size=(140, -1), style=wx.TE_PROCESS_ENTER)
        row.Add(txt, 1, wx.EXPAND)
        vbox.Add(row, 0, wx.EXPAND | wx.ALL, 10)

        # Bottoni: [📌] [OK] [Annulla]
        btn_pin    = wx.Button(dlg, wx.ID_ANY,
                               PIN_ON if self._chord_dialog_pinned else PIN_OFF,
                               size=(32, -1))
        btn_pin.SetToolTip(_(u"Keep this dialog open after inserting"))
        btn_ok     = wx.Button(dlg, wx.ID_OK,     _(u"OK"))
        btn_cancel = wx.Button(dlg, wx.ID_CANCEL, _(u"Cancel"))
        btn_ok.SetDefault()

        btn_sizer = wx.BoxSizer(wx.HORIZONTAL)
        btn_sizer.Add(btn_pin,    0, wx.RIGHT, 4)
        btn_sizer.AddStretchSpacer()
        btn_sizer.Add(btn_ok,     0, wx.RIGHT, 4)
        btn_sizer.Add(btn_cancel, 0)
        vbox.Add(btn_sizer, 0, wx.EXPAND | wx.LEFT | wx.RIGHT | wx.BOTTOM, 8)

        dlg.SetSizer(vbox)
        vbox.Fit(dlg)

        def _insert():
            chord = txt.GetValue().strip()
            if chord:
                self.InsertWithCaret("[%s]" % chord)
            else:
                self.InsertWithCaret("[|]")
            # Dopo inserimento: focus torna all'editor per usare le frecce
            self.text.SetFocus()

        def on_pin(e):
            self._chord_dialog_pinned = not self._chord_dialog_pinned
            btn_pin.SetLabel(PIN_ON if self._chord_dialog_pinned else PIN_OFF)

        def on_ok(e):
            _insert()
            if self._chord_dialog_pinned:
                txt.SetValue("")
                # Focus all'editor: le frecce spostano il cursore nel testo
                self.text.SetFocus()
            else:
                dlg.Destroy()

        def on_cancel(e):
            dlg.Destroy()

        def on_close(e):
            self._chord_dlg = None
            e.Skip()

        # Enter nel campo testo = OK
        txt.Bind(wx.EVT_TEXT_ENTER, on_ok)
        btn_pin.Bind(wx.EVT_BUTTON, on_pin)
        btn_ok.Bind(wx.EVT_BUTTON, on_ok)
        btn_cancel.Bind(wx.EVT_BUTTON, on_cancel)
        dlg.Bind(wx.EVT_CLOSE, on_close)

        # Dialogo non modale: Show() invece di ShowModal()
        dlg.Show()

    def OnVerse(self, evt):
        label = wx.GetTextFromUser(
            _("Insert a label for verse, or press Cancel if you want to omit label."),
            _("Verse label"),
            "",
            self.frame,
        )
        self.InsertWithCaret("{Verse:%s}|" % label)

    def OnChorus(self, evt):
        default = self.pref.decoratorFormat.GetChorusLabel()
        label = wx.GetTextFromUser(
            _("Insert a label for chorus, or press Cancel if you want to omit label."),
            _("Chorus label"),
            default,
            self.frame,
        )
        if label == default:
            self.InsertWithCaret("{soc}\n|\n{eoc}\n")
        else:
            self.InsertWithCaret("{soc:%s}\n|\n{eoc}\n" % label)

    def OnComment(self, evt):
        """Chiede il tipo di commento e il testo, poi inserisce la direttiva scelta."""
        d = wx.Dialog(self.frame, title=_(u"Comment"))
        vbox = wx.BoxSizer(wx.VERTICAL)

        vbox.Add(wx.StaticText(d, -1, _(u"Comment type:")), 0, wx.ALL, 8)
        rb_comment = wx.RadioButton(d, -1, u"{comment:}", style=wx.RB_GROUP)
        rb_box     = wx.RadioButton(d, -1, u"{comment_box:}")
        rb_hash    = wx.RadioButton(d, -1, u"# commento")
        rb_comment.SetValue(True)
        for rb in (rb_comment, rb_box, rb_hash):
            vbox.Add(rb, 0, wx.LEFT | wx.BOTTOM, 8)

        vbox.Add(wx.StaticText(d, -1, _(u"Comment text:")), 0, wx.LEFT, 8)
        txt = wx.TextCtrl(d, -1, u"")
        vbox.Add(txt, 0, wx.EXPAND | wx.ALL, 8)

        btn_sizer = d.CreateButtonSizer(wx.OK | wx.CANCEL)
        vbox.Add(btn_sizer, 0, wx.ALL | wx.ALIGN_RIGHT, 8)
        d.SetSizer(vbox)
        vbox.Fit(d)

        if d.ShowModal() == wx.ID_OK:
            val = txt.GetValue()
            if rb_box.GetValue():
                directive = u"comment_box"
                self.InsertWithCaret(u"{%s:%s|}" % (directive, val) if not val else u"{%s:%s}" % (directive, val))
            elif rb_hash.GetValue():
                self.InsertWithCaret(u"# %s" % val)
            else:
                directive = u"comment"
                self.InsertWithCaret(u"{%s:%s|}" % (directive, val) if not val else u"{%s:%s}" % (directive, val))
        d.Destroy()

    def OnInsertPageBreak(self, evt):
        """Inserisce un'interruzione di pagina esplicita per la stampa."""
        self.InsertWithCaret("{new_page}\n")

    def OnInsertColumnBreak(self, evt):
        """Inserisce un'interruzione di colonna esplicita per il layout a due colonne."""
        self.InsertWithCaret("{column_break}\n")

    def OnLabelVerses(self, evt):
        self.pref.labelVerses = not self.pref.labelVerses
        self.CheckLabelVerses()

    def _OnPreviewClick(self, line_number):
        """Callback dal doppio-click sull'anteprima.

        Porta il cursore alla riga sorgente trovata tramite hit-test,
        seleziona l'intera riga per renderla visibile e sposta il focus
        sull'editor.

        line_number e' 0-based, corrisponde alla riga ChordPro piu' vicina
        al punto cliccato (risolto con hit-test preciso sui SongBox).
        """
        try:
            pos_start = self.text.PositionFromLine(line_number)
            pos_end   = self.text.GetLineEndPosition(line_number)
            # Seleziona la riga trovata cosi' e' immediatamente visibile
            self.text.SetSelection(pos_start, pos_end)
            self.text.EnsureCaretVisible()
            self.text.SetFocus()
        except Exception:
            pass

    def OnTogglePageBreakLines(self, evt):

        self._showPageBreakLines = evt.IsChecked()
        self.previewCanvas.SetShowPageBreakLines(self._showPageBreakLines)
        self.previewCanvas.Refresh(self._get_display_text())

    def OnToggleColumnBreakLines(self, evt):
        self._showColumnBreakLines = evt.IsChecked()
        self.previewCanvas.SetShowColumnBreakLines(self._showColumnBreakLines)
        self.previewCanvas.Refresh(self._get_display_text())

    def OnToggleDurationBeats(self, evt):
        self._showDurationBeats = evt.IsChecked()
        self.previewCanvas.SetShowDurationBeats(self._showDurationBeats)
        self.previewCanvas.SetDurationBeatsPrefs(
            getattr(self.pref, 'durationBeatsColourHex', '#6464C8'),
            getattr(self.pref, 'durationBeatsSizePct', 60),
            getattr(self.pref, 'durationBeatsBold', False),
            getattr(self.pref, 'durationBeatsAlign', 'right'),
            getattr(self.pref, 'durationBeatsMode', 'number'),
        )
        self.previewCanvas.Refresh(self._get_display_text())

    def _UpdateBreakLinesMenuState(self):
        """Abilita o disabilita le voci di menu delle linee di interruzione
        in base alla visibilità del pannello anteprima."""
        preview_visible = self._mgr.GetPane('preview').IsShown()
        self.menuBar.Enable(self._showPageBreakLinesMenuId, preview_visible)
        self.menuBar.Enable(self._showColumnBreakLinesMenuId, preview_visible)
        self.menuBar.Enable(self._showDurationBeatsMenuId, preview_visible)

    def _ApplyPreviewMinSize(self):
        """Reimposta BestSize e MinSize sul pane 'preview' e sul main_panel.
        Deve essere chiamata dopo LoadPerspective, dopo ogni toggle di visibilità,
        e dopo che l'utente cambia la preferenza nelle opzioni.
        LoadPerspective sovrascrive queste proprietà con i valori salvati,
        che possono essere arbitrariamente piccoli.
        """
        enabled = getattr(self.pref, 'previewMinSize', True)
        if enabled:
            min_sz = wx.Size(370, 520)
        else:
            min_sz = wx.Size(-1, -1)
        # Aggiorna il pane AUI
        pane = self._mgr.GetPane('preview')
        pane.BestSize(370, 520).MinSize(min_sz)
        # Aggiorna anche il wx.Window sottostante (doppio vincolo)
        self.previewCanvas.main_panel.SetMinSize(min_sz)

    def OnTogglePaneView(self, evt):
        super().OnTogglePaneView(evt)
        # Dopo il toggle, se il pannello preview è ora visibile,
        # reimpostiamo MinSize perché LoadPerspective potrebbe averlo azzerato
        pane = self._mgr.GetPane('preview')
        if pane.IsShown():
            self._ApplyPreviewMinSize()
            self._mgr.Update()
        self._UpdateBreakLinesMenuState()
        self._SyncPreviewToggleButton()

    def _SyncPreviewToggleButton(self):
        """Sincronizza lo stato premuto/rilasciato del pulsante toggle preview nella toolbar."""
        if not hasattr(self, 'togglePreviewViewToolId'):
            return
        pane = self._mgr.GetPane('preview')
        visible = pane.IsShown()
        self.viewToolBar.ToggleTool(self.togglePreviewViewToolId, visible)
        self.viewToolBar.Refresh()

    def OnPaneClose(self, evt):
        super().OnPaneClose(evt)
        # EVT_AUI_PANE_CLOSE scatta prima che IsShown() venga aggiornato:
        # se il pane che si chiude è 'preview', disabilita subito le voci.
        if evt.GetPane().name == 'preview':
            self.menuBar.Enable(self._showPageBreakLinesMenuId, False)
            self.menuBar.Enable(self._showColumnBreakLinesMenuId, False)
            self.menuBar.Enable(self._showDurationBeatsMenuId, False)
            wx.CallAfter(self._SyncPreviewToggleButton)
        else:
            self._UpdateBreakLinesMenuState()

    def OnChorusLabel(self, evt):
        c = self.pref.decoratorFormat.GetChorusLabel()
        msg = _("Please enter a label for chorus")
        d = wx.TextEntryDialog(self.frame, msg, _("Songpress++"), c)
        if d.ShowModal() == wx.ID_OK:
            c = d.GetValue()
            self.pref.SetChorusLabel(c)
            self.previewCanvas.Refresh(self._get_display_text())

    def OnNoChords(self, evt):
        self.pref.format.showChords = 0
        self.SetFont(True)

    def OnOneVerseForEachChordPattern(self, evt):
        self.pref.format.showChords = 1
        self.SetFont(True)

    def OnWholeSong(self, evt):
        self.pref.format.showChords = 2
        self.SetFont(True)

    def OnChordsAbove(self, evt):
        self.pref.SetChordsPosition('above')
        self.CheckChordsPosition()
        self.previewCanvas.Refresh(self._get_display_text())

    def OnChordsBelow(self, evt):
        self.pref.SetChordsPosition('below')
        self.CheckChordsPosition()
        self.previewCanvas.Refresh(self._get_display_text())

    def CheckChordsPosition(self):
        above = (self.pref.chordsPosition == 'above')
        self.menuBar.Check(self.chordsAboveMenuId, above)
        self.menuBar.Check(self.chordsBelowMenuId, not above)
        self.previewCanvas.SetChordsBelow(not above)

    def OnTextChanged(self, evt):
        self.AutoAdjust(evt.lastPos, evt.currentPos)

    def AutoAdjust(self, lastPos, currentPos):
        if self.text.GetSelections() > 1:
            return  # non interferire con il multicursore attivo
        self.text.AutoChangeMode(True)
        t = self.text.GetTextRange(lastPos, currentPos)
        if self.pref.autoAdjustSpuriousLines:
            if testSpuriousLines(t):
                msg = _("It looks like there are spurious blank lines in the song.\n")
                msg += _("Do you want to try to remove them automatically?")
                title = _("Remove spurious blank lines")
                d = wx.MessageDialog(self.frame, msg, title, wx.YES_NO | wx.ICON_QUESTION)
                if d.ShowModal() == wx.ID_YES:
                    self.text.SetSelection(lastPos, currentPos)
                    t = removeSpuriousLines(t)
                    self.text.ReplaceSelection(t)
                    currentPos = self.text.GetCurrentPos()
        if self.pref.autoAdjustTab2Chordpro:
            n = testTabFormat(t, self.pref.notations)
            if n is not None:
                msg = _("It looks like your song is in tab format (i.e., chords are above the text).\n")
                msg += _("Do you want to convert it to ChordPro automatically?")
                title = _("Convert to ChordPro")
                d = wx.MessageDialog(self.frame, msg, title, wx.YES_NO | wx.ICON_QUESTION)
                if d.ShowModal() == wx.ID_YES:
                    self.text.SetSelection(lastPos, currentPos)
                    t = tab2ChordPro(t, n)
                    self.text.ReplaceSelection(t)
        if self.pref.autoAdjustEasyKey:
            notation = autodetectNotation(t, self.pref.notations)
            count, c, dc, e, de = findEasiestKey(t, self.pref.GetEasyChords(), notation)
            if count > 10 and dc != de:
                msg = _("The key of your song, %s, is not the easiest to play (difficulty: %.1f/5.0).\n") % (c, 5 * dc)
                msg += _("Do you want to transpose the key %s, which is the easiest one (difficulty: %.1f/5.0)?") % (e, 5 * de)
                title = _("Simplify chords")
                d = wx.MessageDialog(self.frame, msg, title, wx.YES_NO | wx.ICON_QUESTION)
                if d.ShowModal() == wx.ID_YES:
                    self.text.SetSelection(lastPos, currentPos)
                    t = transposeChordPro(translateChord(c, notation), translateChord(e, notation), t, notation)
                    self.text.ReplaceSelection(t)
        self.text.AutoChangeMode(False)

    def SetFont(self, updateFontChooser=True):
        try:
            if updateFontChooser:
                self.fontChooser.SetValue(self.pref.format.face)
                self.showChordsChooser.SetValue(self.pref.format.showChords)
                ids = [self.noChordsMenuId, self.oneVerseForEachChordPatternMenuId, self.wholeSongMenuId]
                self.menuBar.Check(ids[self.pref.format.showChords], True)

            self.previewCanvas.SetTempoDisplay(getattr(self.pref, 'tempoDisplay', 0))
            self.previewCanvas.SetTimeDisplay(getattr(self.pref, 'timeDisplay', True))
            self.previewCanvas.SetKeyDisplay(getattr(self.pref, 'keyDisplay', True))
            self.previewCanvas.SetTempoIconSize(getattr(self.pref, 'tempoIconSize', 24))
            self.previewCanvas.SetGridDisplayMode(getattr(self.pref, 'gridDisplayMode', 'pipe'))
            self.previewCanvas.SetGridDefaultLabel(getattr(self.pref, 'gridDefaultLabel', None))
            self.previewCanvas.SetGridSizeDir(getattr(self.pref, 'gridSizeDir', 'both'))
            self.previewCanvas.SetShowPageIndicator(getattr(self.pref, 'showPageIndicator', True))
            self.previewCanvas.SetGreyBackground(getattr(self.pref, 'greyBackground', True))
            _pw, _ph = self._GetPaperSizeMm()
            self.previewCanvas.SetPageSizeMm(_pw, _ph)
            self.previewCanvas.SetPageMarginsMm(self._margin_top, self._margin_bottom)
            self.previewCanvas.Refresh(self._get_display_text())
        except wx._core.PyDeadObjectError:
            # When frame is closed, this method may still be executed, generating an exception
            # because UI elements have been destroyed. Simply ignore it.
            pass

    def CheckLabelVerses(self):
        self.viewToolBar.ToggleTool(self.labelVersesViewToolId, self.pref.labelVerses)
        self.viewToolBar.Refresh()
        self.menuBar.Check(self.labelVersesMenuId, self.pref.labelVerses)
        if self.pref.labelVerses:
            self.pref.decorator.drawLabels = True
            self.pref.decorator.showKlavier = True
            self.pref.decorator.showGuitarDiagrams = True
            self.pref.decorator.klavierHighlightColor = self._getKlavierHighlightColour()
            self.pref.decorator.fingerNumColor = self._getFingerNumColour()
            self.previewCanvas.SetDecorator(self.pref.decorator)
        else:
            sd = SongDecorator()
            sd.drawLabels = False
            sd.showKlavier = True
            sd.showGuitarDiagrams = True
            sd.klavierHighlightColor = self._getKlavierHighlightColour()
            sd.fingerNumColor = self._getFingerNumColour()
            self.previewCanvas.SetDecorator(sd)
        self.previewCanvas.SetLineWidths(self.pref.titleLineWidth, self.pref.verseBoxWidth)
        self.previewCanvas.SetShowPageBreakLines(getattr(self, '_showPageBreakLines', True))
        self.previewCanvas.SetShowColumnBreakLines(getattr(self, '_showColumnBreakLines', True))
        self.previewCanvas.SetShowDurationBeats(getattr(self, '_showDurationBeats', True))
        self.previewCanvas.SetDurationBeatsPrefs(
            getattr(self.pref, 'durationBeatsColourHex', '#6464C8'),
            getattr(self.pref, 'durationBeatsSizePct', 60),
            getattr(self.pref, 'durationBeatsBold', False),
            getattr(self.pref, 'durationBeatsAlign', 'right'),
            getattr(self.pref, 'durationBeatsMode', 'number'),
        )
        self.previewCanvas.Refresh(self._get_display_text())