# Guida rapida — Songpress++

Questa guida descrive tutti i comandi ChordPro supportati da Songpress++ e le principali funzionalità dell'editor.

> **Legenda** — La colonna **Std** indica se la direttiva fa parte dello standard ChordPro ufficiale (✅) o è specifica di Songpress++ (🔧). La colonna **Menu** indica se la direttiva può essere inserita tramite un menu dell'applicazione (⌨️) o deve essere digitata manualmente nell'editor (🖊).

> **Tooltip** — Tutte le checkbox presenti nei dialoghi delle preferenze dispongono di un **tooltip descrittivo**: tenendo il puntatore del mouse fermo su una checkbox per qualche secondo comparirà una breve spiegazione della funzione corrispondente.

---

## Formato ChordPro — Concetti base

Un file ChordPro è un file di testo in cui gli **accordi** vengono inseriti direttamente nel testo della canzone, racchiusi tra parentesi quadre `[accordo]`. Le **direttive** di metadati e struttura sono racchiuse tra parentesi graffe `{direttiva:valore}`.

```chordpro
{title: Amazing Grace}
{artist: Traditional}
{key: G}

[G]Amazing [G7]grace, how [C]sweet the [G]sound
```

### Come digitare `{` e `}` sulla tastiera

| Sistema | `{` (graffa aperta) | `}` (graffa chiusa) |
| ------- | ------------------- | ------------------- |
| **Windows / Linux** — layout italiano | <kbd>Alt Gr</kbd> + <kbd>Shift</kbd> + <kbd>[</kbd> | <kbd>Alt Gr</kbd> + <kbd>Shift</kbd> + <kbd>]</kbd> |
| **Windows / Linux** — layout USA | <kbd>Shift</kbd> + <kbd>[</kbd> | <kbd>Shift</kbd> + <kbd>]</kbd> |
| **Mac** — layout italiano | <kbd>Option</kbd> + <kbd>Shift</kbd> + <kbd>[</kbd> | <kbd>Option</kbd> + <kbd>Shift</kbd> + <kbd>]</kbd> |
| **Mac** — layout USA | <kbd>Option</kbd> + <kbd>[</kbd> | <kbd>Option</kbd> + <kbd>]</kbd> |
| **Windows** — codice ASCII (qualsiasi layout) | <kbd>Alt</kbd> + <kbd>1</kbd><kbd>2</kbd><kbd>3</kbd> | <kbd>Alt</kbd> + <kbd>1</kbd><kbd>2</kbd><kbd>5</kbd> |

> **Nota sul metodo ASCII** — Tieni premuto <kbd>Alt</kbd>, digita il numero sul tastierino numerico (non i tasti numerici sulla fila superiore), poi rilascia <kbd>Alt</kbd>. Funziona solo su Windows.

> **Suggerimento — Intellisense** — In Songpress++ puoi usare l'autocompletamento: digita `{` seguito dalle prime lettere della direttiva e premi <kbd>Ctrl</kbd>+<kbd>Spazio</kbd> per aprire il menu di completamento. La direttiva verrà inserita completa di `:` e `}` dove necessario. Ogni voce mostra un'icona: **✅** indica una direttiva ChordPro ufficiale, **🔧** indica un'estensione esclusiva di Songpress++.

---

## Metadati della canzone

| Direttiva           | Alias        | Std | Menu | Descrizione                                                                               |
| ------------------- | ------------ | --- | ---- | ----------------------------------------------------------------------------------------- |
| `{title:Titolo}`    | `{t:Titolo}` | ✅  | ⌨️   | Titolo della canzone                                                                      |
| `{subtitle:Testo}`  | `{st:...}`   | ✅  | ⌨️   | Sottotitolo o artista secondario                                                          |
| `{artist:Nome}`     |              | ✅  | 🖊    | Artista / interprete (visualizzato come sottotitolo)                                      |
| `{composer:Nome}`   |              | ✅  | 🖊    | Compositore (visualizzato come sottotitolo)                                               |
| `{lyricist:Nome}`   |              | ✅  | 🖊    | Paroliere / autore del testo (visualizzato come «Testo: …»)                               |
| `{arranger:Nome}`   |              | ✅  | 🖊    | Arrangiatore (visualizzato come «Arrangiamento: …»)                                       |
| `{album:Titolo}`    |              | ✅  | 🖊    | Titolo dell'album (visualizzato come «Album: …»)                                          |
| `{year:Anno}`       |              | ✅  | 🖊    | Anno di pubblicazione (visualizzato come sottotitolo)                                     |
| `{copyright:Testo}` |              | ✅  | 🖊    | Nota di copyright (visualizzata come «© …»)                                               |
| `{key:Tonalità}`    |              | ✅  | ⌨️   | Tonalità (es. `Am`, `C`, `G`, `F#m`); visualizzata come «Key: …» se abilitata             |
| `{capo:N}`          |              | ✅  | 🖊    | Capotasto al tasto N (es. `{capo:2}`); visualizzato come «Capo: N»                        |
| `{tempo:BPM[,M]}`   |              | ✅  | ⌨️   | Tempo in BPM; icona e formato configurabili dal dialogo *Inserisci → Tempo* (es. `{tempo:120}`). Il parametro opzionale `,M` sovrascrive la modalità per il singolo comando (0=Testo, 1=♩, 2=BPM, 3=metronomo, -1=nascosto) |
| `{tempo_m:BPM}`     |              | 🔧  | 🖊    | Tempo con icona **minima** fissa — indipendente dalla modalità di visualizzazione globale  |
| `{tempo_s:BPM}`     |              | 🔧  | 🖊    | Tempo con icona **semiminima** fissa                                                      |
| `{tempo_sp:BPM}`    |              | 🔧  | 🖊    | Tempo con icona **semiminima puntata** fissa                                              |
| `{tempo_c:BPM}`     |              | 🔧  | 🖊    | Tempo con icona **croma** fissa                                                           |
| `{tempo_cp:BPM}`    |              | 🔧  | 🖊    | Tempo con icona **croma puntata** fissa                                                   |
| `{tempo_label:Testo}` |            | 🔧  | ⌨️   | Indicazione agogica testuale (es. `{tempo_label:Andante}`, `{tempo_label:Allegro moderato}`); visualizzata come testo accanto alle altre direttive di tempo |
| `{time:N/M}`        |              | ✅  | ⌨️   | Indicazione di tempo (es. `{time:4/4}`, `{time:3/4}`); visualizzata con simbolo grafico   |
| `{beats_time: Acc=N …}` |            | 🔧  | ⌨️   | Durata in battiti degli accordi (es. `{beats_time: Do=2 Sol=1}`); visualizza numero, punti o entrambi sopra gli accordi (configurabile nelle preferenze) |
| `{duration:mm:ss}`  |              | ✅  | 🖊    | Durata totale della canzone (es. `{duration:12:45}`); non visualizzata nell'anteprima né in stampa, ma riportata nelle **Statistiche brano** come «Durata» effettiva al posto della stima automatica. Commentando la riga con `#` la durata torna ad essere calcolata automaticamente. |
| `{sorttitle:Testo}` |              | ✅  | 🖊    | Titolo alternativo usato per l'ordinamento alfabetico (metadato, non visualizzato)        |
| `{keywords:...}`    |              | ✅  | 🖊    | Parole chiave per la ricerca (metadato, non visualizzato)                                 |
| `{topic:...}`       |              | ✅  | 🖊    | Argomento / categoria (metadato, non visualizzato)                                        |
| `{collection:...}`  |              | ✅  | 🖊    | Raccolta o canzoniere di appartenenza (metadato, non visualizzato)                        |
| `{language:...}`    |              | ✅  | 🖊    | Lingua del testo (metadato, non visualizzato)                                             |
| `{meta:chiave valore}` |           | ✅  | 🖊    | Metadato generico in forma libera (non visualizzato)                                      |

> **Nota sui metadati estesi** — Le direttive `{sorttitle}`, `{keywords}`, `{topic}`, `{collection}`, `{language}`, `{meta}` vengono riconosciute e accettate dal parser per garantire la compatibilità con file ChordPro 6, ma il loro valore non viene visualizzato nell'anteprima né in stampa: sono trattate come puri metadati. Il token `:valore` viene consumato silenziosamente. La direttiva `{duration}` ha invece un comportamento speciale: il suo valore viene usato dalla funzione **Statistiche brano** (vedi sotto).

> **Nota sul tempo** — `{tempo:}` ha quattro modalità di visualizzazione selezionabili nel dialogo di inserimento: **Tempo:** (testo semplice), **♩** (nota musicale con valore `♩ = 120`), **BPM** (testo `BPM: 120`), **🎼** (metronomo con valore `♩ = 120`). Spuntando *Metadati*, il valore viene trattato come puro metadato e non appare nell'anteprima né in stampa. La scelta nel dialogo imposta la **modalità globale**; per sovrascriverla per un singolo comando usa la forma `{tempo:BPM,M}` (es. `{tempo:120,1}`). Le varianti `{tempo_m:}`, `{tempo_s:}` ecc. mostrano sempre la propria icona fissa indipendentemente da questa impostazione. La direttiva `{tempo_label:}` permette invece di inserire un'**indicazione agogica testuale** (es. `Andante`, `Allegro moderato`) indipendentemente dal BPM numerico.
>
> **Indicazioni agogiche tradizionali e intervalli BPM di riferimento** (♩ = battiti per minuto):
>
> | Indicazione agogica | Intervallo BPM |
> | ------------------- | -------------- |
> | Largo               | 40 – 60 BPM    |
> | Larghetto           | 60 – 66 BPM    |
> | Adagio              | 66 – 76 BPM    |
> | Andante             | 76 – 108 BPM   |
> | Moderato            | 108 – 120 BPM  |
> | Allegro             | 120 – 168 BPM  |
> | Presto              | 168 – 200 BPM  |
> | Prestissimo         | 200 – 208 BPM  |

> **Nota sulla tonalità (`{key}`)** — Il dialogo *Inserisci → Tonalità* permette di inserire la direttiva `{key:tonalità}` con tre modalità:
>
> - **Manuale** — digitare direttamente la tonalità nel campo di testo (es. `Do`, `La-`, `Sol#m`, `C`, `Am`, `F#m`). La notazione può essere italiana o inglese a seconda della notazione attiva nel documento.
> - **Rilevamento automatico** — spuntando *Rileva automaticamente dagli accordi*, Songpress++ analizza gli accordi presenti nel brano corrente e calcola la tonalità più probabile, mostrandola immediatamente nel campo di testo con il conteggio degli accordi esaminati (es. «✔ Rilevata: Do (da 326 accordi)»). Il campo diventa di sola lettura finché l'opzione è attiva.
> - **Metadati** — spuntando *Metadati*, la tonalità viene inserita come metadato nascosto: non appare nell'anteprima né in stampa, ma è disponibile per la funzione di trasposizione.
>
> **Rilevamento in file multi-brano** — Quando il file contiene più canzoni separate da `{new_song}`, il rilevamento automatico considera **solo il testo del brano corrente**: parte dalla posizione del cursore fino al prossimo `{new_song}` (o alla fine del documento se il brano è l'ultimo). Questo garantisce che gli accordi dei brani precedenti e successivi non alterino il risultato.
>
> La visualizzazione della tonalità nell'anteprima è abilitabile/disabilitabile in *Opzioni → Formato → Mostra tonalità*.

---

## Struttura della canzone

### Blocchi di testo

| Direttiva                                 | Std | Menu | Descrizione                                                                                                                          |
| ----------------------------------------- | --- | ---- | ------------------------------------------------------------------------------------------------------------------------------------ |
| `{start_of_verse}`/`{end_of_verse}`       | ✅  | ⌨️   | Strofa non numerata, senza etichetta                                                                                                 |
| `{start_verse:Etichetta}`/`{end_verse}`   | 🔧  | ⌨️   | Strofa non numerata con etichetta opzionale                                                                                          |
| `{start_verse_num}`/`{end_verse_num}`     | 🔧  | ⌨️   | Strofa numerata automaticamente                                                                                                      |
| `{verse:Etichetta}`                       | ✅  | ⌨️   | Apre una strofa con etichetta personalizzata (es. `{verse:1}`)                                                                       |
| `{start_of_chorus}`/`{end_of_chorus}`     | ✅  | ⌨️   | Ritornello                                                                                                                           |
| `{soc}`/`{eoc}`                           | ✅  | ⌨️   | Abbreviazione di `start_of_chorus`/`end_of_chorus`                                                                                   |
| `{soc:Etichetta}`                         | ✅  | ⌨️   | Ritornello con etichetta personalizzata                                                                                              |
| `{start_chorus:Etichetta}`/`{end_chorus}` | 🔧  | ⌨️   | Forma alternativa per il ritornello (con etichetta opzionale)                                                                        |
| `{start_bridge:Etichetta}`/`{end_bridge}` | 🔧  | ⌨️   | Bridge con etichetta opzionale; se omessa, il valore predefinito è «Bridge»                                                          |
| `{start_of_bridge}`/`{end_of_bridge}`     | ✅  | 🖊    | Forma ChordPro standard per il bridge; equivalente a `{start_bridge}`/`{end_bridge}`                                                 |
| `{sob}`/`{eob}`                           | ✅  | 🖊    | Abbreviazione di `start_of_bridge`/`end_of_bridge`                                                                                   |
| `{start_chord:Etichetta}`/`{end_chord}`   | 🔧  | ⌨️   | Blocco intro/accordi; se l'etichetta è omessa, il valore predefinito è «Intro»                                                       |
| `{start_of_tab}`/`{end_of_tab}`           | ✅  | 🖊    | Blocco tablatura ASCII; il contenuto viene visualizzato con font monospace (Courier New) e l'etichetta «Tab»                         |
| `{sot}`/`{eot}`                           | ✅  | 🖊    | Abbreviazione di `start_of_tab`/`end_of_tab`                                                                                         |
| `{start_of_grid}`/`{end_of_grid}`         | ✅  | ⌨️   | Blocco griglia accordi; visualizzato con l'etichetta «Grid»                                                                          |
| `{sog}`/`{eog}`                           | ✅  | 🖊    | Abbreviazione di `start_of_grid`/`end_of_grid`                                                                                       |
| `{grid}`                                  | ✅  | 🖊    | Forma alternativa di `start_of_grid` (senza chiusura esplicita)                                                                      |
| `{row}` / `{r}` *(dentro grid)*           | 🔧  | 🖊    | Inserisce una riga vuota separatrice all'interno di un blocco griglia                                                                |
| `{bar}` *(dentro grid)*                   | ✅  | 🖊    | Separatore di battuta esplicito all'interno di un blocco griglia                                                                     |
| `{start_of_part:Etichetta}`/`{end_of_part}` | ✅  | 🖊  | Sezione generica (ChordPro 6): trattata come strofa con etichetta libera; se l'etichetta è omessa viene usato «Part»                |
| `{sop}`/`{eop}`                           | ✅  | 🖊    | Abbreviazione di `start_of_part`/`end_of_part`                                                                                       |
| `{new_song}`                              | 🔧  | 🖊    | Avvia una nuova canzone nello stesso documento: azzera i contatori di strofe e ritornelli (la numerazione riparte da 1) e resetta gli schemi di accordi memorizzati per il filtro *Una strofa per ogni schema* |

> **Nota sul bridge** — Sono supportate entrambe le forme: `{start_bridge}`/`{end_bridge}` (forma Songpress++, inseribile dal menu) e `{start_of_bridge}`/`{end_of_bridge}` (forma ChordPro standard, con abbreviazioni `{sob}`/`{eob}`). Le due forme sono equivalenti e intercambiabili.

### Inserimento del blocco intro/accordi — `{start_chord}` / `{end_chord}`

Il comando di inserimento del blocco intro/accordi apre la finestra **Etichetta accordi introduzione**:

- **Etichetta** — il campo di testo propone «Intro» come valore predefinito. Confermando con *OK* si inserisce `{start_chord:Etichetta}`; lasciando il campo vuoto si ottiene `{start_chord}` senza etichetta; premendo *Annulla* l'inserimento viene abbandonato.
- **Usa gli accordi della prima riga** — casella opzionale. Se selezionata, il corpo del blocco viene **precompilato con gli accordi tra parentesi quadre `[..]` presenti nella prima riga del documento che ne contiene almeno uno**. Gli accordi rilevati sono mostrati in anteprima (in corsivo) sotto la casella.

Se nessuna riga del documento contiene accordi tra parentesi quadre, la casella è **disabilitata** e al posto dell'anteprima compare l'avviso *«nessun accordo trovato nella prima riga»*.

Con la casella disattivata (o in assenza di accordi utilizzabili) il blocco viene inserito vuoto, con il cursore posizionato al suo interno:

```chordpro
{start_chord:Intro}
|
{end_chord}
```

Con la casella attiva e, ad esempio, `[Am] [F] [G] [C]` nella prima riga utile, il blocco risulta già compilato:

```chordpro
{start_chord:Intro}
[Am] [F] [G] [C]
{end_chord}
```

### Interruzioni di pagina e colonna

| Direttiva        | Alias    | Std | Menu | Descrizione                                      |
| ---------------- | -------- | --- | ---- | ------------------------------------------------ |
| `{new_page}`     | `{np}`   | ✅  | ⌨️   | Interruzione di pagina esplicita per la stampa   |
| `{column_break}` | `{colb}` | ✅  | ⌨️   | Interruzione di colonna (layout a 2 colonne)     |

---

## Accordi e formattazione inline

### Accordi

Gli accordi si inseriscono nel testo con le parentesi quadre, immediatamente prima della sillaba a cui appartengono:

```chordpro
[Am]Nel [F]blu [C]dipinto di [G]blu
```

### Font e colori locali

Queste direttive cambiano il font per la sezione seguente; usate senza argomento ripristinano il valore predefinito.

| Direttiva di apertura | Direttiva di chiusura | Std | Menu | Descrizione                                                                      |
| --------------------- | --------------------- | --- | ---- | -------------------------------------------------------------------------------- |
| `{textfont:Nome}`     | `{textfont}`          | ✅  | ⌨️   | Famiglia di font del testo                                                       |
| `{textsize:Pt}`       | `{textsize}`          | ✅  | ⌨️   | Dimensione del testo in pt (accetta anche percentuale, es. `{textsize:80%}`)     |
| `{textcolour:#HEX}`   | `{textcolour}`        | ✅  | ⌨️   | Colore del testo in formato `#RRGGBB`                                            |
| `{chordfont:Nome}`    | `{chordfont}`         | ✅  | ⌨️   | Famiglia di font degli accordi                                                   |
| `{chordsize:Pt}`      | `{chordsize}`         | ✅  | ⌨️   | Dimensione degli accordi in pt (accetta anche percentuale)                       |
| `{chordcolour:#HEX}`  | `{chordcolour}`       | ✅  | ⌨️   | Colore degli accordi in formato `#RRGGBB`                                        |

### Spaziatura

| Direttiva             | Std | Menu | Descrizione                                                                                                                        |
| --------------------- | --- | ---- | ---------------------------------------------------------------------------------------------------------------------------------- |
| `{linespacing:N}`     | 🔧  | ⌨️   | Interlinea in punti (es. `{linespacing:1}`); senza argomento ripristina il valore predefinito                                      |
| `{chordtopspacing:N}` | 🔧  | ⌨️   | Spazio sopra gli accordi in punti (es. `{chordtopspacing:0}` per eliminarlo); senza argomento ripristina il valore predefinito     |
| `{row}` o `{r}`       | 🔧  | 🖊    | Inserisce mezza riga verticale vuota (spaziatore) fuori dai blocchi griglia — non disponibile nel menu                            |
| `{bar}`               | ✅  | 🖊    | Separatore di battuta esplicito all'interno di un blocco `{start_of_grid}`; ignorato fuori dal contesto griglia                   |

---

## Direttive di spaziatura in Songpress++

---

## `{linespacing: <valore>}` — **Voce di menu:** *Interlinea*

### Descrizione — linespacing

Imposta l'**interlinea** tra le righe di testo della canzone dal punto in cui viene inserita la direttiva. Agisce sulla spaziatura verticale complessiva tra una riga di testo (con i relativi accordi) e la successiva.

### Sintassi — linespacing

```chordpro
{linespacing: 13}
{linespacing: 13 rel}
```

### Parametro — linespacing

| Valore           | Effetto                                                                              |
| ---------------- | ------------------------------------------------------------------------------------ |
| `0`              | Elimina lo spazio extra tra le righe (valore predefinito nella finestra di dialogo)  |
| numero positivo  | Aggiunge spazio verticale tra le righe (in punti tipografici)                        |
| `N rel`          | Modalità relativa: gli N px escludono la banda dei numeri di battito (`{beats_time}`) |

### Note d'uso — linespacing

- La direttiva può essere inserita in qualsiasi punto della canzone; agisce sulle righe successive.
- I valori tipici sono compresi tra `10` e `20` a seconda del font e della dimensione utilizzati.
- Utile per regolare la densità del testo in stampa, specialmente con layout a due colonne o formato due pagine per foglio.
- **Modalità `rel`** — con `{beats_time}` attivo, la fila di numeri di battito sopra gli accordi normalmente si aggiunge al passo di riga. Aggiungendo `rel` (`{linespacing: 13 rel}`), quella banda non viene conteggiata: gli N px sono misurati dalla riga accordi alla riga di testo, escludendo i battiti, che vengono disegnati dentro lo spazio del `linespacing`. Vedi la sezione *«`{beats_time}` e `{linespacing}` — come interagiscono le distanze»* per i dettagli.
- **Scope globale** — `{linespacing}` si propaga per tutta la canzone a partire dal punto di inserimento, attraversando anche le interruzioni di pagina (`{new_page}`). Se la direttiva viene usata più volte, ogni occorrenza sovrascrive il valore precedente; l'ultima `{linespacing}` presente nel file determina l'interlinea per il resto del brano.
- **Coesistenza con `{new_page}` sulla stessa riga** — È consentito e funziona correttamente scrivere le due direttive sulla stessa riga, in entrambi gli ordini:
  ```chordpro
  {new_page} {linespacing:15}
  {linespacing:15} {new_page}
  ```
  Il parser le processa in sequenza da sinistra a destra. In entrambi i casi il nuovo valore di interlinea viene aggiornato nel formato globale prima che venga costruito il blocco della pagina successiva, quindi le righe della nuova pagina adottano regolarmente il valore specificato. Non vi è alcuna differenza di comportamento tra i due ordini.

---
- **Coesistenza con `{new_page}` sulla stessa riga** — È consentito e funziona correttamente scrivere le due direttive sulla stessa riga, in entrambi gli ordini:
  ```chordpro
  {new_page} {linespacing:15}
  {linespacing:15} {new_page}
  ```
  Il parser le processa in sequenza da sinistra a destra. In entrambi i casi il nuovo valore di interlinea viene aggiornato nel formato globale prima che venga costruito il blocco della pagina successiva, quindi le righe della nuova pagina adottano regolarmente il valore specificato. Non vi è alcuna differenza di comportamento tra i due ordini.

---

## `{chordtopspacing: <valore>}` — **Voce di menu:** *Spazio sopra gli accordi*

### Descrizione — chordtopspacing

Imposta lo **spazio verticale sopra gli accordi**, ovvero la distanza tra il bordo superiore della riga degli accordi e il contenuto che la precede (es. la riga di testo della strofa precedente). Consente di allentare o comprimere il margine che separa visivamente gli accordi dalla strofa soprastante.

### Sintassi — chordtopspacing

```chordpro
{chordtopspacing: 4}
```

### Parametro — chordtopspacing

| Valore           | Effetto                                                                                      |
| ---------------- | -------------------------------------------------------------------------------------------- |
| `0`              | Elimina lo spazio extra sopra gli accordi (valore predefinito nella finestra di dialogo)     |
| numero positivo  | Aumenta il respiro visivo sopra la riga degli accordi                                        |

### Note d'uso — chordtopspacing

- Agisce in modo indipendente da `linespacing`: i due parametri si sommano nella spaziatura complessiva.
- Utile quando gli accordi appaiono visivamente «schiacciati» contro il testo della riga precedente.
- Come `linespacing`, può essere usato più volte nella stessa canzone in punti diversi per variare la spaziatura sezione per sezione.

## Differenza tra chordtopspacing e linespacing

```text
[riga di testo precedente]
                         ↕  chordtopspacing  (spazio sopra gli accordi)
[riga accordi:  G    D    A]
[riga testo:    Quando il sole...]
                         ↕  linespacing      (spaziatura tra righe complete)
[riga accordi:  Em   B...]
[riga testo:    ...sorge e...]
```

In sintesi: `chordtopspacing` controlla il margine **sopra** la coppia accordo+testo, mentre `linespacing` controlla lo spazio **tra** coppie successive.

## `{row}` / `{r}` 🖊

**Voce di menu:** *nessuna — deve essere digitato manualmente*

### Descrizione — row

Inserisce uno **spazio verticale dimezzato** (spaziatore) tra le righe della canzone. Utile per aggiungere un piccolo respiro visivo tra le strofe senza usare `{linespacing}`.

### Sintassi — row

```chordpro
{row}
```

oppure in forma abbreviata:

```chordpro
{r}
```

### Note d'uso — row

- Inserisce uno spazio pari a circa **metà riga** rispetto all'interlinea corrente.
- Non ha parametri: `{row}` e `{r}` sono equivalenti e non accettano valori.
- Non è accessibile dal menu **Inserisci**: deve essere digitato direttamente nell'editor.

---

## `{start_of_tab}` / `{end_of_tab}` 🖊

**Alias abbreviati:** `{sot}` / `{eot}`

### Descrizione — start_of_tab

Delimita un **blocco di tablatura ASCII**. Il contenuto viene visualizzato nell'anteprima e in stampa con font monospace (Courier New) e l'etichetta «Tab», in modo che l'allineamento colonnare delle corde sia preservato.

### Sintassi — start_of_tab

```chordpro
{start_of_tab}
e|--0--2--3--2--0--|
B|--1--3--3--3--1--|
G|--0--2--0--2--0--|
D|--2--0--0--0--2--|
A|--3--x--2--x--3--|
E|--x--x--3--x--x--|
{end_of_tab}
```

oppure con alias abbreviati:

```chordpro
{sot}
e|--0--2--3--|
B|--1--3--3--|
{eot}
```

oppure con etichetta personalizzata:

```chordpro
{start_of_tab: Assolo}
e|--12-14-15-14-12--|
{end_of_tab}
```

### Note d'uso — start_of_tab

- Il font monospace garantisce che le linee della tablatura siano perfettamente allineate nella stampa.
- Gli accordi inline `[Am]` eventualmente presenti nel blocco **non vengono visualizzati** sopra il testo: la tablatura è già una notazione completa.
- Il blocco viene trattato come una strofa non numerata; riceve un'etichetta «Tab» (o quella personalizzata).
- Nell'editor il contenuto del blocco appare in **marrone corsivo** per distinguerlo visivamente dal testo normale.

---

## `{start_of_grid}` / `{end_of_grid}` 🖊

**Alias abbreviati:** `{sog}` / `{eog}` · Forma alternativa: `{grid}`

### Descrizione — start_of_grid

Delimita un **blocco griglia accordi** (chord grid). Utile per indicare sequenze ritmiche di accordi in formato simbolico, es. per chitarra ritmica o ukulele. Il blocco viene visualizzato con l'etichetta «Grid» (configurabile nelle preferenze).

### Sintassi — start_of_grid

Forma base:

```chordpro
{start_of_grid}
| Am . . . | F . . . | C . . . | G . . . |
{end_of_grid}
```

Alias abbreviati:

```chordpro
{sog}
| G . . . | D . . . | Em . . . | C . . . |
{eog}
```

Forma alternativa (si chiude automaticamente alla riga vuota successiva):

```chordpro
{grid}
| C . . . | G . . . | Am . . . | F . . . |
```

### Come vengono contate le celle — start_of_grid

**Ogni coppia di `|` delimita esattamente una battuta = una cella.** Il numero di celle dipende **solo** da quante `|` scrivi, non da quanti caratteri o spazi ci sono dentro:

```chordpro
{start_of_grid}
| FA DO | DO FA SOL | DO |
{end_of_grid}
```

produce **3 celle** (`FA DO`, `DO FA SOL`, `DO`), anche se la seconda battuta è molto più larga delle altre. Gli spazi interni vengono normalizzati: `| DO      FA |` e `| DO FA |` danno lo stesso risultato.

Una battuta può contenere **più di un accordo** (`| FA DO |` = una cella con due accordi), e gli accordi si possono scrivere indifferentemente con o senza parentesi quadre:

```chordpro
| FA DO | SOL |
|[FA] [DO] |[SOL] |
```

Per lasciare una **battuta vuota**, scrivi una cella senza contenuto:

```chordpro
| Am |   | G |
```

produce 3 celle, di cui la centrale vuota.

> **Nota (cambiamento di comportamento)** — Nelle versioni precedenti la larghezza in caratteri della battuta veniva usata per stimare quante celle occupasse: una battuta più larga delle altre generava automaticamente delle **celle vuote extra** prima di sé. Questo comportamento è stato rimosso perché produceva battute fantasma non richieste. Se in un vecchio brano avevi usato battute volutamente larghe per spostare gli accordi a destra, sostituiscile con celle vuote esplicite (`|   |`).

### Opzioni — start_of_grid

Tutte le opzioni si specificano come coppie `chiave=valore` nell'argomento della direttiva, dopo l'eventuale etichetta. Possono essere combinate liberamente.

| Opzione             | Tipo    | Default         | Descrizione                                                                                                                                                       |
| ------------------- | ------- | --------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| *(etichetta)*       | testo   | «Grid»          | Etichetta di sezione personalizzata (testo libero, prima di qualsiasi `chiave=valore`)                                                                            |
| `size=N`            | numero  | `1`             | Moltiplicatore dimensione celle: moltiplica il padding orizzontale e/o verticale per N. Accetta interi o decimali fino a 2 cifre, con `.` o `,` (es. `1.5`, `2,50`) |
| `size=N agisce su`  | scelta  | Larghezza e altezza | Controlla quale dimensione viene moltiplicata da `size=N`: **Larghezza e altezza** (entrambi i padding), **Solo larghezza** (solo `_pad_x`), **Solo altezza** (solo `_pad_y`). Si imposta nelle preferenze.  |
| `chordtopspacing=N` | intero  | `0`             | Spazio extra in pixel **sopra** ogni riga di celle                                                                                                                |
| `linespacing=N`     | intero  | `0`             | Spazio extra in pixel **sotto** ogni riga di celle                                                                                                                |
| `sizedir=horizontal\|vertical\|both` | stringa | valore da preferenze | Sovrascrive per questo blocco la preferenza globale **size=N agisce su**: `horizontal` (solo larghezza), `vertical` (solo altezza), `both` (larghezza e altezza) |

> **Nota:** `chordtopspacing` e `linespacing` dentro `{start_of_grid}` agiscono localmente solo su quel blocco griglia, indipendentemente dalle direttive globali `{chordtopspacing}` e `{linespacing}` che influenzano i blocchi strofa/ritornello normali. Anche `sizedir` è locale al blocco e sovrascrive la preferenza globale solo per quella griglia.

### Esempi — start_of_grid

Solo etichetta personalizzata:

```chordpro
{start_of_grid: Strofa}
| Am . . | F . . | G . . |
{end_of_grid}
```

Celle ingrandite (`size=2` o decimale, es. `size=1.5`):

```chordpro
{start_of_grid: size=2}
| Am | F | G | C |
{end_of_grid}
```

```chordpro
{start_of_grid: size=1.5}
| Am | F | G | C |
{end_of_grid}
```

Etichetta + celle ingrandite:

```chordpro
{start_of_grid: Ritornello size=2}
| G . . . | D . . . | Em . . . | C . . . |
{end_of_grid}
```

Spaziatura verticale extra tra le righe:

```chordpro
{start_of_grid: chordtopspacing=8 linespacing=4}
| Am | F |
| C  | G |
{end_of_grid}
```

Tutte le opzioni combinate:

```chordpro
{start_of_grid: Intro size=2 chordtopspacing=6 linespacing=3}
| Am . . . | F . . . |
| C . . .  | G . . . |
{end_of_grid}
```

`sizedir` locale (sovrascrive la preferenza globale per questo blocco):

```chordpro
{start_of_grid: Ritornello size=2 sizedir=horizontal}
| G . . . | D . . . | Em . . . | C . . . |
{end_of_grid}
```

### Inserimento dal menu — start_of_grid

**Menu Inserisci → Griglia `{start_of_grid}\{end_of_grid}`**

Apre un dialogo che propone come etichetta il valore impostato in **Preferenze → Formattazione → Griglia accordi → Etichetta predefinita** (default: «Grid»).

- **Conferma il default o annulla** → inserisce il blocco senza etichetta:
  ```chordpro
  {start_of_grid}
  | | | |
  {end_of_grid}
  ```
- **Digita un'etichetta diversa** → inserisce il blocco con etichetta personalizzata:
  ```chordpro
  {start_of_grid:Ritornello}
  | | | |
  {end_of_grid}
  ```

La riga `| | | |` precompilata fornisce 4 celle vuote come punto di partenza; modificala o aggiungine altre secondo necessità. Con la barra spaziatrice (se abilitata nelle preferenze) puoi navigare rapidamente tra le celle.

### Modalità di visualizzazione — start_of_grid

La modalità di resa per tutti i blocchi griglia si imposta globalmente in **scheda Formattazione → Griglia accordi** nelle preferenze:

| Modalità                   | Aspetto                                                                 |
| ---------------------------| ------------------------------------------------------------------------|
| **Tabella pipe** (default) | `\| Am  \| F   \| G   \| C   \|` — battute separate dal carattere `\|`  |
| **Spaziatura semplice**    | `Am   F   G   C` — accordi distanziati senza separatori                 |
| **Tabella**                | celle con bordi visibili disegnati                                      |

### Comportamento della tastiera nel blocco griglia

Quando il cursore si trova dentro un blocco `{start_of_grid}`:

| Tasto                 | Azione                                                                                                       |
| ----------------------| ------------------------------------------------------------------------------------------------------------ |
| **Barra spaziatrice** | Inserisce un separatore `\|` pipe, spostando la cella corrente verso destra (configurabile nelle preferenze) |
| `{row}` / `{r}`       | Inserisce una riga vuota separatrice (spazio verticale tra le righe)                                         |

### Battiti degli accordi nella griglia — `{beats_time:}`

La direttiva `{beats_time:}` funziona anche **dentro** un blocco griglia: mettila su una riga tutta sua, subito **prima** della riga di celle a cui si riferisce.

```chordpro
{start_of_grid:Intro linespacing=10}
{beats_time: DO=2 SOL=2 RE-=2 LA-=2}
|[DO] [SOL] |[RE-] [LA-] |
{end_of_grid}
```

I battiti vengono disegnati **sopra ogni singolo accordo**, anche quando una battuta ne contiene più di uno, con lo stesso aspetto (numero, puntini o entrambi), colore, allineamento e dimensione impostati in **Preferenze → Formattazione → Conteggio battiti (`{beats_time}`)**. Lo spazio necessario viene riservato automaticamente sopra le celle.

La direttiva vale **solo per la riga di celle immediatamente successiva**: per assegnare i battiti a più righe, ripetila prima di ciascuna.

Il comando *Inserisci → Durata accordi `{beats_time:}`…* riconosce anche le righe di griglia scritte **senza parentesi quadre** (`| Am | F | G |`), quindi puoi usare il dialogo esattamente come nel corpo del brano.

> Il comportamento della barra spaziatrice come pipe può essere disabilitato in **Formattazione → Griglia accordi → Barra spaziatrice inserisce il separatore \|**.
> La dimensione scalata da `size=N` si configura in **Formattazione → Griglia accordi → size=N agisce su**: scegli tra *Larghezza e altezza* (default), *Solo larghezza* o *Solo altezza*.

### Note d'uso — start_of_grid

- Il blocco viene trattato come una strofa non numerata con etichetta «Grid» (o quella personalizzata specificata nella direttiva o nelle preferenze).
- Nell'editor il contenuto del blocco appare in **marrone corsivo**, come i blocchi tablatura.
- `size=N` moltiplica `_pad_x` (padding orizzontale, base 8 px) e/o `_pad_y` (padding verticale, base 4 px) per N, ingrandendo le celle. Quale dimensione viene scalata dipende dall'opzione **Preferenze → Formattazione → Griglia accordi → size=N agisce su**: *Larghezza e altezza* (default, entrambi i padding), *Solo larghezza* (solo `_pad_x`), *Solo altezza* (solo `_pad_y`). N può essere un intero o un decimale con al massimo 2 cifre dopo il separatore (`.` o `,`): es. `size=1.5`, `size=2,50`, `size=1.7`.
- `chordtopspacing=N` aggiunge N pixel sopra ogni riga; `linespacing=N` aggiunge N pixel sotto ogni riga. Entrambi hanno default `0` (nessuna spaziatura extra).
- `sizedir=horizontal|vertical|both` sovrascrive localmente la preferenza globale **size=N agisce su** per il singolo blocco; se omesso, viene usato il valore dalle preferenze.
- Più opzioni e un'etichetta possono coesistere in qualsiasi ordine dopo i due punti: `{start_of_grid: Mia Etichetta size=3 linespacing=5 sizedir=horizontal}`.
- In modalità pipe, il testo raw dentro il blocco deve già contenere i delimitatori `|`; in modalità plain, gli accordi separati da spazi vengono distribuiti automaticamente.

---

## `{start_of_part}` / `{end_of_part}` 🖊

**Alias abbreviati:** `{sop}` / `{eop}`

### Descrizione — start_of_part

Delimita una **sezione generica** della canzone secondo la specifica ChordPro 6. È la scelta giusta quando nessun'altra direttiva strutturale (`{start_of_verse}`, `{start_of_chorus}`, `{start_of_bridge}` …) descrive adeguatamente la sezione: ad esempio un'introduzione strumentale, un interludio, una coda o qualsiasi parte con etichetta libera.

In Songpress++ il blocco viene trattato come una strofa non numerata con l'etichetta specificata. Se l'etichetta è omessa, viene usata «Part» come valore predefinito.

### Sintassi — start_of_part

```chordpro
{start_of_part: Intro}
[Am][G][F][E7]
{end_of_part}
```

Con alias abbreviati:

```chordpro
{sop: Coda}
[G]Ritorna a [D]te
{eop}
```

Senza etichetta (usa il default «Part»):

```chordpro
{start_of_part}
[C][G][Am][F]
{end_of_part}
```

### Note d'uso — start_of_part

- Il blocco non è numerato e non incrementa il contatore delle strofe.
- L'etichetta è libera: può essere qualsiasi testo (es. «Intro», «Interludio», «Coda», «Assolo», «Outro»).
- È equivalente funzionalmente a `{start_verse:Etichetta}` — la distinzione è semantica, per mantenere la compatibilità con file ChordPro 6 provenienti da altre applicazioni.
- Non è accessibile dal menu **Inserisci**: deve essere digitato direttamente nell'editor o inserito tramite l'intellisense (`Ctrl+Space`).

---

## Commenti e note redazionali

![Songpress++ Finestra Commento](./img/GUIDE/commento_it.png)

| Forma                    | Alias        | Std | Menu | Descrizione                                                                                              |
| ------------------------ | ------------ | --- | ---- | -------------------------------------------------------------------------------------------------------- |
| `{comment:Testo}`        | `{c:Testo}`  | ✅  | ⌨️   | Commento visibile nell'anteprima, racchiuso automaticamente tra parentesi                                |
| `{comment_italic:Testo}` | `{ci:Testo}` | ✅  | 🖊    | Come `{comment}`, ma con testo in corsivo                                                                |
| `{comment_box:Testo}`    | `{cb:Testo}` | ✅  | 🖊    | Commento in riquadro                                                                                     |
| `# Testo`                |              | ✅  | 🖊    | Riga di commento (preceduta da `#`): trattata come riga vuota, non appare nell'anteprima né in stampa    |

---

## Diagrammi accordi, tastiera e immagini

![Songpress++ Diagramma accordi chitarra](./img/GUIDE/accordi_1_it.png)
![Songpress++ Diagramma accordi tastiera](./img/GUIDE/accordi_2_it.png)

| Direttiva                                    | Std | Menu | Descrizione                                                              |
| -------------------------------------------- | --- | ---- | ------------------------------------------------------------------------ |
| `{define: C base-fret 1 frets X 3 2 0 1 0}`  | ✅  | ⌨️   | Definisce un diagramma accordo per chitarra                              |
| `{taste:Accordo}`                            | 🔧  | ⌨️   | Mostra i tasti evidenziati sulla tastiera (klavier) — es. `{taste:Am}`   |
| `{fingering: Accordo}`                       | 🔧  | ⌨️   | Mostra la tastiera del **primo accordo** con i numeri delle dita — es. `{fingering: Am 3=Do 1=Mi 2=La}` |
| `{image: nomefile}`                          | ✅  | ⌨️   | Inserisce un'immagine (PNG, JPG, GIF, BMP, TIFF) nella canzone           |

La tastiera (klavier) visualizza i tasti corrispondenti all'accordo specificato, evidenziati con il colore impostato nelle preferenze.

Entrambe le direttive `{taste:}` e `{fingering:}` accettano le opzioni `start=` (nota di partenza della tastiera) e `octave=` (evidenziazione dell'ottava) descritte più avanti; le rispettive finestre di inserimento offrono i controlli **Nota di partenza**, **Evidenzia la nota su entrambe le ottave** e **Accordo in maiuscolo**.

![Songpress++ Opzione colore tasti accordi](./img/GUIDE/accordi_3_it.png)

### Diteggiatura del primo accordo — `{fingering:}`

La direttiva `{fingering:}` è una variante della tastiera klavier pensata per indicare **come posizionare la mano sul primo accordo** della canzone. Oltre a evidenziare i tasti dell'accordo, può mostrare il numero del dito su ogni tasto e un'etichetta che indica quale mano utilizzare.

**Formato:**

```chordpro
{fingering: Am}
{fingering: Am 3=Do 1=Mi 2=La}
{fingering: G 2=Sol 1=Si 3=Re}
{fingering: Am hand=R 3=Do 1=Mi 2=La}
{fingering: Am hand=L}
{fingering: Si hand=R start=Si 1=Si 2=Re# 3=Fa#}
```

La parte `dito=nota` è opzionale. Il token `hand=` è anch'esso opzionale e può comparire in qualsiasi posizione dopo il nome dell'accordo. I numeri corrispondono alle dita:

| Numero | Dito    |
| ------ | ------- |
| 1      | Pollice |
| 2      | Indice  |
| 3      | Medio   |
| 4      | Anulare |
| 5      | Mignolo |

**Indicazione della mano (`hand=`):**

| Valore   | Significato   | Etichetta visualizzata |
| -------- | ------------- | ---------------------- |
| `hand=R` | Mano destra   | *Right hand*           |
| `hand=L` | Mano sinistra | *Left hand*            |

L'etichetta compare centrata sotto la tastiera, in corsivo grigio. Se il token `hand=` è assente, non viene visualizzata alcuna etichetta. Il valore è case-insensitive (`hand=r` equivale a `hand=R`).

**Nota di partenza della tastiera (`start=`):**

Per impostazione predefinita la tastiera parte dal **DO**. Con il token opzionale `start=Nota` è possibile farla partire da un'altra nota naturale, indicata in notazione italiana (`Do Re Mi Fa Sol La Si`) o inglese (`C D E F G A B`). Il token può comparire in qualsiasi posizione dopo il nome dell'accordo ed è insensibile alle maiuscole.

```chordpro
{taste: Si start=Si}
{fingering: Si hand=R start=Si 1=Si 2=Re# 3=Fa#}
```

| Partenza          | Tasti bianchi | Tasti neri  |
| ----------------- | ------------- | ----------- |
| `DO` o `FA`       | 7             | 5 (tutti)   |
| ogni altra nota   | 8             | 5 (tutti)   |

Partendo da DO o FA la tastiera mostra i canonici 7 tasti bianchi. Partendo da qualsiasi altra nota, una finestra di soli 7 tasti "taglierebbe" un tasto nero: per questo Songpress++ **aggiunge automaticamente un ottavo tasto bianco in fondo** — l'ottava della nota iniziale (es. `Si … Si`) — così tutti e 12 i suoni dell'ottava restano rappresentabili e ogni nota dell'accordo può essere evidenziata. La larghezza complessiva del diagramma resta invariata: con 8 tasti risultano semplicemente un po' più stretti.

Sono ammesse solo note naturali (tasti bianchi); un valore alterato o non riconosciuto fa ricadere la partenza su DO.

**Evidenziazione dell'ottava (`octave=`):**

Nelle tastiere a 8 tasti la nota iniziale compare a **entrambe le estremità**. Se quella nota fa parte dell'accordo, per impostazione predefinita viene evidenziata su tutte e due (comportamento naturale di una vista "ottava-ottava"). Con il token `octave=one` viene evidenziata **solo** su quella di sinistra.

| Valore        | Effetto                                                        |
| ------------- | -------------------------------------------------------------- |
| `octave=both` | Evidenzia la nota iniziale su entrambe le ottave (predefinito) |
| `octave=one`  | Evidenzia solo la nota iniziale a sinistra                     |

Il token ha effetto solo nei layout a 8 tasti (partenza diversa da DO/FA); negli altri casi è ignorato.

```chordpro
{fingering: Si hand=R start=Si octave=one 1=Si 2=Re# 3=Fa#}
```

**Colore del tasto d'ottava:** con `octave=both` le due note uguali hanno per impostazione predefinita lo stesso colore. Per distinguere quella più a destra (es. il **Si alto** in una tastiera Si…Si) attiva *Opzioni → Formattazione → Accordi e tastiera → Colore diverso per il tasto dell'ottava superiore* e scegli il colore (predefinito `#3C78D2`, blu). L'impostazione vale per anteprima, stampa, esportazione e anteprima del dialogo.

Le note si scrivono in notazione italiana (`Do`, `Re`, `Mi`, `Fa`, `Sol`, `La`, `Si`, con `#` per i diesis) o inglese (`C`, `D`, `E`, `F`, `G`, `A`, `B`).

> **Nota sulla notazione** — Il dialogo di inserimento e la griglia delle dita rispettano la **notazione predefinita** impostata nelle preferenze di Songpress++ (*Opzioni → Notazione predefinita*). I nomi delle note mostrati nella griglia e scritti nella direttiva generata cambiano automaticamente in base alla notazione scelta: con notazione Americana si vedrà `A, C#, E`; con Italiana `La, Do#, Mi`; con Tedesca `A, Cis, E`, e così via. Anche il riconoscimento degli accordi digitati nel campo *Accordo* segue la notazione corrente. Le notazioni Nashville e Romana non sono supportate per la diteggiatura.

**Inserimento dal menu:** *Inserisci → Altro → Diteggiatura primo accordo {fingering:}*
Si apre una finestra che mostra automaticamente le note dell'accordo e permette di:

- assegnare un dito a ciascuna nota con un menu a tendina;
- selezionare la mano (Destra / Sinistra / Nessuna indicazione);
- scegliere la **Nota di partenza** della tastiera dal menu a tendina omonimo;
- attivare **Evidenzia la nota su entrambe le ottave** (abilitata solo quando la partenza genera 8 tasti);
- attivare **Accordo in maiuscolo** (attiva per impostazione predefinita): scrive il nome dell'accordo sempre in maiuscolo nella direttiva. Il riconoscimento dell'accordo è comunque insensibile alle maiuscole, quindi `Am` → `AM` resta La minore.

Se attiva, la casella *Mostra anteprima tastiera* in fondo alla finestra riflette in tempo reale tutte queste scelte. La finestra *Tasti accordo* (`{taste:}`) offre gli stessi controlli **Nota di partenza**, **Evidenzia la nota su entrambe le ottave** e **Accordo in maiuscolo**.

> **Nota — posizione della tastiera.** In entrambe le finestre una nota con l'icona ℹ ricorda che la tastiera con l'accordo viene sempre disegnata in fondo alla pagina, anche se nell'editor la direttiva (`{taste:}` o `{fingering:}`) può essere inserita in qualunque punto.

**Colore dei numeri delle dita:**
Il colore dei numeri visualizzati sui tasti si imposta in *Opzioni → Formattazione → Accordi e tempo → Colore numeri diteggiatura*. Per impostazione predefinita è quasi nero (`#1A1A1A`); su tasti neri il numero appare in bianco per garantire il contrasto.

**Controllo sintassi per `hand=`:**

Il controllo sintassi integrato (`Strumenti → Controlla sintassi`) valida il token `hand=` e segnala i seguenti errori:

| Errore | Esempio | Segnalazione |
| ------ | ------- | ------------ |
| Valore non valido | `{fingering: Am hand=X}` | `hand` deve essere R o L |
| Token `hand=` duplicato | `{fingering: Am hand=R hand=L}` | `hand` specificato più di una volta |

### Tempo — `{tempo:}` e varianti

![Songpress++ Finestra Tempo](./img/GUIDE/tempo_it.png)

La direttiva `{tempo:BPM}` indica la velocità della canzone in battiti per minuto. Songpress++ la visualizza nell'anteprima e in stampa con un'icona e un formato scelti dall'utente.

**Inserimento dal menu:**

Il comando *Inserisci → Tempo {tempo:}…* apre un dialogo con due campi:

- **Campo testo** — inserisci il valore BPM (es. `120`). Se lasciato vuoto, viene inserito un segnaposto `{tempo:|}` con il cursore posizionato pronto per la digitazione.
- **Visualizza come** — quattro opzioni disposte in griglia 2×2:

| Opzione | Icona/Testo | Aspetto nell'anteprima |
| ------- | ----------- | ---------------------- |
| **Tempo:** | testo semplice | `Tempo: 120` |
| **BPM** | testo semplice | `BPM: 120` |
| **♩** (nota musicale) | icona nota | `♩ = 120` |
| **🎼** (metronomo) | icona metronomo | `🎼 = 120` |

- **Metadati** — se spuntato, la direttiva viene accettata dal parser ma non visualizzata nell'anteprima né in stampa. Tutte le opzioni di visualizzazione vengono disabilitate automaticamente.

La scelta fatta nel dialogo viene **salvata come preferenza globale** e si applica a tutte le successive visualizzazioni di `{tempo:}` nell'anteprima e in stampa, finché non viene modificata di nuovo.

**Sovrascrittura per singolo comando — parametro `,M`:**

Per forzare una modalità diversa su un singolo comando senza cambiare la preferenza globale, si può usare la forma `{tempo:BPM,M}`, dove `M` è un intero che corrisponde alla voce del dialogo:

| Valore `M` | Voce nel dialogo | Aspetto nell'anteprima |
| ---------- | ---------------- | ---------------------- |
| `0` | **Tempo:** | `Tempo: 120` |
| `1` | **♩** (nota musicale) | `♩ = 120` |
| `2` | **BPM** | `BPM: 120` |
| `3` | **🎼** (metronomo) | `🎼 = 120` |
| `-1` | **Metadati** | *(non visualizzato)* |

Se `,M` è omesso, viene usata la modalità impostata nelle preferenze globali.

> **Nota:** non tutti i simboli si possono dimensionare. Le modalità `1` e `3` usano icone ridimensionabili (16×16 / 24×24 / 32×32); le modalità `0` e `2` mostrano solo testo e non sono influenzate dall'impostazione della dimensione icona.

**Dimensione dell'icona:**

La dimensione dell'icona nota (o metronomo) si imposta in *Opzioni → Formato → Tempo → Dimensione icona tempo*, con tre valori disponibili:

| Valore | Uso consigliato |
| ------ | --------------- |
| **16×16** | Documenti con font piccoli o layout compatti |
| **24×24** | Dimensione predefinita, adatta alla maggior parte dei casi |
| **32×32** | Documenti con font grandi o per maggiore leggibilità |

La preferenza si applica a tutte le direttive `{tempo:}` e varianti (`{tempo_m:}`, `{tempo_s:}` ecc.) nell'anteprima e in stampa. La direttiva `{tempo_label:}` non è influenzata da questa preferenza: visualizza sempre il testo agogico così com'è.

> **Nota — Varianti con icona fissa** — Le direttive `{tempo_m:}`, `{tempo_s:}`, `{tempo_sp:}`, `{tempo_c:}`, `{tempo_cp:}` mostrano sempre la propria icona nota specifica (rispettivamente minima, semiminima, semiminima puntata, croma, croma puntata) **indipendentemente** dalla modalità di visualizzazione globale impostata per `{tempo:}`. L'unica cosa influenzata dalla preferenza globale è il formato del numero: `= 120` oppure `BPM: 120`. Queste varianti non hanno una voce di menu dedicata e vanno digitate manualmente nell'editor. La direttiva `{tempo_label:}` è invece inseribile tramite menu (*Inserisci → Indicazione agogica*) e visualizza un'etichetta testuale senza alcun valore numerico.

### Durata degli accordi — `{beats_time:}`

La direttiva `{beats_time:}` specifica la **durata in battiti** di ciascun accordo della riga successiva. Songpress++ usa queste informazioni per calcolare e visualizzare i **numeri di battito** sopra gli accordi nell'anteprima, aiutando l'esecutore a capire il ritmo senza leggere la partitura.

**Formato:**

```chordpro
{beats_time: NomeAccordo=N NomeAccordo=N …}
```

- `NomeAccordo` — nome dell'accordo in notazione italiana (`Do`, `Sol`, `La-`, `Re7`…) o inglese (`C`, `G`, `Am`, `D7`…); gli accordi con basso esplicito (`Re-/Fa#`, `C/E`) vengono usati nella forma **completa** come chiave, inclusa la parte dopo `/`
- `N` — numero intero di battiti ≥ 1
- Gli accordi sono separati da spazi
- Solo gli accordi elencati ricevono un'indicazione di battito; gli altri vengono ignorati

**Esempi:**

```chordpro
{beats_time: Do=4 Sol=2 La-=2 Fa=4}
[Do]Amaz[Sol]ing [La-]grace, how [Fa]sweet
```

```chordpro
{beats_time: G=2 Em=2 C=4}
[G]Nel [Em]mezzo del [C]cammino
```

```chordpro
{beats_time: Am=4 F=2 C=2 G=4}
[Am]Tanti [F]au[C]guri a [G]te
```

```chordpro
{beats_time: La-=2 Re-/Fa#=2 LA-=2}
[LA-]Par[RE-/FA#]late ed an[LA-]nunciate
```

Ogni direttiva `{beats_time:}` si applica **alla riga di testo/accordi immediatamente successiva**. Per assegnare durate a più righe, inserisci una `{beats_time:}` prima di ognuna.

La direttiva funziona anche dentro i blocchi `{start_chord}`, `{start_bridge}` e `{start_of_grid}` — vedi *Battiti degli accordi nella griglia*.

**Inserimento dal menu — dialogo guidato:**

Il comando *Inserisci → Durata accordo {beats_time:}…* è accessibile anche tramite la scorciatoia da tastiera <kbd>Ctrl</kbd>+<kbd>Shift</kbd>+<kbd>D</kbd>.

Il comando riconosce automaticamente la situazione:

- **Se nessuna riga vicina al cursore contiene accordi `[…]`** — inserisce direttamente `{beats_time: }` senza aprire nessuna finestra.
- **Se la riga corrente (o quella precedente o successiva) contiene accordi `[…]`** — apre un dialogo con un campo numerico (`SpinCtrl`) per ogni accordo unico trovato, preimpostato su 1 battito. Mentre si modificano i valori, il campo **Anteprima** mostra in tempo reale la direttiva che verrà inserita (es. `{beats_time: Do=4 Sol=2 La-=2 Fa=1}`). Impostando un accordo a **0** viene escluso dalla direttiva. Se la riga contiene più di **8** accordi, l'elenco diventa scorrevole. Gli accordi con basso esplicito (es. `Re-/Fa#`) sono mostrati nella loro forma completa — sia come etichetta che come chiave nella direttiva generata.

> **Nota — Posizionamento cursore** — Per aprire il dialogo, il comando cerca gli accordi nell'ordine: **riga corrente** → **successiva** → **precedente**. Una volta confermato, l'inserimento cerca nell'ordine: **riga corrente** → **precedente** → **successiva**. Il modo più diretto è posizionare il cursore direttamente sulla riga con gli accordi.

> **Nota — Sostituzione in-place** — Se la riga che precede immediatamente la riga degli accordi è già una direttiva `{beats_time:}`, al click **OK** essa viene **sostituita** anziché duplicata. Se invece tra la `{beats_time:}` esistente e la riga degli accordi ci sono righe vuote, l'inserimento avviene in cima alla riga degli accordi, scavalcando le righe vuote per evitare interruzioni visive indesiderate.

Il dialogo offre tre controlli aggiuntivi:

- **Tutti: [N] [Applica a tutti]** — imposta in un solo clic lo stesso numero di battiti su tutti gli accordi presenti nel dialogo.
- **[Applica all'intero brano…]** — inserisce automaticamente una direttiva `{beats_time:}` prima di ogni riga con accordi nell'intero brano, usando i valori impostati nel dialogo. Le righe già precedute da una `{beats_time:}` vengono saltate. L'operazione è annullabile con un singolo `Ctrl+Z`. Per gli accordi che appaiono nel brano ma **non sono presenti nel dialogo** (perché la riga di riferimento del cursore era diversa), il numero di battiti predefinito è **1** — a meno che tutti gli spin del dialogo siano impostati a **0**, nel qual caso anche questi accordi vengono omessi dalla direttiva, producendo `{beats_time: }` vuota.
- **[OK +] [↕N] [s]** — conferma e inserisce la direttiva esattamente come il pulsante **OK**, ma riapre automaticamente il dialogo dopo il ritardo scelto. Il ritardo si imposta con lo **SpinCtrl** (1–60 secondi, default 5) affiancato al pulsante: si modifica direttamente prima di cliccare, e il valore viene **salvato** nelle preferenze e ripristinato alla prossima apertura. Utile quando si lavora su un brano lungo e si vuole assegnare la durata accordo riga per riga: nel tempo di pausa configurato è possibile spostare il cursore sulla riga successiva nell'editor, dopodiché il dialogo si riapre già aggiornato con i nuovi accordi.

> **Nota — Modalità selezione** — Se si seleziona un intervallo di testo prima di aprire il dialogo, il dialogo mostra un **badge blu** («● Modalità selezione: N righe con accordi selezionate») e raccoglie in un unico elenco tutti gli accordi unici presenti nelle righe selezionate. Al click **OK**, la direttiva viene inserita (o sostituita in-place) prima di **ogni riga con accordi** nell'intervallo, in un solo `Ctrl+Z`. Ogni riga riceve una direttiva personalizzata con i propri accordi, usando i valori impostati nel dialogo.

> **Nota — Multicursore** — Il comando è compatibile con il multicursore (Alt+Clic, Ctrl+D). Se sono attivi più cursori sulla stessa sequenza di accordi, il dialogo mostra un **badge verde** («● Multicursore attivo: N posizioni») e la direttiva viene inserita in tutte le posizioni in un solo `Ctrl+Z`. Se invece i cursori puntano a **sequenze di accordi diverse** (multicursore eterogeneo), il dialogo apre un **Notebook** con una tab per ogni cursore (fino a un massimo di 5): ogni tab mostra gli SpinCtrl specifici per quella posizione e la propria anteprima in tempo reale. Sotto il Notebook è sempre visibile un campo **Anteprima (cursore 1)** riepilogativo. Se i cursori attivi superano 5, viene mostrato un avviso «⚠ Visualizzati i primi 5 cursori su N».
>
> Nella modalità multicursore eterogeneo il dialogo mostra anche la checkbox **☑ Evidenzia le righe degli accordi nell'editor**, affiancata da un **colour picker**. Quando è attiva, le righe degli accordi a cui si riferisce ogni cursore vengono evidenziate nell'editor con un colore di sfondo: la riga del **cursore attivo** (la tab selezionata nel Notebook) usa il **colore pieno** scelto con il picker, mentre le righe degli **altri cursori** usano la stessa tinta in versione più chiara (schiarita automaticamente verso il bianco). Il colore scelto e lo stato della checkbox vengono **salvati nelle preferenze** e ripristinati alla prossima apertura. Le evidenziazioni vengono rimosse automaticamente alla chiusura del dialogo (OK, Annulla o X).
>
> **Più cursori sulla stessa riga** — Se due o più cursori ricadono sulla **stessa riga di accordi**, vengono considerati come **uno solo**: la riga riceve una singola direttiva `{beats_time:}` e nel dialogo compare una sola tab (il conteggio del badge riflette i cursori effettivi, non quelli inseriti con Alt+Clic). Questo è il comportamento corretto, dato che una riga di accordi può essere preceduta da una sola direttiva.

**Visualizzazione nell'anteprima:**

La voce **Visualizza → Mostra battiti accordi** abilita o disabilita la visualizzazione dei numeri di battito nell'anteprima. Quando abilitata, sopra ogni accordo compare un'indicazione del battito secondo la modalità impostata nelle preferenze.

**Preferenze — *Opzioni → Formattazione → Conteggio battiti ({beats_time})*:**

| Opzione | Valori | Default | Descrizione |
| ------- | ------ | ------- | ----------- |
| **Colore** | `#RRGGBB` | `#6464C8` (blu-viola) | Colore del numero/punto visualizzato sopra l'accordo. Si imposta tramite il pulsante *Scegli…* o digitando il codice esadecimale. |
| **Dimensione** | 30 % – 150 % | 60 % | Dimensione del numero di battito come percentuale della dimensione del font degli accordi. |
| **Grassetto** | ☐ / ☑ | ☐ (disabilitato) | Se spuntato, il numero viene disegnato in grassetto. |
| **Allineamento** | Sinistra / Centro / Destra | Destra | Posizione del numero rispetto al nome dell'accordo. |
| **Modalità** | Numero / Punti / Entrambi | Numero | Controlla *cosa* viene visualizzato sopra l'accordo (vedi dettaglio sotto). |

**Modalità di visualizzazione:**

| Modalità | Aspetto | Descrizione |
| -------- | ------- | ----------- |
| **Numero** | `4` sopra l'accordo | Mostra il numero di battiti come cifra. |
| **Punti** | `· · · ·` tra gli accordi | Mostra un punto per ogni battito nello spazio tra un accordo e il successivo. |
| **Entrambi** | numero + punti | Combina le due rappresentazioni. |

**Controllo sintassi:**

Il controllo sintassi integrato (`Strumenti → Controlla sintassi`) segnala gli errori nel valore di `{beats_time:}`:

| Errore | Esempio | Segnalazione |
| ------ | ------- | ------------ |
| Token senza `=` | `{beats_time: Sol}` | formato non valido |
| Accordo non riconosciuto | `{beats_time: Xyz=2}` | accordo sconosciuto |
| Accordo ripetuto | `{beats_time: Sol=2 Sol=1}` | accordo duplicato |
| Battiti mancanti | `{beats_time: Sol=}` | valore mancante |
| Battiti non interi o ≤ 0 | `{beats_time: Sol=0}`, `Sol=1.5` | deve essere intero positivo |

> **Nota** — «Accordo non riconosciuto» è segnalato come **avvertimento** (⚠️), non come errore bloccante: i battiti non vengono applicati a quell'accordo, ma la composizione del brano prosegue. Vedi la sezione *Controllo sintassi* per la distinzione tra errori e avvertimenti.

### `{beats_time}` e `{linespacing}` — come interagiscono le distanze

Quando si usa `{beats_time}` insieme a `{linespacing}`, è importante capire a quale **coppia accordo+testo** si applica lo spazio extra.

La regola è semplice: `{linespacing}` agisce sulla distanza tra la riga corrente e la **successiva**; i numeri di battito (prodotti da `{beats_time}`) appaiono **sopra** gli accordi e non modificano il `linespacing` della riga stessa.

#### Schema visivo

```text
{beats_time: Do=4 Sol=2 La-=2 Fa=4}
[Do]Gloria a [Sol]Dio nell'[La-]alto dei [Fa]cieli

                 ┌──────────────────────────────────────────┐
                 │   2     2     2     2    ← numeri beats   │
                 │  DO   SOL   LA-    FA    ← accordi        │
                 │  Gloria a Dio nell'alto  ← testo          │
                 └──────────────────────────────────────────┘
                          ↕  linespacing  (spazio DOPO questa riga, verso la riga successiva)
                 ┌──────────────────────────────────────────┐
                 │   4     2     2     4    ← numeri beats   │
                 │  DO   SOL   LA-    FA    ← accordi        │
                 │  dei cieli, pace in te  ← testo           │
                 └──────────────────────────────────────────┘
```

Il `linespacing` si inserisce **tra** i blocchi riga — ovvero tra il fondo della riga corrente e il margine superiore della riga successiva (inclusi gli eventuali numeri di battito che la sovrastano). I numeri di battito rimangono compressi **dentro** la loro riga.

#### Confronto: senza e con `{linespacing}`

```text
── Senza {linespacing} ──────────────────────────────────────

  2     2     2     2
 DO   SOL   LA-    FA
 Eccomi,  eccomi!           ← riga 1 (beats sopra gli accordi)
  2     2                   ← riga 2 inizia subito sotto
 FA    DO
 Signore io vengo

── Con {linespacing: 12} ────────────────────────────────────

  2     2     2     2
 DO   SOL   LA-    FA
 Eccomi,  eccomi!
                            ← {linespacing: 12} aggiunge 12 pt qui ↕
  2     2
 FA    DO
 Signore io vengo
```

#### Dove inserire `{linespacing}` rispetto a `{beats_time}`

`{linespacing}` deve essere collocato **prima** della riga a cui si vuole applicare, o in un punto separato del file per regolare l'intera sezione. Se lo si inserisce **nella stessa riga** di `{beats_time}`, il comportamento è definito: il nuovo valore di interlinea entra in vigore a partire dalla riga degli accordi **successiva**, senza alterare i numeri di battito già associati alla riga corrente.

```chordpro
{linespacing: 12}
{beats_time: Do=4 Sol=2 La-=2 Fa=4}
[Do]Eccomi, [Sol]eccomi! [La-]Signore [Fa]io vengo
```

```text
  ↑ {linespacing: 12} si applica a partire da questa riga
  │
  │   4     2     2     4
  │  DO   SOL   LA-    FA
  │  Eccomi, eccomi!...
  │
  ╰──── 12 pt ────╮
                  │
     prossima riga...
```

> **Nota tecnica** — Internamente, `{beats_time}` e `{linespacing}` usano formati separati: il primo agisce sui `SongText` (i singoli token accordo), il secondo sul `ParagraphFormat` del blocco. Non si sovrascrivono a vicenda.

#### Modalità relativa `{linespacing: N rel}` — escludere la banda dei battiti

Di norma i numeri di battito occupano una fascia **sopra** gli accordi che si somma allo spazio complessivo: due righe con `{beats_time}` risultano quindi più distanti di due righe senza, anche a parità di `{linespacing}`. Se vuoi che l'interlinea resti **costante** indipendentemente dalla presenza dei battiti, aggiungi il flag `rel`:

```chordpro
{linespacing: 13 rel}
```

Con `rel`, la banda dei numeri **non** viene conteggiata nel passo di riga: gli N px sono misurati dalla riga degli accordi alla riga di testo, e i battiti vengono disegnati **dentro** lo spazio del `linespacing` invece di aggiungersi.

```text
── {linespacing: 13} (normale) ──────────────────────────────
   Testo riga precedente
        ↕  13 pt + altezza numeri battito   ← la banda si somma
   4    2    2    4
  DO  SOL  LA-   FA
  Testo riga corrente

── {linespacing: 13 rel} ────────────────────────────────────
   Testo riga precedente
        ↕  13 pt                            ← i numeri stanno dentro
   4    2    2    4                            questo spazio
  DO  SOL  LA-   FA
  Testo riga corrente
```

> **Attenzione:** poiché i battiti occupano lo spazio del `linespacing`, un valore di `N` più piccolo dell'altezza dei numeri può farli avvicinare molto al testo della riga superiore. Scegli `N` in modo che contenga comodamente la fascia dei battiti. Sulle righe **senza** `{beats_time}` la modalità `rel` non produce alcuna differenza.

### Direttiva immagine

![Songpress++ Inserisci immagine](./img/GUIDE/inserisciImmagine_it.png)

La direttiva `{image:}` inserisce un'immagine raster nel punto in cui appare nella canzone. Songpress++ supporta due modalità: **collegamento esterno** (percorso file) e **immagine incorporata** (embedded base64).

#### Opzioni della direttiva

| Opzione        | Std | Descrizione                                                                             |
| -------------- | --- | --------------------------------------------------------------------------------------- |
| `width=N`      | ✅  | Larghezza in punti tipografici (1/72 di pollice), o percentuale es. `width=50%`         |
| `height=N`     | ✅  | Altezza in punti tipografici, o percentuale                                             |
| `scale=N%`     | ✅  | Fattore di scala, es. `scale=50%` (non combinabile con width/height)                    |
| `align=left`   | ✅  | Allineamento a sinistra                                                                 |
| `align=center` | ✅  | Allineamento al centro (predefinito)                                                    |
| `align=right`  | ✅  | Allineamento a destra                                                                   |
| `border`       | ✅  | Disegna un bordo da 1pt attorno all'immagine                                            |
| `border=N`     | ✅  | Disegna un bordo di N punti tipografici                                                 |

**Formati supportati:**

| Formato | Estensioni      |
| ------- | --------------- |
| PNG     | `.png`          |
| JPEG    | `.jpg`, `.jpeg` |
| GIF     | `.gif`          |
| BMP     | `.bmp`          |
| TIFF    | `.tiff`, `.tif` |

---

#### Modalità 1 — Collegamento esterno (percorso file)

Il file immagine rimane su disco e viene caricato ogni volta che il documento viene aperto. Se il file immagine si trova nella stessa cartella del documento, è sufficiente il solo nome del file. I percorsi contenenti spazi o backslash devono essere racchiusi tra virgolette doppie.

```chordpro
{image: logo.png}
{image: logo.png width=200 align=left}
{image: logo.png scale=50% border}
{image: "C:\Users\Utente\Immagini\foto.jpg" align=center}
```

---

#### Modalità 2 — Immagine incorporata (embedded base64) 🔧

Quando si attiva la checkbox **Incorpora immagine nel file** nel dialogo di inserimento, il contenuto dell'immagine viene codificato in base64 e salvato direttamente all'interno del file documento. Il file diventa così completamente autosufficiente: non dipende da file esterni e può essere condiviso o spostato senza perdere l'immagine.

```chordpro
{image: data:image/png;base64,iVBORw0KGgoAAAANS... width=200 align=center}
```

Il dato base64 viene generato automaticamente dal dialogo — non è necessario scriverlo manualmente. Allineamento, bordo e dimensioni si impostano normalmente tramite i controlli del dialogo e vengono inclusi nella direttiva anche in modalità embedded.

> **Nota sulla dimensione** — La codifica base64 aumenta la dimensione del dato di circa il 33%. Il dialogo mostra una stima dei KB/MB che verranno aggiunti al file documento prima di confermare. Il nome dell'estensione nella stima riflette l'estensione predefinita impostata in **Opzioni → Generale 2 → Estensione dei file predefinita**.

---

#### Finestra di dialogo Inserisci immagine

L'immagine può essere inserita tramite **Inserisci → Altro → Immagine {image:}**. Il dialogo permette di selezionare il file, impostare tutte le opzioni e vedere in tempo reale la direttiva che verrà generata nel campo **Anteprima direttiva**.

| Campo      | Valore iniziale | Intervallo | Unità    | Note                                                         |
| ---------- | --------------- | ---------- | -------- | ------------------------------------------------------------ |
| Larghezza  | 0               | 0–9999     | `pt` / `%` | 0 = non incluso nella direttiva; unità di default: `pt`   |
| Altezza    | 0               | 0–9999     | `pt` / `%` | 0 = non incluso nella direttiva; unità di default: `pt`   |
| Scala      | 100             | 1–500      | `%`      | 100 = non incluso (è il valore default)                      |
| Bordo      | 1               | 0–50       | pt       | attivo solo se la checkbox **Bordo** è spuntata; passo 0,5  |

La checkbox **Incorpora immagine nel file (base64, senza dipendenza esterna)** si trova nella parte inferiore del dialogo, sotto la sezione Bordo. Quando attiva, l'anteprima mostra `{image: data:<embedded> ...}` con le opzioni reali (allineamento, bordo, ecc.) visibili e modificabili in tempo reale.

---

### Indicatore Transposer 🖊

![Songpress++ Inserisci indicatore Transposer](./img/GUIDE/transposer_it.png)

L'**indicatore Transposer** è una rappresentazione testuale a pallini che mostra quale tasto premere sul dispositivo Transposer fisico dell'organo. Viene inserito direttamente nel testo della canzone come blocco `{start_of_tab: TRANSPOSER}` in modo che sia visibile nell'anteprima e in stampa con font monospace (Courier New), garantendo l'allineamento perfetto tra i simboli e le note.

#### Accesso

**Inserisci → Altro → Immagine Transposer {image:}...**

#### Struttura dell'indicatore

Il blocco inserito è composto da due righe in font monospace:

- **Riga 1** — i simboli dei tasti: un pallino pieno per il tasto selezionato, pallini vuoti per gli altri
- **Riga 2** — le etichette delle note: `Gb  G   Ab  A   A#  B`

```
{start_of_tab: TRANSPOSER}
 ·   ·   ·   •   ·   ·
 Gb  G   Ab  A   A#  B
{end_of_tab}
```

#### Anteprima pallini

| Tasto | Riga simboli                   | Nota premuta |
|-------|-------------------------------|--------------|
| G♭    | `•   ·   ·   ·   ·   ·`      | G♭           |
| G     | `·   •   ·   ·   ·   ·`      | G            |
| A♭    | `·   ·   •   ·   ·   ·`      | A♭           |
| **A** | `·   ·   ·   •   ·   ·`      | **A** *(default)* |
| A♯    | `·   ·   ·   ·   •   ·`      | A♯           |
| B     | `·   ·   ·   ·   ·   •`      | B            |

> Il tasto **A** ha sempre un bordo rosso nel pannello grafico del dialog: indica la tonalità di riferimento del Transposer fisico.

#### Scelta del simbolo

Il dialog permette di scegliere il simbolo per il tasto premuto tra quattro opzioni:

| Simbolo | Codice Unicode | Descrizione        | Spazio colonna |
|---------|----------------|--------------------|----------------|
| `•`     | U+2022         | Bullet             | 4              |
| `●`     | U+25CF         | Black circle       | 4              |
| `◉`     | U+25C9         | Fisheye            | 4              |
| `⬤`     | U+2B24         | Large black circle | 5              |

Il simbolo per i tasti **non premuti** è sempre `·` (U+00B7) oppure `○` (U+25CB) in funzione della scelta.

#### Posizione nel documento

| Opzione                  | Descrizione                                                                 |
|--------------------------|-----------------------------------------------------------------------------|
| Prima del titolo         | Inserisce il blocco all'inizio del file, prima di qualsiasi contenuto       |
| Dopo il titolo           | Cerca `{title:}` o `{t:}` e inserisce subito dopo                          |
| Alla posizione del cursore | Inserisce nel punto corrente del cursore *(predefinito)*                  |
| Fine della canzone       | Inserisce in fondo al testo, prima delle righe vuote finali                 |

---


## Struttura del file — Esempio completo

```chordpro
{title: O Sole Mio}
{artist: Eduardo di Capua}
{key: C}
{time: 4/4}
{tempo: 80}
{capo: 0}

{start_verse_num}
{beats_time: C=2 G7=2}
[C]Che bella [G7]cosa na jurnata 'e [C]sole
[C]N'aria serena [G7]doppo na tempesta!
{end_verse_num}

{soc:Ritornello}
[C]O sole [C7]mio sta [F]'nfronte a [C]te
[G7]O sole, o sole [C]mio
{eoc}

{start_of_tab: Intro}
e|--0--3--2--0--|
B|--1--0--3--1--|
G|--0--0--2--0--|
{end_of_tab}

{new_page}

{start_verse_num}
[C]Ma n'atu sole [G7]cchiu bello, oje [C]ne'
{end_verse_num}
```

---

## Funzionalità dell'editor

### Inserimento guidato (menu Inserisci)

Tutte le principali direttive sono accessibili tramite il menu **Inserisci**, che apre finestre di dialogo di supporto per compilare i valori. Il cursore `|` in InsertWithCaret indica la posizione in cui il cursore verrà posizionato dopo l'inserimento.

#### Ordine del menu Inserisci

Le voci sono raggruppate in cinque blocchi, separati da linee:

1. **Intestazione** — Titolo, Sottotitolo, Commento
2. **Accordi** — Accordo, Accordi di intro, Diteggiatura primo accordo, Tastiera accordo, Diagramma accordo chitarra, Durata accordo
3. **Struttura della canzone** — Strofa numerata, Strofa non numerata, Strofa con etichetta personalizzata o senza, Ritornello, Bridge, Griglia
4. **Tempo e tonalità** — Tempo, Indicazione agogica, Indicazione del tempo, Tonalità
5. **Immagini e simboli** — Immagine, Immagine Transposer, Simbolo musicale (Unicode)

#### Ritornello (<kbd>Ctrl</kbd>+<kbd>U</kbd>)

Una sola voce, **Inserisci → Ritornello…**, inserisce il blocco del ritornello. La stessa finestra si apre anche dall'icona *Ritornello…* della toolbar Inserisci. La finestra contiene:

| Campo | Descrizione |
| --- | --- |
| **Etichetta** | Testo mostrato come etichetta del ritornello. Se lasciato vuoto o invariato, viene usata l'etichetta predefinita (quella impostata in *Opzioni → Formattazione*, di solito «Rit.») e il comando viene scritto senza etichetta. |
| **Forma** | Radio button per scegliere come scrivere il blocco: **`{start_chorus} ... {end_chorus}`** (forma estesa, predefinita) oppure **`{soc} ... {eoc}`** (forma abbreviata di `start_of_chorus` / `end_of_chorus`). |

Esempi di testo inserito (il cursore `|` si posiziona all'interno del blocco):

```chordpro
{start_chorus}
|
{end_chorus}
```

```chordpro
{soc:Finale}
|
{eoc}
```

La forma scelta viene ricordata finché il programma resta aperto. Passando il mouse sul campo etichetta e sui due radio button compare un suggerimento (tooltip), uguale su Windows e Linux.

### Gestione degli accordi

- **Inserisci accordo** — inserisce `[|]` con il cursore all'interno delle parentesi
- **Sposta accordo a destra / sinistra** — sposta l'accordo sotto il cursore di un carattere
- **Rimuovi accordi** — elimina tutti gli accordi dalla selezione. Il comando è attivo solo se la selezione contiene almeno un accordo tra `[ ]`; altrimenti resta grigio
- **Incolla accordi** — incolla solo gli accordi (senza testo) dalla selezione copiata
- **Propaga accordi alle strofe** — copia gli accordi dalla prima strofa a tutte le strofe con lo stesso numero di righe
- **Propaga accordi ai ritornelli** — come sopra, per i ritornelli
- **Integra accordi** — converte due righe separate (accordi sopra / testo sotto) nel formato ChordPro inline. Agisce sulla riga del cursore (accordi) e su quella successiva (testo) ed è attivo solo quando il cursore è su una riga di soli accordi in formato tab seguita da una riga di testo

### Trasposizione e notazione

- **Trasponi** — apre la finestra di dialogo per trasporre gli accordi. Il dialogo offre le seguenti opzioni:

  | Opzione | Descrizione |
  |---|---|
  | **Notazione degli accordi** | Notazione rilevata automaticamente; può essere cambiata manualmente |
  | **Dalla tonalità** | Tonalità di partenza, rilevata automaticamente dal testo |
  | **Semitoni** | Numero di semitoni di trasposizione (da −11 a +12) |
  | **Alla tonalità** | Tonalità di destinazione; si aggiorna automaticamente al variare dei semitoni |
  | **Alterazioni** | Scelta tra automatico, diesis (#) o bemolle (b) per le note cromatiche |
  | **Applica solo alla selezione** | Se attiva (e solo se c'è testo selezionato), traspone esclusivamente gli accordi `[...]` e le direttive `{beats_time:}` contenuti nella selezione, lasciando invariato il resto del brano |
  | **Trasponi anche gli accordi in {beats_time:}** | Estende la trasposizione anche ai nomi degli accordi nelle direttive `{beats_time: DO=4 SOL=2 …}`, rispettando lo stesso ambito (selezione o intero brano) scelto con l'opzione precedente |

  > **Nota — Notazioni relative (Nashville e Romana):** le notazioni **Nashville** (1, 2, 3… 7) e **Romana** (I, II, III… VII) rappresentano *gradi della scala* e non altezze assolute. Per questo motivo vengono escluse dalla trasposizione: spostare il grado `[1]` da Do a Re non avrebbe alcun senso musicale, poiché il grado rimane invariato indipendentemente dalla tonalità. Se il testo contiene accordi in notazione Nashville o Romana, questi restano inalterati dopo la trasposizione.

- **Semplifica accordi** — trova la tonalità più facile da suonare
- **Cambia notazione** — converte tra notazione anglosassone (C D E…) e solfeggio (Do Re Mi…)
- **Normalizza accordi** — standardizza la scrittura degli accordi (es. `Hm` → `Bm`)
- **Converti Tab → ChordPro** — converte automaticamente il formato tab (accordi sopra il testo) in ChordPro inline. Agisce sulla selezione o sull'intero brano ed è attivo solo se il testo è in formato tab
- **Converti accordi in linea in ChordPro** — racchiude tra `[ ]` gli accordi *attaccati* alle parole del testo (vedi sotto). È attivo solo se c'è qualcosa da convertire

> **Comandi attivi solo quando servono** — **Integra accordi**, **Converti Tab → ChordPro** e **Converti accordi in linea in ChordPro** restano grigi quando non avrebbero alcun effetto: ad esempio con un editor vuoto, senza accordi o con accordi già in ChordPro. Si attivano da soli appena il testo, la selezione o la posizione del cursore lo permettono. Se preferisci averli sempre disponibili, disattiva *Opzioni → Generale → Attiva i comandi di conversione degli accordi solo quando servono*. **Rimuovi accordi** segue invece sempre la selezione (attivo solo se contiene accordi).

#### Converti accordi in linea in ChordPro

Serve per i brani in cui gli accordi sono **incollati alle sillabe** del testo, senza parentesi quadre — il formato tipico di molti canzonieri copiati da internet o da vecchi file di testo:

```
LAProtegga il nostro popoSOLlo
```

diventa:

```chordpro
[LA]Protegga il nostro popo[SOL]lo
```

Il comando agisce sulla **selezione**, se c'è del testo selezionato, altrimenti sull'**intero brano**. L'operazione è annullabile con un singolo <kbd>Ctrl</kbd>+<kbd>Z</kbd>.

**Notazione usata**

La conversione usa la **notazione predefinita** impostata in **Strumenti → Opzioni… → Generale → Notazione predefinita**. Se il brano è scritto in un'altra notazione, cambiala *prima* di lanciare il comando: gli accordi non verranno riconosciuti.

**Come distingue un accordo dal testo**

| Situazione | Esito |
| --- | --- |
| Radice preceduta da una lettera **minuscola** | Accordo dentro la parola → `popo[SOL]lo` |
| Radice a inizio parola, seguita da una **maiuscola** | Accordo → `[SOL]Fa che` |
| Radice a inizio parola, seguita da una **minuscola** | Dipende dalla notazione (vedi sotto) |
| Riga composta **solo da accordi** | Racchiusi tutti → `[RE] [SOL] [LA]` |
| Direttive `{…}`, commenti `#`, testo già tra `[ ]` | Lasciati intatti |

Il caso ambiguo (radice a inizio parola seguita da minuscola) è risolto in base alla notazione:

- **Notazioni con radici tutte maiuscole e lunghe almeno 2 caratteri** (`DO RE MI FA SOL LA SI`): accettato, perché `REtuoi` non è una parola italiana.
- **Notazioni a lettera singola** (`C D E`) **o capitalizzate** (`Do Re Mi`): rifiutato, altrimenti parole comuni come `Fai` diventerebbero `[F]ai` o `[Fa]i`.

Vengono riconosciute anche alterazioni (`#`, `b`, `♯`, `♭`), qualità (`-`, `m`, `M`, `min`, `maj`, `dim`, `aug`, `°`, `+`), estensioni (`sus`, `add`, numeri) e il basso dopo la barra (`LA-/DO`). La `b` di bemolle vale come alterazione solo se **non** è seguita da altre minuscole, così `LAbella` resta `[LA]bella` e non `[LAb]ella`.

**Messaggi**

| Esito | Messaggio |
| --- | --- |
| Conversione riuscita | Nella barra di stato: *«N accordi convertiti in ChordPro»* |
| Testo vuoto | Nella barra di stato: *«Niente da convertire: il testo è vuoto»* |
| Accordi già tra `[ ]` | Nella barra di stato: *«Niente da convertire: gli accordi sono già in formato ChordPro»* |
| Nessun accordo attaccato riconosciuto | Finestra di avviso con la notazione usata, un esempio del formato atteso e l'invito a cambiare la notazione predefinita |

> **Suggerimento:** dopo la conversione conviene lanciare **Strumenti → Controlla sintassi** (<kbd>F7</kbd>) e dare un'occhiata all'anteprima: parole del testo che coincidono con un nome di nota possono, in casi rari, essere racchiuse per errore.

### Formato e struttura

- **Font canzone** — apre la finestra di dialogo per impostare il font globale
- **Font testo** — inserisce le direttive `{textfont}`/`{textsize}`/`{textcolour}` per il tratto corrente
- **Font accordi** — inserisce le direttive `{chordfont}`/`{chordsize}`/`{chordcolour}`
- **Etichette strofe** — mostra/nasconde le etichette delle strofe nell'anteprima
- **Accordi sopra / sotto** — posiziona gli accordi sopra o sotto il testo
- **Mostra accordi** — tre modalità: nessuno / solo prima strofa / intera canzone
- **Linee interruzione pagina/colonna** — mostra/nasconde le linee guida nell'anteprima

### Pulizia del testo

- **Rimuovi righe vuote superflue** — elimina le righe vuote doppie
- **Normalizza spazi multipli** — riduce gli spazi multipli a uno solo

### Simboli musicali Unicode ⌨️

- **Simbolo musicale (Unicode)…** (`Inserisci › Simbolo musicale (Unicode)…`, scorciatoia `Ctrl+Shift+M`) — apre la **finestra Simboli musicali**, da cui è possibile scegliere un carattere Unicode e inserirlo nel punto del cursore. I simboli sono organizzati in sei schede — *Note e pause*, *Alterazioni*, *Dinamiche*, *Pentagramma e chiavi*, *Ornamenti e articolazioni* e *Comuni (BMP)* — e la finestra offre alcune opzioni di inserimento:
  - **Dimensione personalizzata (pt)** — racchiude il simbolo tra `{textsize:N}…{textsize}` per inserirlo a una dimensione specifica (6–144 pt);
  - **Colore del simbolo** — applica un colore tramite `{textcolour:#RRGGBB}…{textcolour}`, con selettore *Pick…*; la scelta viene ricordata tra le sessioni;
  - **Incorpora in una strofa (non conteggiata)** — racchiude il simbolo in `{start_verse}…{end_verse}` senza alterare la numerazione progressiva delle strofe.

  Lo stato delle opzioni viene salvato automaticamente. Le due famiglie di caratteri (BMP e SMP) e i dettagli completi sono descritti nella sezione *Simboli musicali Unicode — finestra di dialogo*.

### Controllo sintassi

**Controlla sintassi** (`Strumenti › Controllo sintassi`, <kbd>F7</kbd>) analizza il testo ChordPro e segnala accordi, direttive e parentesi che non risultano corretti. Il risultato compare in una finestra dedicata.

I problemi rilevati sono distinti in due livelli di gravità, indicati nella colonna **Tipo** con un'icona:

| Tipo | Icona | Significato |
| ---- | ----- | ----------- |
| **Errore** | ❌ | Problema strutturale o valore non valido, da correggere: parentesi non chiusa, comando sconosciuto, valore numerico mancante o malformato, token nel formato sbagliato, ecc. |
| **Avvertimento** | ⚠️ | Segnalazione **non bloccante**: tipicamente un **accordo non riconosciuto** (es. `[(FA)]`, `{taste: Xyz}`, `{beats_time: Xyz=2}`, `{fingering: Xyz …}`). Il brano si compone comunque, ma vale la pena verificare che la notazione sia intenzionale. |

La finestra dei risultati mostra una tabella con le colonne **Tipo**, **Riga**, **Colonna** e **Descrizione**. Il colore di sfondo riassume l'esito a colpo d'occhio:

- **verde** — nessun problema;
- **giallo** — solo avvertimenti;
- **arancione** — almeno un errore.

L'intestazione riporta il conteggio (ad esempio *«Trovato 1 avvertimento:»* oppure *«Trovati 2 errori e 1 avvertimento:»*). Due pulsanti aiutano la consultazione:

- **Vai alla riga** (o doppio clic su una riga) — sposta il cursore dell'editor alla riga e colonna del problema selezionato;
- **Adatta larghezza** — allarga la finestra in modo che la colonna *Descrizione* mostri per intero il messaggio più lungo.


### Controllo ortografico (<kbd>F6</kbd>)

Songpress++ integra un **controllo ortografico** basato sul motore **Hunspell** (tramite la libreria PyEnchant) che analizza **solo il testo cantato**: gli accordi tra `[ ]` e le direttive tra `{ }` vengono ignorati, così un nome di accordo o una direttiva non viene mai segnalato come errore. Sono ignorate anche le parole che contengono cifre.

Il controllo ortografico è accessibile da tre comandi del menu **Strumenti**:

| Comando | Scorciatoia | Funzione |
| --- | --- | --- |
| **Controllo ortografico…** | <kbd>F6</kbd> | Apre il dialogo di correzione che scorre gli errori uno per uno |
| **Sottolineatura ortografica live** | — | Attiva/disattiva l'**ondina rossa** sotto le parole errate, aggiornata mentre si digita |
| **Opzioni ortografia…** | — | Lingua predefinita, ondina all'avvio, colore, dizionario personale, installazione dizionari |

#### Accordi in mezzo alle parole (`sal[LA-]varmi`)

Nel formato ChordPro un accordo può cadere **in mezzo a una parola**. Per impostazione predefinita Songpress++ **ricompone** la parola prima di controllarla, trattando l'accordo come invisibile:

```chordpro
sal[LA-]varmi     →  controllato come «salvarmi»
can[DO]-tare      →  controllato come «cantare»
```

I trattini `-` e gli underscore `_` di sillabazione o giunzione vengono rimossi durante la ricomposizione. Al contrario, un accordo **preceduto o seguito da uno spazio** separa due parole distinte (`Quando [Am]arrivi` → «Quando», «arrivi»).

Questo comportamento è regolato dalla casella **«Unisci le parole spezzate dagli accordi inline»** nelle *Opzioni ortografia…*. Disattivandola si torna al comportamento classico, in cui un accordo interno spezza la parola in due token (`sal` + `varmi`) generando falsi errori.

#### Dialogo di correzione (<kbd>F6</kbd>)

Il dialogo **Controllo ortografia** funziona come quello dei principali word processor: mostra una parola errata alla volta, con l'elenco dei suggerimenti e il numero di errori ancora da correggere. La parola corrispondente viene selezionata e resa visibile nell'editor.

| Pulsante | Azione |
| --- | --- |
| **Ignora** | Salta questa occorrenza |
| **Ignora tutto** | Ignora tutte le occorrenze della parola per la sessione corrente |
| **Aggiungi al dizionario** | Salva la parola nel dizionario personale (in modo permanente) |
| **Cambia** | Sostituisce con il suggerimento selezionato (o con il testo digitato nel campo) |
| **Cambia tutto** | Sostituisce tutte le occorrenze della parola |
| **Chiudi** | Chiude il dialogo |

Il campo **lingua** in fondo al dialogo permette di cambiare al volo la lingua di controllo. È possibile correggere la parola anche **a mano**, digitandola nel campo di testo prima di premere *Cambia*; un doppio clic su un suggerimento equivale a *Cambia*. Se il documento non contiene errori, compare direttamente il messaggio di controllo completato, senza aprire il dialogo.

#### Ondina rossa live

Con la **sottolineatura live** attiva, le parole non riconosciute vengono sottolineate da un'ondina (rossa per impostazione predefinita) che si aggiorna automaticamente mentre si scrive, con un breve ritardo (~350 ms) per non rallentare la digitazione. Il colore dell'ondina è personalizzabile nelle *Opzioni ortografia…*.

#### Opzioni ortografia

Il pannello **Opzioni ortografia…** raccoglie tutte le impostazioni:

| Opzione | Descrizione |
| --- | --- |
| **Abilita controllo ortografico** | Interruttore generale della funzione |
| **Lingua predefinita** | Lingua usata all'avvio e dall'ondina live |
| **Sottolinea le parole errate all'avvio** | Accende automaticamente l'ondina live all'apertura del programma |
| **Unisci le parole spezzate dagli accordi inline** | Ricompone parole come `sal[LA-]varmi` (vedi sopra) |
| **Colore sottolineatura** | Colore dell'ondina (default rosso) |

Le impostazioni vengono salvate e mantenute tra una sessione e l'altra.

#### Dizionario personale

Le parole aggiunte con **Aggiungi al dizionario** vengono salvate, una per riga, in un semplice file di testo modificabile anche a mano:

| Sistema | Percorso |
| --- | --- |
| **Linux/Debian** | `~/.config/songpress/user_dict.txt` |
| **Windows** | `%APPDATA%\Songpress\user_dict.txt` |
| **macOS** | `~/Library/Application Support/Songpress/user_dict.txt` |

Dal pannello *Opzioni ortografia…* i pulsanti **Apri…** e **Svuota** permettono rispettivamente di aprire il file nell'editor di sistema o di azzerarlo.

#### Installazione dei dizionari

Il motore ha bisogno dei dizionari **Hunspell** (coppie di file `.aff` + `.dic`) per ciascuna lingua.

- **Su Linux/Debian** conviene installare i dizionari di sistema, ad esempio:
  ```
  sudo apt install hunspell-it hunspell-en-us
  ```
- **Su Windows** i dizionari non sono presenti nel sistema: si installano direttamente dal programma con il pulsante **Installa dizionari…** (nelle *Opzioni ortografia…*).

La finestra **Installa dizionari** mostra le lingue già installate e quelle scaricabili, e scarica le coppie `.aff`/`.dic` da repository open source (principalmente il progetto **LibreOffice**). La nuova lingua è utilizzabile **subito, senza riavviare** il programma. I dizionari scaricati dall'utente possono essere rimossi con **Disinstalla**; i dizionari di sistema, contrassegnati come *[system]*, non vengono mai toccati.

Lingue disponibili nel catalogo: italiano, inglese (US/UK), spagnolo, portoghese (PT/BR), tedesco, olandese, polacco, russo, danese, ceco, ungherese, greco, croato, sloveno, rumeno e latino.

> **Nota — motore non disponibile** — Il controllo ortografico richiede la libreria **PyEnchant** (`pip install pyenchant`). Se non è installata, la funzione viene disattivata senza bloccare il programma: al primo utilizzo compare un avviso con le istruzioni per installarla.


### Copia prompt IA per beats_time (<kbd>Ctrl</kbd>+<kbd>Shift</kbd>+<kbd>B</kbd>)

**Strumenti › Copia prompt IA per beats_time**

Copia negli appunti un **prompt pronto da incollare** in un assistente di intelligenza artificiale, chiedendogli di aggiungere le direttive `{beats_time:}` al file della canzone corrente leggendo uno spartito PDF. L'IA analizza lo spartito, calcola la durata in battiti di ciascun accordo e restituisce il file `.crd` con le direttive già inserite.

**Come si usa:**

1. Apri il file della canzone (`.crd`, `.cho`, `.chordpro`, ecc.)
2. Scegli **Strumenti › Copia prompt IA per beats_time** oppure premi <kbd>Ctrl</kbd>+<kbd>Shift</kbd>+<kbd>B</kbd>
3. Apri l'assistente IA che preferisci (vedi sotto)
4. Allega lo spartito PDF e il file della canzone
5. Incolla il prompt copiato e invia

Se lo spartito PDF ha un nome diverso dal file della canzone, modificalo nel prompt prima di inviarlo. Il nome del file della canzone e quello del PDF vengono compilati automaticamente dal documento aperto; il nome del PDF viene assunto uguale al file della canzone con estensione `.pdf`.

**Struttura del prompt copiato negli appunti:**

```
Aggiungi beats_time a MiaCanzone.crd usando lo spartito MiaCanzone.pdf.
La croma vale 1 battito. Il beats_time va scritto prima della riga con gli
accordi, esempio:
`{beats_time: DO=2 SOL=2 RE-=2 LA-=2}` / `[DO]Ecco[SOL]mi, [RE-]ecco[LA-]mi!`
```

**Assistenti IA compatibili**

Qualsiasi assistente IA in grado di leggere file PDF e di testo è adatto. I seguenti sono alcuni esempi — l'elenco non è esaustivo e non costituisce una raccomandazione:

| Assistente | Indirizzo | Note |
| ---------- | --------- | ---- |
| Claude (Anthropic) | [claude.ai](https://claude.ai) | Supporta allegati PDF e file di testo; piano gratuito disponibile |
| ChatGPT (OpenAI) | [chatgpt.com](https://chatgpt.com) | Supporta allegati PDF e file di testo; piano gratuito disponibile |
| Gemini (Google) | [gemini.google.com](https://gemini.google.com) | Supporta allegati PDF; piano gratuito disponibile |
| Copilot (Microsoft) | [copilot.microsoft.com](https://copilot.microsoft.com) | Integrato in Windows 11 e Microsoft 365 |

> **Nota** — Se nessun file canzone è aperto, viene mostrato un avviso. Apri prima il file, poi usa il comando.

### Statistiche brano (<kbd>F8</kbd>)

**Strumenti › Statistiche brano…** apre una finestra di riepilogo che analizza il documento aperto e produce una valutazione immediata della difficoltà.

#### Sezioni del dialogo

| Sezione | Informazioni mostrate |
|---|---|
| **Struttura** | Numero di strofe, ritornelli, bridge e pagine stimate |
| **Testo** | Righe di testo attive e conteggio parole (esclusi accordi e direttive) |
| **Accordi** | Totale accordi, accordi unici e percentuale di accordi complessi (7ª, dim, aug, sus, add…) |
| **Metadati** | Tonalità, tempo BPM, indicazione di tempo, capo e durata (se presenti nel file) |

#### Valutazione difficoltà

La finestra mostra una valutazione da **1 a 5 stelle** basata su un punteggio 0–100 calcolato automaticamente:

| Stelle | Giudizio | Condizioni |
|---|---|---|
| ★★★★★ | Ottimo per principianti | ≤ 12 accordi unici, nessun accordo complesso |
| ★★★★☆ | Accessibile | Pochi accordi complessi o struttura semplice |
| ★★★☆☆ | Intermedio | Accordi moderatamente complessi |
| ★★☆☆☆ | Avanzato | Molti accordi complessi o struttura articolata |
| ★☆☆☆☆ | Molto difficile | Brano senza accordi o con accordi molto complessi |

La barra sotto le stelle visualizza il punteggio grezzo (0–100).

#### Durata

Il dialogo mostra la durata del brano nella sezione **Metadati** con due modalità distinte:

- **Durata dichiarata** — se il file contiene la direttiva `{duration:MM:SS}` su una riga attiva (non commentata con `#`), viene usato quel valore e la riga nelle statistiche viene etichettata **«Durata»**.
- **Durata stimata** — se `{duration:}` è assente o commentata (`#{duration:12:45}`), il dialogo calcola una stima approssimativa a partire dalle direttive `{tempo:}` e `{time:}`, moltiplicando il numero di cambi accordo per la durata di ogni battuta. La riga viene etichettata **«Durata stimata»**.

> **Nota** — La stima automatica è orientativa: non tiene conto di ripetizioni, ritornelli multipli o pause. Inserire `{duration:MM:SS}` con la durata reale del brano permette di visualizzare un valore preciso nelle statistiche.

### Righello a schermo (<kbd>F9</kbd>)

**Strumenti › Righello a schermo…** misura in pixel (o in altre unità) la larghezza e l'altezza di qualsiasi cosa visibile sullo schermo: l'altezza reale di un testo nell'anteprima, la distanza tra due righe, lo spazio sopra gli accordi, un margine della pagina.

All'avvio Songpress++ cattura un'immagine dello schermo e la mostra a tutto schermo; in alto compare una piccola barra con le modalità di misura e le opzioni. Le misure vengono eseguite su quell'immagine, quindi ciò che si vede non cambia finché il righello resta aperto.

#### Modalità di misura

Nella barra ogni modalità è un pulsante con un'icona: quadrato con i punti agli angoli (*Riquadro*), croce (*Spaziatura*), doppia freccia orizzontale (*Orizzontale*) e doppia freccia verticale (*Verticale*). Passando il mouse sul pulsante compaiono il nome e la descrizione. Chi preferisce i nomi scritti può sceglierli in **Opzioni › Generale › Righello a schermo › Pulsanti modalità › Scritte**; la scelta viene salvata e vale dalla successiva apertura del righello.

| Modalità | Tasto | Come si usa |
|---|---|---|
| **Riquadro** | <kbd>1</kbd> | Trascina un rettangolo con il mouse: viene mostrata la dimensione *larghezza × altezza*. |
| **Spaziatura** | <kbd>2</kbd> | Nessun trascinamento: una croce parte dal cursore e si ferma ai primi bordi a sinistra, destra, sopra e sotto. Misura lo spazio uniforme attorno al cursore. |
| **Orizzontale** | <kbd>3</kbd> | Come *Spaziatura*, ma solo in orizzontale. |
| **Verticale** | <kbd>4</kbd> | Come *Spaziatura*, ma solo in verticale. |

Nelle modalità **Orizzontale** e **Verticale** il puntatore del mouse a croce viene nascosto, per non coprire il punto misurato: la posizione è indicata dalla linea di misura stessa. Il puntatore riappare passando sulla barra degli strumenti.

#### Opzioni della barra

Le caselle *Adatta al contenuto*, *Mostra croce*, *Ingrandimento morbido* e *Alta risoluzione* compaiono affiancate nella barra oppure, se in **Opzioni › Generale › Righello a schermo › Opzioni** è scelto **In una lista**, in una lista verticale che si apre con il pulsante a lista della barra. La lista resta aperta mentre si attivano le caselle e si chiude cliccando altrove, con <kbd>Esc</kbd> o premendo di nuovo il pulsante. I tasti <kbd>F</kbd>, <kbd>C</kbd>, <kbd>S</kbd> e <kbd>H</kbd> funzionano in entrambi i casi.

| Opzione | Funzione |
|---|---|
| **Adatta al contenuto** | Solo in modalità *Riquadro*. Il rettangolo trascinato si restringe automaticamente attorno al contenuto diverso dallo sfondo. Il rettangolo originale resta visibile tratteggiato in grigio. Attiva per impostazione predefinita (tasto <kbd>F</kbd>). |
| **Mostra croce** | Mostra o nasconde la croce di misura: le linee tratteggiate che seguono il cursore in modalità *Riquadro* e le linee arancioni con i trattini di estremità nelle modalità *Spaziatura*, *Orizzontale* e *Verticale*. Quando è nascosta resta visibile solo l'etichetta con la misura, utile per non coprire il testo che si sta misurando. L'impostazione viene ricordata fino alla chiusura di Songpress++ (tasto <kbd>C</kbd>). |
| **Tolleranza** | Differenza di colore massima (0–255) oltre la quale un pixel è considerato un bordo. Valori bassi rendono la misura sensibile anche alle sfumature (antialiasing); valori alti ignorano le piccole variazioni. Predefinito: 30. Il valore viene ricordato ed è lo stesso di **Opzioni › Generale › Righello a schermo › Tolleranza**, dove si può anche scegliere di non mostrare il campo nella barra. |
| **Unità** | `px`, `pt`, `mm`, `cm`, `in` (tasto <kbd>U</kbd> per passare alla successiva). |
| **Ingrandimento morbido** | Con lo zoom attivo ingrandisce la vista con interpolazione bicubica: i pixel non appaiono più come quadratini, ma i bordi diventano sfumati. Spenta per impostazione predefinita, perché per misurare sono più chiari i pixel netti. L'impostazione viene ricordata fino alla chiusura di Songpress++ (tasto <kbd>S</kbd>). |
| **Alta risoluzione** | Solo su schermi HiDPI (ridimensionamento oltre il 100%). Per la vista ingrandita usa tutti i pixel fisici dello schermo invece dei pixel logici, così icone e testi mostrano più dettagli. Accesa per impostazione predefinita; al 100% la casella è disattivata (grigia) perché non ci sono pixel in più. L'impostazione viene ricordata fino alla chiusura di Songpress++ (tasto <kbd>H</kbd>). |
| **Zoom − / +** | Ingrandisce la vista attorno al cursore, da 1× a 8× a passi di 1. Vedi *Ingrandimento* qui sotto. |
| **✕** | Chiude il righello (come <kbd>Esc</kbd>). |

#### Ingrandimento

Per misurare con precisione elementi piccoli (un accordo, lo spessore di una linea, la distanza tra due lettere) si può ingrandire la vista con <kbd>+</kbd>, <kbd>Ctrl</kbd>+rotellina o i pulsanti **− / +** della barra. L'ingrandimento avviene attorno al cursore, da 1× a 8× a passi di 1, e ogni pixel dello schermo diventa un quadratino ben visibile, senza sfumature. La barra del righello non cambia dimensione: si ingrandisce solo l'immagine catturata.

L'immagine ingrandita non può contenere più dettagli di quelli presenti sullo schermo: un'icona di 16×16 pixel, ingrandita, mostra i suoi 256 quadratini. Per un aspetto diverso la barra offre due caselle, entrambe **solo visive**, attivabili anche con i tasti <kbd>S</kbd> e <kbd>H</kbd>:

- **Ingrandimento morbido** — elimina l'effetto a quadratini ammorbidendo i passaggi di colore; l'immagine appare più liscia ma meno nitida.
- **Alta risoluzione** — sugli schermi HiDPI (per esempio con ridimensionamento al 150% o 200%) lo schermo ha più pixel fisici di quelli logici usati per le misure: con questa opzione la vista ingrandita li usa tutti e mostra dettagli reali più fini.

Le due opzioni si possono combinare.

Lo zoom **cambia solo la visualizzazione, non la misura**: un testo alto 12 pixel viene sempre indicato come `12 px`, sia a 1× sia a 8×, con o senza *Ingrandimento morbido* e *Alta risoluzione*. Anche i tasti freccia spostano il cursore sempre di 1 pixel reale.

| Azione | Effetto |
|---|---|
| <kbd>+</kbd> / <kbd>-</kbd> oppure <kbd>Ctrl</kbd>+rotellina | Ingrandisce / riduce attorno al cursore |
| <kbd>0</kbd> | Torna alla vista 1:1 |
| Rotellina (con zoom attivo) | Scorre la vista in verticale; con <kbd>Shift</kbd> in orizzontale |
| Trascinamento con il tasto centrale | Sposta la vista ingrandita |
| Frecce oltre il bordo | La vista scorre automaticamente |

#### Misurare l'altezza o la larghezza di un testo

1. Apri il righello con <kbd>F9</kbd>.
2. Lascia la modalità **Riquadro** con **Adatta al contenuto** attivo.
3. Trascina un rettangolo abbondante attorno alla parola o alla riga, includendo un po' di sfondo su tutti i lati.
4. Il rettangolo si stringe da solo attorno alle lettere e mostra, per esempio, `212 × 17 px`: 212 è la larghezza del testo, 17 l'altezza dall'ascendente più alto al discendente più basso effettivamente presenti.

Per misurare lo **spazio tra due righe** usa invece la modalità **Verticale** e posiziona il cursore nello spazio vuoto tra le righe.

#### Comandi

| Azione | Effetto |
|---|---|
| Clic sinistro | Fissa la misura corrente (resta disegnata in azzurro) e la copia negli appunti, es. `212 × 17 px` |
| Clic destro | Cancella le misure fissate; se non ce ne sono, chiude il righello |
| <kbd>Ctrl</kbd>+<kbd>C</kbd> | Copia negli appunti la misura attuale (o l'ultima fissata) |
| <kbd>←</kbd> <kbd>→</kbd> <kbd>↑</kbd> <kbd>↓</kbd> | Sposta il cursore di 1 pixel (con <kbd>Shift</kbd> di 10 pixel) |
| <kbd>C</kbd> | Mostra / nasconde la croce di misura |
| <kbd>S</kbd> | Attiva / disattiva *Ingrandimento morbido* |
| <kbd>H</kbd> | Attiva / disattiva *Alta risoluzione* (solo schermi HiDPI) |
| <kbd>+</kbd> / <kbd>-</kbd> / <kbd>0</kbd> | Ingrandisce / riduce / torna a 1:1 |
| <kbd>Canc</kbd> / <kbd>Backspace</kbd> | Cancella le misure fissate |
| <kbd>Esc</kbd> | Annulla il trascinamento in corso oppure chiude il righello |

> **Nota — unità fisiche** — I valori in `mm`, `cm`, `pt` e `in` sono calcolati dai DPI dichiarati dal sistema operativo (spesso 96 su Linux) e sono esatti solo se questo valore corrisponde alla risoluzione reale del monitor. La misura in pixel è sempre precisa. Per misurare la dimensione di stampa di un elemento conviene usare l'anteprima allo zoom 100%.

> **Nota — Linux / Wayland** — Su Wayland le applicazioni non possono leggere direttamente lo schermo. Songpress++ prova in ordine: **grim** (Sway/wlroots) o **spectacle** (KDE) se installati, poi il **portale xdg-desktop-portal**, presente di serie su GNOME e KDE, e infine **gnome-screenshot**. Con il portale non serve installare nulla: al primo utilizzo il desktop può chiedere il permesso di catturare lo schermo; se lo neghi o annulli, il righello non si apre. Su X11 e Windows non serve nulla di aggiuntivo. Con lo scaling HiDPI attivo le misure sono espresse in pixel logici; l'opzione **Alta risoluzione** usa i pixel fisici solo per la vista ingrandita.

### Intellisense direttive (`Ctrl+Spazio`)

Premendo `Ctrl+Spazio` con il cursore posizionato all'interno di una coppia di parentesi graffe `{…}`, l'editor mostra un elenco a comparsa con tutte le direttive ChordPro supportate da Songpress++. Selezionando una voce dall'elenco (con `Enter` o doppio clic), la direttiva viene inserita nella posizione corretta.

Questa funzionalità può essere abilitata o disabilitata in **Strumenti → Opzioni… → scheda Generale → Abilita intellisense direttive (Ctrl+Spazio)**.

---

## Simboli musicali Unicode — finestra di dialogo

La finestra **Musical Symbols** (`Inserisci › Simbolo musicale (Unicode)…`, `Ctrl+Shift+M`) permette di inserire nell'editor qualsiasi carattere Unicode musicale speciale, inclusi i simboli del blocco **Musical Symbols** (U+1D100–U+1D1FF) e i caratteri BMP più comuni.

### Struttura della finestra

La finestra è organizzata in **sei schede** per categoria:

| Scheda | Contenuto |
| ---------------------- | ---------------------------------------------------------------- |
| **Note e pause** | Note dalla breve alla 128ª, teste di nota, pause di ogni valore e pausa multi-misura (U+1D13A–U+1D164) |
| **Alterazioni** | Diesis, bemolle, bequadro, doppi, quarti di tono e microtonali (alzati/abbassati) |
| **Dinamiche** | *p*, *m*, *f* e composte (*pp*, *mp*, *mf*, *ff*, *sf*, *sfz*, *fp*…), rinforzando, crescendo/decrescendo |
| **Pentagramma e chiavi** | Chiavi (violino, basso, Do, con ottave), stanghette, ritornelli, *segno*, *coda*, *dal segno*, *da capo* |
| **Ornamenti e articolazioni** | Fermata, respiro, cesura, trilli, gruppetti, abbellimenti, legature e frasi |
| **Comuni (BMP)** | ♩ ♪ ♫ ♬ ★ † ½ ¼ × – — … e altri caratteri d'uso comune |

### Come inserire un simbolo

1. Aprire la finestra con `Inserisci › Simbolo musicale (Unicode)…` o `Ctrl+Shift+M`.
2. Selezionare la scheda della categoria desiderata.
3. **Fare clic** su una cella per selezionare il simbolo — in basso appariranno l'anteprima ingrandita e la descrizione con il codepoint Unicode (es. `U+1D157`).
4. Premere **Insert** oppure fare **doppio clic** sulla cella per inserire il carattere nel cursore dell'editor e chiudere la finestra.
5. Premere **Close** (o `Esc`) per annullare senza inserire nulla.

> **Suggerimento** — Passando il mouse sulle celle appare un tooltip con il nome del simbolo e il codepoint.

### Opzioni di inserimento

Nella parte inferiore della finestra si trovano due opzioni che controllano il modo in cui il simbolo viene inserito nell'editor. Il loro stato viene salvato automaticamente e ripristinato alla riapertura del programma.

**Dimensione personalizzata (pt)** — checkbox + campo numerico (6–144)

Quando è attiva, il simbolo viene wrappato con le direttive `{textsize:N}` e `{textsize}` per applicare la dimensione scelta e ripristinare poi quella originale. La seconda `{textsize}` senza argomento è la forma corretta per il reset (diversamente da `{textsize:}` con due punti finali, che costituisce un errore sintattico rilevato dalla verifica sintattica).

| Checkbox | Testo inserito |
| -------- | -------------- |
| disattivata | `♩` |
| attivata (pt = 24) | `{textsize:24}♩{textsize}` |

> **Nota** — Non tutti i simboli possono essere ridimensionati: i caratteri del piano SMP (U+1D100–U+1D1FF) richiedono un font con copertura adeguata (FreeSerif, Bravura, ecc.) nella cartella `fonts/`. Se il font non copre il glifo, la dimensione viene applicata ma il carattere potrebbe non essere visibile.

**Incorpora il simbolo in una strofa (non conteggiata)** — checkbox

Quando è attiva, il simbolo viene racchiuso in un blocco `{start_verse}…{end_verse}`. In questo modo appare nell'anteprima come un blocco strofa autonomo, ma **non viene conteggiato** nella numerazione progressiva delle strofe: le strofe adiacenti mantengono la loro numerazione corretta.

| Checkbox | Testo inserito |
| -------- | -------------- |
| disattivata | `♩` |
| attivata | `{start_verse}♩{end_verse}` |

Le due opzioni sono combinabili: se entrambe sono attive, il risultato è:

```chordpro
{start_verse}{textsize:24}♩{textsize}{end_verse}
```

Le stesse impostazioni sono accessibili anche da **Preferenze → Formattazione → Inserimento simbolo musicale**, dove vengono salvate in modo permanente.

### Simboli SMP e BMP — che differenza c'è

I caratteri offerti dalla finestra appartengono a due famiglie Unicode che Songpress++ tratta in modo molto diverso. Sapere a quale famiglia appartiene un simbolo spiega perché alcuni si comportano come normale testo e altri richiedono un font dedicato.

| | **BMP** (Basic Multilingual Plane) | **SMP** (Supplementary Multilingual Plane) |
| --- | --- | --- |
| **Cosa sono** | Caratteri con codepoint ≤ U+FFFF | Caratteri con codepoint > U+FFFF |
| **Esempi** | ♩ ♪ ♫ ♬ ★ † ½ ¼ × – — … | 𝄞 𝄢 e gli altri glifi del blocco *Musical Symbols* (U+1D100–U+1D1FF) |
| **Dove nella finestra** | scheda **Comuni (BMP)** | schede *Note e pause*, *Alterazioni*, *Dinamiche*, *Pentagramma e chiavi*, *Ornamenti e articolazioni* |
| **Copertura font** | quasi tutti i font di sistema li contengono | i font comuni (Arial, Times, Calibri) **non** li coprono: serve un font dedicato (FreeSerif, incluso) |
| **Come vengono resi** | **direttamente col font della canzone**, esattamente come una lettera | tramite un **percorso di disegno separato** (GDI+/`GraphicsContext` in anteprima, rasterizzazione FreeType/Pillow in stampa) |
| **Ridimensionabili con `{textsize:}`** | sì, sempre | sì, ma solo se il font copre il glifo |
| **Allineamento verticale** | naturale (sono testo normale) | il glifo tende a stare più in alto: si regola con **Abbassamento simbolo (%)** nelle Opzioni |

In pratica: un simbolo **BMP** è a tutti gli effetti un carattere di testo — scala, si stampa e si allinea come le lettere accanto, senza alcun trattamento speciale. Un simbolo **SMP** è notazione musicale "vera" che i font ordinari non contengono, perciò Songpress++ lo disegna a parte con FreeSerif.

Nella finestra, la descrizione del simbolo selezionato (in basso) indica a quale piano appartiene, così sai subito se richiede il font dedicato oppure no.

> **Abbassamento simbolo (%)** — Poiché i glifi SMP vengono disegnati con un percorso separato, tendono a comparire un po' più in alto rispetto alle lettere. L'opzione **Preferenze → Formato → Inserimento simbolo musicale → Abbassamento simbolo (%)** li abbassa fino ad allinearli alla riga di testo, con aggiornamento in tempo reale nell'anteprima. A **0** il simbolo resta nella posizione grezza, il valore predefinito **~5** lo allinea alla riga; valori più alti lo abbassano ancora. I simboli BMP non ne sono influenzati.

I simboli del blocco Musical Symbols (U+1D100–U+1D1FF) appartengono al piano supplementare Unicode (**SMP**, codepoint > U+FFFF). I font di sistema comuni (Arial, Times New Roman, Calibri) non coprono questo range; Songpress++ risolve il problema in due modi distinti:

**Nell'editor (pannello di testo)** — l'editor usa il motore di rendering **DirectWrite** (`SetTechnology(STC_TECHNOLOGY_DIRECTWRITE)`), che abilita il font-fallback automatico di Windows: se il font scelto per l'editor non contiene il glifo, Windows cerca automaticamente tra i font installati quello più adatto.

**Nell'anteprima e in stampa** — il renderer usa **GDI+** tramite `wx.GraphicsContext` esclusivamente per i caratteri SMP. Per ogni stringa che contiene almeno un codepoint > U+FFFF, Songpress++ crea un contesto grafico separato e imposta il font nell'ordine di preferenza:

1. **FreeSerif** (GNU FreeFont) — copertura completa del blocco Musical Symbols; deve essere presente in `<installazione>/fonts/FreeSerif.ttf`.
2. **Segoe UI Symbol** — presente di default su Windows 10/11; copertura SMP parziale.
3. Font corrente del documento — usato come ultimo tentativo (mostrerà rettangoli per i glifi mancanti).

Il testo normale (accordi, testo canzone, titoli) continua a usare il renderer GDI classico senza overhead aggiuntivo.

### Come modificare le dimensioni del simbolo nell'anteprima

I simboli musicali vengono visualizzati nella stessa dimensione del testo circostante, scalata automaticamente in base a:

- **Font globale della canzone** — modificabile da `Formato › Font canzone…`. Aumentare la dimensione in punti del font principale aumenta proporzionalmente anche i simboli SMP.
- **Direttiva `{textsize:Pt}`** — inserita direttamente nel testo ChordPro prima del simbolo, imposta la dimensione in punti per quel tratto. Esempio:

  ```chordpro
  {textsize:24}𝄞{textsize}
  ```

  La seconda `{textsize}` (senza argomento) ripristina la dimensione predefinita.

- **Direttiva `{textsize:N%}`** — versione percentuale, relativa alla dimensione base del documento. Esempio per un simbolo al 150%:

  ```chordpro
  {textsize:150%}𝅘𝅥𝅮{textsize}
  ```

- **Zoom dell'anteprima** — il cursore di zoom nella barra dell'anteprima scala tutta la pagina (testo + simboli) senza modificare le dimensioni del file. Non influisce sulla stampa.

> **Nota tecnica** — Il renderer moltiplica automaticamente la dimensione in punti del font per il fattore di zoom corrente prima di creare il `wx.GraphicsFont`, in modo che i simboli SMP abbiano sempre le stesse proporzioni del testo GDI circostante.

### Aggiungere librerie di simboli personalizzate

Songpress++ carica automaticamente **tutti** i file `.ttf` presenti nella cartella `fonts/` all'interno della directory di installazione. Per aggiungere il supporto a nuovi simboli Unicode è sufficiente copiare il file del font in quella cartella — non è richiesta nessuna configurazione aggiuntiva.

```
<installazione>/
  fonts/
    FreeSerif.ttf           ← già incluso — copertura completa Musical Symbols
    Bravura.ttf             ← font SMuFL (notazione musicale professionale)
    NotoMusic.ttf           ← Google Noto — ampia copertura SMP
    SegoeUISymbol.ttf       ← eventuale copia locale di Segoe UI Symbol
    qualsiasi_altro.ttf     ← viene caricato e usato automaticamente
```

**Ordine di priorità** — I font vengono provati nell'ordine seguente:

1. `FreeSerif.ttf` — ha precedenza assoluta (copertura Musical Symbols garantita)
2. `Bravura.ttf` — se presente
3. `NotoMusic.ttf` / `NotoMusicRegular.ttf` — se presenti
4. Tutti gli altri `.ttf` nella cartella, in ordine alfabetico
5. **Segoe UI Symbol** — font di sistema Windows 10/11 (fallback automatico, nessun file da copiare)
6. Font corrente del documento — ultimo tentativo (mostra rettangoli per i glifi mancanti)

Per ogni carattere SMP, Songpress++ percorre questa lista e usa il primo font che wx riesce a caricare correttamente. Se un font non copre un particolare glifo, GDI+ non fa ulteriore fallback automatico — il font corretto deve quindi trovarsi nella cartella `fonts/`.

> **Suggerimento** — I font **SMuFL** (Standard Music Font Layout, <https://www.smufl.org>) come Bravura, Petaluma o Leland coprono centinaia di simboli musicali specializzati non inclusi in FreeSerif. Per la notazione gregoriana o mensurale sono consigliati font come **Caeciliae** o **Volpiano**.

---


## Modalità istanza singola

**Percorso:** *Opzioni → Generale 2 → Generale → Istanza singola: apri i file nella finestra esistente*

Quando questa opzione è attiva (predefinito: **sì**), Songpress++ funziona in **modalità istanza singola**: aprire un file da Esplora risorse, dalla riga di comando o con doppio clic su un file `.crd` / `.cho` / `.chordpro` instrada sempre il file nella **finestra già aperta**, invece di avviare un nuovo processo.

### Come funziona

1. All'avvio, Songpress++ apre un **socket locale** sulla porta 47833 (solo localhost, invisibile alla rete).
2. Se viene avviata una seconda istanza (ad esempio con doppio clic su un altro file), il nuovo processo rileva il socket in ascolto, **invia il percorso del file** all'istanza in esecuzione e termina immediatamente.
3. La finestra in esecuzione riceve il percorso, **si porta in primo piano** e apre il file come se l'utente avesse usato *File → Apri*.

L'intero scambio è silenzioso: in condizioni normali non compaiono dialoghi né notifiche.

### Casi di errore

| Situazione | Comportamento |
|---|---|
| Il file passato dalla riga di comando non esiste | Viene mostrato un dialogo di errore, poi l'applicazione termina |
| Nessuna istanza in ascolto (primo avvio o istanza precedente terminata in modo anomalo) | Songpress++ si avvia normalmente e diventa la nuova istanza singola |

### Pro e contro

| ✅ Vantaggi | ⚠️ Svantaggi |
|---|---|
| Evita la proliferazione accidentale di finestre quando si aprono più file da Esplora risorse | È possibile avere un solo brano aperto per volta per finestra (a meno che il file non contenga più blocchi `{new_song}`) |
| Preserva il layout, il livello di zoom e lo stato dell'editor della finestra esistente | Se si vuole deliberatamente avere due finestre indipendenti (ad es. per confrontare due brani), occorre **disattivare** questa opzione |
| Coerente con il comportamento della maggior parte degli editor professionali (VS Code, Notepad++, Sublime Text) | Richiede che la porta TCP 47833 sia disponibile su localhost; i conflitti sono estremamente rari ma possibili in ambienti molto vincolati |
| Aprire un file porta la finestra in primo piano automaticamente, senza intervento dell'utente | |

### Quando disattivarla

Deseleziona *Istanza singola* se hai bisogno di:

- Lavorare su **due o più brani contemporaneamente** in finestre separate e indipendenti.
- Eseguire Songpress++ in un ambiente **multi-utente / RDS** dove ogni sessione deve essere completamente isolata.
- Diagnosticare un conflitto di porta (controlla `startup.log` in `%LOCALAPPDATA%\Songpress++\` per la diagnostica).

> **Nota — startup.log** — Ogni evento legato all'istanza singola viene registrato in `%LOCALAPPDATA%\Songpress++\startup.log` (Windows) oppure `~/.Songpress++/startup.log` (Linux/macOS). Il log registra il percorso del config letto, il valore della chiave `singleinstance`, se è stata trovata un'istanza esistente e se il file è stato inoltrato con successo. È il primo posto dove cercare in caso di comportamento anomalo con più finestre.

---
## Nuovo da template — creare un brano da un modello

**File → Nuovo da template** apre un sottomenu con l'elenco dei modelli di canzone disponibili (file `.crd`). Scegliendone uno, il suo contenuto viene caricato in un **nuovo documento**, pronto da personalizzare.

### Come si usa

1. Apri **File → Nuovo da template**.
2. Scegli un modello dall'elenco (ordinato alfabeticamente per nome).
3. Il contenuto del modello viene inserito in un **documento nuovo e senza nome**, esattamente come con **Nuovo**: la barra del titolo mostra *Untitled* e il brano risulta «modificato».
4. Il primo **Salva** si comporta come **Salva con nome**: decidi tu nome e posizione.

Il file del modello **non viene mai sovrascritto**: quello che scegli è solo il punto di partenza del nuovo brano.

### Da dove arrivano i modelli

I modelli sono i file `.crd` contenuti in `templates/songs`. Songpress++ guarda in due cartelle:

- **pacchetto** — `templates/songs` distribuita con l'applicazione (i modelli di esempio);
- **utente** — `templates/songs` nella cartella dati dell'utente, dove metti i tuoi.

A parità di nome file, **vince la copia utente**. Se non viene trovato alcun modello, il menu mostra la voce disabilitata **(nessun modello disponibile)**.

### Aggiungere o modificare un modello

- **Aggiungerne uno tuo**: metti un file `.crd` nella cartella modelli utente. La via più rapida è **Strumenti → Opzioni → Generale → Apri cartella modelli**, poi entra in `songs/` e copiaci il file (oppure usa *Salva con nome* direttamente lì). Il nome del file è quello che comparirà nel menu.
- **Modificarne uno esistente**: aprilo, modificalo e salvalo. Le modifiche vengono usate immediatamente, perché il contenuto del modello viene riletto dal file ogni volta che lo selezioni.

> **L'elenco si aggiorna da solo.** Il sottomenu viene rigenerato a ogni apertura del menu **File**: i modelli aggiunti, rinominati o eliminati compaiono **subito**, senza dover riavviare l'applicazione. Il pulsante *Apri cartella modelli* apre proprio la cartella utente che l'app rilegge, così ciò che aggiungi o modifichi lì diventa immediatamente disponibile.

---
## Finestra Opzioni — riferimento completo

Si apre da **Strumenti → Opzioni…** (titolo della finestra: *Opzioni Songpress++*). È un dialogo a schede ridimensionabile (dimensione minima 730 × 800 px).

### Pulsanti comuni a tutte le schede

| Pulsante | Funzione |
| -------- | -------- |
| 📌 **Pin** | Mantiene la finestra aperta dopo aver premuto OK: le preferenze vengono salvate e applicate immediatamente, ma il dialogo resta a disposizione per ulteriori modifiche. Molto comodo per regolare colori e spaziature vedendo subito l'effetto nell'anteprima. |
| **OK** | Salva tutte le preferenze (`Preferences.Save()`) e chiude la finestra. |
| **Annulla** | Chiude senza salvare. Le anteprime interattive (colori sintassi, sfondo editor…) vengono comunque scartate. |

> **Riavvio di Songpress++** — Alcune impostazioni hanno effetto solo dopo il riavvio; in pratica l'unica è la **lingua dell'interfaccia**. Songpress++ è in grado di riavviarsi da solo: salva le preferenze, chiude la finestra corrente e si riapre automaticamente. Se il brano ha modifiche non salvate, Songpress++ chiede **prima** se salvarle: premendo **Annulla** il riavvio viene interrotto e non si apre nessuna seconda finestra. La nuova istanza parte solo dopo la chiusura riuscita di quella corrente. Ci sono due modi per avviarlo:
>
> - **Cambio lingua.** Quando si sceglie una lingua diversa (campo **Lingua**, gruppo *Canzone* qui sotto) e si conferma, appare un messaggio con due pulsanti: **OK** (la nuova lingua verrà applicata al prossimo avvio) e **Riavvia ora** (riavvia subito Songpress++, applicando immediatamente la lingua).
> - **Menu File → «Riavvia Songpress++».** Voce di riavvio rapido, disponibile in qualsiasi momento senza dover chiudere e riaprire a mano (si può mostrare/nascondere dal gruppo *Generale* qui sotto).
>
> Il riavvio automatico funziona sia che Songpress++ sia stato avviato dal menu del desktop, sia da terminale. Tutte le altre opzioni hanno effetto immediato, senza riavvio.

> **Nota tecnica (Linux) — come avviene il riavvio automatico.** Per far sopravvivere la nuova istanza alla chiusura di quella vecchia, Songpress++ sceglie il metodo di avvio in base a *come* è stato lanciato, distinguendo i casi dalla presenza di un terminale di controllo (tty):
>
> - **Menu del desktop (KDE/GNOME, nessun tty)** — l'app gira in uno *scope* systemd transitorio che verrebbe distrutto alla sua uscita, uccidendo il processo figlio; la nuova istanza viene quindi avviata in uno scope nuovo e indipendente con `systemd-run --user --scope` (e con `argv[0]` reso assoluto). → riapre.
> - **Terminale interattivo (tty)** — basta il detach classico (`setsid`, cioè `start_new_session`): non c'è alcuno scope da distruggere. → riapre come prima.
> - **Terminale con flussi rediretti** (es. `songpress++ >log 2>&1 </dev/null &`, nessun tty) — si usa il ramo `systemd-run`; grazie ad `argv[0]` assoluto il riavvio regge anche se la directory di lavoro cambia.

---

### Scheda *Generale*

#### Gruppo **Canzone**

| Campo | Predefinito | Descrizione |
| ----- | ----------- | ----------- |
| **Notazione predefinita** | prima della lista | Notazione degli accordi usata per i nuovi brani (italiana, inglese, tedesca…). |
| **Estensione predefinita** | `crd` | Estensione proposta al salvataggio. Valori: `crd`, `pro`, `chopro`, `chordpro`, `cho`, `sng`. |
| **Lingua** | lingua di sistema | Lingua dell'interfaccia, con bandierina. **Richiede il riavvio.** |

#### Gruppo **Generale**

| Comando / opzione | Predefinito | Descrizione |
| ----------------- | :---------: | ----------- |
| **Cancella file recenti** (pulsante) | — | Svuota l'elenco dei file recenti. La cancellazione avviene alla conferma con OK. |
| **Apri cartella modelli** (pulsante) | — | Apre nel file manager di sistema la cartella modelli **utente** (`templates/`, usata anche per i temi dei colori) — la stessa che l'app rilegge. I file `.crd` messi in `songs/` compaiono in *File → Nuovo da template* (vedi il capitolo *Nuovo da template*). |
| **Abilita il pulsante «Salva» solo quando la canzone è modificata** | ✓ | Il comando Salva (menu e toolbar) resta disabilitato finché non ci sono modifiche non salvate. |
| **Attiva i comandi di conversione degli accordi solo quando servono** | ✓ | **Integra accordi**, **Converti Tab in ChordPro** e **Converti accordi in linea in ChordPro** restano grigi quando non hanno nulla da fare (vedi *Gestione degli accordi*). Se disattivata, sono sempre attivi. Il valore viene salvato alla chiusura e ripristinato all'avvio. |
| **Abilita intellisense direttive (Ctrl+Spazio)** | ✓ | Attiva il completamento automatico delle direttive ChordPro nell'editor. |
| **Abilita multicursore (Alt+Clic, Ctrl+D)** | ☐ | Alt+Clic aggiunge un cursore; Ctrl+D seleziona l'occorrenza successiva della parola corrente. |
| **Istanza singola: apri i file nella finestra esistente** | ✓ | I file aperti da Esplora risorse o da riga di comando riutilizzano la finestra già aperta. Vedi il capitolo *Modalità istanza singola*. |
| **Mostra «Riavvia Songpress++» nel menu File** | ✓ | Aggiunge al menu **File** la voce **Riavvia Songpress++**, per un riavvio rapido senza chiudere e riaprire a mano (vedi il riquadro *Riavvio di Songpress++* più sopra). |
| **Mostra il percorso completo del file nella barra del titolo** | ☐ | Nella barra del titolo mostra il **percorso completo** del file aperto (es. `C:\Songs\ballad.crd`) invece del solo nome. Per un brano nuovo non ancora salvato mostra comunque *Untitled*. L'asterisco iniziale, che segnala modifiche non salvate, resta invariato. |
| **Mostra messaggi di debug (percorso salvataggio temi)** | ☐ | Mostra popup diagnostici (es. il percorso in cui viene salvato un tema). Utile solo per diagnosi. |
| **Salva dimensione e posizione della finestra all'uscita** | ✓ | Ripristina geometria della finestra al successivo avvio. |
| **Sostituisci gli spazi con «_» nei nomi dei file salvati** | ☐ | Gli spazi nel nome del file (non nel percorso) diventano underscore in salvataggio ed esportazione. |
| **Suggerisci il {title:} della canzone come nome file in «Salva con nome»** | ☐ | Propone il titolo come nome file, ripulito dai caratteri non validi. Vedi *Nomi dei file salvati*. |
| **Dimensione icone toolbar** | Piccole | Radio: **Piccole (16×16)**, **Medie (19×19)**, **Grandi (21×21)**. |

> Le checkbox del gruppo sono ordinate alfabeticamente secondo la lingua dell'interfaccia: l'ordine a schermo può differire da quello della tabella.

#### Gruppo **Righello a schermo**

Opzioni della barra del *Righello a schermo* (<kbd>F9</kbd>). Valgono dalla successiva apertura del righello.

| Comando / opzione | Predefinito | Descrizione |
| ----------------- | :---------: | ----------- |
| **Pulsanti modalità** | Icone | Radio: **Icone** (icone 16×16, il nome compare nel suggerimento) oppure **Scritte** (nome della modalità sul pulsante). |
| **Opzioni** | Affiancate | Radio: **Affiancate** (le caselle *Adatta al contenuto*, *Mostra croce*, *Ingrandimento morbido* e *Alta risoluzione* una accanto all'altra nella barra) oppure **In una lista** (al loro posto un pulsante apre una lista verticale con le stesse caselle; la barra diventa più corta). |
| **Mantieni le icone a 16×16 pixel reali** | ✓ | Con ridimensionamento dello schermo oltre il 100% (es. 150%) le icone della barra non vengono ingrandite: restano nitide a 16×16 pixel ma appaiono più piccole del testo. Se disattivata, vengono ingrandite come le altre icone e possono apparire leggermente sfocate. Al 100% non ha effetto. |
| **Tolleranza** | 30 | Differenza di colore massima (0–255) oltre la quale un pixel è considerato un bordo. È **lo stesso valore** del campo *Tolleranza* della barra del righello: se lo cambi nella barra, alla chiusura del righello viene salvato e lo ritrovi qui; se lo cambi qui, il righello si apre con il nuovo valore. |
| **Mostra anche nella "Barra Righello dello schermo..."** | ✓ | Se attiva, il campo *Tolleranza* compare anche nella barra del righello. Se disattivata, la tolleranza si cambia solo qui e la barra diventa più corta. |

---

### Scheda *Editor*

#### Gruppo **Font editor**

| Campo | Predefinito | Descrizione |
| ----- | ----------- | ----------- |
| **Font** | font a spaziatura fissa di sistema | Carattere dell'editor (elenco con anteprima). |
| **Dimensione** | 12 | Corpo del font (7–20). |
| **Colore di sfondo editor** | `#FFFFFF` | Sfondo dell'area di scrittura. |
| **Colore selezione** | `#C0C0C0` | Sfondo del testo selezionato. |
| **Colore cursore (caret)** | `#000000` | Colore della barra di inserimento. |
| **Colore didascalia Editor** | `#4682C8` | Colore della barra titolo del riquadro AUI *Editor*. |
| **Colore didascalia Pagina** | `#329B82` | Colore della barra titolo del riquadro AUI *Pagina*. |

Ogni colore ha tre controlli: il campo **esadecimale** (`#RRGGBB`, modificabile a mano), il pulsante **Scegli…** (apre il selettore colore di sistema) e il **quadratino di anteprima**.

#### Gruppo **Colori sintassi**

Colora l'evidenziazione della sintassi ChordPro nell'editor. L'anteprima in fondo alla scheda mostra subito il risultato su un brano di esempio.

| Elemento | Predefinito |
| -------- | ----------- |
| **Testo normale** | `#000000` |
| **Ritornello** | `#000000` |
| **Accordi** | `#FF0000` |
| **Comandi** | `#0000FF` |
| **Attributi** | `#008000` |
| **Commenti** | `#808080` |
| **Tab / Griglia** | `#8B5A00` |

**Barra dei temi** — permette di salvare e riusare combinazioni di colori:

- **Tema** (elenco) — temi disponibili nella cartella `templates/`.
- **Carica** — applica il tema selezionato ai campi colore.
- **Salva** — chiede un nome e salva la combinazione corrente come tema.
- **Elimina** — rimuove il tema selezionato previa conferma.

> Con *Mostra messaggi di debug* attivo, al salvataggio di un tema viene mostrato il percorso completo del file creato.

---

### Scheda *Correzione automatica*

Controlla le proposte automatiche di correzione all'apertura/salvataggio di un brano.

| Opzione | Predefinito | Descrizione |
| ------- | :---------: | ----------- |
| **Proponi di rimuovere le righe vuote** | ✓ | Offre di eliminare le righe vuote superflue. |
| **Proponi di convertire le canzoni in tab** | ✓ | Offre di convertire il formato *accordi sopra il testo* in ChordPro. |
| **Proponi di trasporre per semplificare gli accordi** | ☐ | Offre di trasporre nella tonalità con gli accordi più semplici. |
| **Colore barra livelli** | `#2980B9` | Colore delle barre dei cursori di semplificazione sottostanti. |

Sotto, il pannello scorrevole **semplificazione accordi** contiene un cursore per ogni gruppo di accordi: imposta quanto un dato gruppo debba essere considerato «facile» quando Songpress++ cerca la tonalità ottimale.

---

### Scheda *Formato*

#### Gruppo **Titolo e struttura**

| Campo | Predefinito | Intervallo |
| ----- | :---------: | ---------- |
| **Spessore sottolineatura titolo** | 4 | 1–5 |
| **Spessore bordo numero strofa** | 1 | 1–5 |

#### Gruppo **Accordi e tastiera**

| Campo | Predefinito | Descrizione |
| ----- | ----------- | ----------- |
| **Colore tasti Klavier** | `#D23C3C` | Evidenziazione dei tasti nel diagramma di tastiera. |
| **Colore diverso per il tasto dell'ottava superiore** | disattivato, `#3C78D2` | Nelle tastiere a 8 tasti colora con un secondo colore il tasto più a destra uguale al primo (es. Si alto in Si…Si). |
| **Colore numeri diteggiatura** | `#1A1A1A` | Colore dei numeri di `{fingering:}`. |

#### Gruppo **Tempo**

| Campo | Predefinito | Descrizione |
| ----- | ----------- | ----------- |
| **Dimensione icone tempo** | 24×24 | Dimensione delle icone delle direttive `{tempo_*}`: 16×16, 24×24, 32×32. |

#### Gruppo **Griglia accordi (`{start_of_grid}`…`{end_of_grid}`)**

| Campo | Predefinito | Descrizione |
| ----- | :---------: | ----------- |
| **Modalità di visualizzazione** | Pipe | **Tabella pipe** (`\| C \| G \| Am \| F \|`), **Spaziatura semplice** (accordi spaziati senza pipe), **Tabella** (celle con bordi disegnati). |
| **Etichetta predefinita** | *Griglia* | Etichetta usata quando `{start_of_grid}` non ha argomento. `{start_of_grid: Intro}` la sovrascrive. |
| **La barra spaziatrice inserisce il separatore pipe `\|` (modalità pipe)** | ✓ | Dentro un blocco griglia lo spazio inserisce un `\|` spostando la cella corrente a destra. Disattivare per digitare spazi normali. |
| **`size=N` agisce su** | Larghezza e altezza | Scegli se `size=N` moltiplichi il padding delle celle in **larghezza e altezza**, **solo larghezza** o **solo altezza**. |

#### Gruppo **Inserimento simbolo musicale**

| Campo | Predefinito | Descrizione |
| ----- | :---------: | ----------- |
| **Dimensione personalizzata all'inserimento dei simboli (pt)** | ☐ | Se attivo, il simbolo viene racchiuso tra `{textsize:N}`…`{textsize:}` con il corpo scelto nello spin (6–144, predefinito 24). |
| **Racchiudi il simbolo in un blocco strofa (non conteggiato)** | ☐ | Il simbolo viene avvolto in `{start_verse}`…`{end_verse}` così da non entrare nella numerazione delle strofe. |
| **Abbassamento simbolo (%)** | 5 | Abbassa i simboli **SMP** per allinearli alla riga di testo (0–25); 0 = posizione grezza, ~5 li allinea (predefinito). Aggiornamento in tempo reale nell'anteprima. Non influisce sui simboli BMP. |

#### Gruppo **Conteggio battute (`{beats_time}`)**

| Campo | Predefinito | Descrizione |
| ----- | :---------: | ----------- |
| **Colore** | `#6464C8` | Colore del numero/puntini di durata. |
| **Dimensione font (% del font accordo)** | 60 | 30–150 %. |
| **Grassetto** | ☐ | Disegna il numero in grassetto. |
| **Posizione** | Destra | Sinistra / Centro / Destra rispetto al nome dell'accordo. |
| **Modalità di visualizzazione** | Numero | **Numero**, **Puntini** (fra gli accordi) o **Entrambi**. |

---

### Scheda *Pagina Songpress++*

Contiene tre gruppi già descritti in dettaglio nei capitoli *Opzioni Pagina*, *Stampa e anteprima* e *Nessun accordo: blocchi da nascondere*:

- **Pagina Songpress++** — Doppio clic porta il focus all'editor (✓), Dimensione minima pannello 370×520 (✓), Mostra indicatore pagina (✓), Ritarda aggiornamento durante la digitazione — debounce (✓), Sfondo grigio (✓).
- **Stampa** — Aggiornamento in tempo reale dello stato duplex/colore nell'anteprima ogni 1,5 s (✓), Mantieni l'anteprima di stampa sempre in primo piano (☐), Mostra anteprima di stampa prima di stampare (✓).
- **Nessun accordo: blocchi da nascondere** — Accordi di intro, Bridge, Griglia, Indicazione di tempo `{time}`, Tempo `{tempo_*}` (tutti ☐).

---

### Scheda *Guida rapida*

| Campo | Predefinito | Descrizione |
| ----- | ----------- | ----------- |
| **Visualizzatore Markdown** | Automatico | Motore usato per il rendering di questa guida: **Automatico** (prova *python-markdown*, poi *mistune*, infine il parser interno), **python-markdown**, **mistune**, **Parser interno**. I primi due vanno installati separatamente. |

---

### Scheda *Menu contestuale*

Sceglie quali voci compaiono nel menu del tasto destro dell'editor.

| Gruppo | Voci |
| ------ | ---- |
| **Cronologia** | Annulla, Ripeti |
| **Modifica** | Taglia, Copia, Incolla, Elimina + **Chiedi conferma prima di eliminare** (☐, sotto-opzione di *Elimina*) |
| **Azioni speciali** | Incolla accordi, Propaga accordi strofa, Propaga accordi ritornello, Copia solo testo |
| **Selezione** | Seleziona tutto |
| **Aspetto** | **Mostra le icone nel menu contestuale** (✓) |

---

### Scheda *Associazioni file*

Associa le estensioni a Songpress++ **solo per l'utente corrente**.

- Checkbox per: `.crd`, `.cho`, `.chordpro`, `.chopro`, `.pro`, `.tab`, `.sng`
- Pulsanti **Associa tutte** / **Rimuovi tutte** e **Applica ora**

> **Su Linux** i controlli sono disabilitati: con il pacchetto `.deb` le associazioni MIME sono gestite dal sistema (`/usr/share/mime`) e non vengono modificate dall'applicazione. Su Windows la scrittura avviene in `HKEY_CURRENT_USER`. Su altri sistemi la scheda mostra un avviso di non disponibilità.

---

### Scheda *Toolbar*

Contiene quattro sotto-schede — **Standard**, **Formato**, **Inserisci**, **Visualizza** — con una checkbox per ogni icona della relativa barra e, in alto sopra le sotto-schede, i pulsanti **Seleziona tutto** / **Deseleziona tutto** (agiscono solo sulla sotto-scheda aperta). Dettagli e comportamento dei separatori nel capitolo *Personalizzazione delle toolbar*.

---

## Personalizzazione delle toolbar

Songpress++ consente di mostrare o nascondere singole icone in ciascuna delle quattro barre degli strumenti: **Standard**, **Formattazione**, **Inserisci** e **Visualizza**.

### Come accedere alle impostazioni

Aprire **Strumenti → Opzioni…** e selezionare la scheda **Toolbar**. La scheda contiene quattro sotto-schede, una per barra:

| Sotto-scheda    | Barra corrispondente | Icone configurabili |
|-----------------|----------------------|---------------------|
| Standard        | Barra standard       | Nuovo, Apri, Salva, Anteprima di stampa, Stampa, Annulla, Ripeti, Taglia, Copia, Copia come immagine, Incolla, Incolla accordi, Verifica sintassi, Opzioni… |
| Formattazione   | Barra di formattazione | Font, Mostra/nascondi accordi, Interlinea |
| Inserisci       | Barra di inserimento | Tutte le icone di inserimento (titolo, accordi, strofe, metadati musicali, immagini, simboli, ecc.). Il ritornello ha un'unica icona, *Ritornello…*, che apre la stessa finestra della voce di menu |
| Visualizza      | Barra di visualizzazione | Mostra Pagina Songpress++, Mostra etichette strofe e ritornelli |

### Come mostrare o nascondere un'icona

1. Nella sotto-scheda corrispondente, **spuntare** la casella per mostrare l'icona, **deselezionarla** per nasconderla.
2. I pulsanti **Seleziona tutto** e **Deseleziona tutto**, in alto sopra le sotto-schede, agiscono solo sulla sotto-scheda aperta.
3. Fare clic su **OK**: la toolbar viene aggiornata immediatamente.

Le impostazioni vengono salvate nel file di configurazione dell'applicazione e ripristinate ad ogni avvio.

> **Nota:** nascondere un'icona dalla toolbar non rimuove il comando corrispondente. Tutti i comandi rimangono sempre accessibili dal menu e tramite le scorciatoie da tastiera.

### Comportamento dei separatori

I separatori visivi tra gruppi di icone vengono gestiti automaticamente: se tutte le icone di un gruppo vengono nascoste, il separatore tra quel gruppo e il successivo scompare, evitando separatori orfani nella toolbar.

### Note per sviluppatori

La lista completa delle icone configurabili è definita nelle costanti di classe `MAIN_TOOLBAR_ITEMS`, `FORMAT_TOOLBAR_ITEMS`, `INSERT_TOOLBAR_ITEMS` e `VIEW_TOOLBAR_ITEMS` nel mixin `SongpressToolbarsMixin` (`SongpressToolbars.py`). Ogni voce ha la forma `(xrc_name, label, pref_key)`.

Quando si aggiunge un nuovo comando a una toolbar, è sufficiente:

1. Aggiungere la voce alla costante `*_TOOLBAR_ITEMS` corrispondente.
2. Aggiungere il percorso icona in `_*_toolbar_icons` e il testo di aiuto in `_*_toolbar_helps` dentro il rispettivo metodo `_Build*ToolBar()`.

**`MyPreferencesDialog` e `SongpressFrame` non richiedono alcuna modifica**: entrambi leggono le costanti `*_TOOLBAR_ITEMS` in modo dinamico — il dialogo preferenze genera automaticamente i checkbox per ogni nuova voce, e il save/load del config itera sull'intera lista.

---

## Nomi dei file salvati

Nella scheda **Generale** di **Strumenti → Opzioni…** due caselle di controllo governano il nome proposto e usato quando si salva un brano. Sono **indipendenti** e possono essere attivate insieme: la prima decide *quale* nome viene proposto, la seconda *come* viene scritto.

| Opzione | Predefinito | Effetto |
|---|---|---|
| **Suggerisci il `{title:}` del brano come nome file in 'Salva con nome'** | disattiva | Il campo *Nome file* della finestra «Salva con nome» viene precompilato con il titolo del brano |
| **Sostituisci gli spazi con `_` nei nomi dei file salvati** | disattiva | Ogni spazio nel nome del file (non nel percorso della cartella) diventa un trattino basso |

### Suggerimento del nome dal titolo

Se l'opzione è attiva, Songpress++ legge la direttiva `{title:}` (o la forma abbreviata `{t:}`) e la propone come nome file, con l'estensione predefinita già applicata.

Regole di estrazione:

- viene usata la **prima** direttiva `{title:}` o `{t:}` valida del documento;
- le righe che iniziano con `#` sono commenti ChordPro e vengono **ignorate**, quindi un titolo commentato non viene proposto;
- gli eventuali accordi inline nel titolo vengono rimossi: `{title: [Do]Ave Maria}` → `Ave Maria`;
- se manca la `}` di chiusura, viene preso il resto della riga;
- i caratteri non ammessi nei nomi file (`< > : " / \ | ? *`) vengono eliminati, e i punti iniziali o finali vengono rimossi (per evitare file nascosti su Linux);
- se il titolo manca, è vuoto o non contiene caratteri validi, il campo torna al comportamento predefinito (nome del documento corrente, oppure vuoto per un brano nuovo).

Le altre direttive che iniziano per `t` — `{tempo:}`, `{time:}`, `{taste:}` — non vengono mai confuse con `{t:}`.

### Interazione tra le due opzioni

Le due opzioni si **compongono** senza conflitti. Con `{title: Ave Maria splendore del mattino}` ed estensione `crd`:

| Suggerisci titolo | Sostituisci spazi | Nome proposto |
|---|---|---|
| ✗ | ✗ | *(vuoto)* |
| ✓ | ✗ | `Ave del mattino.crd` |
| ✓ | ✓ | `Ave_del_mattino.crd` |
| ✗ | ✓ | *(vuoto, ma gli spazi digitati a mano diventano `_`)* |

Il nome resta comunque modificabile nella finestra di dialogo prima di confermare.

> **Nota — Windows e Linux** — Il comportamento è identico sui due sistemi. I caratteri illegali su Windows vengono rimossi anche su Linux, dove tecnicamente alcuni sarebbero ammessi: questo garantisce che i file restino portabili tra le due piattaforme.

> **Suggerimento — Diagnostica** — Se il nome non viene proposto nonostante l'opzione sia attiva, attivare **Mostra messaggi di debug** nella stessa scheda: Songpress++ segnalerà il motivo (opzione disattiva, direttiva `{title:}` assente, oppure titolo privo di caratteri validi).

---

## Preferenze di visualizzazione

I seguenti controlli si trovano nella scheda **Formattazione** delle preferenze e influenzano l'anteprima e la stampa.

| Campo                                  | Predefinito | Intervallo | Passo |
| -------------------------------------- | ----------- | ---------- | ----- |
| Spessore sottolineatura titolo         | 4           | 1–5        | 1     |
| Spessore bordo numero strofa           | 1           | 1–5        | 1     |

---

## Stampa e anteprima

- **Anteprima di stampa** — mostra l'anteprima con i pulsanti «Opzioni di stampa», «Impostazione pagina» e «Impostazioni driver»
- **Stampa** — se la preferenza **Mostra anteprima di stampa prima di stampare** (scheda *Generale* delle opzioni) è attiva, viene mostrata prima l'anteprima di stampa; se è disattivata, viene aperto il dialogo di stampa del sistema (selezione stampante, numero di copie, ecc.) e la stampa parte dopo la conferma
- **Impostazione pagina** — carta, orientamento e margini (in mm)

> **Gestione automatica della selezione** — l'anteprima di stampa rileva automaticamente se è attiva una selezione di testo nell'editor (`_print_scope = 'auto'`): se c'è una selezione, viene stampata solo quella; altrimenti viene stampato l'intero documento. Non è necessaria alcuna impostazione manuale.

### Preferenze di stampa (scheda *Pagina Songpress++*)

> **Nota — Ordinamento automatico** — Le checkbox di questo gruppo vengono ordinate alfabeticamente in base alla **lingua dell'interfaccia** attiva. L'ordine può quindi differire da quello mostrato in questa tabella.

| Preferenza | Predefinito | Descrizione |
| ---------- | ----------- | ----------- |
| Mostra anteprima di stampa prima di stampare | ✅ attivo | Se attivo, il comando **Stampa** apre prima l'anteprima; se disattivato, apre direttamente il dialogo di stampa del sistema |
| Aggiornamento in tempo reale dello stato fronte/retro e colore nell'anteprima (ogni 1,5 s) | ✅ attivo | Se attivo, la barra di stato dell'anteprima interroga il driver ogni 1,5 secondi e aggiorna gli indicatori duplex, colore e orientamento in tempo reale, anche mentre il pannello del driver è aperto; se disattivato, la lettura avviene una sola volta all'apertura |
| Mantieni sempre in primo piano la finestra di anteprima di stampa | ☐ disattivo | Se attivo, la finestra di anteprima rimane sopra a tutte le altre finestre (`wx.STAY_ON_TOP`); se disattivato, si comporta come una finestra normale |

### Opzioni di stampa

| Opzione                                              | Descrizione                                                              |
| ---------------------------------------------------- | ------------------------------------------------------------------------ |
| Pagine per foglio (1 / 2)                            | Seleziona quante pagine logiche stampare su un foglio fisico             |
| Colonne per pagina (1 / 2)                           | Distribuisce il testo su una o due colonne                               |
| Riduci se eccede la pagina                           | Riduce il contenuto solo se eccede la pagina (senza ingrandimento)       |
| Comprimi per adattare alla pagina corrente           | Riduce ulteriormente per evitare che il contenuto venga tagliato in basso|
| Non replicare (lascia metà destra vuota)             | Con 2 pagine/foglio: lascia la seconda metà vuota invece di copiare     |
| Rimuovi pagine vuote                                 | Rimuove le pagine logiche quasi vuote dall'output di stampa              |
| Soglia pagina vuota (%)                              | Percentuale massima di pagina occupata sotto cui la pagina viene rimossa |
| Scala (%)                                            | Ingrandisce o riduce l'intero contenuto stampato (50–200%, predefinito 100%) |
| Scrivi log del layout di pagina (Diagnostica)        | Scrive un file di log con i parametri di impaginazione (vedi *Diagnostica di stampa*); predefinito disattivo |
| Apri cartella (Diagnostica)                          | Apre la cartella che contiene il file di log; accanto è mostrato il percorso completo |
| 📌 Pin                                                | Mantiene aperto il dialogo dopo OK, applicando subito le modifiche all'anteprima |

#### Diagnostica di stampa

In fondo al dialogo **Opzioni di stampa** c'è la sezione **Diagnostica**, utile per capire perché un brano viene impaginato in un certo modo (o per segnalare un problema):

- **Scrivi log del layout di pagina** — se attiva, a ogni anteprima/stampa viene scritto il file `songpress_print_debug.log`. Registra i parametri di impaginazione (riduzione attiva, impaginazione per blocchi, colonne, due pagine per foglio, pagine per foglio, scala verticale, offset, area di ritaglio), i **salti di blocco** e le **regioni di ritaglio** di ogni pagina. Predefinito: disattivo.
- **Apri cartella** — apre la cartella del log. Il percorso completo del file è mostrato in grigio accanto al pulsante.
- Il file si trova nella cartella temporanea del sistema: `%TEMP%` su Windows, `/tmp` (o `$TMPDIR`) su Linux e macOS.

Il log serve solo per la diagnostica: lasciarlo disattivato non influisce sulla stampa.

La direttiva `{new_page}` nel testo forza una nuova pagina logica durante la stampa. Con il layout a 2 colonne, `{column_break}` forza il salto alla colonna successiva.

### Persistenza delle opzioni di stampa

Tutte le impostazioni del dialogo **Opzioni di stampa** e della finestra **Imposta pagina** vengono **salvate automaticamente** e ripristinate al successivo avvio di Songpress++. Il salvataggio avviene in due momenti:

- **Alla conferma con OK** nel dialogo *Opzioni di stampa* (salvataggio immediato, così le impostazioni non vanno perse in caso di chiusura anomala del programma).
- **Alla chiusura del programma**, insieme alle altre preferenze.

Il ripristino avviene **all'apertura del programma**, prima che la stampa o l'anteprima siano disponibili.

I valori sono memorizzati nella sezione `/PageSetup` della configurazione utente (file `~/.Songpress++/Songpress++.ini` su Linux, registro di sistema su Windows).

| Parametro salvato        | Chiave di configurazione | Valore predefinito |
| ------------------------ | ------------------------ | ------------------ |
| Margine superiore (mm)   | `margin_top`             | 15                 |
| Margine inferiore (mm)   | `margin_bottom`          | 15                 |
| Margine sinistro (mm)    | `margin_left`            | 15                 |
| Margine destro (mm)      | `margin_right`           | 15                 |
| Formato carta            | `paper_id`               | A4                 |
| Orientamento             | `orientation`            | Verticale          |
| Pagine per foglio        | `two_pages_per_sheet`    | 1 pagina           |
| Colonne per pagina       | `columns_per_page`       | 1 colonna          |
| Riduci se eccede la pagina | `fit_to_page`          | disattivo          |
| Comprimi per adattare alla pagina corrente | `shrink_to_fit` | disattivo   |
| Margine minimo per compressione automatica (mm) | `min_margin_shrink` | 5   |
| Non replicare (metà destra vuota) | `no_mirror_right` | disattivo         |
| Rimuovi pagine vuote     | `remove_blank_pages`     | disattivo          |
| Soglia pagina vuota (%)  | `blank_page_threshold`   | 5                  |
| Stato del pulsante 📌 Pin | `print_options_pinned`   | disattivo          |
| Scrivi log del layout    | `print_debug`            | disattivo          |

> **Eccezione — Scala (%)** — Il valore del campo **Scala** non viene **mai** salvato. Resta attivo per tutta la sessione di lavoro (utile per regolarlo con il dialogo «pinnato» osservando l'anteprima in tempo reale), ma a ogni riavvio di Songpress++ torna sempre a **100%**. Questo evita di ritrovarsi con stampe ingrandite o ridotte senza accorgersene, dopo aver usato la scala per un singolo brano. Anche eventuali valori residui salvati da versioni precedenti vengono rimossi dalla configurazione.

> **Nota** — I valori letti dalla configurazione vengono validati: se una chiave è assente, illeggibile o fuori intervallo (ad esempio colonne diverse da 1 o 2, o soglia pagina vuota fuori dall'intervallo 1–95), viene usato il valore predefinito senza segnalazioni di errore.

### Impostazioni di stampa e spiegazioni

![Songpress++ Impostazioni di pagina](./img/GUIDE/ImpostaPagina_it.png)
![Songpress++ Opzioni di stampa](./img/GUIDE/OpzioniDiStampa_it.png)

**Cosa significa «Margine minimo per compressione automatica (mm)»?**

È un parametro di controllo per la funzione Comprimi per adattare, che si attiva quando l'opzione **«Comprimi per adattare alla pagina corrente (evita taglio in basso)»** è spuntata.

Come funziona la logica: Songpress++ misura per ciascun segmento del brano (separati da `{new_page}`) quanto contenuto sfora oltre il bordo inferiore dell'ultima pagina che occupa, e tenta di recuperare esattamente quello spazio in due passi:

**Primo passo** — riduce i margini superiore e inferiore, distribuendo la riduzione in proporzione alla riducibilità di ciascuno (non necessariamente 50/50: se un margine è già vicino al minimo, viene ridotto meno dell'altro). La riduzione si ferma non appena lo sforamento è recuperato, oppure quando entrambi i margini hanno raggiunto il valore minimo configurato da questo SpinCtrl. Se il margine impostato dall'utente è, ad esempio, 20 mm, può essere compresso automaticamente fino a 5 mm (predefinito). Questo impedisce alla riduzione automatica di azzerare completamente i margini.

**Secondo passo** — scala il contenuto (rimpicciolisce testo/accordi), solo se la riduzione dei margini da sola non è stata sufficiente. Il fattore di scala viene calcolato separatamente per ogni segmento e viene applicato il più restrittivo, garantendo che nessun segmento venga tagliato.

In pratica: il valore (predefinito 5 mm) rappresenta il limite inferiore al di sotto del quale i margini non scendono mai durante la riduzione automatica. Maggiore è il valore, meno aggressiva è la compressione dei margini (e prima inizia la scalatura del testo). Il controllo è disabilitato quando la checkbox Riduci se eccede la pagina è disattivata, e si riabilita automaticamente quando viene attivata.

**Cosa significa «Soglia pagina vuota (%)»?**

È il parametro di controllo per la funzione **«Rimuovi pagine vuote»**, che si attiva quando la relativa checkbox è spuntata.

In stampa può accadere che l'ultimo elemento di una canzone (ad esempio la tastiera degli accordi) sfori di pochissimo oltre il limite della pagina, generando un foglio fisico aggiuntivo quasi completamente bianco. La funzione «Rimuovi pagine vuote» intercetta questo caso ed elimina automaticamente quella pagina residua.

La soglia (predefinita **5%**) rappresenta la percentuale massima di altezza pagina che il contenuto residuo può occupare perché la pagina venga considerata «vuota» e rimossa. Se il contenuto sfora di una quantità inferiore o uguale a questa soglia, la pagina viene soppressa; se sfora di più, la pagina viene mantenuta perché considerata effettivamente necessaria.

Esempi pratici:

- **5%** (predefinito) — rimuove la pagina solo se lo sforamento è minimo (pochi pixel, tipicamente la tastiera DO o un simbolo finale).
- **20%** — rimuove la pagina anche se il contenuto residuo occupa fino a un quinto della pagina.
- **50%** — rimuove la pagina se è meno di metà piena (uso sconsigliato: rischia di tagliare contenuto visibile).

Il controllo è disabilitato quando la checkbox «Rimuovi pagine vuote» è disattivata, e si riabilita automaticamente quando viene attivata.

### Pulsante «Impostazioni driver» nell'anteprima

La toolbar dell'anteprima include il pulsante **Impostazioni driver…** che apre il pannello nativo del driver di stampa (`DocumentProperties` su Windows). Da questo pannello si possono modificare tutte le impostazioni del driver: orientamento, fronte/retro, colore, numero di copie, formato carta e qualsiasi opzione specifica del modello (es. qualità di stampa, vassoio carta).

#### Come funziona internamente

L'apertura del pannello segue tre percorsi in cascata:

**Tentativo 1 — pywin32 (percorso preferito su Windows)**

Usa i binding `win32print` e `pywintypes` inclusi nella dipendenza `pywin32`:

1. Prima chiamata a `DocumentProperties(hwnd, hprinter, nome, None, None, 0)` → ottiene la dimensione totale del DEVMODE specifico del driver.
2. Alloca un `pywintypes.DEVMODEType(driver_extra)` con la dimensione corretta (dimensione fissa + `dmDriverExtra`).
3. Seconda chiamata con `DM_OUT_BUFFER` → legge le impostazioni correnti nel buffer allocato.
4. Terza chiamata con `DM_IN_BUFFER | DM_OUT_BUFFER | DM_IN_PROMPT` → **mostra il pannello nativo del driver** e attende la conferma dell'utente.

**Tentativo 2 — ctypes puro su `winspool.drv` (fallback, nessuna dipendenza esterna)**

Se `pywin32` non è disponibile o genera un errore, viene usata la stessa logica tramite `ctypes.WinDLL('winspool.drv')`, chiamando `DocumentPropertiesW` direttamente con buffer `ctypes.create_string_buffer`. I campi del DEVMODE risultante (orientamento, formato carta, copie, colore, duplex) vengono letti tramite offset fissi nella struttura `DEVMODEW`.

**Tentativo 3 — Finestra Imposta pagina (non-Windows o entrambi i tentativi falliti)**

Su piattaforme diverse da Windows, o se entrambi i tentativi precedenti falliscono, viene aperta la finestra standard **Imposta pagina** (`wx.PageSetupDialog`), dove si possono modificare orientamento, formato carta e margini. Le modifiche confermate con OK vengono applicate all'anteprima.

#### Propagazione delle modifiche

Quando l'utente conferma con OK, Songpress++ propaga automaticamente in `wx.PrintData` i campi che wx espone (orientamento, duplex, colore, copie, formato carta) e aggiorna la barra di stato dell'anteprima. Se l'orientamento è cambiato, l'anteprima viene ricaricata automaticamente per mostrare il foglio nel verso corretto.

> **Nota** — Il pulsante **Impostazioni driver…** è disponibile solo nell'anteprima di stampa, non nel menu principale.

### Rilevamento automatico della stampante nell'anteprima

La barra di stato dell'anteprima di stampa mostra quattro indicatori che leggono le impostazioni **reali** della stampante selezionata, non solo quelle impostate da wx:

| Indicatore | Valori possibili |
| ---------- | ---------------- |
| **Fronte/retro** | `Fronte/retro: disattivato (solo fronte)` · `ATTIVO — rilegatura lato lungo` · `ATTIVO — rilegatura lato corto` |
| **Colore** | `Colore: stampa a colori` · `Colore: bianco e nero` |
| **Ambito di stampa** | `Stampa tutto il documento` (verde) · `Stampa solo la selezione` (ambra) |
| **Orientamento** | Icona foglio verticale (ritratto) o orizzontale (landscape) |

**Come funziona il rilevamento (Windows)**

Su Windows il rilevamento del colore usa tre fonti in cascata, ognuna attivata solo se la precedente non ha prodotto un risultato; il duplex usa solo la fonte 1. Su macOS e Linux viene usato il valore restituito da `wx.PrintData`.

| Fonte | API | Quando viene usata |
| ----- | --- | ------------------ |
| **1 — DEVMODE** | `win32print.GetPrinter` livello 2 | Sempre per prima: riflette la scelta dell'utente nel pannello del driver |
| **2 — Capability hardware** | `win32print.GetPrinterCaps(DC_COLORDEVICE)` | Solo se `dmColor` è assente: indica se la stampante è fisicamente capace di colore |
| **3 — Fallback wx** | `wx.PrintData.GetColour()` | Solo se entrambe le fonti precedenti falliscono |

| Campo | Valori |
| ----- | ------ |
| `DEVMODE.dmDuplex` | `1` = solo fronte · `2` = fronte/retro lato lungo · `3` = fronte/retro lato corto |
| `DEVMODE.dmColor` | `1` = bianco e nero (`DMCOLOR_MONOCHROME`) · `2` = colore (`DMCOLOR_COLOR`) |
| `DC_COLORDEVICE` | `0` = hardware solo B/N (certezza assoluta) · `1` = hardware capace di colore |

**Affidabilità per tipo di stampante**

| Situazione | Fronte/retro rilevato? | Colore rilevato? |
| ---------- | ---------------------- | ---------------- |
| Stampante locale con driver nativo (es. Brother, HP, Canon) | ✅ sì | ✅ sì |
| Stampante di rete con driver nativo installato | ✅ sì | ✅ sì |
| Stampante PDF (Microsoft Print to PDF, PDFCreator) | ⚠️ dipende | ⚠️ dipende |
| Stampante di rete via IPP senza driver nativo (solo porta TCP/IP generica) | ❌ spesso no | ❌ spesso no |
| Stampante B/N che non espone `dmColor` nel DEVMODE | ✅ sì | ✅ sì (via `DC_COLORDEVICE`) |
| macOS / Linux | ⚠️ solo valore wx | ⚠️ solo valore wx |

> **Nota** — Se `win32print` non è disponibile o si verifica un errore globale, entrambi gli indicatori cadono automaticamente sul valore fornito da `wx.PrintData`. La fonte `DC_COLORDEVICE` è isolata da un proprio `try/except`: se `GetPrinterCaps` non è supportato dal driver, si passa comunque al fallback wx senza interrompere il rilevamento.

---

## Esporta

| Formato              | Note                                         |
| -------------------- | -------------------------------------------- |
| SVG                  | Vettoriale, scalabile                        |
| EMF                  | Formato vettoriale Windows                   |
| PNG                  | Immagine raster                              |
| HTML                 | Pagina web con accordi colorati              |
| Tab                  | Formato testo con accordi sopra              |
| PDF                  | Documento PDF (chiede prima l'impostazione pagina, poi il nome file) |
| PowerPoint (.pptx)   | Presentazione                                |
| Crea Songbook PDF    | Raccolta PDF di canzoni con indice cliccabile |
| Crea Indice          | Indice PDF/DOCX a due colonne (numero e titolo) |
| Canzonatore          | Unisce più file ChordPro in un unico file    |
| Copia come immagine  | Copia negli appunti come immagine vettoriale |
| Copia solo testo     | Copia il testo senza accordi                 |

> **Nota — Esporta PDF:** il flusso di esportazione apre prima il dialogo **Impostazione pagina** (formato carta, orientamento, margini in mm); solo dopo la conferma viene chiesto il nome del file di output. I margini impostati vengono memorizzati e riutilizzati nelle successive esportazioni.

---

## Filigrana (watermark) 🖊

Il comando **Filigrana** (menu *File*) sovrappone al brano una scritta diagonale (per esempio *DRAFT*, *BOZZA*, *COPIA OMAGGIO*) disegnata **dietro** al testo, così non ne copre mai il contenuto. La filigrana viene applicata **sempre in stampa e in tutti i formati esportati** (PNG, SVG, EMF, EPS, PDF) e, se lo si desidera, anche nell'anteprima di Songpress++.

### Finestra di dialogo

| Campo | Predefinito | Descrizione |
| ----- | ----------- | ----------- |
| Abilita filigrana | ☐ disattivo | Attiva o disattiva la filigrana per il brano corrente. Con la casella deselezionata tutti gli altri campi sono disabilitati |
| Mostra nella Pagina Songpress++ | ✅ attivo | Se attivo, la filigrana compare anche nel pannello Pagina; stampa ed export la applicano comunque, indipendentemente da questa opzione |
| Testo | `DRAFT` | Testo della filigrana. Può contenere spazi e simboli; se vuoto, la filigrana non viene disegnata |
| Opacità (%) | 12 | Intensità della scritta, da 2 a 100. Valori **alti = più scuro**. La trasparenza è simulata fondendo il colore verso il bianco del foglio, così il risultato è identico su ogni formato (anche SVG ed EPS, che non supportano l'alpha) |
| Angolo (°) | 45 | Inclinazione della scritta, da −90 a +90 gradi |
| Dimensione (%) | 100 | Scala del carattere, da 20 a 300 |
| Colore | nero | Colore della filigrana (prima della fusione verso il bianco data dall'opacità) |
| Affianca (ripeti sulla pagina) | ☐ disattivo | Se disattivo, un'unica scritta centrata; se attivo, la scritta è ripetuta a mosaico su tutta la pagina |

### Dove vengono salvate le impostazioni

La configurazione della filigrana è **per-documento**: viene scritta all'inizio del file `.crd` come direttiva `{watermark: …}`, così ogni brano conserva la propria filigrana e la ritrova alla riapertura.

I **campi di stile** — opacità, angolo, dimensione, colore e mosaico — vengono inoltre memorizzati come **preferenze globali**: l'ultima combinazione usata diventa il valore predefinito per i brani nuovi (o privi di direttiva). I campi *Abilita*, *Testo* e *Mostra nell'anteprima* restano invece legati al singolo documento.

### Direttiva `{watermark:}`

La direttiva viene gestita automaticamente dal dialogo, ma può anche essere scritta o modificata a mano nell'editor: filigrana, anteprima e stato del dialogo si allineano da soli. Il campo `text=` è sempre **l'ultimo**, così può contenere `=` e `;` senza rompere il parsing; le graffe nel testo vengono neutralizzate.

```chordpro
{watermark: enabled=1; opacity=12; angle=45; sizePct=100; tile=0; showInPreview=1; colourHex=#000000; text=DRAFT}
```

| Chiave | Valori | Significato |
| ------ | ------ | ----------- |
| `enabled` | 0 / 1 | Filigrana attiva |
| `opacity` | 2–100 | Intensità (alto = più scuro) |
| `angle` | −90…90 | Inclinazione in gradi |
| `sizePct` | 20–300 | Scala del carattere in percentuale |
| `tile` | 0 / 1 | 0 = scritta unica centrata; 1 = mosaico ripetuto |
| `showInPreview` | 0 / 1 | Mostra la filigrana anche nell'anteprima |
| `colourHex` | `#RRGGBB` | Colore della scritta |
| `text` | testo libero | Testo della filigrana (sempre l'ultimo campo) |

---

## Crea Songbook PDF

La funzione **Crea Songbook PDF** (menu *File → Crea Songbook PDF…*) genera un documento PDF completo da tutti i brani ChordPro presenti in una cartella selezionata.

### Come si usa

1. Scegliere la **cartella dei brani** tramite il pulsante *Sfoglia…*
2. Indicare il **file PDF di output**
3. Compilare i campi facoltativi: **Titolo Songbook**, **Autore / Gruppo**, **Anno**
4. Selezionare le **estensioni** da includere (`.crd`, `.cho`, `.chordpro`, `.chopro`, `.pro`, `.tab`, `.sng`, `.txt`)
5. Scegliere se rendere le **voci dell'indice cliccabili**
6. Regolare le impostazioni di pagina e le opzioni di stampa
7. Premere **OK** per avviare la generazione

### Struttura del PDF generato

| Sezione   | Descrizione |
| --------- | ----------- |
| Copertina | Titolo, autore e anno su sfondo blu scuro con banda arancione |
| Brani     | Un brano per pagina (o più se il testo è lungo); i brani sono ordinati alfabeticamente per titolo estratto da `{t:}` o `{title:}`, con fallback al nome del file |
| Indice    | Elenco numerato di tutti i brani con puntini di connessione e numero di pagina |

### Opzioni

| Opzione | Descrizione |
| ------- | ----------- |
| Estensioni | Selezionare quali tipi di file includere nella raccolta |
| Voci indice cliccabili (link PDF) | Se attivo, ogni voce dell'indice è un link interno che porta direttamente alla pagina del brano nel PDF; il titolo appare in blu con sottolineatura |
| Pagine per foglio (1 / 2) | Affianca due brani sullo stesso foglio fisico |
| Imposta pagina | Formato carta, orientamento e margini |
| Opzioni di stampa | Modalità 2 pagine per foglio |

### Note

- Le immagini `{image: nomefile.png}` inserite nei brani vengono cercate **nella stessa cartella del file sorgente** e incluse automaticamente nel PDF.
- I brani sono sempre ordinati alfabeticamente, indipendentemente dall'ordine dei file nella cartella.
- Per includere file `.txt` (che di norma non contengono direttive ChordPro), spuntare l'apposita estensione nell'elenco.

---

## Crea Indice

La funzione **Crea Indice** (menu *File → Crea Indice PDF…*, oppure avviando `CreaIndice.py` come programma indipendente) genera un **indice a due colonne — numero del canto e titolo — ordinato per numero di canto**, a partire da tutti i file ChordPro presenti in una cartella. L'indice può essere prodotto in formato **PDF** o **DOCX**.

A differenza dell'indice interno del *Songbook PDF* (ordinato per titolo e legato a un singolo documento raccolta), *Crea Indice* produce un elenco autonomo, pensato come sommario numerico del canzoniere.

### Come si usa

1. Scegliere la **Cartella principale** con i brani; l'opzione **Includi anche le sottocartelle** estende la scansione alle cartelle annidate
2. Facoltativo: spuntare **Escludi i file con la direttiva «watermark»** per lasciare fuori i brani che contengono la direttiva `{watermark: …}` (copie bozza/timbrate). Una volta attiva, si può spuntare anche **Aggiungi in fondo all'indice una nota sui brani esclusi** (con l'icona info), che stampa in fondo all'indice un avviso sull'esclusione
3. Selezionare l'**estensione** dei file da includere tramite i pulsanti di scelta: `.cho`, `.chopro`, `.pro`, `.crd`, `.txt`, **Tutti i file** o **Altro…** (campo libero). Accanto a ogni voce compare il **numero di file** trovati con quell'estensione. All'apertura è già selezionato il pulsante corrispondente all'**Estensione dei file predefinita** impostata in *Opzioni → Generale*
4. Facoltativo: impostare una **filigrana di sfondo** (immagine) con opacità, angolo e dimensione, e scegliere se renderla **a colori** o in **bianco e nero**
5. Facoltativo: personalizzare il **Titolo indice** (predefinito «Indice»)
6. Facoltativo: spuntare **Scrivi nell'indice il numero dei brani** per aggiungere in fondo all'indice una riga con il totale dei brani
7. Lasciare attiva o disattivare la casella **Apri il PDF ora**
8. Premere **Genera PDF** o **Genera DOCX** e scegliere dove salvare il file

### Come vengono estratti numero e titolo

| Dato | Origine | In mancanza |
| ---- | ------- | ----------- |
| **Numero del canto** | Primo `{subtitle:}` / `{st:}` contenente `numero: N` (es. `{subtitle: Canto numero: 22}`); in alternativa, il primo numero intero presente in un sottotitolo | Il brano viene collocato **in fondo** all'elenco |
| **Titolo** | Prima direttiva `{title:}` / `{t:}` | Nome del file (senza estensione) |

L'ordinamento è per **numero crescente**; i brani senza numero sono elencati **dopo** quelli numerati, in ordine alfabetico di titolo.

### Opzioni

| Opzione | Predefinito | Descrizione |
| ------- | ----------- | ----------- |
| Cartella principale | ultima usata | Cartella dei brani da scansionare. **L'ultimo percorso usato viene ricordato** e riproposto al successivo avvio |
| Includi anche le sottocartelle | ✅ attivo | Scansiona anche le cartelle annidate |
| Escludi i file con la direttiva «watermark» | ☐ disattivo | Se attivo, i file che contengono la direttiva `{watermark: …}` (copie bozza/timbrate) vengono esclusi dall'indice e dai conteggi. Il conteggio dei file si aggiorna appena la casella viene spuntata. La scansione è veloce e i risultati vengono ricordati (vedi *Note*) |
| Aggiungi in fondo all'indice una nota sui brani esclusi | ☐ disattivo | Disponibile **solo quando «Escludi i file con la direttiva «watermark»» è attivo**: altrimenti la casella e la relativa icona info restano disabilitate. Se attiva, in fondo all'indice (sia PDF sia DOCX) viene aggiunta una riga con l'icona info e il testo «I brani con filigrana sono stati esclusi da questo indice.». La scelta viene **ricordata tra un avvio e l'altro** |
| Estensione file | da *Opzioni* | Tipo di file da includere. All'avvio è preselezionato il pulsante corrispondente all'**Estensione dei file predefinita** di *Opzioni → Generale* (se tale estensione non è tra quelle fisse, viene selezionato **Altro…** e il campo compilato automaticamente); **Tutti i file** salta automaticamente i binari (`.pdf`, `.docx`, `.svg`, `.emf` e le immagini `.png`, `.jpg`, `.jpeg`, `.webp`, `.gif`, `.bmp`, `.tif`, `.tiff`); **Altro…** abilita un campo per un'estensione personalizzata |
| Filigrana di sfondo | nessuna | Immagine (PNG, JPG/JPEG, WebP, GIF, BMP, TIFF) disegnata dietro al testo su ogni pagina, con **Opacità (%)**, **Angolo (°)** e **Dimensione (%)**. L'opzione **Rendering** permette di sceglierla **a colori** (predefinito) o in **bianco e nero** (l'immagine viene desaturata mantenendo la trasparenza). Questi controlli sono attivi **solo quando è selezionata un'immagine** (altrimenti restano disabilitati). Tutti questi valori vengono **ricordati tra un avvio e l'altro** |
| Titolo indice | `Indice` | Intestazione stampata in cima all'indice |
| Scrivi nell'indice il numero dei brani | ☐ disattivo | Se attivo, subito dopo la tabella (PDF e DOCX) viene aggiunta una riga in grassetto con il totale dei brani, es. «Totale brani nell'indice: 120». Compare prima dell'eventuale nota sui brani esclusi. La scelta viene **ricordata tra un avvio e l'altro** |
| Apri il PDF ora | ✅ attivo | Se attivo, al termine il file generato (PDF o DOCX) viene aperto con l'applicazione predefinita del sistema. La scelta viene ricordata tra un avvio e l'altro |

### Note

- L'ultima **Cartella principale** usata viene salvata e riproposta automaticamente al riavvio; se la cartella non esiste più, si riparte dalla cartella home.
- All'apertura, il pulsante dell'**estensione** riflette l'**Estensione dei file predefinita** impostata in *Opzioni → Generale* (letta dalle impostazioni di Songpress++); quando la finestra è avviata come programma autonomo si usa `crd` come ripiego.
- I valori della **filigrana** (Opacità, Angolo, Dimensione e la scelta Colori/Bianco e nero) vengono ricordati a ogni modifica e ripristinati alla riapertura della finestra.
- I controlli della **filigrana** (Opacità, Angolo, Dimensione e Rendering) sono disabilitati finché non si seleziona un'immagine, e si attivano automaticamente appena il campo **Immagine** contiene un percorso.
- La **nota sui brani esclusi** viene stampata solo se **entrambe** le caselle sono attive («Escludi i file con la direttiva «watermark»» e «Aggiungi in fondo all'indice una nota…»). Se si disattiva l'esclusione, la casella della nota si disabilita e la nota non viene stampata, ma la scelta fatta resta memorizzata e si riattiva insieme all'esclusione.
- **Avviso opacità filigrana.** Quando è selezionata un'immagine e l'**Opacità** supera il **50%**, sotto il controllo compare un avviso in rosso («Attenzione: con un'opacità superiore al 50% il testo potrebbe essere difficile da leggere.»). È solo un avviso: il valore non viene limitato.
- Tutti i controlli della finestra hanno un **tooltip** esplicativo.
- L'icona della nota viene letta da `img/info.png`, nella cartella che contiene `CreaIndice.py`; se il file manca, la nota viene stampata ugualmente, senza icona. Il testo della nota segue la lingua dell'interfaccia di Songpress++.
- **Velocità della scansione «watermark».** La ricerca della direttiva `{watermark}` è stata resa molto più rapida: i file vengono letti direttamente come byte (senza provare più codifiche di testo), controllati **in parallelo** quando sono più di 16 e l'esito di ciascun file viene **ricordato** finché il file non cambia (data o dimensione). Per questo riattivare la casella, cambiare estensione o generare l'indice non rileggono i file: solo la **prima** scansione di una cartella richiede più tempo, le successive sono quasi immediate.
- Il numero del canto viene cercato in **tutti** i sottotitoli del file: è sufficiente che uno di essi contenga `numero: N`.
- La generazione **PDF** richiede la libreria `reportlab`, quella **DOCX** richiede `python-docx`; la **filigrana** richiede `Pillow`. Se una libreria manca, il programma mostra un avviso con il comando `pip` per installarla.
- *Crea Indice* può essere usato anche come programma autonomo (`python3 CreaIndice.py [cartella]`), utile per generare rapidamente un sommario senza aprire Songpress++.

---

## Canzonatore — Unisci brani

La funzione **Canzonatore** (menu *File → Canzonatore (unisci brani)…*) unisce più file ChordPro in un unico file di testo, inserendo un separatore tra un brano e l'altro.

### Come si usa

1. Aprire il dialogo dal menu *File → Canzonatore (unisci brani)…*
2. Aggiungere i file tramite **Aggiungi file…** (selezione multipla) o **Aggiungi cartella…** (importa tutti i file supportati nella cartella in ordine alfabetico)
3. Riordinare i brani con i pulsanti **▲ Su** e **▼ Giù**
4. Scegliere il **separatore** tra i brani e la **codifica di output**
5. Premere **Unisci…**, scegliere dove salvare il file risultante e confermare

### Opzioni

| Opzione | Valori | Descrizione |
| ------- | ------ | ----------- |
| Separatore brani | `{new_page}` (predefinito) | Inserisce un'interruzione di pagina esplicita tra i brani |
| | Riga vuota | Separa i brani con una riga vuota |
| Codifica output | UTF-8 (predefinito) | Raccomandato per la massima compatibilità |
| | Latin-1 (ISO-8859-1) | Per compatibilità con software più datati |
| Apri file unito nell'editor | ✅ attivo per default | Apre automaticamente il file risultante nell'editor di Songpress++ al termine dell'unione |

### Estensioni supportate

`.crd` `.cho` `.chordpro` `.chopro` `.pro` `.tab` `.cpm`

### Doppio clic nella lista

Fare doppio clic (o premere Invio) su un file nell'elenco apre quel file nell'editor di Songpress++. Se nell'elenco è presente un file da rivedere prima di unire, non è necessario uscire dal dialogo.

### Dialogo di completamento

Al termine dell'unione appare un dialogo con:
- **Link al file** — clic apre il file con l'applicazione predefinita del sistema operativo
- **Link alla cartella** — clic apre il file manager sulla cartella contenente il file (con selezione del file su Windows e macOS)

### Note

- I file già presenti nell'elenco non vengono aggiunti una seconda volta (deduplicazione automatica).
- La codifica dei file sorgente viene rilevata automaticamente (UTF-8-BOM → UTF-8 → Latin-1).
- Se un file non può essere letto, viene saltato e segnalato nel dialogo di completamento; l'unione prosegue con gli altri file.

## Formati di importazione supportati

| Estensione  | Descrizione                           |
| ----------- | ------------------------------------- |
| `.crd`      | ChordPro (estensione principale)      |
| `.cho`      | ChordPro                              |
| `.chordpro` | ChordPro                              |
| `.chopro`   | ChordPro                              |
| `.pro`      | ChordPro                              |
| `.tab`      | Formato tab (accordi sopra il testo)  |

---

## Guida: Pannello Pagina — Songpress++

Il pannello **Pagina** (PreviewCanvas) mostra in tempo reale il rendering grafico della canzone ChordPro mentre si digita nell'editor. È ancorato come pannello AUI sul lato destro della finestra principale e può essere ridimensionato, nascosto o sganciato come qualsiasi altro pannello AUI.

---

## Struttura visiva

![Songpress++ Pannello Pagina](./img/GUIDE/AnteprimaSonpress++_it.png)

La barra degli strumenti compatta in alto raggruppa tutti i controlli; al di sotto si trova l'area scorrevole con il contenuto della canzone renderizzato.

---

## Barra degli strumenti della Pagina

### 📋 Copia negli appunti

Copia il rendering grafico della canzone negli **appunti di sistema** come immagine (metafile / bitmap), pronta per essere incollata in un documento Word, una presentazione o un'altra applicazione.

---

### Controlli zoom

| Elemento              | Funzione                                                       |
| --------------------- | -------------------------------------------------------------- |
| Pulsante **−**        | Riduce lo zoom del 10%                                         |
| **Slider** orizzontale| Trascina per impostare liberamente lo zoom tra 30% e 300%      |
| Pulsante **+**        | Aumenta lo zoom del 10%                                        |
| Etichetta **`xx%`**   | Mostra la percentuale corrente (sola lettura)                  |
| Pulsante **1:1**      | Reimposta lo zoom esattamente al 100%                          |

Tutti i controlli sono **sincronizzati bidirezionalmente**: usare la rotella del mouse, la tastiera o trascinare lo slider aggiorna sempre tutti gli altri elementi.

**Intervallo:** 30% – 300%, passo 10%.

---

### ⛶ Schermo intero

Apre l'anteprima in una **finestra a schermo intero dedicata** (`F11`).

La finestra a schermo intero condivide lo stesso renderer del pannello principale: il contenuto è sempre aggiornato. Ha una propria barra degli strumenti con slider zoom e pulsante *Adatta*. Si chiude con `Esc`, `F11` o il pulsante *Esci da schermo intero*.

> Il doppio clic per navigare alla riga corrispondente nell'editor è attivo anche nella finestra a schermo intero.

---

### Adatta (Adatta alla larghezza)

Calcola automaticamente lo zoom che fa corrispondere esattamente la larghezza della canzone alla larghezza disponibile del pannello, tenendo conto dei margini dinamici (3% per lato) e dell'eventuale barra di scorrimento verticale. Premere il pulsante più volte dà lo stesso risultato (operazione idempotente).

**Scorciatoia:** `Ctrl+Shift+G`

---

### Indicatore di pagina

L'etichetta in fondo alla barra degli strumenti (es. `Pagina 2 di 5`) mostra la pagina corrente in base alla posizione di scorrimento verticale. Si aggiorna ad ogni scorrimento. Può essere nascosta nelle preferenze.

Il conteggio delle pagine è calcolato in base al **formato carta corrente** (larghezza, altezza e margini) impostato in *File → Impostazione pagina*.

---

## Interazione con mouse e tastiera

### Zoom

| Gesto / tasto             | Effetto                                  |
| --------------------- --- | ---------------------------------------- |
| `Ctrl` + scorrimento su   | Zoom avanti (+10%)                       |
| `Ctrl` + scorrimento giù  | Zoom indietro (−10%)                     |
| `Ctrl++`                  | Zoom avanti (+10%)                       |
| `Ctrl+-`                  | Zoom indietro (−10%)                     |
| `Ctrl+0`                  | Reimposta zoom 100%                      |
| `Ctrl+Shift+G`            | Adatta alla larghezza                    |
| `F11`                     | Apre / chiude la finestra schermo intero |

### Scorrimento

| Tasto                          | Effetto                            |
| ------------------------------ | ---------------------------------- |
| Rotella del mouse (senza Ctrl) | Scorrimento verticale normale      |
| `Ctrl+PgDn`                    | Scorri una pagina in giù           |
| `Ctrl+PgUp`                    | Scorri una pagina in su            |

> La granularità dello scorrimento è **proporzionale allo zoom**: a zoom molto elevato lo scorrimento è più fine, così la navigazione rimane precisa.

### Doppio clic → Navigazione nell'editor

**Facendo doppio clic** su un punto dell'anteprima, Songpress++ identifica il token più vicino al clic (parola o accordo) e **sposta il cursore dell'editor** alla riga sorgente corrispondente.

Il meccanismo funziona in tre passi:

1. Le coordinate del clic vengono corrette per lo scorrimento e lo zoom e riportate alle coordinate del renderer.
2. Viene eseguito un **hit-test preciso** sull'albero dei box renderizzati (SongSong → SongBlock → SongLine → SongText), trovando il token più vicino per distanza euclidea.
3. Il testo del token viene cercato nel sorgente ChordPro usando una **strategia a cerchi concentrici** (±5 righe → ±20 righe → intero file), per gestire correttamente gli accordi ripetuti molte volte.

Questa funzione può essere disabilitata nelle preferenze.

---

## Layout e sfondo

![Songpress++ Preferenze Pagina](./img/GUIDE/AnteprimaSonpress++Preferenze_it.png)

### Sfondo della pagina

L'area di anteprima simula un **foglio bianco su sfondo grigio**: il renderer disegna il contenuto come su carta, con le stesse dimensioni e margini del formato carta corrente. Lo sfondo grigio può essere cambiato in bianco puro nelle preferenze.

### Margine orizzontale dinamico

Il margine sinistro e destro del contenuto è calcolato come **3% della larghezza del pannello** (minimo 8 px). Questo fa sì che l'anteprima si adatti automaticamente quando il pannello viene ridimensionato.

### Colonne

Se il testo sorgente contiene la direttiva `{column_break}` (o `{colb}`), il renderer passa automaticamente a un **layout a due colonne**. Non è richiesta alcuna azione manuale.

---

## Debounce del refresh

Per evitare ridisegni continui durante la digitazione rapida, il refresh dell'anteprima è governato da un **timer debounce di 300 ms**:

- Ogni modifica del testo avvia (o riavvia) il timer.
- Il ridisegno avviene solo **quando la digitazione si ferma** per almeno 300 ms.
- Se si preferisce un feedback immediato ad ogni tasto premuto, il debounce può essere disabilitato nelle preferenze.

---

## Dimensione minima del pannello

Per impostazione predefinita il pannello Pagina ha una dimensione minima di **370 × 520 px**: trascinare il divisore AUI al di sotto di questa soglia non è possibile, né all'avvio né durante la sessione. La soglia può essere rimossa nelle preferenze per chi lavora su monitor piccoli o vuole massimizzare lo spazio dell'editor.

---

## Opzioni Pagina

Le opzioni si trovano in **Strumenti → Opzioni... → scheda Pagina Songpress++**.
Tutte le modifiche vengono applicate **immediatamente** al pannello aperto, senza necessità di riavvio.

> **Nota — Ordinamento automatico** — Le checkbox di questo gruppo (come quelle dei gruppi *Stampa* e *Nessun accordo: blocchi da nascondere*) vengono ordinate alfabeticamente in base alla **lingua dell'interfaccia** attiva. L'ordine può quindi differire da quello mostrato in questa tabella.

| Opzione                                        | Predefinito | Descrizione                                                                                        |
| ---------------------------------------------- | :---------: | -------------------------------------------------------------------------------------------------- |
| **Mostra indicatore pagina**                   | ✓           | Mostra/nasconde l'etichetta «Pagina X di Y» nella barra degli strumenti                            |
| **Sfondo grigio**                              | ✓           | Sfondo grigio con «foglio bianco» simulato; se deselezionato, sfondo bianco puro                   |
| **Debounce refresh**                           | ✓           | Ritarda il ridisegno di 300 ms dopo l'ultimo tasto premuto; deselezionare per feedback immediato   |
| **Doppio clic porta il focus all'editor**      | ✓           | Abilita la navigazione nell'editor con doppio clic nell'anteprima                                  |
| **Dimensione minima pannello**                 | ✓           | Impone la dimensione minima di 370 × 520 px sul pannello AUI                                       |

> **Nota su *Dimensione minima pannello*:** questa preferenza agisce sia sul `wx.Window` sottostante sia sul riquadro AUI tramite `_ApplyPreviewMinSize()`. La modifica è quindi efficace immediatamente, senza riavvio.

---

## Nessun accordo: blocchi da nascondere

Quando lo slider **Mostra accordi** (barra degli strumenti Formato) è impostato su **Nessuno**, l'anteprima e la stampa omettono tutti gli accordi inline `[…]`. Con questa impostazione attiva è possibile nascondere anche i blocchi di struttura che contengono solo accordi e che diventerebbero privi di significato senza di essi.

Le opzioni si trovano in **Strumenti → Opzioni... → scheda Pagina Songpress++ → Nessun accordo: blocchi da nascondere**.

> **Nota — Ordinamento automatico** — Le checkbox di questo gruppo vengono ordinate alfabeticamente in base alla **lingua dell'interfaccia** attiva. L'ordine può quindi differire da quello mostrato in questa tabella.

| Opzione | Predefinito | Descrizione |
| ------- | :---------: | ----------- |
| **Accordi di intro `{start_chord}`\`{end_chord}`** | ☐ | Nasconde l'intero blocco intro accordi (compreso il suo contenuto) quando gli accordi sono disabilitati |
| **Bridge `{start_bridge}`\`{end_bridge}`** | ☐ | Nasconde i blocchi bridge quando gli accordi sono disabilitati (copre anche le forme `{start_of_bridge}`/`{sob}`) |
| **Griglia `{start_of_grid}`\`{end_of_grid}`** | ☐ | Nasconde i blocchi griglia accordi quando gli accordi sono disabilitati (copre anche le forme `{sog}`, `{grid}`) |
| **Tempo `{tempo_m}`\`{tempo_s}`\`{tempo_sp}`\`{tempo_c}`\`{tempo_cp}`\`{tempo_label}`** | ☐ | Nasconde tutte le direttive di indicazione del tempo quando gli accordi sono disabilitati |
| **Indicazione di tempo `{time}`** | ☐ | Nasconde le direttive `{time:…}` (indicazione metrica, es. `4/4`) quando gli accordi sono disabilitati |

> **Nota:** le checkbox agiscono **esclusivamente** quando lo slider Mostra accordi è su *Nessuno* (valore 0). Con le altre modalità (*Solo prima strofa*, *Intera canzone*) i blocchi vengono sempre visualizzati normalmente, indipendentemente da queste impostazioni.

> **Nota:** il filtro agisce sul testo passato al renderer prima del ridisegno. Il documento sorgente nell'editor non viene mai modificato.

> **Nota tecnica:** `{start_chord}`, `{start_bridge}`, `{start_of_grid}` sono **blocchi paired** (apertura + contenuto + chiusura): l'intera sezione viene soppressa. `{tempo_m}`, `{tempo_s}`, `{tempo_sp}`, `{tempo_c}`, `{tempo_cp}`, `{tempo_label}` e `{time}` sono invece **direttive singole**: viene rimossa soltanto la riga che le contiene.

### Compatibilità di `{new_song}` con i filtri accordi

| Modalità slider *Mostra accordi* | Valore interno | Compatibile con `{new_song}`? | Note |
| -------------------------------- | :------------: | :---------------------------: | ---- |
| **Nessuno** | `0` | ✅ | `_strip_nochords_blocks()` non tocca `{new_song}`; il brano successivo viene filtrato correttamente |
| **Solo prima strofa** *(una strofa per ogni schema di accordi)* | `1` | ✅ | `{new_song}` azzera anche `chordPatterns`: gli schemi del brano precedente non inquinano il confronto sul brano successivo |
| **Intera canzone** | `2` | ✅ | Nessun filtraggio attivo; `{new_song}` si limita ad azzerare i contatori di strofe/ritornelli |

> **Dettaglio tecnico (modalità 1):** prima della correzione, `chordPatterns` non veniva resettato al `{new_song}`. Il renderer confrontava le strofe del secondo brano con gli schemi accordi del primo tramite `minEditDist`, rimuovendo erroneamente gli accordi da strofe che avrebbero dovuto mostrarli. La correzione aggiunge `self.chordPatterns = []` contestualmente agli altri azzeramenti in `Renderer.py`.

---

## Scorciatoie — Riepilogo

| Scorciatoia             | Funzione                                      |
| ----------------------- | --------------------------------------------- |
| `Ctrl++`                | Zoom avanti                                   |
| `Ctrl+-`                | Zoom indietro                                 |
| `Ctrl+0`                | Zoom 100%                                     |
| `Ctrl+Shift+G`          | Adatta larghezza al pannello                  |
| `F11`                   | Apre / chiude la finestra schermo intero      |
| `Ctrl+Rotella`          | Zoom con la rotella del mouse                 |
| `Ctrl+PgDn`/`Ctrl+PgUp` | Scorri una pagina                             |
| Doppio clic             | Naviga alla riga sorgente nell'editor         |
| `Esc` (schermo intero)  | Chiudi la finestra schermo intero             |

---

## Guida: Trova / Sostituisci — Songpress++

![Songpress++ Opzioni di stampa](./img/GUIDE/Trova-Sostituisci_it.png)

La finestra **Trova / Sostituisci** (`Ctrl+H` o menu *Modifica*) è organizzata in due schede affiancate da una colonna verticale di pulsanti. Le opzioni sono **sincronizzate** tra le due schede: spuntare una checkbox nella scheda *Trova* aggiorna automaticamente la scheda *Sostituisci*, e viceversa.

![Songpress++ Opzioni di stampa](./img/GUIDE/Trova-Sostituisci2_it.png)

---

## Struttura della finestra

| Area                   | Contenuto                                                                           |
| ---------------------- | ----------------------------------------------------------------------------------- |
| Scheda **Trova**       | Campo di ricerca, opzioni, direzione                                                |
| Scheda **Sostituisci** | Due campi (Trova / Sostituisci con), stesse opzioni + *Avvolgi silenziosamente*     |
| Colonna destra         | Pulsanti di azione                                                                  |
| Etichetta inferiore    | Contatore o messaggi di risultato (es. «3 corrispondenze trovate»)                  |

---

## Pulsanti

| Pulsante                 | Funzione                                                                                                                                                        |
| ---------------------    | --------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| **Trova successivo**     | Trova la corrispondenza successiva (o precedente, a seconda della direzione). Premere `Enter` nel campo di testo equivale a fare clic su questo pulsante.       |
| **Sostituisci**          | Se il testo attualmente selezionato corrisponde al termine di ricerca, lo sostituisce e avanza alla corrispondenza successiva.                                  |
| **Sostituisci tutto**    | Sostituisce tutte le occorrenze nel documento in un'unica operazione **annullabile** con `Ctrl+Z`. Mostra il numero di sostituzioni effettuate al termine.      |
| **Conta corrispondenze** | Conta tutte le occorrenze e mostra il numero nell'etichetta sotto la scheda, senza spostare il cursore.                                                         |
| **Chiudi**               | Chiude la finestra di dialogo (o `Esc`).                                                                                                                        |

> **Nota:** i pulsanti *Sostituisci* e *Sostituisci tutto* sono visibili solo quando la scheda **Sostituisci** è attiva.

---

## Opzioni (Checkbox)

### ☐ Solo parole intere

Limita la ricerca alle occorrenze in cui il termine è delimitato da **caratteri non alfanumerici** (spazi, punteggiatura, inizio/fine riga).

| Ricerca                              | Testo       | Trovato?                                 |
| ------------------------------------ | ----------- | ---------------------------------------- |
| `sol` — ✗ Solo parole intere         | `dissolve`  | **Sì** (`dis`**`sol`**`ve`)              |
| `sol` — ✓ Solo parole intere         | `dissolve`  | **No**                                   |
| `sol` — ✓ Solo parole intere         | `[Sol]`     | **Sì** (`[` `]` sono delimitatori)       |
| `sol` — ✓ Solo parole intere         | `sol mi fa` | **Sì**                                   |

**Uso tipico in Songpress++:** trovare l'accordo `[La]` senza colpire `[LaM]` o `[La7]` — ma per questo caso è più efficace usare le espressioni regolari (vedi sotto).

> ⚠️ *Solo parole intere* è **incompatibile** con le Espressioni regolari: se entrambe sono attive, la ricerca usa solo il flag regex e ignora il confine di parola automatico. Per combinare i due comportamenti, incorporare `\b` nel pattern (es. `\bsol\b`).

---

### ☐ Maiuscole/minuscole

Per impostazione predefinita la ricerca è **senza distinzione di maiuscole/minuscole**: `Alleluia`, `alleluia` e `ALLELUIA` sono equivalenti.

Abilitando questa opzione la corrispondenza diventa **esatta**:

| Ricerca                   | Testo      | Trovato?   |
| ------------------------- | ---------- | ---------- |
| `Alleluia` — ✗ Maiuscole  | `alleluia` | **Sì**     |
| `Alleluia` — ✓ Maiuscole  | `alleluia` | **No**     |
| `Alleluia` — ✓ Maiuscole  | `Alleluia` | **Sì**     |

**Uso tipico:** correggere le maiuscole uniformi di un titolo o un accordo scritto in modo non coerente (`Re` vs `re`).

---

### ☐ Espressioni regolari

Attiva il motore **regex** integrato in Scintilla (compatibile con POSIX esteso / ECMA). Il campo *Trova* diventa un **pattern** e il campo *Sostituisci con* può usare **riferimenti ai gruppi**.

Quando questa opzione è attiva, il testo viene interpretato letteralmente solo per i caratteri normali; i metacaratteri hanno significato speciale.

---

## Espressioni regolari — Guida ed esempi

### Metacaratteri fondamentali

---

### Esempi pratici in contesto ChordPro

#### 1 — Trovare un accordo specifico (senza colpire le varianti)

**Problema:** cercare `[Re]` senza trovare `[Rem]`, `[Re7]`, `[Re/Fa#]` ecc.

```text
Pattern:  \[Re\]
```

I `[` e `]` devono essere **escaped** perché sono metacaratteri (delimitatori di classe di caratteri).

---

#### 2 — Trovare qualsiasi accordo maggiore: Do, Re, Mi…

```text
Pattern:  \[(Do|Re|Mi|Fa|Sol|La|Si)\]
```

Trova `[Do]`, `[Re]`, `[Mi]` ecc. ma **non** `[Dom]`, `[Re7]`.

---

#### 3 — Trovare qualsiasi accordo (apertura + contenuto + chiusura)

```text
Pattern:  \[[^\]]+\]
```

Si legge: `\[` — parentesi quadra aperta letterale; `[^\]]+` — uno o più caratteri che **non** sono `]`; `\]` — parentesi quadra chiusa letterale.

Trova tutti gli accordi nel documento; utile con *Conta corrispondenze* per contare quanti accordi ci sono.

---

#### 4 — Rinominare un accordo mantenendo le varianti (sostituzione con gruppo)

**Problema:** la canzone usa `Sib` ma voglio `Bb`. Devo trasformare `[Sib]`, `[Sibm]`, `[Sib7]`, `[Sibm7]` ecc. tutti in una volta.

```text
Trova:      \[Sib([^\]]*)\]
Sostituisci: [Bb\1]
```

- `([^\]]*)` cattura tutto ciò che segue `Sib` fino a `]` (es. `m`, `7`, `m7`, vuoto).
- `\1` nel campo *Sostituisci* reinserisce il suffisso catturato.

| Prima     | Dopo     |
| --------- | -------- |
| `[Sib]`   | `[Bb]`   |
| `[Sibm]`  | `[Bbm]`  |
| `[Sib7]`  | `[Bb7]`  |
| `[Sibm7]` | `[Bbm7]` |

---

#### 5 — Rimuovere spazi doppi (o multipli) in una riga di testo

```text
Trova:      [ ]{2,}
Sostituisci: (campo vuoto)
```

`[ ]{2,}` significa «almeno 2 spazi consecutivi». In alternativa: `<spazio><spazio>+` (uno spazio seguito da `+`).

---

### 6 — Aggiungere un'etichetta a tutte le righe di commento

Le righe di commento ChordPro iniziano con `#`. Per racchiuderle in `{comment: …}`:

```chordpro
Trova:      ^#(.+)$
Sostituisci: {comment: \1}
```

- `^` — inizio riga
- `#` — il carattere cancelletto letterale
- `(.+)` — cattura il resto della riga (gruppo 1)
- `$` — fine riga
- `\1` — reinserisce il contenuto catturato

---

#### 7 — Trovare strofe vuote (righe completamente vuote)

```text
Pattern:  ^$
```

Trova ogni riga che non contiene nulla. Utile per contare o rimuovere righe vuote extra. Con *Sostituisci tutto* e un campo di sostituzione vuoto, tutte le righe vuote vengono eliminate (attenzione: operazione invasiva).

---

#### 8 — Trovare titoli scritti in MAIUSCOLO

```text
Pattern:  ^[A-Z][A-Z ]+$
```

Trova righe composte solo da lettere maiuscole (e spazi), lunghezza ≥ 2. Utile per identificare titoli in caps-lock da normalizzare.

---

### Note sul comportamento di Scintilla

- Il motore regex è quello di **Scintilla (simile a POSIX)**: supporta `()`, `[]`, `\b`, `\d`, `\w`, `\s`, `{n,m}`, ma **non** lookahead `(?=…)` o lookbehind `(?<=…)`.
- Nei pattern i **backslash devono essere singoli** (`\[`, `\d`), non raddoppiati come in Python.
- I riferimenti ai gruppi nel campo *Sostituisci* si scrivono `\1`, `\2` (non `$1`).
- Il flag *Maiuscole/minuscole* si combina liberamente con regex.

---

## Opzione esclusiva della scheda Sostituisci

### ☐ Avvolgi silenziosamente

Quando la ricerca raggiunge la fine del documento (o l'inizio, se la direzione è *Su*), normalmente appare una finestra di dialogo che chiede conferma prima di tornare all'inizio.

Abilitando questa opzione l'**avvolgimento avviene automaticamente e silenziosamente**, senza interrompere il flusso di lavoro.

---

## Direzione: Su / Giù

Controlla se *Trova successivo* cerca **verso il basso** (dopo il cursore) o **verso l'alto** (prima del cursore). La direzione predefinita è **Giù**.

Non ha effetto su *Sostituisci tutto* e *Conta corrispondenze*, che operano sempre sull'intero documento.

---

## Cronologia delle ricerche

I campi *Trova* e *Sostituisci con* sono **ComboBox** che memorizzano fino a **10** ricerche recenti. Fare clic sulla freccia del campo (o premere `Alt+↓`) apre l'elenco della cronologia.

---

## Scorciatoie da tastiera

| Tasto                              | Azione                          |
| ---------------------------------- | ------------------------------- |
| `Enter` nel campo Trova            | Trova successivo                |
| `Enter` nel campo Sostituisci con  | Esegui Sostituisci              |
| `Esc`                              | Chiudi finestra di dialogo      |
| `Ctrl+Z` (nell'editor)             | Annulla un *Sostituisci tutto*  |

---

## Barra di stato

La **barra di stato** si trova nella parte inferiore della finestra di Songpress++ e mostra in tempo reale informazioni sullo stato dell'editor e della tastiera.

### Campo sinistro — Messaggi

Il campo più largo, a sinistra, visualizza messaggi temporanei dell'applicazione (ad esempio avvisi su operazioni completate o istruzioni per comandi speciali). Il messaggio scompare automaticamente dopo alcuni secondi.

### Campo centrale — Indicatori editor

Il secondo campo mostra gli indicatori relativi alle modalità attive nell'editor:

| Indicatore | Significato |
| ---------- | ----------- |
| **● Intellisense** | L'autocompletamento è attivo. Digitando `{` seguito da alcune lettere e premendo <kbd>Ctrl</kbd>+<kbd>Spazio</kbd> si apre il menu delle direttive ChordPro. |
| **● Multicursor** | La modalità multicursore è attiva. È possibile posizionare più cursori simultanei nel testo. |

Gli indicatori appaiono solo quando la modalità corrispondente è abilitata nelle preferenze. Entrambi possono essere attivati o disattivati dal menu *Modifica → Preferenze*.

### Campo destro — Tasti di blocco

Il terzo campo, all'estrema destra, visualizza in modo permanente lo stato dei **tasti di blocco della tastiera**, in stile Debian/GNOME:

| Badge | Tasto | Comportamento |
| ----- | ----- | ------------- |
| **CAPS** | <kbd>Caps Lock</kbd> | **Attivo** (sfondo grigio, testo scuro): le lettere vengono digitate in maiuscolo. **Non attivo**: il badge non è visualizzato. |
| **NUM** | <kbd>Num Lock</kbd> | **Attivo**: il tastierino numerico produce cifre. **Non attivo**: il badge non è visualizzato. |
| **SCR** | <kbd>Scroll Lock</kbd> | **Attivo**: lo Scroll Lock è inserito. **Non attivo**: il badge non è visualizzato. |

> **Tooltip** — Passando il puntatore del mouse su un badge appare un tooltip che indica esplicitamente lo stato corrente del tasto (es. *Caps Lock: attivo* / *Caps Lock: non attivo*).

#### Differenze tra Windows e Linux

Il comportamento dei tre badge **non è identico sulle due piattaforme**, perché dipende da come il sistema operativo espone lo stato dei tasti di blocco.

| Badge | Windows | Linux (X11 / Wayland) |
| ----- | ------- | --------------------- |
| **CAPS** | Riflette lo stato del *lock*: resta acceso finché Caps Lock è inserito. | Identico a Windows: Caps Lock è un modificatore reale (`Lock`), quindi lo stato viene letto correttamente. |
| **NUM** | Riflette lo stato del *lock*: resta acceso finché Num Lock è inserito. | Identico a Windows: Num Lock è un modificatore reale (`Mod2`). |
| **SCR** | Riflette lo stato del *lock*: resta acceso finché Scroll Lock è inserito. | ⚠️ **Appare solo mentre il tasto è fisicamente premuto e scompare non appena viene rilasciato.** |

> **Nota — SCR su Linux** — Nei layout di tastiera moderni (XKB) `Scroll_Lock` non è più mappato a un modificatore né a un LED di sistema: non esiste quindi uno stato «inserito/disinserito» che l'applicazione possa interrogare. La funzione di libreria usata da Songpress++ restituisce in questo caso soltanto lo stato *istantaneo* del tasto (premuto/rilasciato). Il risultato è che su Linux il badge **SCR** lampeggia — compare mentre si tiene premuto <kbd>Scroll Lock</kbd> e sparisce al rilascio — invece di restare acceso. **Non è un difetto di Songpress++**: è una limitazione dell'ambiente grafico. Gli indicatori **CAPS** e **NUM** funzionano invece in modo identico su Windows e su Linux.

---

## Verifica dipendenze

**Aiuto › Verifica dipendenze…** apre una finestra diagnostica che elenca i pacchetti Python richiesti da Songpress++, il loro stato di installazione e la versione rilevata. In cima compare un riepilogo complessivo: **✅ Tutte le dipendenze richieste sono installate correttamente** oppure **❌ Una o più dipendenze richieste risultano mancanti**. Il riepilogo tiene conto delle sole dipendenze *obbligatorie*: se manca esclusivamente una dipendenza *opzionale*, il riepilogo resta verde.

### Pacchetti controllati

| Pacchetto       | Ruolo                                   | Tipo                       |
| --------------- | --------------------------------------- | -------------------------- |
| **wxPython**    | Interfaccia grafica                     | Obbligatoria               |
| **requests**    | Richieste di rete                       | Obbligatoria               |
| **python-pptx** | Esportazione PowerPoint                 | Obbligatoria               |
| **pyshortcuts** | Creazione dei collegamenti sul desktop  | Obbligatoria               |
| **reportlab**   | Generazione dei PDF                     | Obbligatoria               |
| **pypdf**       | Manipolazione dei PDF                    | Obbligatoria               |
| **markdown**    | Rendering del Markdown                  | Obbligatoria               |
| **mistune**     | Rendering del Markdown                  | Obbligatoria               |
| **Pillow**      | Rendering dei glifi musicali            | Opzionale                  |
| **PyEnchant**   | Correttore ortografico                  | Opzionale                  |
| **pywin32**     | Funzioni specifiche di Windows          | Opzionale (solo Windows)   |

### Autotest dei font musicali

Sotto l'elenco dei pacchetti, la finestra esegue due verifiche sui font necessari alla resa dei simboli musicali:

- **FreeSerif → SMP** — verifica end-to-end che il file **FreeSerif.ttf** incluso nel programma sappia rasterizzare un glifo musicale del piano SMP (ad es. U+1D13D), percorrendo esattamente lo stesso percorso usato in stampa. Se questa riga è ✅, i simboli musicali verranno stampati correttamente. Il test riguarda il file *incluso* in Songpress++ e non dipende dai font installati nel sistema; richiede però **Pillow**.
- **NotoMusic → SMP** — verifica la disponibilità del font **NotoMusic** per mostrare i simboli SMP *nell'editor*. È rilevante solo su **Linux**: lì l'editor (GTK) visualizza i glifi del blocco U+1D100–U+1D1FF soltanto se è presente un font che li copre. Fuori da Linux i font di sistema coprono già questi simboli nel controllo di testo, quindi la riga non è un requisito: viene mostrata come **–** (N/D) con la nota *«Non richiesto su questo sistema»*. Il font viene cercato prima tra quelli inclusi nel programma, poi tra i font di sistema; su **Linux** i font installati vengono individuati tramite **fontconfig** (`fc-list`/`fc-match`), che usa una cache ed evita la scansione ricorsiva delle cartelle font.

In fondo alla finestra sono indicate le versioni di **Python** e **wxPython** attualmente in uso.

> **Voci specifiche del sistema** — Le dipendenze che non si applicano al sistema in uso non compaiono come mancanti (❌) ma come **–** (non applicabile): ad esempio **pywin32** è **–** su Linux e macOS (serve solo su Windows) e la riga **NotoMusic → SMP** è **–** fuori da Linux.

> **Icone di stato** — Lo stile delle icone ✅/❌ della colonna *Stato* può essere scelto nella scheda *Generale* della finestra **Opzioni** (glifi nativi oppure immagini). Se le immagini non sono disponibili, la finestra ripiega automaticamente sui glifi.

> **Aggiornamento del controllo** — Per aprirsi rapidamente, la finestra rileva i pacchetti senza caricarli e memorizza l'esito per la sessione corrente. Di conseguenza, se installi una dipendenza mancante mentre Songpress++ è in esecuzione, per vederne aggiornato lo stato riapri la finestra dopo aver **riavviato** il programma.

---

## Licenza e crediti

**Songpress++** è un'opera derivata di **Songpress**, originariamente sviluppato da Luca Allulli / [Skeed](https://www.skeed.it/songpress) — copyright © 2009–2026 Luca Allulli (Skeed).

Le modifiche presenti in Songpress++ sono copyright © Denisov21.

Songpress++ è distribuito secondo i termini della **GNU General Public License versione 2** (GPL v2), la stessa licenza del progetto originale. Il programma è software libero: è possibile ridistribuirlo e/o modificarlo secondo i termini della GPL v2 come pubblicata dalla Free Software Foundation. Il programma è distribuito nella speranza che sia utile, ma **senza alcuna garanzia**, nemmeno la garanzia implicita di commerciabilità o idoneità a uno scopo particolare.

Il testo completo della licenza è disponibile su: <https://www.gnu.org/licenses/old-licenses/gpl-2.0.html>

## Componenti di terze parti

Songpress (e di conseguenza Songpress++) utilizza i seguenti componenti software di terze parti:

| Componente                              | Licenza                                                          | Riferimento                                    |
| --------------------------------------- | ---------------------------------------------------------------- | ---------------------------------------------- |
| Python e libreria standard Python       | Python Software Foundation License                               | <https://www.python.org>                       |
| wxPython                                | wxWindows Library Licence                                        | <https://wxpython.org>                         |
| uv (solo installatore Windows)          | MIT License — copyright © 2025 Astral Software Inc.              | <https://github.com/astral-sh/uv>              |
| INetC (plugin NSIS, solo installatore)  | zlib/libpng License — copyright © 2004–2015 Takhir Bedertdinov   | <https://nsis.sourceforge.io/Inetc_plug-in>    |
