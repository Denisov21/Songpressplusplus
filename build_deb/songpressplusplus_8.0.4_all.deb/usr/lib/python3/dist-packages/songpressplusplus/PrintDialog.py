##############################################################
# Name:         PrintDialog.py
# Purpose:      Tutto il codice di stampa di Songpress++:
#               - SongpressPrintout  (wx.Printout)
#               - PrintManager       (mixin con stato e metodi di stampa)
#               - PrintOptionsDialog (dialog opzioni di stampa ottimizzato)
# Author:       Denisov21
# Created:      2026
# Copyright:    Denisov21 © 2026
#               Basato su Songpress di Luca Allulli (https://www.skeed.it/songpress)
# License:      GNU GPL v2
##############################################################
#
# USO IN SongpressFrame.py
# ────────────────────────
# 1. Aggiungere in cima al file:
#
#       from .PrintDialog import SongpressPrintout, PrintManager
#
# 2. Rimuovere da SongpressFrame.py:
#    • La classe SongpressPrintout   (righe 694-1149)
#    • Il dict  _PAPER_SIZE_MM       (righe 7243-7253)
#    • I metodi _GetPaperSizeMm      (7255-7262)
#    •          OnPageSetup          (7264-7283)
#    •          _reopen_print_options_if_pinned (7286-7316)
#    •          _ask_two_pages_per_sheet        (7318-7491)
#    •          OnPrint              (7493-7525)
#    •          OnPrintPreview       (7527-7758)
#
# 3. Aggiungere PrintManager come base aggiuntiva di SongpressFrame:
#
#       class SongpressFrame(SDIMainFrame, PrintManager):
#           def __init__(self, res):
#               PrintManager.__init__(self)
#               ...
#
##############################################################

import math
import os

import wx

from .Globals import glb
from .Renderer import Renderer, SongDecorator

_ = wx.GetTranslation

# ── Diagnostica layout di stampa ──────────────────────────────────────────────
# Attivabile dalla casella «Scrivi log impaginazione» in «Opzioni di stampa»
# (salvata in configurazione). Scrive come viene impaginato il brano in
# <cartella temporanea>/songpress_print_debug.log: %TEMP% su Windows, /tmp
# (o $TMPDIR) su Linux e macOS. Utile se un'interruzione di pagina non cade
# dove ci si aspetta.
PRINT_DEBUG = False


def _debug_log_path():
    """Percorso del log di impaginazione (cartella temporanea del sistema)."""
    import tempfile
    return os.path.join(tempfile.gettempdir(), 'songpress_print_debug.log')


def _dbg(msg):
    if not PRINT_DEBUG:
        return
    try:
        with open(_debug_log_path(), 'a', encoding='utf-8') as f:
            f.write(msg + '\n')
    except Exception:
        pass


def _open_debug_log_folder():
    """Apre nel file manager la cartella del log (Windows, Linux, macOS).

    Se il file esiste su Windows/macOS viene anche evidenziato; altrimenti si
    apre solo la cartella. Restituisce True se l'apertura è stata avviata."""
    import subprocess
    path   = _debug_log_path()
    folder = os.path.dirname(path)
    try:
        if wx.Platform == '__WXMSW__':
            if os.path.isfile(path):
                subprocess.Popen(['explorer', '/select,', os.path.normpath(path)])
            else:
                os.startfile(folder)
            return True
        if wx.Platform == '__WXMAC__':
            subprocess.Popen(['open', '-R', path] if os.path.isfile(path)
                             else ['open', folder])
            return True
        subprocess.Popen(['xdg-open', folder])
        return True
    except Exception:
        pass
    try:
        return bool(wx.LaunchDefaultApplication(folder))
    except Exception:
        return False


# ── Rilevamento duplex dal driver di sistema ───────────────────────────────────

def _get_duplex_mode(print_data):
    """
    Restituisce la modalità duplex reale della stampante selezionata.

    Strategia (Windows):
      1. Prova win32print per leggere il DEVMODE del driver nativo → fonte più
         affidabile, riflette le impostazioni del pannello del driver (es. Brother).
      2. Fallback: wx.PrintData.GetDuplex() → utile se wx ha impostato il duplex
         esplicitamente (es. dall'utente tramite PrintDialog di wx).

    Su macOS / Linux restituisce direttamente il valore wx.

    Valori restituiti (costanti wx):
      wx.DUPLEX_SIMPLEX     – stampa su un solo lato
      wx.DUPLEX_HORIZONTAL  – fronte/retro, rilegatura lato corto
      wx.DUPLEX_VERTICAL    – fronte/retro, rilegatura lato lungo
    """
    # ── Tentativo win32print (solo Windows) ───────────────────────────────
    if wx.Platform == '__WXMSW__':
        try:
            import win32print

            # Nome stampante: preferisce quello in print_data, altrimenti default
            printer_name = print_data.GetPrinterName().strip()
            if not printer_name:
                printer_name = win32print.GetDefaultPrinter()

            # Apre la stampante in sola lettura
            hprinter = win32print.OpenPrinter(printer_name)
            try:
                # Livello 2 → struttura PRINTER_INFO_2 con DEVMODE
                info = win32print.GetPrinter(hprinter, 2)
            finally:
                win32print.ClosePrinter(hprinter)

            devmode = info.get('pDevMode')
            if devmode is not None:
                # dmDuplex: 1 = simplex, 2 = vertical (long-edge), 3 = horizontal (short-edge)
                dm_duplex = getattr(devmode, 'Duplex', 1)
                if dm_duplex == 2:
                    return wx.DUPLEX_VERTICAL       # rilegatura lato lungo  (caso più comune)
                elif dm_duplex == 3:
                    return wx.DUPLEX_HORIZONTAL     # rilegatura lato corto
                else:
                    return wx.DUPLEX_SIMPLEX
        except Exception:
            pass  # win32print non disponibile o errore → fallback sotto

    # ── Fallback: valore wx.PrintData ─────────────────────────────────────
    return print_data.GetDuplex()


def _get_color_mode(print_data):
    """
    Restituisce la modalità colore reale della stampante selezionata.

    Strategia (Windows):
      1. Prova win32print per leggere il DEVMODE del driver nativo → fonte più
         affidabile, riflette le impostazioni del pannello del driver (es. Brother).
      2. Fallback: wx.PrintData.GetColour() → True se colore, False se B/N.

    Su macOS / Linux restituisce direttamente il valore wx.

    Valori restituiti:
      "color"   – stampa a colori
      "mono"    – stampa in bianco e nero / scala di grigi
      "unknown" – impossibile determinare la modalità
    """
    # ── Tentativo win32print (solo Windows) ───────────────────────────────
    if wx.Platform == '__WXMSW__':
        try:
            import win32print

            printer_name = print_data.GetPrinterName().strip()
            if not printer_name:
                printer_name = win32print.GetDefaultPrinter()

            hprinter = win32print.OpenPrinter(printer_name)
            try:
                info = win32print.GetPrinter(hprinter, 2)
            finally:
                win32print.ClosePrinter(hprinter)

            devmode = info.get('pDevMode')
            if devmode is not None:
                # dmColor: 1 = DMCOLOR_MONOCHROME, 2 = DMCOLOR_COLOR
                dm_color = getattr(devmode, 'Color', None)
                if dm_color == 2:
                    return "color"
                elif dm_color == 1:
                    return "mono"
                # dm_color None o valore imprevisto → fallback wx sotto
        except Exception:
            pass

    # ── Fallback: wx.PrintData.GetColour() ────────────────────────────────
    try:
        return "color" if print_data.GetColour() else "mono"
    except Exception:
        return "unknown"


def _get_orientation(print_data):
    """
    Restituisce l'orientamento reale della stampante selezionata.

    Strategia (Windows):
      1. Prova win32print per leggere dmOrientation dal DEVMODE del driver.
      2. Fallback: wx.PrintData.GetOrientation().

    Su macOS / Linux restituisce direttamente il valore wx.

    Valori restituiti (costanti wx):
      wx.PORTRAIT   – orientamento verticale
      wx.LANDSCAPE  – orientamento orizzontale
    """
    if wx.Platform == '__WXMSW__':
        try:
            import win32print

            printer_name = print_data.GetPrinterName().strip()
            if not printer_name:
                printer_name = win32print.GetDefaultPrinter()

            hprinter = win32print.OpenPrinter(printer_name)
            try:
                info = win32print.GetPrinter(hprinter, 2)
            finally:
                win32print.ClosePrinter(hprinter)

            devmode = info.get('pDevMode')
            if devmode is not None:
                # dmOrientation: 1 = PORTRAIT, 2 = LANDSCAPE
                orient = getattr(devmode, 'Orientation', None)
                if orient == 2:
                    return wx.LANDSCAPE
                elif orient == 1:
                    return wx.PORTRAIT
        except Exception:
            pass

    return print_data.GetOrientation()


def _make_orientation_bitmap(landscape: bool, field_h: int) -> wx.Bitmap:
    """
    Disegna e restituisce un wx.Bitmap che raffigura un foglio A4 stilizzato.

    Portrait:  rettangolo verticale  (proporzione ~√2)
    Landscape: rettangolo orizzontale (stesse dimensioni, ruotato 90°)

    Il bitmap viene disegnato su sfondo trasparente tramite wx.GraphicsContext
    in modo da adattarsi a qualsiasi colore della status bar.

    Parametri
    ----------
    landscape : bool
        True → foglio orizzontale, False → foglio verticale.
    field_h : int
        Altezza in pixel del campo della status bar; l'icona viene
        dimensionata per occuparne circa il 75 %.
    """
    # ── dimensioni icona ──────────────────────────────────────────────────
    icon_h = max(10, int(field_h * 0.75))
    # proporzione A4 ≈ 1 : √2  →  corto = icon_h / √2
    short = max(6, int(icon_h / 1.4142))

    if landscape:
        bmp_w, bmp_h = icon_h, short          # larghezza > altezza
        rect_w, rect_h = icon_h - 2, short - 2
    else:
        bmp_w, bmp_h = short, icon_h          # altezza > larghezza
        rect_w, rect_h = short - 2, icon_h - 2

    bmp = wx.Bitmap(bmp_w, bmp_h, 32)

    # ── disegno tramite GraphicsContext (anti-alias + trasparenza) ────────
    mdc = wx.MemoryDC(bmp)
    gc  = wx.GraphicsContext.Create(mdc)

    # sfondo trasparente
    gc.SetBrush(wx.TRANSPARENT_BRUSH)
    gc.SetPen(wx.TRANSPARENT_PEN)
    gc.DrawRectangle(0, 0, bmp_w, bmp_h)

    # colori
    if landscape:
        fill   = wx.Colour(180, 210, 255)   # azzurro chiaro
        border = wx.Colour( 20, 100, 180)   # blu
    else:
        fill   = wx.Colour(220, 220, 220)   # grigio chiaro
        border = wx.Colour( 80,  80,  80)   # grigio scuro

    gc.SetBrush(wx.Brush(fill))
    gc.SetPen(wx.Pen(border, 1))
    gc.DrawRectangle(1, 1, rect_w, rect_h)

    # angolo ripiegato (dog-ear) in alto a destra — proporzione ~20 % del lato corto
    ear = max(3, int(min(rect_w, rect_h) * 0.22))
    x0  = 1 + rect_w - ear          # x inizio taglio
    y0  = 1                          # y in cima

    # ridisegna solo il corpo del foglio senza l'angolo
    gc.SetBrush(wx.Brush(fill))
    gc.SetPen(wx.Pen(border, 1))
    path = gc.CreatePath()
    path.MoveToPoint(1,            y0)
    path.AddLineToPoint(x0,        y0)
    path.AddLineToPoint(x0 + ear,  y0 + ear)
    path.AddLineToPoint(x0 + ear,  y0 + rect_h)
    path.AddLineToPoint(1,         y0 + rect_h)
    path.CloseSubpath()
    gc.DrawPath(path)

    # triangolino dell'angolo ripiegato (colore leggermente più scuro)
    fold_colour = wx.Colour(
        max(0, fill.Red()   - 40),
        max(0, fill.Green() - 40),
        max(0, fill.Blue()  - 40),
    )
    gc.SetBrush(wx.Brush(fold_colour))
    gc.SetPen(wx.Pen(border, 1))
    fold = gc.CreatePath()
    fold.MoveToPoint(x0,       y0)
    fold.AddLineToPoint(x0 + ear, y0 + ear)
    fold.AddLineToPoint(x0,       y0 + ear)
    fold.CloseSubpath()
    gc.DrawPath(fold)

    mdc.SelectObject(wx.NullBitmap)
    return bmp


def _open_driver_settings(print_data, parent_hwnd=None):
    """
    Apre il pannello impostazioni del driver di stampa (DocumentProperties).

    Su Windows prova in ordine:
      1. win32print (pywin32) — usa DEVMODEType allocato correttamente
      2. ctypes puro su winspool.drv — sempre disponibile su Windows
    Su altre piattaforme (o se entrambi falliscono) mostra wx.PageSetupDialog.

    Restituisce il wx.PrintData aggiornato (o quello originale se annullato).
    """

    def _apply_devmode_to_printdata(dm, pd):
        """Copia i campi rilevanti dal DEVMODE (pywin32 object) in wx.PrintData."""
        orient = getattr(dm, 'Orientation', None)
        if orient == 2:
            pd.SetOrientation(wx.LANDSCAPE)
        elif orient == 1:
            pd.SetOrientation(wx.PORTRAIT)

        duplex = getattr(dm, 'Duplex', None)
        if duplex == 2:
            pd.SetDuplex(wx.DUPLEX_VERTICAL)
        elif duplex == 3:
            pd.SetDuplex(wx.DUPLEX_HORIZONTAL)
        elif duplex == 1:
            pd.SetDuplex(wx.DUPLEX_SIMPLEX)

        color = getattr(dm, 'Color', None)
        if color == 2:
            pd.SetColour(True)
        elif color == 1:
            pd.SetColour(False)

        copies = getattr(dm, 'Copies', None)
        if copies is not None and copies > 0:
            pd.SetNoCopies(copies)

        paper = getattr(dm, 'PaperSize', None)
        if paper is not None and paper > 0:
            try:
                pd.SetPaperId(paper)
            except Exception:
                pass

    if wx.Platform == '__WXMSW__':

        # ── Tentativo 1: pywin32 (win32print + pywintypes.DEVMODEType) ─────
        try:
            import win32print
            import win32con
            import pywintypes

            printer_name = print_data.GetPrinterName().strip()
            if not printer_name:
                printer_name = win32print.GetDefaultPrinter()

            hprinter = win32print.OpenPrinter(printer_name)
            try:
                # Prima chiamata: ottieni la dimensione totale del DEVMODE
                # (None, None, 0 → sola query della dimensione)
                dm_size = win32print.DocumentProperties(
                    parent_hwnd or 0, hprinter, printer_name, None, None, 0
                )
                if dm_size <= 0:
                    raise RuntimeError(f"DocumentProperties size query: {dm_size}")

                # Calcola dmDriverExtra = dimensione totale − dimensione fissa
                dm_fixed = pywintypes.DEVMODEType().Size
                driver_extra = max(0, dm_size - dm_fixed)

                # Alloca un DEVMODE con la driverExtra corretta e leggi
                # le impostazioni correnti dal driver (DM_OUT_BUFFER)
                dm = pywintypes.DEVMODEType(driver_extra)
                win32print.DocumentProperties(
                    parent_hwnd or 0, hprinter, printer_name,
                    dm, dm, win32con.DM_OUT_BUFFER
                )

                # Mostra il pannello del driver con DM_IN_PROMPT
                result = win32print.DocumentProperties(
                    parent_hwnd or 0, hprinter, printer_name,
                    dm, dm,
                    win32con.DM_IN_BUFFER | win32con.DM_OUT_BUFFER | win32con.DM_IN_PROMPT,
                )

                # IDOK = 1
                if result == 1:
                    _apply_devmode_to_printdata(dm, print_data)

            finally:
                win32print.ClosePrinter(hprinter)

            return print_data

        except Exception:
            pass  # win32print non disponibile o errore → tentativo 2

        # ── Tentativo 2: ctypes puro su winspool.drv ───────────────────────
        try:
            import ctypes
            import ctypes.wintypes as wt

            DM_IN_BUFFER  = 8
            DM_OUT_BUFFER = 2
            DM_IN_PROMPT  = 4

            # Offset nella struttura DEVMODEW (Unicode, Windows ≥ 2000)
            _OFF_ORIENTATION = 44
            _OFF_PAPERSIZE   = 46
            _OFF_COPIES      = 78
            _OFF_COLOR       = 96
            _OFF_DUPLEX      = 100

            def _short(buf, off):
                return ctypes.c_short.from_buffer_copy(buf[off:off + 2]).value

            winspool = ctypes.WinDLL('winspool.drv', use_last_error=True)

            printer_name = print_data.GetPrinterName().strip()
            if not printer_name:
                buf_size = wt.DWORD(0)
                winspool.GetDefaultPrinterW(None, ctypes.byref(buf_size))
                buf = ctypes.create_unicode_buffer(buf_size.value)
                winspool.GetDefaultPrinterW(buf, ctypes.byref(buf_size))
                printer_name = buf.value

            if not printer_name:
                raise RuntimeError("Nessuna stampante predefinita trovata")

            hprinter = wt.HANDLE()
            if not winspool.OpenPrinterW(printer_name, ctypes.byref(hprinter), None):
                raise ctypes.WinError(ctypes.get_last_error())

            try:
                # Query dimensione
                dm_size = winspool.DocumentPropertiesW(
                    parent_hwnd or 0, hprinter, printer_name, None, None, 0
                )
                if dm_size <= 0:
                    raise RuntimeError(f"DocumentProperties size query: {dm_size}")

                # Leggi impostazioni correnti
                dm_buf = ctypes.create_string_buffer(dm_size)
                ret = winspool.DocumentPropertiesW(
                    parent_hwnd or 0, hprinter, printer_name,
                    dm_buf, None, DM_OUT_BUFFER
                )
                if ret != 1:
                    raise RuntimeError(f"DocumentProperties DM_OUT_BUFFER: {ret}")

                # Mostra dialogo driver
                dm_out = ctypes.create_string_buffer(dm_size)
                ret = winspool.DocumentPropertiesW(
                    parent_hwnd or 0, hprinter, printer_name,
                    dm_out, dm_buf,
                    DM_IN_BUFFER | DM_OUT_BUFFER | DM_IN_PROMPT,
                )

                if ret == 1:
                    orient  = _short(dm_out, _OFF_ORIENTATION)
                    paper   = _short(dm_out, _OFF_PAPERSIZE)
                    copies  = _short(dm_out, _OFF_COPIES)
                    color   = _short(dm_out, _OFF_COLOR)
                    duplex  = _short(dm_out, _OFF_DUPLEX)

                    if orient == 2:
                        print_data.SetOrientation(wx.LANDSCAPE)
                    elif orient == 1:
                        print_data.SetOrientation(wx.PORTRAIT)
                    if paper > 0:
                        try:
                            print_data.SetPaperId(paper)
                        except Exception:
                            pass
                    if copies > 0:
                        print_data.SetNoCopies(copies)
                    if color == 2:
                        print_data.SetColour(True)
                    elif color == 1:
                        print_data.SetColour(False)
                    if duplex == 2:
                        print_data.SetDuplex(wx.DUPLEX_VERTICAL)
                    elif duplex == 3:
                        print_data.SetDuplex(wx.DUPLEX_HORIZONTAL)
                    elif duplex == 1:
                        print_data.SetDuplex(wx.DUPLEX_SIMPLEX)

            finally:
                winspool.ClosePrinter(hprinter)

            return print_data

        except Exception:
            pass  # ctypes fallito → fallback wx

    # ── Fallback: wx.PageSetupDialog (non-Windows o entrambi i tentativi falliti)
    # SetSetupDialog() è stato rimosso in wxPython 4.x (Phoenix).
    pdd = wx.PageSetupDialogData(print_data)
    dlg = wx.PageSetupDialog(None, pdd)
    try:
        if dlg.ShowModal() == wx.ID_OK:
            print_data = wx.PrintData(dlg.GetPageSetupData().GetPrintData())
    finally:
        dlg.Destroy()
    return print_data


# ── Costanti ──────────────────────────────────────────────────────────────────

_GAP = 8          # margine interno dialogo (px)

_PAPER_SIZE_MM = {
    wx.PAPER_A3:        (297.0, 420.0),
    wx.PAPER_A4:        (210.0, 297.0),
    wx.PAPER_A5:        (148.0, 210.0),
    wx.PAPER_B4:        (250.0, 354.0),
    wx.PAPER_B5:        (176.0, 250.0),
    wx.PAPER_LETTER:    (215.9, 279.4),
    wx.PAPER_LEGAL:     (215.9, 355.6),
    wx.PAPER_TABLOID:   (279.4, 431.8),
    wx.PAPER_EXECUTIVE: (184.1, 266.7),
}


# ══════════════════════════════════════════════════════════════════════════════
# SongpressPrintout
# ══════════════════════════════════════════════════════════════════════════════

class SongpressPrintout(wx.Printout):
    """
    Printout per Songpress++.

    Supporta interruzioni di pagina esplicite tramite il comando {new_page}:
    il testo viene suddiviso in segmenti, ognuno stampato su una o più pagine.
    All'interno di ciascun segmento il contenuto scorre automaticamente se
    supera l'altezza della pagina.
    """

    _SCREEN_PPI = 96

    def __init__(self, frame_obj, title="Song", two_pages_per_sheet=False,
                 font_scale=100, force_full=False):
        wx.Printout.__init__(self, title)
        self.frame_obj          = frame_obj
        self.two_pages_per_sheet = two_pages_per_sheet
        self._font_scale        = font_scale / 100.0
        # force_full=True → ignora la selezione e stampa sempre l'intero documento
        self._force_full        = force_full
        self._page_offsets      = None   # list of (segment_idx, y_offset_px)
        self._page_clip_px      = None   # per pagina: altezza max (px schermo) o None
        self._segments          = None   # list of text strings (split on {new_page})
        self._scale_x           = None
        self._scale_y           = None
        self._margin_du         = None
        self._usable_w_du       = None
        self._song_info         = None   # (full_song, sel_text)
        self._col_h_px          = 0      # altezza colonna testo in px schermo (0 = illimitata)
        self._seg_verse_start   = {}     # seg_idx -> (verseCount, labelCount, chorusCount)
        self._col_w_du          = None
        self._gap_du            = None
        # Dimensione pagina in device-unit COERENTE con dc.GetPPI(): calcolata
        # una sola volta in _ensure_layout e riusata in _render_logical_page e
        # OnPrintPage, così tutti i calcoli restano nello stesso frame.
        self._page_w_du         = None
        self._page_h_du         = None

    # ── Helpers ───────────────────────────────────────────────────────────────

    def _mm_to_du(self, mm, ppi):
        return int(mm * ppi / 25.4)

    def _page_size_du(self, ppi_x, ppi_y):
        """Dimensione pagina (larghezza, altezza) in device-unit coerenti con `ppi`.

        FIX Linux (wxGTK)
        ─────────────────
        Su GTK, in anteprima di stampa, GetPageSizePixels() restituisce i pixel
        a risoluzione STAMPANTE, mentre dc.GetPPI() (usato per margini e scala)
        restituisce i DPI dello SCHERMO. Mescolare le due unità falsava altezza
        utile, numero di pagine, «colonne per pagina» e «pagine per foglio».

        Ricaviamo quindi la dimensione dalla misura in mm (GetPageSizeMM(),
        indipendente dalla risoluzione) usando gli STESSI ppi del resto del
        layout. Fallback ai pixel nativi se la misura in mm non è disponibile.
        """
        try:
            w_mm, h_mm = self.GetPageSizeMM()
        except Exception:
            w_mm, h_mm = 0, 0
        if w_mm and h_mm:
            return (int(round(w_mm * ppi_x / 25.4)),
                    int(round(h_mm * ppi_y / 25.4)))
        return self.GetPageSizePixels()

    @staticmethod
    def _split_on_new_page(text):
        """
        Divide il testo su comandi {new_page} / {np} (case-insensitive).
        Le righe commentate con '#' vengono ignorate.
        Restituisce una lista di segmenti (almeno uno).
        """
        import re
        cmd_pat     = re.compile(r'\{\s*(?:new_page|np)\s*\}', re.IGNORECASE)
        comment_pat = re.compile(r'^\s*#')

        split_positions = []
        offset = 0
        for line in text.splitlines(keepends=True):
            if not comment_pat.match(line):
                for m in cmd_pat.finditer(line):
                    split_positions.append((offset + m.start(), offset + m.end()))
            offset += len(line)

        if not split_positions:
            return [text]

        parts = []
        prev = 0
        for start, end in split_positions:
            parts.append(text[prev:start])
            prev = end
        parts.append(text[prev:])

        return [p for p in parts if p.strip()] or [text]

    def _make_renderer(self):
        decorator = (
            self.frame_obj.pref.decorator
            if self.frame_obj.pref.labelVerses
            else SongDecorator()
        )
        r = Renderer(
            self.frame_obj.pref.format,
            decorator,
            self.frame_obj.pref.notations,
        )
        r.tempoDisplay    = getattr(self.frame_obj.pref, 'tempoDisplay',    0)
        r.timeDisplay     = getattr(self.frame_obj.pref, 'timeDisplay',     True)
        r.keyDisplay      = getattr(self.frame_obj.pref, 'keyDisplay',      True)
        r.tempoIconSize   = getattr(self.frame_obj.pref, 'tempoIconSize',   24)
        if hasattr(self.frame_obj, '_getTempoIconColour'):
            r.tempoIconColour = self.frame_obj._getTempoIconColour()
        r.gridDisplayMode = getattr(self.frame_obj.pref, 'gridDisplayMode', 'pipe')
        r.gridDefaultLabel = getattr(self.frame_obj.pref, 'gridDefaultLabel', None)
        r.gridSizeDir     = getattr(self.frame_obj.pref, 'gridSizeDir',     'both')
        r.columns         = getattr(self.frame_obj, '_columns_per_page', 1)
        r.columnHeight    = getattr(self, '_col_h_px', 0)
        # Imposta la directory del documento per risolvere i percorsi relativi
        # delle immagini ({image: intro.png} → cerca nella stessa cartella del .crd)
        import os as _os
        doc_path = getattr(self.frame_obj, 'document', None)
        r._document_dir = _os.path.dirname(doc_path) if doc_path else ''
        return r

    def _block_breaks(self, seg_idx, seg_text, seg_h, mdc):
        """Altezze (px schermo) dove si può interrompere la pagina.

        Dopo Renderer.Render() ogni blocco del brano (titolo, strofa,
        ritornello, griglia, immagine…) conosce la propria posizione verticale
        `y`: l'inizio di ciascun blocco (tranne il primo) è un punto valido
        dove andare a capo di pagina. Si usa la stessa formula
        `song.marginTop + block.y` di Renderer.page_break_ys, quindi coincide
        con il layout realmente disegnato. Il punto è alzato di qualche pixel (PAD)
        per non tagliare la cornice/etichetta che il decorator disegna appena
        sopra il blocco.
        Restituisce una lista ordinata (eventualmente vuota)."""
        # La riga dei battiti ({beats_time}, i numeri sopra gli accordi) viene
        # disegnata SOPRA l'inizio del blocco (circa 12 px logici): il punto
        # di interruzione va quindi messo piu' in alto di block.y, ma mai sopra
        # il fondo del blocco precedente.
        PROTRUDE = 24
        try:
            r = self._make_renderer()
            vc, lc, cc = self._seg_verse_start.get(seg_idx, (0, 0, 0))
            r.initialVerseCount  = vc
            r.initialLabelCount  = lc
            r.initialChorusCount = cc
            r.Render(seg_text, mdc)
            margin_top = getattr(r.song, 'marginTop', 0) or 0
            ys = []
            prev = None
            for box in r.song.boxes:
                by = getattr(box, 'y', None)
                if by is None:
                    continue
                top = float(margin_top + by)
                y = top - PROTRUDE
                if prev is not None:
                    try:
                        prev_bottom = (float(margin_top + prev.y)
                                       + float(prev.GetTotalHeight()) + 2.0)
                        y = max(y, prev_bottom)
                    except Exception:
                        pass
                prev = box
                if 0 < y < seg_h - 0.5 and (not ys or y > ys[-1] + 0.5):
                    ys.append(y)
            _dbg('block_breaks seg=%d h=%s marginTop=%s ys=%s'
                 % (seg_idx, seg_h, margin_top, sorted(ys)))
            return sorted(ys)
        except Exception:
            import traceback
            _dbg('block_breaks seg=%d ERRORE:\n%s' % (seg_idx, traceback.format_exc()))
            return []

    @staticmethod
    def _paginate_blocks(h, ppp, ys):
        """Divide un segmento alto `h` in pagine alte al massimo `ppp`,
        interrompendo solo ai punti `ys` (fine blocco). Se fra due pagine non
        c'è alcun punto valido (blocco più alto di una pagina) taglia a `ppp`.
        Restituisce [(offset_y, altezza_pagina | None)]; None = ultima pagina."""
        ppp = max(1.0, float(ppp))
        pages, start = [], 0.0
        while h - start > ppp + 0.5:
            limit = start + ppp
            cand  = [y for y in ys if start + 1.0 < y <= limit + 0.5]
            end   = max(cand) if cand else limit
            pages.append((start, end - start))
            start = end
        pages.append((start, None))
        return pages

    def _ensure_layout(self, dc):
        if self._page_offsets is not None:
            return

        ppi_x, ppi_y = dc.GetPPI()
        # Su wxGTK usiamo la dimensione derivata dai mm (coerente con GetPPI);
        # su Windows/macOS manteniamo il valore nativo per non alterarne il
        # comportamento (che lì è già corretto).
        if wx.Platform == '__WXGTK__':
            pw, ph = self._page_size_du(ppi_x, ppi_y)
        else:
            pw, ph = self.GetPageSizePixels()
        # Memorizza per riuso coerente in _render_logical_page e OnPrintPage.
        self._page_w_du, self._page_h_du = pw, ph

        ml = self._mm_to_du(self.frame_obj._margin_left,   ppi_x)
        mr = self._mm_to_du(self.frame_obj._margin_right,  ppi_x)
        mt = self._mm_to_du(self.frame_obj._margin_top,    ppi_y)
        mb = self._mm_to_du(self.frame_obj._margin_bottom, ppi_y)
        self._margin_du = (ml, mt, mr, mb)

        columns_per_page = getattr(self.frame_obj, '_columns_per_page', 1)

        if self.two_pages_per_sheet:
            gap      = self._mm_to_du(5, ppi_x)
            col_w    = (pw - ml - mr - gap) // 2
            usable_w = col_w
            usable_h = ph - mt - mb
            self._col_w_du = col_w
            self._gap_du   = gap
        else:
            usable_w = pw - ml - mr
            usable_h = ph - mt - mb

        if columns_per_page >= 2:
            col_gap_du      = self._mm_to_du(8, ppi_x)
            text_col_w      = (usable_w - col_gap_du) // 2
            self._col_h_px  = usable_h / (ppi_y / self._SCREEN_PPI)
            usable_w_for_scale = text_col_w
        else:
            self._col_h_px      = 0
            usable_w_for_scale  = usable_w

        self._usable_w_du = usable_w
        self._scale_x     = ppi_x / self._SCREEN_PPI * self._font_scale
        self._scale_y     = ppi_y / self._SCREEN_PPI * self._font_scale

        start, end  = self.frame_obj.text.GetSelection()
        # Se force_full è attivo, oppure non c'è selezione → stampa intero documento
        full_song   = self._force_full or (start == end)
        full_text   = self.frame_obj._strip_hash_commands(self.frame_obj.text.GetText())

        if full_song:
            sel_text = full_text
        else:
            # Estrae direttamente il testo selezionato (come fa _get_display_text),
            # così i comandi {start_of_grid}, {start_chorus}, ecc. presenti nella
            # selezione vengono inclusi senza dipendere dal filtraggio per numero di riga.
            raw_sel  = self.frame_obj.text.GetTextRange(start, end)
            sel_text = self.frame_obj._strip_hash_commands(raw_sel)

        self._song_info = (full_song, sel_text)

        if full_song:
            self._segments = self._split_on_new_page(full_text)
        else:
            self._segments = [sel_text]

        mdc = wx.MemoryDC(wx.Bitmap(1, 1))
        self._page_offsets = []
        self._page_clip_px = []

        verse_count = label_count = chorus_count = 0
        for seg_idx, seg_text in enumerate(self._segments):
            r = self._make_renderer()
            r.initialVerseCount  = verse_count
            r.initialLabelCount  = label_count
            r.initialChorusCount = chorus_count
            self._seg_verse_start[seg_idx] = (verse_count, label_count, chorus_count)
            sw, sh = r.Render(seg_text, mdc)
            sw, sh = max(1, sw), max(1, sh)
            verse_count  = r.song.verseCount
            label_count  = r.song.labelCount
            chorus_count = r.song.chorusCount

            natural_w = sw * self._scale_x
            if natural_w > usable_w_for_scale:
                fit = usable_w_for_scale / natural_w
                self._scale_x = min(self._scale_x, self._scale_x * fit)
                self._scale_y = min(self._scale_y, self._scale_y * fit)

        # ── fit_to_page / shrink_to_fit ───────────────────────────────
        #
        # Approccio diretto: rendiamo tutti i segmenti su un DC temporaneo
        # con la scala corrente, misuriamo l'altezza reale di ciascuno, e
        # ricaviamo il fattore di scala / la riduzione di margine necessari
        # senza approssimazioni su row_h.
        #
        # Grandezze usate in questo blocco:
        #   px_per_page  = altezza utile in pixel-schermo (unità del Renderer)
        #                = usable_h [device units] / self._scale_y
        #   seg_h_px[]   = altezze reali di ciascun segmento in pixel-schermo
        #   overflow_px  = quanto sporge l'ultimo segmento oltre la sua pagina
        #                  (sempre nell'ultima pagina di quel segmento)
        # ─────────────────────────────────────────────────────────────────────

        mdc2 = wx.MemoryDC(wx.Bitmap(1, 1))

        # Renderizza una volta sola tutti i segmenti e memorizza le altezze.
        seg_h_px = []
        for seg_idx, seg_text in enumerate(self._segments):
            r = self._make_renderer()
            vc, lc, cc = self._seg_verse_start.get(seg_idx, (0, 0, 0))
            r.initialVerseCount  = vc
            r.initialLabelCount  = lc
            r.initialChorusCount = cc
            _, sh = r.Render(seg_text, mdc2)
            seg_h_px.append(max(1, sh))

        total_h_px = sum(seg_h_px)

        if getattr(self.frame_obj, '_fit_to_page', False):
            # Scala font in riduzione se il contenuto eccede la pagina (no ingrandimento).
            if total_h_px * self._scale_y > usable_h:
                f = usable_h / (total_h_px * self._scale_y)
                self._scale_x *= f
                self._scale_y *= f
                # Aggiorna le altezze scalate (non i px, che sono invarianti
                # rispetto al renderer, ma serviranno corretti sotto).
                # Non serve: seg_h_px rimane in px-schermo; scale è cambiata.

        # ── Interruzioni di pagina per BLOCCHI (opzione «adatta alla pagina») ──
        #
        # Con «Riduci per adattare alla pagina/colonna corrente» una pagina
        # non viene più tagliata a un'altezza fissa: se un blocco (strofa,
        # ritornello…) non entra per intero, passa per intero alla pagina
        # successiva. Il font NON viene rimpicciolito per forzare tutto in una
        # sola pagina. Disponibile con 1 colonna di testo per pagina (con 2
        # colonne la spezzatura è gestita dal Renderer).
        shrink_on   = bool(getattr(self.frame_obj, '_shrink_to_fit', False))
        block_aware = shrink_on and columns_per_page < 2
        seg_breaks  = [[] for _ in self._segments]
        if block_aware:
            for seg_idx, seg_text in enumerate(self._segments):
                seg_breaks[seg_idx] = self._block_breaks(
                    seg_idx, seg_text, seg_h_px[seg_idx], mdc2)

        if shrink_on:
            # ── Parametri di margine riducibile ───────────────────────────
            min_margin_mm = float(getattr(self.frame_obj, '_min_margin_shrink', 5))
            min_margin_du = self._mm_to_du(min_margin_mm, ppi_y)

            red_top_max = max(0, mt - min_margin_du)
            red_bot_max = max(0, mb - min_margin_du)
            reducible_du = red_top_max + red_bot_max   # totale disponibile

            px_per_page = usable_h / self._scale_y   # in px-schermo

            def _overflow_px(h_px, ppp):
                """Pixel che sporgono oltre l'ultima pagina piena di un segmento.
                Se il segmento sta già in una pagina non c'è nulla da recuperare."""
                if ppp <= 0 or h_px <= ppp:
                    return 0.0
                return math.fmod(h_px, ppp)

            max_overflow_px = max(_overflow_px(h, px_per_page) for h in seg_h_px)

            if max_overflow_px > 0:
                needed_du = max_overflow_px * self._scale_y

                if needed_du <= reducible_du:
                    # Fase 1: i margini bastano a recuperare lo sbordo.
                    if reducible_du > 0:
                        ratio       = needed_du / reducible_du
                        red_top_du  = int(math.ceil(red_top_max * ratio))
                        red_bot_du  = int(math.floor(red_bot_max * ratio))
                    else:
                        red_top_du = red_bot_du = 0

                    mt -= red_top_du
                    mb -= red_bot_du
                    usable_h += red_top_du + red_bot_du
                    self._margin_du = (ml, mt, mr, mb)

                elif block_aware:
                    # Fase 2 (a blocchi): i margini non bastano → il blocco che
                    # non entra va alla pagina dopo. Si interviene su margini e
                    # font SOLO se un singolo blocco è più alto di una pagina.
                    tallest_px = 0.0
                    for seg_idx, h in enumerate(seg_h_px):
                        edges = [0.0] + list(seg_breaks[seg_idx]) + [float(h)]
                        for e0, e1 in zip(edges, edges[1:]):
                            tallest_px = max(tallest_px, e1 - e0)
                    if tallest_px * self._scale_y > usable_h:
                        mt       -= red_top_max
                        mb       -= red_bot_max
                        usable_h += reducible_du
                        self._margin_du = (ml, mt, mr, mb)
                        if tallest_px * self._scale_y > usable_h:
                            f = max(0.5, usable_h / (tallest_px * self._scale_y))
                            self._scale_x *= f
                            self._scale_y *= f

                else:
                    # Fase 2 (comportamento originale, modalità 2 colonne):
                    # sfrutta tutto il margine, poi riduce anche il font.
                    mt       -= red_top_max
                    mb       -= red_bot_max
                    usable_h += reducible_du
                    self._margin_du = (ml, mt, mr, mb)

                    f_min = 1.0
                    for h_px in seg_h_px:
                        h_du = h_px * self._scale_y
                        n_pages = max(1, math.ceil(h_du / usable_h))
                        target_du = n_pages * usable_h
                        if h_du > target_du:
                            f_candidate = target_du / h_du
                        elif h_du > 0:
                            overflow_du = math.fmod(h_du, usable_h)
                            if overflow_du > 0:
                                f_candidate = ((n_pages - 1) * usable_h) / h_du
                                f_candidate = max(0.5, f_candidate)
                            else:
                                f_candidate = 1.0
                        else:
                            f_candidate = 1.0
                        f_min = min(f_min, f_candidate)

                    if f_min < 1.0:
                        self._scale_x *= f_min
                        self._scale_y *= f_min

        # ── calcolo definitivo degli offsets di pagina ─────────────────
        px_per_page = usable_h / self._scale_y

        mdc3 = wx.MemoryDC(wx.Bitmap(1, 1))
        for seg_idx, seg_text in enumerate(self._segments):
            r = self._make_renderer()
            vc, lc, cc = self._seg_verse_start.get(seg_idx, (0, 0, 0))
            r.initialVerseCount  = vc
            r.initialLabelCount  = lc
            r.initialChorusCount = cc
            sw, sh = r.Render(seg_text, mdc3)
            sw, sh = max(1, sw), max(1, sh)

            if getattr(self.frame_obj, '_remove_blank_pages', False) and sh <= 2:
                continue

            if block_aware:
                for start_y, page_h in self._paginate_blocks(
                        sh, px_per_page, seg_breaks[seg_idx]):
                    self._page_offsets.append((seg_idx, start_y))
                    self._page_clip_px.append(page_h)
            else:
                y = 0.0
                while y < sh:
                    self._page_offsets.append((seg_idx, y))
                    self._page_clip_px.append(None)
                    y += px_per_page

        if not self._page_offsets:
            self._page_offsets = [(0, 0.0)]
            self._page_clip_px = [None]

        _dbg('layout shrink_on=%s block_aware=%s cols=%s two_pages=%s ppp=%.1f '
             'scale_y=%.3f offsets=%s clip=%s'
             % (shrink_on, block_aware, columns_per_page, self.two_pages_per_sheet,
                px_per_page, self._scale_y, self._page_offsets, self._page_clip_px))

        # Rimuovi ultima pagina quasi vuota
        if getattr(self.frame_obj, '_remove_blank_pages', False) and len(self._page_offsets) > 1:
            last_seg_idx, last_y = self._page_offsets[-1]
            r_check = self._make_renderer()
            vc, lc, cc = self._seg_verse_start.get(last_seg_idx, (0, 0, 0))
            r_check.initialVerseCount  = vc
            r_check.initialLabelCount  = lc
            r_check.initialChorusCount = cc
            _, sh_last = r_check.Render(self._segments[last_seg_idx], mdc3)
            remaining  = sh_last - last_y
            threshold  = getattr(self.frame_obj, '_blank_page_threshold', 5) / 100.0
            if remaining < px_per_page * threshold:
                self._page_offsets.pop()
                self._page_clip_px.pop()

    # ── wx.Printout interface ─────────────────────────────────────────────────

    def _n_sheets(self):
        # Il layout deve essere già stato fatto da OnPreparePrinting (che ha un DC
        # garantito). Se per qualsiasi motivo non è ancora pronto, restituiamo 1
        # come fallback sicuro anziché tentare di ottenere un DC fuori contesto.
        n_logical = len(self._page_offsets) if self._page_offsets else 1
        if self.two_pages_per_sheet:
            return max(1, math.ceil(n_logical / 2))
        return max(1, n_logical)

    def GetPageInfo(self):
        n = self._n_sheets()
        return 1, n, 1, n

    def HasPage(self, page):
        return 1 <= page <= self._n_sheets()

    def OnPreparePrinting(self):
        dc = self.GetDC()
        if dc:
            self._ensure_layout(dc)

    def _preview_fit_scale(self, dc):
        """Fattore di adattamento per l'ANTEPRIMA wxGTK.

        In anteprima wxGTK il DC su cui disegna il printout è la bitmap della
        pagina GIÀ RIMPICCIOLITA per entrare nella finestra di preview, mentre
        il layout e i posizionamenti (SetDeviceOrigin) sono calcolati in
        device-unit ricavate dai mm a risoluzione schermo
        (self._page_w_du / self._page_h_du), che sono più grandi della bitmap.
        Manca cioè il fattore standard `dc.GetSize() / dimensione_pagina` che il
        codice di stampa wx applica proprio per gestire lo zoom dell'anteprima.
        Senza correzione le due colonne e la riga di separazione «sforano» a
        destra e il centro cade oltre metà foglio.

        Restituisce (kx, ky) = dimensione REALE del DC / dimensione pagina in du,
        da moltiplicare alle coordinate/scala device in fase di disegno: così
        colonne e separatore rientrano e restano centrati.

        Attivo SOLO in anteprima e SOLO su wxGTK. In stampa reale
        (IsPreview() == False) e su Windows/macOS restituisce (1.0, 1.0)
        → nessun effetto, nessuna regressione.
        """
        try:
            if wx.Platform != '__WXGTK__' or not self.IsPreview():
                return 1.0, 1.0
            dcw, dch = dc.GetSize()
            pw = self._page_w_du or dcw
            ph = self._page_h_du or dch
            kx = (dcw / pw) if pw else 1.0
            ky = (dch / ph) if ph else 1.0
            # Applichiamo solo una RIDUZIONE (anteprima). Scarti trascurabili
            # (~1) o valori anomali (≤0) non toccano nulla, per sicurezza.
            if not (0.0 < kx < 0.999):
                kx = 1.0
            if not (0.0 < ky < 0.999):
                ky = 1.0
            return kx, ky
        except Exception:
            return 1.0, 1.0

    def _render_logical_page(self, dc, logical_page_idx, origin_x, origin_y):
        if logical_page_idx >= len(self._page_offsets):
            return

        seg_idx, y_offset_px = self._page_offsets[logical_page_idx]
        ml, mt, mr, mb       = self._margin_du
        usable_h_du          = self._page_h_du - mt - mb
        full_song, _ = self._song_info  # sel_text già incluso in self._segments

        seg_text = self._segments[seg_idx]

        # FIX Linux (wxGTK) — anteprima bianca con simboli SMP.
        # ────────────────────────────────────────────────────────────────
        # Su GTK, in anteprima di stampa, il DC della bitmap di preview può
        # non essere ancora "caldo": la prima GetTextExtent() restituisce
        # 0×0 e il layout del testo collassa (pagina bianca). Un'operazione
        # dummy di misura forza GTK a inizializzare il contesto Pango/Cairo
        # prima del render reale. No-op su Windows/macOS e in stampa reale.
        try:
            if wx.Platform == '__WXGTK__':
                _wf = dc.GetFont()
                if _wf and _wf.IsOk():
                    dc.SetFont(_wf)
                dc.GetTextExtent("A")  # warm-up del DC
        except Exception:
            pass

        col_w_du = self._col_w_du if self.two_pages_per_sheet else self._usable_w_du

        # FIX Linux (wxGTK) — «2 pagine per foglio» non divideva a metà
        # ────────────────────────────────────────────────────────────────
        # Impostiamo PRIMA la trasformazione (origine device + scala) e SOLO
        # DOPO la regione di clip, espressa in coordinate LOGICHE relative alla
        # nuova origine. Su wxGTK impostare il clip mentre l'origine è ancora a
        # (0,0) e cambiarla subito dopo faceva "seguire" il clip allo
        # spostamento dell'origine: per la pagina di DESTRA (origin_x grande)
        # la regione di clip finiva fuori dalla metà utile e il testo non
        # restava confinato → le due metà si sovrapponevano e il foglio non
        # appariva diviso a metà.
        #
        # Con quest'ordine la regione risultante in coordinate device è
        # identica a prima su Windows/macOS (dove l'origine ambiente è già
        # l'identità), quindi il comportamento lì non cambia; su GTK diventa
        # corretto perché il clip viene calcolato con la trasformazione finale.
        #
        # FIX Linux (wxGTK) — anteprima: adattamento alla bitmap di preview.
        # kx/ky valgono 1.0 in stampa reale e su Windows/macOS (nessun effetto);
        # in anteprima GTK rimpiccioliscono origine device e scala così la
        # colonna rientra nella bitmap più piccola e resta al posto giusto.
        # NB: il blocco di clip qui sotto NON va toccato — è in coordinate
        # LOGICHE e il fattore k, portato dalla SetUserScale, si semplifica:
        # l'estensione device del clip resta col_w_du * kx, coerente con
        # l'origine e con il separatore.
        kx, ky = self._preview_fit_scale(dc)
        dc.SetDeviceOrigin(
            int(round(origin_x * kx)),
            int(round((origin_y - y_offset_px * self._scale_y) * ky)),
        )
        dc.SetUserScale(self._scale_x * kx, self._scale_y * ky)

        # Clip in coordinate logiche (verrà composto con origine/scala correnti):
        #   x: 0 .. larghezza colonna / scale_x
        #   y: y_offset .. y_offset + altezza utile / scale_y
        # → in device equivale esattamente a
        #   (origin_x, origin_y, col_w_du, usable_h_du).
        sx = self._scale_x if self._scale_x else 1.0
        sy = self._scale_y if self._scale_y else 1.0
        # FIX — bordo sinistro dei box-commento ({comment_box}) tagliato.
        # Il SongDecorator disegna la cornice del box a
        #     x = (bordo sx del testo) - padding      (padding = 2 px LOGICI)
        # quindi per il box più a sinistra il bordo cade a x ≈ -2, cioè appena
        # dentro il margine. La regione di clip è anch'essa in coordinate
        # LOGICHE: partendo da x=0 tagliava via quel bordo. (Dividere il pad per
        # sx era sbagliato: in stampa sx≈6 → pad=1, che non copre il -2.)
        # Spostiamo il lato SINISTRO del clip a un x negativo fisso (in unità
        # logiche) sufficiente a contenere padding + spessore pen, lasciando
        # INVARIATO il bordo destro (clip_x + clip_w costante): essenziale per la
        # modalità «2 pagine per foglio», dove il clip confina la colonna destra.
        # Lo sconfino a sinistra ricade nel margine (colonna sx) o nel gap tra le
        # colonne (colonna dx), quindi non è mai visibile.
        BOX_LEFT_PAD = 4  # px logici: padding box (2) + pen (1) + margine
        clip_x = -BOX_LEFT_PAD
        clip_y = int(y_offset_px)
        clip_w = int(math.ceil(col_w_du / sx)) + BOX_LEFT_PAD
        clip_h = int(math.ceil(usable_h_du / sy))
        # Pagine a blocchi: non disegnare oltre il punto di interruzione, così
        # la prima riga del blocco successivo non resta tagliata in fondo.
        try:
            _ph = self._page_clip_px[logical_page_idx]
        except Exception:
            _ph = None
        if _ph:
            clip_h = min(clip_h, int(math.ceil(_ph)) + 1)
        _dbg('render page=%d seg=%d y_off=%.1f clip=(%s,%s,%s,%s) page_h=%s preview=%s'
             % (logical_page_idx, seg_idx, y_offset_px, clip_x, clip_y, clip_w,
                clip_h, _ph, self.IsPreview()))
        dc.SetClippingRegion(clip_x, clip_y, clip_w, clip_h)

        r = self._make_renderer()
        vc, lc, cc = self._seg_verse_start.get(seg_idx, (0, 0, 0))
        r.initialVerseCount  = vc
        r.initialLabelCount  = lc
        r.initialChorusCount = cc
        # Su DC di stampa (carta/PDF) e in anteprima di stampa i glifi SMP vanno
        # rasterizzati su bitmap: sul PrinterDC di Windows il GraphicsContext li
        # rende come garbage. Il flag è confinato a questo render e ripristinato
        # subito, così l'anteprima live (che condivide pref.decorator) resta sul
        # percorso nitido a GraphicsContext.
        _prev_smp_bmp = getattr(r.sd, 'smp_via_bitmap', False)
        _prev_smp_res = getattr(r.sd, 'smp_device_res', True)

        _is_preview = self.IsPreview()
        _is_gtk     = wx.Platform == '__WXGTK__'

        r.sd.smp_via_bitmap = True
        # Su carta/PDF (IsPreview False) usa la bitmap a risoluzione device →
        # nitida. In anteprima di stampa (IsPreview True) usa il blit a coordinate
        # logiche, altrimenti la trasformazione di anteprima nasconde il glifo.
        try:
            r.sd.smp_device_res = not _is_preview
        except Exception:
            r.sd.smp_device_res = True

        # FIX Linux (wxGTK) — anteprima bianca con simboli SMP.
        # ────────────────────────────────────────────────────────────────
        # In anteprima GTK il render dei glifi SMP via bitmap può fallire
        # silenziosamente (o sollevare eccezione) e portarsi dietro l'intera
        # pagina, che resta bianca. Se il render solleva un'eccezione in questo
        # contesto, riproviamo una volta col percorso diretto (senza bitmap
        # SMP): la resa dei soli glifi SMP è meno nitida, ma il resto del testo
        # torna visibile — molto meglio di una pagina vuota. Su Windows/macOS e
        # in stampa reale il comportamento non cambia (nessun fallback).
        try:
            r.Render(seg_text, dc)
        except Exception:
            if _is_preview and _is_gtk:
                try:
                    r.sd.smp_via_bitmap = False
                    r.sd.smp_device_res = True
                    r.Render(seg_text, dc)
                except Exception:
                    pass  # ultimo tentativo fallito: si prosegue comunque
            else:
                raise
        finally:
            r.sd.smp_via_bitmap = _prev_smp_bmp
            r.sd.smp_device_res = _prev_smp_res

        dc.DestroyClippingRegion()
        dc.SetUserScale(1.0, 1.0)
        dc.SetDeviceOrigin(0, 0)

    def OnPrintPage(self, page):
        dc = self.GetDC()
        self._ensure_layout(dc)

        # FIX Linux (wxGTK) — anteprima bianca con simboli SMP.
        # ────────────────────────────────────────────────────────────────
        # Stabilizza il DC prima di disegnare qualsiasi cosa (filigrana,
        # separatore, colonne). Se la prima misura del testo torna 0×0 il DC
        # non è pronto: impostiamo una font valida per forzare GTK a
        # inizializzare il contesto. No-op su Windows/macOS.
        try:
            if wx.Platform == '__WXGTK__':
                dc.SetFont(wx.Font(10, wx.FONTFAMILY_DEFAULT,
                                   wx.FONTSTYLE_NORMAL, wx.FONTWEIGHT_NORMAL))
                _w, _h = dc.GetTextExtent("Test")
                if not _w or not _h:
                    dc.SetFont(wx.Font(12, wx.FONTFAMILY_SWISS,
                                       wx.FONTSTYLE_NORMAL, wx.FONTWEIGHT_NORMAL))
        except Exception:
            pass

        ml, mt, mr, mb = self._margin_du
        pw, ph         = self._page_w_du, self._page_h_du

        # Filigrana DIETRO al contenuto: disegnata prima, cosi' il testo che
        # segue non viene oscurato. Copre stampa ed export PDF Linux/macOS (CUPS).
        self._draw_watermark(dc, pw, ph)

        if self.two_pages_per_sheet:
            left_idx  = (page - 1) * 2
            right_idx = left_idx + 1
            n_logical = len(self._page_offsets)
            no_mirror = getattr(self.frame_obj, '_no_mirror_right', False)
            if right_idx >= n_logical:
                right_idx = None if no_mirror else left_idx

            left_x   = ml
            right_x  = ml + self._col_w_du + self._gap_du
            center_x = ml + self._col_w_du + self._gap_du // 2

            # ── Separatore centrale ────────────────────────────────────────
            # center_x / mt / (ph - mb) sono in DEVICE-UNIT: le STESSE unita'
            # che _render_logical_page passa a SetDeviceOrigin per collocare le
            # due colonne. Vanno quindi disegnate nel frame DEVICE nativo del DC.
            #
            # FIX Linux (wxGTK) — linea non centrata (ne' orizzontale ne' verticale)
            # ─────────────────────────────────────────────────────────────────────
            # In ANTEPRIMA wxGTK lascia sul DC una trasformazione «ambiente»:
            #   • SetUserScale  = zoom di anteprima (device stampante -> preview)
            #   • SetDeviceOrigin = offset di centratura della pagina
            # Le colonne non ne risentono perche' _render_logical_page sovrascrive
            # scala e origine. La linea, invece, disegnata "cosi' com'e'", veniva
            # interpretata in quel frame ambiente: con coordinate in pixel-schermo
            # (valori piccoli) finiva in alto a sinistra e accorciata -> non
            # centrata ne in orizzontale ne in verticale.
            # Su Windows/macOS l'ambiente e' gia' l'identita', quindi lì e' un no-op.
            #
            # Azzeriamo scala e origine (salvando/ripristinando lo stato) così la
            # linea usa lo stesso frame device delle colonne su ogni piattaforma.
            #
            # In anteprima wxGTK moltiplichiamo le coordinate per lo STESSO
            # fattore (kx, ky) applicato alle colonne in _render_logical_page:
            # così il separatore rientra nella bitmap di preview e cade
            # esattamente a metà (center_x * kx = larghezza_DC / 2), restando
            # nel gap tra le due colonne. In stampa reale e su Windows/macOS
            # kx = ky = 1.0 → nessun cambiamento.
            kx, ky = self._preview_fit_scale(dc)
            cx = int(round(center_x * kx))
            y0 = int(round(mt * ky))
            y1 = int(round((ph - mb) * ky))
            _sx0, _sy0 = dc.GetUserScale()
            _org0      = dc.GetDeviceOrigin()
            try:
                dc.SetUserScale(1.0, 1.0)
                dc.SetDeviceOrigin(0, 0)
                dc.SetPen(wx.Pen(wx.Colour(180, 180, 180), 1, wx.PENSTYLE_DOT))
                dc.DrawLine(cx, y0, cx, y1)
                dc.SetPen(wx.NullPen)
            finally:
                dc.SetUserScale(_sx0, _sy0)
                dc.SetDeviceOrigin(_org0.x, _org0.y)

            self._render_logical_page(dc, left_idx,  left_x,  mt)
            if right_idx is not None:
                self._render_logical_page(dc, right_idx, right_x, mt)
        else:
            page_idx = page - 1
            if page_idx >= len(self._page_offsets):
                return False
            self._render_logical_page(dc, page_idx, ml, mt)

        return True

    def _draw_watermark(self, dc, pw, ph):
        """Disegna la filigrana sull'intero foglio (se abilitata nelle pref).

        Copre sia la stampa sia l'export PDF su Linux/macOS (che passa da qui
        tramite wx.PRINT_MODE_FILE / CUPS).

        FIX Linux/anteprima
        ───────────────────
        La filigrana DEVE essere tracciata nello STESSO sistema di coordinate
        «foglio» usato per i margini (self._margin_du) e per la linea di
        separazione 2-pagine, cioe' con la scala/origine AMBIENTE che wx ha
        gia' impostato sul DC per la pagina corrente.

        La versione precedente forzava qui SetUserScale(1,1) e
        SetDeviceOrigin(0,0). In stampa reale la scala ambiente e' l'identita',
        quindi non si notava nulla; ma sul backend GTK l'anteprima applica al
        DC una scala device->schermo (es. ~0.16 a 600 dpi). Azzerandola, la
        filigrana veniva disegnata a piena risoluzione stampante (pw x ph in
        pixel «grandi») su un DC di anteprima molto piu' piccolo: il centro del
        testo finiva ben oltre l'area visibile e la filigrana risultava
        «invisibile». Ora NON tocchiamo la trasformazione: disegniamo nello
        stesso frame del separatore, che su Linux funziona correttamente.

        Salviamo/ripristiniamo comunque scala e origine, cosi' questo metodo
        non lascia stato residuo sul DC condiviso (evita effetti collaterali
        sulla riga separatrice quando la filigrana e' attiva in 2-pagine).
        """
        if not getattr(self.frame_obj.pref, 'watermarkEnabled', False):
            return
        try:
            from . import Watermark
            cfg = self.frame_obj._GetWatermarkConfig()
        except Exception:
            return

        # ── Stato ambiente del DC (impostato da wx per questa pagina) ──────────
        try:
            _sx, _sy = dc.GetUserScale()
        except Exception:
            _sx, _sy = 1.0, 1.0
        try:
            _org = dc.GetDeviceOrigin()
            _ox, _oy = _org.x, _org.y
        except Exception:
            _ox, _oy = 0, 0

        try:
            # NB: nessun SetUserScale/SetDeviceOrigin qui. Disegniamo nel frame
            # «foglio» ambiente (identita' in stampa, scala di zoom in anteprima
            # GTK): e' lo stesso frame in cui sono validi pw/ph e i margini.
            Watermark.draw_watermark(dc, pw, ph, cfg)
        except Exception:
            pass
        finally:
            # Ripristino difensivo dello stato ambiente.
            try:
                dc.SetUserScale(_sx, _sy)
                dc.SetDeviceOrigin(_ox, _oy)
            except Exception:
                pass


# ══════════════════════════════════════════════════════════════════════════════
# PrintOptionsDialog  (dialog grafica ottimizzata)
# ══════════════════════════════════════════════════════════════════════════════

class PrintOptionsDialog:
    """
    Dialog «Opzioni di stampa» con grafica a sezioni (wx.StaticBoxSizer).

    Invocato da PrintManager._ask_two_pages_per_sheet(); riceve il frame
    come ``owner`` per poter leggere e scrivere i parametri di stampa.
    """

    def __init__(self, owner, parent=None, on_apply=None, _dlg_ref=None):
        self.owner    = owner
        self.on_apply = on_apply

        dialog_parent = parent if parent is not None else owner.frame

        self.dlg = wx.Dialog(
            dialog_parent,
            title=_("Print options"),
            style=wx.DEFAULT_DIALOG_STYLE | wx.STAY_ON_TOP,
        )
        if _dlg_ref is not None:
            _dlg_ref[0] = self.dlg

        self._build_ui()
        self._bind_events()

        self.dlg.SetSizerAndFit(self._outer)
        self.dlg.CentreOnParent()

    # ── Helper ────────────────────────────────────────────────────────────────

    @staticmethod
    def _make_spin(parent, vmin, vmax, value, width=90):
        """Crea un wx.SpinCtrl senza tagliare i pulsanti +/-.

        FIX Linux (wxGTK)
        ─────────────────
        Su wxGTK le frecce +/- fanno parte del controllo e richiedono una
        larghezza minima propria (che dipende dal tema GTK/Qt). Imporre una
        `size` fissa troppo piccola (es. 90 px) le taglia: si vedeva solo su
        Linux, perché su Windows/macOS quella larghezza basta.

        Qui NON forziamo la size in costruzione: lasciamo che il controllo
        calcoli la sua best size (che INCLUDE le frecce) e imponiamo come
        larghezza minima il massimo tra quella desiderata e la best size.
        Così su Linux i pulsanti restano interi e su Windows/macOS la
        larghezza voluta è comunque rispettata.
        """
        sp = wx.SpinCtrl(parent, min=vmin, max=vmax, value=str(value))
        best = sp.GetBestSize()
        sp.SetMinSize(wx.Size(max(width, best.width), best.height))
        return sp

    # ── Costruzione UI ────────────────────────────────────────────────────────

    def _build_ui(self):
        owner = self.owner
        dlg   = self.dlg
        self._outer = outer = wx.BoxSizer(wx.VERTICAL)

        # ── Sezione Pagine ────────────────────────────────────────────
        box_pages = wx.StaticBoxSizer(
            wx.StaticBox(dlg, label=_("Pages per sheet")), wx.HORIZONTAL
        )
        self.rb_page1 = wx.ToggleButton(dlg, label=_("1 page"))
        self.rb_page2 = wx.ToggleButton(dlg, label=_("2 pages"))
        self.rb_page1.SetValue(not owner._two_pages_per_sheet)
        self.rb_page2.SetValue(owner._two_pages_per_sheet)
        box_pages.Add(self.rb_page1, 1, wx.EXPAND | wx.ALL, _GAP)
        box_pages.Add(self.rb_page2, 1, wx.EXPAND | wx.ALL, _GAP)
        outer.Add(box_pages, 0, wx.EXPAND | wx.ALL, _GAP)

        # ── Sezione Colonne ───────────────────────────────────────────
        box_cols = wx.StaticBoxSizer(
            wx.StaticBox(dlg, label=_("Columns per page")), wx.HORIZONTAL
        )
        self.rb_col1 = wx.ToggleButton(dlg, label=_("1 column"))
        self.rb_col2 = wx.ToggleButton(dlg, label=_("2 columns"))
        self.rb_col1.SetValue(owner._columns_per_page == 1)
        self.rb_col2.SetValue(owner._columns_per_page == 2)
        box_cols.Add(self.rb_col1, 1, wx.EXPAND | wx.ALL, _GAP)
        box_cols.Add(self.rb_col2, 1, wx.EXPAND | wx.ALL, _GAP)
        outer.Add(box_cols, 0, wx.EXPAND | wx.LEFT | wx.RIGHT | wx.BOTTOM, _GAP)

        # ── Sezione Ridimensionamento ──────────────────────────────────
        box_resize = wx.StaticBoxSizer(
            wx.StaticBox(dlg, label=_("Scaling")), wx.VERTICAL
        )

        self.cb_fit = wx.CheckBox(dlg, label=_("Shrink if exceeds page"))
        self.cb_fit.SetValue(owner._fit_to_page)
        self.cb_fit.SetToolTip(_("Reduce the content only if it exceeds the page size (no upscaling)"))
        box_resize.Add(self.cb_fit, 0, wx.ALL, _GAP)

        # cb_shrink + nota secondaria
        shrink_panel = wx.Panel(dlg)
        shrink_vsz   = wx.BoxSizer(wx.VERTICAL)
        self.cb_shrink = wx.CheckBox(
            shrink_panel, label=_("Shrink to fit current page")
        )
        self.cb_shrink.SetValue(owner._shrink_to_fit)
        self.cb_shrink.SetToolTip(_("Reduce the content only if it exceeds the page size, to avoid bottom clipping"))
        note = wx.StaticText(shrink_panel, label=_("(prevent bottom clipping)"))
        note.SetForegroundColour(wx.SystemSettings.GetColour(wx.SYS_COLOUR_GRAYTEXT))
        nf = note.GetFont()
        nf.SetPointSize(max(7, nf.GetPointSize() - 1))
        note.SetFont(nf)
        shrink_vsz.Add(self.cb_shrink, 0)
        shrink_vsz.Add(note, 0, wx.LEFT, 20)
        self._shrink_panel = shrink_panel
        shrink_panel.SetSizer(shrink_vsz)
        box_resize.Add(shrink_panel, 0, wx.LEFT | wx.RIGHT | wx.BOTTOM, _GAP)

        # Spin margine minimo
        row1 = wx.BoxSizer(wx.HORIZONTAL)
        self.lbl_min_margin = wx.StaticText(
            dlg, label=_("Min margin for auto-shrink (mm):")
        )
        self.spin_min_margin = self._make_spin(
            dlg, 0, 50, getattr(owner, '_min_margin_shrink', 5),
        )
        row1.Add(self.lbl_min_margin, 1, wx.ALIGN_CENTER_VERTICAL | wx.RIGHT, 4)
        row1.Add(self.spin_min_margin, 0, wx.ALIGN_CENTER_VERTICAL)
        box_resize.Add(row1, 0, wx.EXPAND | wx.LEFT | wx.RIGHT | wx.BOTTOM, _GAP)

        self.lbl_min_margin.Enable(owner._shrink_to_fit)
        self.spin_min_margin.Enable(owner._shrink_to_fit)

        # Etichette coerenti con la modalità «pagine per foglio» corrente
        self._update_scope_labels(owner._two_pages_per_sheet)

        outer.Add(box_resize, 0, wx.EXPAND | wx.LEFT | wx.RIGHT | wx.BOTTOM, _GAP)

        # ── Sezione Opzioni avanzate ───────────────────────────────────
        box_adv = wx.StaticBoxSizer(
            wx.StaticBox(dlg, label=_("Advanced options")), wx.VERTICAL
        )

        self.cb_no_mirror = wx.CheckBox(
            dlg, label=_("Do not replicate (leave right half blank)")
        )
        self.cb_no_mirror.SetValue(owner._no_mirror_right)
        self.cb_no_mirror.SetToolTip(_("In 2-pages mode, print only on the left half and leave the right half blank (no mirroring)"))
        self.cb_no_mirror.Enable(owner._two_pages_per_sheet)
        box_adv.Add(self.cb_no_mirror, 0, wx.ALL, _GAP)

        self.cb_remove_blank = wx.CheckBox(dlg, label=_("Remove blank pages"))
        self.cb_remove_blank.SetValue(owner._remove_blank_pages)
        self.cb_remove_blank.SetToolTip(_("Skip pages that are empty or contain only whitespace, based on the threshold below"))
        box_adv.Add(self.cb_remove_blank, 0, wx.LEFT | wx.RIGHT | wx.BOTTOM, _GAP)

        row2 = wx.BoxSizer(wx.HORIZONTAL)
        self.lbl_blank_threshold = wx.StaticText(dlg, label=_("Blank page threshold (%):"))
        self.spin_blank_threshold = self._make_spin(
            dlg, 1, 95, getattr(owner, '_blank_page_threshold', 5),
        )
        row2.Add(self.lbl_blank_threshold, 1, wx.ALIGN_CENTER_VERTICAL | wx.RIGHT, 4)
        row2.Add(self.spin_blank_threshold, 0, wx.ALIGN_CENTER_VERTICAL)
        box_adv.Add(row2, 0, wx.EXPAND | wx.LEFT | wx.RIGHT | wx.BOTTOM, _GAP)

        self.lbl_blank_threshold.Enable(owner._remove_blank_pages)
        self.spin_blank_threshold.Enable(owner._remove_blank_pages)

        outer.Add(box_adv, 0, wx.EXPAND | wx.LEFT | wx.RIGHT | wx.BOTTOM, _GAP)

        # ── Sezione Scala ──────────────────────────────────────────────
        box_scale = wx.StaticBoxSizer(
            wx.StaticBox(dlg, label=_("Scale")), wx.HORIZONTAL
        )
        lbl_scale = wx.StaticText(dlg, label=_("Scale (%):"))
        self.spin_font_scale = self._make_spin(
            dlg, 50, 200, getattr(owner, '_print_font_scale', 100),
        )
        box_scale.Add(lbl_scale, 1, wx.ALIGN_CENTER_VERTICAL | wx.ALL, _GAP)
        box_scale.Add(self.spin_font_scale, 0, wx.ALIGN_CENTER_VERTICAL | wx.ALL, _GAP)
        # Pulsante che riporta la scala a 100% (aggiorna anche la casella).
        self.btn_scale_reset = wx.Button(dlg, wx.ID_ANY, _("100%"), style=wx.BU_EXACTFIT)
        self.btn_scale_reset.SetToolTip(_("Reset scale to 100%"))
        box_scale.Add(self.btn_scale_reset, 0, wx.ALIGN_CENTER_VERTICAL | wx.ALL, _GAP)
        outer.Add(box_scale, 0, wx.EXPAND | wx.LEFT | wx.RIGHT | wx.BOTTOM, _GAP)

        # ── Sezione Diagnostica ────────────────────────────────────────
        box_diag = wx.StaticBoxSizer(
            wx.StaticBox(dlg, label=_("Diagnostics")), wx.VERTICAL
        )
        self.cb_debug = wx.CheckBox(dlg, label=_("Write page layout log"))
        self.cb_debug.SetValue(getattr(owner, '_print_debug', False))
        self.cb_debug.SetToolTip(
            _("Save how the song is split into pages to this file:") + "\n" + _debug_log_path())
        row_dbg = wx.BoxSizer(wx.HORIZONTAL)
        row_dbg.Add(self.cb_debug, 1, wx.ALIGN_CENTER_VERTICAL | wx.RIGHT, 4)
        self.btn_open_log = wx.Button(dlg, wx.ID_ANY, _("Open folder"), style=wx.BU_EXACTFIT)
        self.btn_open_log.SetToolTip(_("Open the folder that contains the log file"))
        row_dbg.Add(self.btn_open_log, 0, wx.ALIGN_CENTER_VERTICAL)
        box_diag.Add(row_dbg, 0, wx.EXPAND | wx.ALL, _GAP)
        lbl_path = wx.StaticText(dlg, label=_debug_log_path())
        lbl_path.SetForegroundColour(wx.SystemSettings.GetColour(wx.SYS_COLOUR_GRAYTEXT))
        pf_ = lbl_path.GetFont()
        pf_.SetPointSize(max(7, pf_.GetPointSize() - 1))
        lbl_path.SetFont(pf_)
        box_diag.Add(lbl_path, 0, wx.LEFT | wx.RIGHT | wx.BOTTOM, _GAP)
        outer.Add(box_diag, 0, wx.EXPAND | wx.LEFT | wx.RIGHT | wx.BOTTOM, _GAP)

        # ── Bottoni ────────────────────────────────────────────────────
        PIN_OFF = u"📌"
        PIN_ON  = u"📍"
        self._pinned = [getattr(owner, '_print_options_pinned', False)]

        btn_sizer = wx.BoxSizer(wx.HORIZONTAL)
        self.btn_pin = wx.Button(
            dlg, wx.ID_ANY,
            PIN_ON if self._pinned[0] else PIN_OFF,
            size=(32, -1),
        )
        self.btn_pin.SetToolTip(_("Keep this dialog open after applying"))
        self.btn_ok     = wx.Button(dlg, wx.ID_OK,     _("OK"))
        self.btn_cancel = wx.Button(dlg, wx.ID_CANCEL, _("Cancel"))
        self.btn_ok.SetDefault()

        btn_sizer.Add(self.btn_pin,    0, wx.RIGHT, 4)
        btn_sizer.AddStretchSpacer()
        btn_sizer.Add(self.btn_ok,     0, wx.RIGHT, 4)
        btn_sizer.Add(self.btn_cancel, 0)
        outer.Add(btn_sizer, 0, wx.EXPAND | wx.ALL, _GAP)

    # ── Bind ──────────────────────────────────────────────────────────────────

    def _bind_events(self):
        self.rb_page1.Bind(wx.EVT_TOGGLEBUTTON, self._on_page1)
        self.rb_page2.Bind(wx.EVT_TOGGLEBUTTON, self._on_page2)
        self.rb_col1.Bind(wx.EVT_TOGGLEBUTTON, self._on_col1)
        self.rb_col2.Bind(wx.EVT_TOGGLEBUTTON, self._on_col2)
        self.cb_shrink.Bind(wx.EVT_CHECKBOX, self._on_shrink_changed)
        self.cb_remove_blank.Bind(wx.EVT_CHECKBOX, self._on_remove_blank_changed)
        self.btn_pin.Bind(wx.EVT_BUTTON, self._on_pin)
        self.btn_scale_reset.Bind(wx.EVT_BUTTON, self._on_scale_reset)
        self.btn_open_log.Bind(wx.EVT_BUTTON, self._on_open_log_folder)
        self.btn_ok.Bind(wx.EVT_BUTTON, self._on_ok)

    # ── Handler eventi ────────────────────────────────────────────────────────

    def _update_scope_labels(self, two_pages):
        """Adegua testi e tooltip delle due opzioni di riduzione.

        Con «2 pagine per foglio» le due pagine logiche sono affiancate sullo
        stesso foglio: la riduzione si applica a ciascuna metà (colonna) e non
        al foglio intero, quindi le etichette parlano di «colonna».
        """
        if two_pages:
            self.cb_fit.SetLabel(_("Shrink if exceeds column"))
            self.cb_fit.SetToolTip(_(
                "Reduce the content only if it exceeds the size of its column "
                "(each half of the sheet), no upscaling"))
            self.cb_shrink.SetLabel(_("Shrink to fit current column"))
            self.cb_shrink.SetToolTip(_(
                "Reduce the content only if it exceeds the size of its column "
                "(each half of the sheet), to avoid bottom clipping"))
        else:
            self.cb_fit.SetLabel(_("Shrink if exceeds page"))
            self.cb_fit.SetToolTip(_(
                "Reduce the content only if it exceeds the page size (no upscaling)"))
            self.cb_shrink.SetLabel(_("Shrink to fit current page"))
            self.cb_shrink.SetToolTip(_(
                "Reduce the content only if it exceeds the page size, to avoid bottom clipping"))
        try:
            self._shrink_panel.Layout()
            self.dlg.Layout()
            self.dlg.Fit()
        except Exception:
            pass

    def _on_page1(self, evt):
        self.rb_page1.SetValue(True)
        self.rb_page2.SetValue(False)
        self.cb_no_mirror.Enable(False)
        self._update_scope_labels(False)

    def _on_page2(self, evt):
        self.rb_page2.SetValue(True)
        self.rb_page1.SetValue(False)
        self.cb_no_mirror.Enable(True)
        self._update_scope_labels(True)

    def _on_col1(self, evt):
        self.rb_col1.SetValue(True)
        self.rb_col2.SetValue(False)

    def _on_col2(self, evt):
        self.rb_col2.SetValue(True)
        self.rb_col1.SetValue(False)

    def _on_open_log_folder(self, evt):
        if not _open_debug_log_folder():
            wx.MessageBox(
                _("Unable to open the folder:") + "\n" + os.path.dirname(_debug_log_path()),
                _("Error"), wx.OK | wx.ICON_ERROR, self.dlg)

    def _on_scale_reset(self, evt):
        # Riporta la scala a 100% aggiornando anche la casella (SpinCtrl).
        self.spin_font_scale.SetValue(100)

    def _on_shrink_changed(self, evt):
        enabled = self.cb_shrink.GetValue()
        self.lbl_min_margin.Enable(enabled)
        self.spin_min_margin.Enable(enabled)
        evt.Skip()

    def _on_remove_blank_changed(self, evt):
        enabled = self.cb_remove_blank.GetValue()
        self.lbl_blank_threshold.Enable(enabled)
        self.spin_blank_threshold.Enable(enabled)
        evt.Skip()

    def _on_pin(self, evt):
        PIN_OFF = u"📌"
        PIN_ON  = u"📍"
        self._pinned[0] = not self._pinned[0]
        self.owner._print_options_pinned = self._pinned[0]
        self.btn_pin.SetLabel(PIN_ON if self._pinned[0] else PIN_OFF)

    def _on_ok(self, evt):
        self._apply_options()
        if not self._pinned[0]:
            self.dlg.EndModal(wx.ID_OK)

    # ── Logica ────────────────────────────────────────────────────────────────

    def _apply_options(self):
        o = self.owner
        o._two_pages_per_sheet  = self.rb_page2.GetValue()
        o._columns_per_page     = 2 if self.rb_col2.GetValue() else 1
        o._fit_to_page          = self.cb_fit.GetValue()
        o._shrink_to_fit        = self.cb_shrink.GetValue()
        o._min_margin_shrink    = self.spin_min_margin.GetValue()
        o._no_mirror_right      = self.cb_no_mirror.GetValue()
        o._remove_blank_pages   = self.cb_remove_blank.GetValue()
        o._blank_page_threshold = self.spin_blank_threshold.GetValue()
        o._print_font_scale     = self.spin_font_scale.GetValue()
        global PRINT_DEBUG
        o._print_debug          = self.cb_debug.GetValue()
        PRINT_DEBUG             = o._print_debug
        # Persistenza immediata (la scala non viene salvata)
        try:
            o._SavePageMargins()
        except Exception:
            pass
        if self.on_apply is not None:
            self.on_apply()

    def show(self):
        """Mostra il dialog in modo modale. Restituisce True se confermato."""
        result = self.dlg.ShowModal()
        self.dlg.Destroy()
        return result == wx.ID_OK


# ══════════════════════════════════════════════════════════════════════════════
# PrintManager  (mixin da aggiungere a SongpressFrame)
# ══════════════════════════════════════════════════════════════════════════════

class PrintManager:
    """
    Mixin che raccoglie tutto lo stato e i metodi legati alla stampa.

    Aggiungere come base di SongpressFrame e chiamare PrintManager.__init__(self)
    nel costruttore di SongpressFrame, PRIMA di _LoadPageMargins().
    """

    # ── Dizionario formato carta ───────────────────────────────────────────────

    _PAPER_SIZE_MM = _PAPER_SIZE_MM

    # ── Init ──────────────────────────────────────────────────────────────────

    def __init__(self):
        self._print_data = wx.PrintData()
        self._print_data.SetPaperId(wx.PAPER_A4)
        self._print_data.SetOrientation(wx.PORTRAIT)

        # Margini in mm
        self._margin_top    = 15
        self._margin_bottom = 15
        self._margin_left   = 15
        self._margin_right  = 15

        # Opzioni di stampa
        self._two_pages_per_sheet  = False
        self._columns_per_page     = 1
        self._fit_to_page          = False
        self._no_mirror_right      = False
        self._remove_blank_pages   = False
        self._blank_page_threshold = 5
        self._shrink_to_fit        = False
        self._min_margin_shrink    = 5
        self._print_font_scale     = 100
        self._print_options_pinned = False
        self._print_debug          = False

        self._preview_frame = None

    # ── Persist ───────────────────────────────────────────────────────────────

    def _SavePageMargins(self):
        """Salva margini, formato carta, orientamento e TUTTE le opzioni di stampa.

        NOTA: ``_print_font_scale`` (Scala %) non viene mai salvato:
        deve ripartire sempre da 100 ad ogni avvio.
        """
        try:
            self.config.SetPath('/PageSetup')
            self.config.Write('margin_top',           str(self._margin_top))
            self.config.Write('margin_bottom',        str(self._margin_bottom))
            self.config.Write('margin_left',          str(self._margin_left))
            self.config.Write('margin_right',         str(self._margin_right))
            self.config.Write('paper_id',             str(self._print_data.GetPaperId()))
            self.config.Write('orientation',          str(self._print_data.GetOrientation()))
            self.config.Write('shrink_to_fit',        '1' if self._shrink_to_fit else '0')
            self.config.Write('min_margin_shrink',    str(self._min_margin_shrink))
            # ── Opzioni del dialog «Opzioni di stampa» ────────────────────
            self.config.Write('two_pages_per_sheet',  '1' if self._two_pages_per_sheet else '0')
            self.config.Write('columns_per_page',     str(self._columns_per_page))
            self.config.Write('fit_to_page',          '1' if self._fit_to_page else '0')
            self.config.Write('no_mirror_right',      '1' if self._no_mirror_right else '0')
            self.config.Write('remove_blank_pages',   '1' if self._remove_blank_pages else '0')
            self.config.Write('blank_page_threshold', str(self._blank_page_threshold))
            self.config.Write('print_options_pinned', '1' if self._print_options_pinned else '0')
            self.config.Write('print_debug',          '1' if self._print_debug else '0')
            # Scala volutamente NON salvata (reset a 100 ad ogni riapertura).
            self.config.DeleteEntry('print_font_scale', False)
            self.config.Flush()
        except Exception:
            pass

    def _LoadPageMargins(self):
        """Ripristina margini, formato carta, orientamento e opzioni di riduzione."""
        try:
            self.config.SetPath('/PageSetup')
            top         = self.config.Read('margin_top')
            bottom      = self.config.Read('margin_bottom')
            left        = self.config.Read('margin_left')
            right       = self.config.Read('margin_right')
            if top:    self._margin_top    = int(top)
            if bottom: self._margin_bottom = int(bottom)
            if left:   self._margin_left   = int(left)
            if right:  self._margin_right  = int(right)
            paper_id    = self.config.Read('paper_id')
            if paper_id:
                self._print_data.SetPaperId(int(paper_id))
            orientation = self.config.Read('orientation')
            if orientation:
                self._print_data.SetOrientation(int(orientation))
            shrink      = self.config.Read('shrink_to_fit')
            if shrink:
                self._shrink_to_fit = (shrink == '1')
            min_m       = self.config.Read('min_margin_shrink')
            if min_m:
                self._min_margin_shrink = int(min_m)

            # ── Opzioni del dialog «Opzioni di stampa» ────────────────────
            def _rb(key, current):
                v = self.config.Read(key)
                return (v == '1') if v else current

            def _ri(key, current, lo=None, hi=None):
                v = self.config.Read(key)
                if not v:
                    return current
                try:
                    n = int(v)
                except ValueError:
                    return current
                if lo is not None and n < lo:
                    return current
                if hi is not None and n > hi:
                    return current
                return n

            self._two_pages_per_sheet  = _rb('two_pages_per_sheet',  self._two_pages_per_sheet)
            self._columns_per_page     = _ri('columns_per_page',     self._columns_per_page, 1, 2)
            self._fit_to_page          = _rb('fit_to_page',          self._fit_to_page)
            self._no_mirror_right      = _rb('no_mirror_right',      self._no_mirror_right)
            self._remove_blank_pages   = _rb('remove_blank_pages',   self._remove_blank_pages)
            self._blank_page_threshold = _ri('blank_page_threshold', self._blank_page_threshold, 1, 95)
            self._print_options_pinned = _rb('print_options_pinned', self._print_options_pinned)
            global PRINT_DEBUG
            self._print_debug = _rb('print_debug', self._print_debug)
            PRINT_DEBUG = self._print_debug

            # La scala non è persistente: sempre 100% all'avvio.
            self._print_font_scale = 100
        except Exception:
            pass

    # ── Helpers ───────────────────────────────────────────────────────────────

    def _GetPaperSizeMm(self):
        """Restituisce (w_mm, h_mm) del foglio tenendo conto dell'orientamento."""
        pid  = self._print_data.GetPaperId()
        w, h = self._PAPER_SIZE_MM.get(pid, (210.0, 297.0))
        if self._print_data.GetOrientation() == wx.LANDSCAPE:
            w, h = h, w
        return w, h

    def _make_printout(self, title=None):
        """Crea e restituisce un SongpressPrintout configurato.

        Se c'è una selezione attiva nell'editor, stampa solo quella;
        altrimenti stampa l'intero documento (gestito da _ensure_layout).
        """
        if title is None:
            title = _("Print")
        return SongpressPrintout(
            self, title,
            two_pages_per_sheet=self._two_pages_per_sheet,
            font_scale=getattr(self, '_print_font_scale', 100),
        )

    # ── Azioni ────────────────────────────────────────────────────────────────

    def OnPageSetup(self, evt):
        """Apre il dialog di impostazione pagina (formato, orientamento, margini)."""
        data = wx.PageSetupDialogData(self._print_data)
        data.SetMarginTopLeft(wx.Point(self._margin_left, self._margin_top))
        data.SetMarginBottomRight(wx.Point(self._margin_right, self._margin_bottom))
        dlg = wx.PageSetupDialog(self.frame, data)
        if dlg.ShowModal() == wx.ID_OK:
            result = dlg.GetPageSetupData()
            self._print_data    = wx.PrintData(result.GetPrintData())
            tl                  = result.GetMarginTopLeft()
            br                  = result.GetMarginBottomRight()
            self._margin_left   = tl.x
            self._margin_top    = tl.y
            self._margin_right  = br.x
            self._margin_bottom = br.y
            w_mm, h_mm = self._GetPaperSizeMm()
            self.previewCanvas.SetPageSizeMm(w_mm, h_mm)
            self.previewCanvas.SetPageMarginsMm(self._margin_top, self._margin_bottom)
        dlg.Destroy()

    def _reopen_print_options_if_pinned(self):
        """Riapre il dialog opzioni di stampa se il pin era attivo.
        Chiamato da wx.CallLater dopo che OnPrintPreview ha creato il nuovo pf."""
        if not getattr(self, '_print_options_pinned', False):
            return
        pf = getattr(self, '_preview_frame', None)
        if pf is None or not pf.IsShown():
            return

        _dlg_ref = [None]

        def _do_apply():
            self.previewCanvas.SetColumns(self._columns_per_page)
            self.previewCanvas.Refresh(self._get_display_text())
            if self._print_options_pinned and _dlg_ref[0] is not None:
                dlg = _dlg_ref[0]
                dlg.EndModal(wx.ID_OK)

                def _deferred_reopen():
                    pf.Close()
                    self.OnPrintPreview(None)
                    wx.CallAfter(
                        wx.CallLater, 50,
                        lambda: self._reopen_print_options_if_pinned()
                    )
                wx.CallAfter(_deferred_reopen)
            else:
                pf.Close()
                wx.CallAfter(self.OnPrintPreview, None)

        self._ask_two_pages_per_sheet(parent=pf, on_apply=_do_apply, _dlg_ref=_dlg_ref)

    def _ask_two_pages_per_sheet(self, parent=None, on_apply=None, _dlg_ref=None):
        """
        Mostra il dialog «Opzioni di stampa» (grafica ottimizzata).

        Args:
            parent:   finestra padre (default: self.frame)
            on_apply: callable invocato dopo il salvataggio delle opzioni
            _dlg_ref: lista [None] popolata con l'istanza wx.Dialog
        """
        dlg_wrapper = PrintOptionsDialog(
            owner=self,
            parent=parent,
            on_apply=on_apply,
            _dlg_ref=_dlg_ref,
        )
        return dlg_wrapper.show()

    def OnPrint(self, evt):
        """Stampa il brano esattamente come mostrato nell'anteprima."""
        if getattr(self.pref, 'showPrintPreview', True):
            self.OnPrintPreview(evt)
            return

        pdd = wx.PrintDialogData(self._print_data)
        dlg = wx.PrintDialog(self.frame, pdd)
        if dlg.ShowModal() != wx.ID_OK:
            dlg.Destroy()
            return
        self._print_data = wx.PrintData(dlg.GetPrintDialogData().GetPrintData())
        dlg.Destroy()

        pdd2    = wx.PrintDialogData(self._print_data)
        printer = wx.Printer(pdd2)
        title   = os.path.splitext(os.path.basename(self.document))[0] \
                  if self.document else _("Print")
        printout = self._make_printout(title)
        success  = printer.Print(self.frame, printout, False)
        if not success:
            if printer.GetLastError() == wx.PRINTER_ERROR:
                wx.MessageBox(
                    _("An error occurred while printing.\nPlease check your printer settings."),
                    _("Print error"),
                    wx.OK | wx.ICON_ERROR,
                    self.frame,
                )
            # In caso di fallimento wx non prende ownership: distruggiamo noi
            printout.Destroy()
        # In caso di successo wx prende ownership del printout: non chiamare Destroy()

    def OnPrintPreview(self, evt):
        """Mostra l'anteprima di stampa del brano."""
        self.previewCanvas.Refresh(self._get_display_text())
        base_title = os.path.splitext(os.path.basename(self.document))[0] \
                     if self.document else _("Print")
        start, end = self.text.GetSelection()
        has_sel    = (start != end)
        if has_sel:
            title = u"{} — {}".format(base_title, _("Selection"))
        else:
            title = base_title

        printout1 = self._make_printout(title)
        printout2 = self._make_printout(title)
        preview   = wx.PrintPreview(printout1, printout2, self._print_data)

        if not preview.IsOk():
            wx.MessageBox(
                _("Unable to create print preview.\nPlease check your printer settings."),
                _("Print preview error"),
                wx.OK | wx.ICON_ERROR,
                self.frame,
            )
            return

        _always_on_top = getattr(getattr(self, 'pref', None), 'printPreviewAlwaysOnTop', False)
        _pf_style = wx.DEFAULT_FRAME_STYLE | wx.STAY_ON_TOP if _always_on_top else wx.DEFAULT_FRAME_STYLE
        pf = wx.PreviewFrame(preview, self.frame, _("Print preview"),
                             style=_pf_style)
        pf.Initialize()
        self._preview_frame = pf

        # ── Personalizzazione toolbar di anteprima ─────────────────────
        ctrl_bar = None
        get_cb   = getattr(pf, 'GetControlBar', None)
        if get_cb is not None:
            ctrl_bar = get_cb()
        if ctrl_bar is None:
            for child in pf.GetChildren():
                if isinstance(child, wx.PreviewControlBar):
                    ctrl_bar = child
                    break

        if ctrl_bar is not None:
            # Rinomina bottoni nativi seguendo la locale attiva
            _label_map = {
                "Print":    _("Print..."),
                "Print...": _("Print..."),
                "Next":     _("Next page"),
                "Prev":     _("Previous page"),
                "Previous": _("Previous page"),
                "First":    _("First page"),
                "Last":     _("Last page"),
                "Close":    _("Close"),
            }
            for child in ctrl_bar.GetChildren():
                if isinstance(child, wx.Button):
                    lbl = child.GetLabel().strip()
                    if lbl in _label_map:
                        child.SetLabel(_label_map[lbl])
            # ATTENZIONE: wx.Window.FindWindowById è di fatto una ricerca
            # GLOBALE (parent=None): con più PreviewFrame in vita — succede
            # quando la preview viene ricreata dopo «OK» in Opzioni di stampa,
            # perché la vecchia finestra è solo in attesa di distruzione —
            # restituisce i bottoni della barra VECCHIA. Cerchiamo quindi
            # esplicitamente solo fra i figli di questa control bar.
            def _find_child_by_id(parent, wid):
                if wid is None:
                    return None
                for ch in parent.GetChildren():
                    if ch.GetId() == wid:
                        return ch
                return None

            _preview_print_id = getattr(wx, 'ID_PREVIEW_PRINT', wx.ID_PRINT)
            btn_print = _find_child_by_id(ctrl_bar, _preview_print_id)
            if btn_print is None:
                btn_print = _find_child_by_id(ctrl_bar, wx.ID_PRINT)
            if btn_print is not None:
                btn_print.SetLabel(_("Print..."))

            # Registro dei percorsi icona dei bottoni personalizzati:
            # verranno ridimensionati tutti alla stessa misura più avanti.
            _custom_icon_paths = {}

            # Icona per il bottone «Stampa» nativo della preview bar
            if btn_print is not None:
                _print_icon_path = glb.AddPath('img/print_icon.png')
                if os.path.isfile(_print_icon_path):
                    _custom_icon_paths[btn_print] = _print_icon_path
                    img = wx.Image(_print_icon_path, wx.BITMAP_TYPE_PNG)
                    btn_print.SetBitmap(wx.Bitmap(img))
                    btn_print.SetBitmapPosition(wx.LEFT)

            # Icone per i bottoni nativi di zoom (- e +) della preview bar,
            # e per le frecce verdi native Precedente/Successiva/
            # Prima/Ultima pagina. Sono tutti wx.BitmapButton SENZA
            # etichetta testuale: vanno identificati tramite gli ID nativi
            # assegnati da wxWidgets alla control bar, non per label.
            _minus_icon_path      = glb.AddPath('img/minus.png')
            _plus_icon_path       = glb.AddPath('img/plus.png')
            _prev_icon_path       = glb.AddPath('img/left.png')
            _next_icon_path       = glb.AddPath('img/right.png')
            _first_icon_path      = glb.AddPath('img/first_page.png')
            _last_icon_path       = glb.AddPath('img/last_page.png')

            _zoom_in_id  = getattr(wx, 'ID_PREVIEW_ZOOM_IN', 9)
            _zoom_out_id = getattr(wx, 'ID_PREVIEW_ZOOM_OUT', 10)
            _prev_id     = getattr(wx, 'ID_PREVIEW_PREVIOUS', 3)
            _next_id     = getattr(wx, 'ID_PREVIEW_NEXT', 2)
            _first_id    = getattr(wx, 'ID_PREVIEW_FIRST', 6)
            _last_id     = getattr(wx, 'ID_PREVIEW_LAST', 7)

            _nav_icon_by_id = {
                _zoom_out_id: _minus_icon_path,
                _zoom_in_id:  _plus_icon_path,
                _prev_id:     _prev_icon_path,
                _next_id:     _next_icon_path,
                _first_id:    _first_icon_path,
                _last_id:     _last_icon_path,
            }

            def _iter_descendants(win):
                for ch in win.GetChildren():
                    yield ch
                    yield from _iter_descendants(ch)

            for child in _iter_descendants(ctrl_bar):
                if not isinstance(child, wx.AnyButton):
                    continue
                _icon_path = _nav_icon_by_id.get(child.GetId())
                if _icon_path and os.path.isfile(_icon_path):
                    _custom_icon_paths[child] = _icon_path
                    img = wx.Image(_icon_path, wx.BITMAP_TYPE_PNG)
                    child.SetBitmap(wx.Bitmap(img))
                    child.SetBitmapPosition(wx.LEFT)

            # Bottone «Impostazioni driver»
            btn_driver = wx.Button(ctrl_bar, wx.ID_ANY, _("Driver settings..."))
            _driver_icon_path = glb.AddPath('img/option_printer.png')
            if os.path.isfile(_driver_icon_path):
                _custom_icon_paths[btn_driver] = _driver_icon_path
                img = wx.Image(_driver_icon_path, wx.BITMAP_TYPE_PNG)
                btn_driver.SetBitmap(wx.Bitmap(img))
                btn_driver.SetBitmapPosition(wx.LEFT)
            else:
                # Icona di fallback: stampante dal catalogo wxArtProvider
                bmp = wx.ArtProvider.GetBitmap(wx.ART_PRINT, wx.ART_BUTTON, wx.Size(16, 16))
                if bmp.IsOk():
                    btn_driver.SetBitmap(bmp)
                    btn_driver.SetBitmapPosition(wx.LEFT)

            def on_driver_settings(e):
                hwnd = None
                if wx.Platform == '__WXMSW__':
                    try:
                        hwnd = pf.GetHandle()
                    except Exception:
                        hwnd = None
                orient_before = self._print_data.GetOrientation()
                try:
                    self._print_data = _open_driver_settings(self._print_data, parent_hwnd=hwnd)
                except Exception as exc:
                    wx.MessageBox(
                        _("Impossibile aprire le impostazioni del driver:\n{err}").format(err=exc),
                        _("Errore"), wx.OK | wx.ICON_ERROR, pf
                    )
                    return
                orient_after  = self._print_data.GetOrientation()
                # Aggiorna la status bar (duplex/colore/orientamento possono essere cambiati)
                try:
                    _sb._refresh_labels()
                except Exception:
                    pass
                # Se l'orientamento è cambiato la preview mostra ancora il foglio
                # nel verso sbagliato: bisogna ricrearla con i nuovi dati di stampa.
                if orient_after != orient_before:
                    pf.Close()
                    wx.CallAfter(self.OnPrintPreview, None)

            btn_driver.Bind(wx.EVT_BUTTON, on_driver_settings)

            # Bottone «Opzioni di stampa»
            btn_options = wx.Button(ctrl_bar, wx.ID_ANY, _("Print options..."))
            _icon_path  = glb.AddPath('img/print_icon2.png')
            if os.path.isfile(_icon_path):
                _custom_icon_paths[btn_options] = _icon_path
                img = wx.Image(_icon_path, wx.BITMAP_TYPE_PNG)
                btn_options.SetBitmap(wx.Bitmap(img))
                btn_options.SetBitmapPosition(wx.LEFT)

            def on_print_options(e):
                _dlg_ref = [None]

                def _do_apply():
                    self.previewCanvas.SetColumns(self._columns_per_page)
                    self.previewCanvas.Refresh(self._get_display_text())
                    if self._print_options_pinned and _dlg_ref[0] is not None:
                        _dlg_ref[0].EndModal(wx.ID_OK)

                        def _deferred_reopen():
                            pf.Close()
                            self.OnPrintPreview(None)
                            wx.CallAfter(
                                wx.CallLater, 50,
                                lambda: self._reopen_print_options_if_pinned()
                            )
                        wx.CallAfter(_deferred_reopen)
                    else:
                        pf.Close()
                        wx.CallAfter(self.OnPrintPreview, None)

                self._ask_two_pages_per_sheet(
                    parent=pf, on_apply=_do_apply, _dlg_ref=_dlg_ref
                )

            btn_options.Bind(wx.EVT_BUTTON, on_print_options)

            # Bottone «Impostazione pagina»
            btn_page_setup  = wx.Button(ctrl_bar, wx.ID_ANY, _("Page setup..."))
            _page_icon_path = glb.AddPath('img/file-black-icon.png')
            if os.path.isfile(_page_icon_path):
                _custom_icon_paths[btn_page_setup] = _page_icon_path
                img = wx.Image(_page_icon_path, wx.BITMAP_TYPE_PNG)
                btn_page_setup.SetBitmap(wx.Bitmap(img))
                btn_page_setup.SetBitmapPosition(wx.LEFT)

            def on_page_setup_preview(e):
                data = wx.PageSetupDialogData(self._print_data)
                data.SetMarginTopLeft(wx.Point(self._margin_left, self._margin_top))
                data.SetMarginBottomRight(wx.Point(self._margin_right, self._margin_bottom))
                dlg = wx.PageSetupDialog(pf, data)
                if dlg.ShowModal() == wx.ID_OK:
                    result = dlg.GetPageSetupData()
                    self._print_data    = wx.PrintData(result.GetPrintData())
                    tl                  = result.GetMarginTopLeft()
                    br                  = result.GetMarginBottomRight()
                    self._margin_left   = tl.x
                    self._margin_top    = tl.y
                    self._margin_right  = br.x
                    self._margin_bottom = br.y
                    dlg.Destroy()
                    pf.Close()
                    wx.CallAfter(self.OnPrintPreview, None)
                else:
                    dlg.Destroy()

            btn_page_setup.Bind(wx.EVT_BUTTON, on_page_setup_preview)

            # Bottone «Chiudi»
            btn_close = wx.Button(ctrl_bar, wx.ID_ANY, _("Close"))
            _close_icon_path = glb.AddPath('img/close_print_dialog.png')
            if os.path.isfile(_close_icon_path):
                _custom_icon_paths[btn_close] = _close_icon_path
                img = wx.Image(_close_icon_path, wx.BITMAP_TYPE_PNG)
                btn_close.SetBitmap(wx.Bitmap(img))
                btn_close.SetBitmapPosition(wx.LEFT)
            btn_close.Bind(wx.EVT_BUTTON, lambda e: pf.Close())

            # Rimuove il bottone «Chiudi» nativo della preview control bar
            # (altrimenti compare doppio, senza icona, accanto al nostro).
            # Si cercano TUTTI i candidati fra i figli di *questa* barra:
            # per id wx.ID_PREVIEW_CLOSE/wx.ID_CANCEL oppure per etichetta.
            _close_ids = set()
            for _n in ('ID_PREVIEW_CLOSE', 'ID_CANCEL', 'ID_CLOSE'):
                _v = getattr(wx, _n, None)
                if _v is not None:
                    _close_ids.add(_v)
            _close_labels = {'Close', 'Chiudi', _('Close')}

            _natives = []
            for child in ctrl_bar.GetChildren():
                if child is btn_close or not isinstance(child, wx.Button):
                    continue
                if child.GetId() in _close_ids or child.GetLabel().strip() in _close_labels:
                    _natives.append(child)

            _cb_sizer = ctrl_bar.GetSizer()
            for _native_close in _natives:
                try:
                    if _cb_sizer:
                        _cb_sizer.Detach(_native_close)
                    _native_close.Hide()
                    # Distruzione differita: eliminarlo subito dentro la
                    # costruzione della barra può lasciare il sizer incoerente.
                    wx.CallAfter(_native_close.Destroy)
                except Exception:
                    pass

            # Inserisce i bottoni personalizzati nella toolbar
            # (le etichette duplex/colore sono nella status bar in basso)
            sizer = ctrl_bar.GetSizer()
            if sizer:
                spacer_idx = None
                for i in range(sizer.GetItemCount() - 1, -1, -1):
                    item = sizer.GetItem(i)
                    if item.IsSpacer() and item.GetProportion() > 0:
                        spacer_idx = i
                        break
                ins = (spacer_idx + 1) if spacer_idx is not None else sizer.GetItemCount()
                sizer.Insert(ins,     btn_page_setup, 0, wx.ALL | wx.ALIGN_CENTER_VERTICAL, 2)
                sizer.Insert(ins + 1, btn_driver,     0, wx.ALL | wx.ALIGN_CENTER_VERTICAL, 2)
                sizer.Insert(ins + 2, btn_options,    0, wx.ALL | wx.ALIGN_CENTER_VERTICAL, 2)
                sizer.Insert(ins + 3, btn_close,      0, wx.ALL | wx.ALIGN_CENTER_VERTICAL, 2)

            # Uniforma altezza dei bottoni personalizzati a quella dei
            # bottoni nativi della preview bar (quelli di sinistra).
            def _native_ref_height():
                # Prova prima il bottone «Print» nativo, poi qualunque
                # altro bottone nativo diverso dai nostri custom.
                _custom = (btn_page_setup, btn_driver, btn_options, btn_close)
                ref = btn_print
                if ref is not None and ref not in _custom:
                    h = ref.GetBestSize().height
                    if h > 4:
                        return h
                for child in ctrl_bar.GetChildren():
                    if isinstance(child, wx.Button) and child not in _custom:
                        h = child.GetBestSize().height
                        if h > 4:
                            return h
                return btn_options.GetBestSize().height

            ref_h = _native_ref_height()

            # Ridimensiona tutte le icone dei bottoni custom alla stessa
            # misura, ricavata dall'altezza dei bottoni nativi (con un
            # margine per il bordo del bottone). Rilegge sempre dal file
            # sorgente per non accumulare perdite di qualità.
            _icon_cache = {}

            def _apply_uniform_icons(btn_h):
                icon_sz = int(btn_h) - 8
                if icon_sz < 8:
                    icon_sz = 8
                if icon_sz > 24:
                    icon_sz = 24
                if _icon_cache.get('sz') == icon_sz:
                    return
                _icon_cache['sz'] = icon_sz
                for _b, _p in _custom_icon_paths.items():
                    try:
                        im = wx.Image(_p, wx.BITMAP_TYPE_PNG)
                        if im.GetWidth() != icon_sz or im.GetHeight() != icon_sz:
                            im = im.Scale(icon_sz, icon_sz, wx.IMAGE_QUALITY_HIGH)
                        _b.SetBitmap(wx.Bitmap(im))
                        _b.SetBitmapPosition(wx.LEFT)
                    except Exception:
                        pass

            _apply_uniform_icons(ref_h)
            for btn in (btn_page_setup, btn_driver, btn_options, btn_close):
                btn.SetMinSize(wx.Size(btn.GetBestSize().width, ref_h))
            ctrl_bar.Layout()

            def _equalize_heights():
                try:
                    h = _native_ref_height()
                    if h < 4:
                        return
                    _apply_uniform_icons(h)
                    for btn in (btn_page_setup, btn_driver, btn_options, btn_close):
                        bw = btn.GetBestSize().width
                        btn.SetMinSize(wx.Size(bw, h))
                        btn.SetSize(wx.Size(bw, h))
                    ctrl_bar.Layout()
                except Exception:
                    pass
            wx.CallAfter(_equalize_heights)

        pf.Show()

        # ── Barra di stato personalizzata (fronte/retro + colore) ─────────────
        # wx.StatusBar nativa non supporta testo colorato per campo su Windows,
        # quindi usiamo un wx.Panel agganciato come StatusBar owner-draw.
        class _ColoredStatusBar(wx.StatusBar):
            """
            Status bar con testo colorato per i campi 1, 2 e icona nel campo 3.

            Campo 0 → testo nativo wxWidgets ("Pagina N di M").
            Campo 1 → stato fronte/retro.
            Campo 2 → modalità colore.
            Campo 3 → icona orientamento foglio (wx.StaticBitmap disegnata a codice).

            Se live_poll=True un wx.Timer interroga il driver ogni _POLL_MS ms
            così le etichette si aggiornano in tempo reale anche mentre il
            pannello del driver è aperto.
            Se live_poll=False la lettura avviene una sola volta all'apertura
            e rimane fissa fino alla chiusura della preview.
            """

            _POLL_MS = 1500   # intervallo di polling in millisecondi

            # ── dizionari statici ──────────────────────────────────────────
            _DUPLEX_LABELS = {
                wx.DUPLEX_SIMPLEX:    (lambda: _("Duplex: off (simplex)"),           wx.Colour(160, 160, 160)),
                wx.DUPLEX_HORIZONTAL: (lambda: _("Duplex: ON — short-edge binding"), wx.Colour( 20, 140,  60)),
                wx.DUPLEX_VERTICAL:   (lambda: _("Duplex: ON — long-edge binding"),  wx.Colour( 20, 140,  60)),
            }
            _COLOR_LABELS = {
                "color":   (lambda: _("Color: color print"),   wx.Colour(  0, 100, 200)),
                "mono":    (lambda: _("Color: black & white"), wx.Colour( 80,  80,  80)),
                "unknown": (lambda: _("Color: unknown"),       wx.Colour(180,  80,   0)),
            }

            def __init__(self, parent, print_data_ref, live_poll=True,
                         scope_text="", scope_colour=None):
                super().__init__(parent, style=wx.STB_DEFAULT_STYLE)
                # print_data_ref: callable → wx.PrintData corrente
                self._get_pd   = print_data_ref
                self._live     = live_poll

                # Campo 4: larghezza fissa per l'icona (bitmap + padding)
                self.SetFieldsCount(5)
                self.SetStatusWidths([-1, -2, -2, -2, 44])

                # Campo 1: fronte/retro
                self._lbl_duplex = wx.StaticText(self, wx.ID_ANY, "")
                _f1 = self._lbl_duplex.GetFont()
                _f1.SetWeight(wx.FONTWEIGHT_BOLD)
                self._lbl_duplex.SetFont(_f1)

                # Campo 2: colore
                self._lbl_color = wx.StaticText(self, wx.ID_ANY, "")
                _f2 = self._lbl_color.GetFont()
                _f2.SetWeight(wx.FONTWEIGHT_BOLD)
                self._lbl_color.SetFont(_f2)

                # Campo 3: ambito di stampa (intero documento / solo selezione).
                # È fisso per la sessione di anteprima, quindi impostato una volta.
                self._lbl_scope = wx.StaticText(self, wx.ID_ANY, scope_text)
                _f3 = self._lbl_scope.GetFont()
                _f3.SetWeight(wx.FONTWEIGHT_BOLD)
                self._lbl_scope.SetFont(_f3)
                if scope_colour is not None:
                    self._lbl_scope.SetForegroundColour(scope_colour)

                # Campo 4: icona orientamento — placeholder, bitmap creata al primo reposition
                self._bmp_orient = _make_orientation_bitmap(False, 20)
                self._lbl_orient = wx.StaticBitmap(self, wx.ID_ANY, self._bmp_orient)
                self._last_orient = None   # None → forza primo aggiornamento

                # Stato precedente per evitare refresh inutili
                self._last_duplex = None
                self._last_color  = None

                # Prima lettura sempre immediata
                self._refresh_labels()

                # Timer: avviato solo se live_poll è attivo
                self._timer = wx.Timer(self)
                self.Bind(wx.EVT_TIMER, self._on_timer, self._timer)
                if self._live:
                    self._timer.Start(self._POLL_MS)

                self.Bind(wx.EVT_SIZE, self._on_size)
                wx.CallAfter(self._reposition)

            # ── aggiornamento etichette ────────────────────────────────────

            def _resolve_duplex(self):
                """Restituisce (text, colour) per lo stato duplex corrente."""
                try:
                    mode = _get_duplex_mode(self._get_pd())
                except Exception:
                    mode = wx.DUPLEX_SIMPLEX
                entry = self._DUPLEX_LABELS.get(mode)
                if entry:
                    text_fn, colour = entry
                    return text_fn(), colour
                return _("Duplex: unknown (mode {})".format(mode)), wx.Colour(180, 80, 0)

            def _resolve_color(self):
                """Restituisce (text, colour) per la modalità colore corrente."""
                try:
                    mode = _get_color_mode(self._get_pd())
                except Exception:
                    mode = "unknown"
                entry = self._COLOR_LABELS.get(mode)
                if entry:
                    text_fn, colour = entry
                    return text_fn(), colour
                return _("Color: unknown"), wx.Colour(180, 80, 0)

            def _resolve_orient(self):
                """Restituisce il bool landscape per l'orientamento corrente."""
                try:
                    orient = _get_orientation(self._get_pd())
                except Exception:
                    orient = wx.PORTRAIT
                return orient == wx.LANDSCAPE

            def _refresh_labels(self):
                """Interroga il driver e aggiorna le etichette se cambiate."""
                changed = False

                d_text, d_colour = self._resolve_duplex()
                if d_text != self._last_duplex:
                    self._last_duplex = d_text
                    self._lbl_duplex.SetLabel(d_text)
                    self._lbl_duplex.SetForegroundColour(d_colour)
                    changed = True

                c_text, c_colour = self._resolve_color()
                if c_text != self._last_color:
                    self._last_color = c_text
                    self._lbl_color.SetLabel(c_text)
                    self._lbl_color.SetForegroundColour(c_colour)
                    changed = True

                landscape = self._resolve_orient()
                if landscape != self._last_orient:
                    self._last_orient = landscape
                    # Ricostruisce il bitmap con l'altezza attuale del campo
                    try:
                        field_h = self.GetFieldRect(4).height
                    except Exception:
                        field_h = 20
                    self._bmp_orient = _make_orientation_bitmap(landscape, field_h)
                    self._lbl_orient.SetBitmap(self._bmp_orient)
                    changed = True

                if changed:
                    wx.CallAfter(self._reposition)

            def _on_timer(self, evt):
                self._refresh_labels()

            # ── layout ────────────────────────────────────────────────────

            def _reposition(self):
                try:
                    r1 = self.GetFieldRect(1)
                    r2 = self.GetFieldRect(2)
                    r3 = self.GetFieldRect(3)
                    r4 = self.GetFieldRect(4)
                    pad = 4
                    for lbl, r in ((self._lbl_duplex, r1),
                                   (self._lbl_color, r2),
                                   (self._lbl_scope, r3)):
                        _, h = lbl.GetBestSize()
                        y = r.y + max(0, (r.height - h) // 2)
                        lbl.SetPosition(wx.Point(r.x + pad, y))
                        lbl.SetSize(wx.Size(r.width - pad * 2, h))
                    # Campo 4: icona centrata nel campo
                    bw, bh = self._lbl_orient.GetBestSize()
                    ix = r4.x + max(0, (r4.width  - bw) // 2)
                    iy = r4.y + max(0, (r4.height - bh) // 2)
                    self._lbl_orient.SetPosition(wx.Point(ix, iy))
                except Exception:
                    pass

            def _on_size(self, evt):
                evt.Skip()
                wx.CallAfter(self._reposition)

            def stop_timer(self):
                """Ferma il polling; chiamato alla chiusura della preview."""
                try:
                    if self._timer.IsRunning():
                        self._timer.Stop()
                except Exception:
                    pass

        _live_poll = getattr(self, 'pref', None)
        _live_poll = getattr(_live_poll, 'liveDriverPoll', True) if _live_poll else True
        if has_sel:
            _scope_text   = _("Printing selection only")
            _scope_colour = wx.Colour(180, 80, 0)      # ambra: NON tutto il doc
        else:
            _scope_text   = _("Printing whole document")
            _scope_colour = wx.Colour(20, 140, 60)     # verde: intero documento
        _sb = _ColoredStatusBar(pf, lambda: self._print_data, live_poll=_live_poll,
                                scope_text=_scope_text, scope_colour=_scope_colour)
        pf.SetStatusBar(_sb)

        # Al chiusura della preview: ferma il timer di polling e ripristina il canvas
        def _on_preview_close(e):
            e.Skip()
            _sb.stop_timer()
            wx.CallAfter(
                self.previewCanvas.Refresh,
                self._strip_hash_commands(self.text.GetText()),
            )
        pf.Bind(wx.EVT_CLOSE, _on_preview_close)
        # Dimensiona la finestra di anteprima al 90% dell'area di lavoro
        display_idx = wx.Display.GetFromWindow(self.frame)
        if display_idx == wx.NOT_FOUND:
            display_idx = 0
        display     = wx.Display(display_idx)
        client_area = display.GetClientArea()
        preview_w   = min(int(client_area.width  * 0.90), client_area.width)
        preview_h   = min(int(client_area.height * 0.90), client_area.height)
        pf.SetSize(wx.Size(preview_w, preview_h))
        pf.CentreOnScreen()
