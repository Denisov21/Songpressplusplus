# -*- coding: utf-8 -*-

import wx

from .FontComboBox import FontComboBox
from . import Editor

_ = wx.GetTranslation

import wx
import wx.xrc
import wx.adv

# Patch Debian/GTK - visibilita' delle frecce "+"/"-" degli SpinCtrl.
# Su wxGTK i pulsanti freccia sono piu' larghi che su Windows: una size fissa
# calibrata su MSW li taglia. Su piattaforme non-MSW aggiungiamo un margine.
# (Stesso valore di _spin_size() in SongpressFrame.py.)
_SPIN_EXTRA_WIDTH = 0 if wx.Platform == '__WXMSW__' else 46

class PreferencesDialog(wx.Dialog):

    def __init__(self, parent, pref=None):
        wx.Dialog.__init__(self, parent, id=wx.ID_ANY, title=_(u"Songpress++ options"), pos=wx.DefaultPosition,
                                             size=wx.Size(760, 860), style=wx.DEFAULT_DIALOG_STYLE | wx.RESIZE_BORDER)
        if pref is not None:
            self.pref = pref

        # Dimensione minima finestra: sotto questa soglia compaiono le scrollbar
        # nella scheda Editor (barra a destra e in basso) invece di schiacciare
        # l'anteprima.
        self.SetSizeHints(wx.Size(700, 640), wx.DefaultSize)

        bSizer10 = wx.BoxSizer(wx.VERTICAL)

        self.notebook = wx.Notebook(self, wx.ID_ANY, wx.DefaultPosition, wx.DefaultSize, 0)
        # Scheda "Editor": pannello scorrevole così, quando la finestra è troppo
        # piccola per contenere tutte le righe colore + l'anteprima, compaiono le
        # barre di scorrimento (destra = verticale, bassa = orizzontale) invece di
        # comprimere l'anteprima.
        self.general = wx.ScrolledWindow(self.notebook, wx.ID_ANY, wx.DefaultPosition, wx.DefaultSize,
                                         wx.HSCROLL | wx.VSCROLL | wx.TAB_TRAVERSAL)
        self.general.SetScrollRate(10, 10)
        bSizer11 = wx.BoxSizer(wx.VERTICAL)

        # ── Gruppo: Editor ───────────────────────────────────────────
        grpEditor = wx.StaticBoxSizer(wx.StaticBox(self.general, wx.ID_ANY, _(u"Editor font")), wx.VERTICAL)

        bSizer12 = wx.BoxSizer(wx.HORIZONTAL)
        self.label1 = wx.StaticText(self.general, wx.ID_ANY, _(u"Font"), wx.DefaultPosition, wx.DefaultSize, 0)
        self.label1.Wrap(-1)
        bSizer12.Add(self.label1, 0, wx.ALIGN_CENTER_VERTICAL | wx.RIGHT, 5)
        self.fontCB = FontComboBox(self.general, wx.ID_ANY, self.pref.editorFace)
        bSizer12.Add(self.fontCB, 1, wx.ALIGN_CENTER_VERTICAL | wx.RIGHT, 8)
        self.m_staticText8 = wx.StaticText(self.general, wx.ID_ANY, _(u"Size"), wx.DefaultPosition, wx.DefaultSize, 0)
        self.m_staticText8.Wrap(-1)
        bSizer12.Add(self.m_staticText8, 0, wx.ALIGN_CENTER_VERTICAL | wx.RIGHT, 5)
        sizeCBChoices = [_(u"7"), _(u"8"), _(u"9"), _(u"10"), _(u"11"), _(u"12"), _(u"13"), _(u"14"), _(u"16"), _(u"18"), _(u"20")]
        self.sizeCB = wx.ComboBox(self.general, wx.ID_ANY, _(u"12"), wx.DefaultPosition, wx.DefaultSize, sizeCBChoices, 0)
        self.sizeCB.SetMinSize(wx.Size(100, -1))
        bSizer12.Add(self.sizeCB, 0, wx.ALIGN_CENTER_VERTICAL)
        grpEditor.Add(bSizer12, 0, wx.EXPAND | wx.ALL, 5)

        # Editor background colour row
        bSizerEditorBg = wx.BoxSizer(wx.HORIZONTAL)
        self.labelEditorBg = wx.StaticText(self.general, wx.ID_ANY, _(u"Editor background colour"), wx.DefaultPosition, wx.DefaultSize, 0)
        self.labelEditorBg.Wrap(-1)
        bSizerEditorBg.Add(self.labelEditorBg, 1, wx.ALIGN_CENTER_VERTICAL | wx.RIGHT, 5)
        self.editorBgHexCtrl = wx.TextCtrl(self.general, wx.ID_ANY, u"#FFFFFF", wx.DefaultPosition, wx.Size(80, -1), 0)
        bSizerEditorBg.Add(self.editorBgHexCtrl, 0, wx.ALIGN_CENTER_VERTICAL | wx.RIGHT, 5)
        self.editorBgBtn = wx.Button(self.general, wx.ID_ANY, _(u"Pick…"), wx.DefaultPosition, wx.Size(60, -1), 0)
        bSizerEditorBg.Add(self.editorBgBtn, 0, wx.ALIGN_CENTER_VERTICAL | wx.RIGHT, 5)
        self.editorBgSwatch = wx.Panel(self.general, wx.ID_ANY, wx.DefaultPosition, wx.Size(24, 24), wx.BORDER_SIMPLE)
        bSizerEditorBg.Add(self.editorBgSwatch, 0, wx.ALIGN_CENTER_VERTICAL)
        grpEditor.Add(bSizerEditorBg, 0, wx.EXPAND | wx.ALL, 5)

        # Selection colour row
        bSizerSelColour = wx.BoxSizer(wx.HORIZONTAL)
        self.labelSelColour = wx.StaticText(self.general, wx.ID_ANY, _(u"Selection colour"), wx.DefaultPosition, wx.DefaultSize, 0)
        self.labelSelColour.Wrap(-1)
        bSizerSelColour.Add(self.labelSelColour, 1, wx.ALIGN_CENTER_VERTICAL | wx.RIGHT, 5)
        self.selColourHexCtrl = wx.TextCtrl(self.general, wx.ID_ANY, u"#C0C0C0", wx.DefaultPosition, wx.Size(80, -1), 0)
        bSizerSelColour.Add(self.selColourHexCtrl, 0, wx.ALIGN_CENTER_VERTICAL | wx.RIGHT, 5)
        self.selColourBtn = wx.Button(self.general, wx.ID_ANY, _(u"Pick…"), wx.DefaultPosition, wx.Size(60, -1), 0)
        bSizerSelColour.Add(self.selColourBtn, 0, wx.ALIGN_CENTER_VERTICAL | wx.RIGHT, 5)
        self.selColourSwatch = wx.Panel(self.general, wx.ID_ANY, wx.DefaultPosition, wx.Size(24, 24), wx.BORDER_SIMPLE)
        bSizerSelColour.Add(self.selColourSwatch, 0, wx.ALIGN_CENTER_VERTICAL)
        grpEditor.Add(bSizerSelColour, 0, wx.EXPAND | wx.ALL, 5)

        # Caret colour row
        bSizerCaretColour = wx.BoxSizer(wx.HORIZONTAL)
        self.labelCaretColour = wx.StaticText(self.general, wx.ID_ANY, _(u"Caret colour"), wx.DefaultPosition, wx.DefaultSize, 0)
        self.labelCaretColour.Wrap(-1)
        bSizerCaretColour.Add(self.labelCaretColour, 1, wx.ALIGN_CENTER_VERTICAL | wx.RIGHT, 5)
        self.caretColourHexCtrl = wx.TextCtrl(self.general, wx.ID_ANY, u"#000000", wx.DefaultPosition, wx.Size(80, -1), 0)
        bSizerCaretColour.Add(self.caretColourHexCtrl, 0, wx.ALIGN_CENTER_VERTICAL | wx.RIGHT, 5)
        self.caretColourBtn = wx.Button(self.general, wx.ID_ANY, _(u"Pick…"), wx.DefaultPosition, wx.Size(60, -1), 0)
        bSizerCaretColour.Add(self.caretColourBtn, 0, wx.ALIGN_CENTER_VERTICAL | wx.RIGHT, 5)
        self.caretColourSwatch = wx.Panel(self.general, wx.ID_ANY, wx.DefaultPosition, wx.Size(24, 24), wx.BORDER_SIMPLE)
        bSizerCaretColour.Add(self.caretColourSwatch, 0, wx.ALIGN_CENTER_VERTICAL)
        grpEditor.Add(bSizerCaretColour, 0, wx.EXPAND | wx.ALL, 5)

        # Caption Editor colour row
        bSizerCapEditor = wx.BoxSizer(wx.HORIZONTAL)
        self.labelCapEditor = wx.StaticText(self.general, wx.ID_ANY, _(u"Editor caption colour"), wx.DefaultPosition, wx.DefaultSize, 0)
        self.labelCapEditor.Wrap(-1)
        bSizerCapEditor.Add(self.labelCapEditor, 1, wx.ALIGN_CENTER_VERTICAL | wx.RIGHT, 5)
        self.capEditorHexCtrl = wx.TextCtrl(self.general, wx.ID_ANY, u"#4682C8", wx.DefaultPosition, wx.Size(80, -1), 0)
        bSizerCapEditor.Add(self.capEditorHexCtrl, 0, wx.ALIGN_CENTER_VERTICAL | wx.RIGHT, 5)
        self.capEditorBtn = wx.Button(self.general, wx.ID_ANY, _(u"Pick…"), wx.DefaultPosition, wx.Size(60, -1), 0)
        bSizerCapEditor.Add(self.capEditorBtn, 0, wx.ALIGN_CENTER_VERTICAL | wx.RIGHT, 5)
        self.capEditorSwatch = wx.Panel(self.general, wx.ID_ANY, wx.DefaultPosition, wx.Size(24, 24), wx.BORDER_SIMPLE)
        bSizerCapEditor.Add(self.capEditorSwatch, 0, wx.ALIGN_CENTER_VERTICAL)
        grpEditor.Add(bSizerCapEditor, 0, wx.EXPAND | wx.ALL, 5)

        # Caption Preview colour row
        bSizerCapPreview = wx.BoxSizer(wx.HORIZONTAL)
        self.labelCapPreview = wx.StaticText(self.general, wx.ID_ANY, _(u"Page caption colour"), wx.DefaultPosition, wx.DefaultSize, 0)
        self.labelCapPreview.Wrap(-1)
        bSizerCapPreview.Add(self.labelCapPreview, 1, wx.ALIGN_CENTER_VERTICAL | wx.RIGHT, 5)
        self.capPreviewHexCtrl = wx.TextCtrl(self.general, wx.ID_ANY, u"#329B82", wx.DefaultPosition, wx.Size(80, -1), 0)
        bSizerCapPreview.Add(self.capPreviewHexCtrl, 0, wx.ALIGN_CENTER_VERTICAL | wx.RIGHT, 5)
        self.capPreviewBtn = wx.Button(self.general, wx.ID_ANY, _(u"Pick…"), wx.DefaultPosition, wx.Size(60, -1), 0)
        bSizerCapPreview.Add(self.capPreviewBtn, 0, wx.ALIGN_CENTER_VERTICAL | wx.RIGHT, 5)
        self.capPreviewSwatch = wx.Panel(self.general, wx.ID_ANY, wx.DefaultPosition, wx.Size(24, 24), wx.BORDER_SIMPLE)
        bSizerCapPreview.Add(self.capPreviewSwatch, 0, wx.ALIGN_CENTER_VERTICAL)
        grpEditor.Add(bSizerCapPreview, 0, wx.EXPAND | wx.ALL, 5)

        # ── Colori sintassi editor ──────────────────────────────────
        _boxSyntax = wx.StaticBox(self.general, wx.ID_ANY, _(u"Syntax colours"))
        grpSyntax = wx.StaticBoxSizer(_boxSyntax, wx.VERTICAL)

        # Barra temi
        # NB: tutti i controlli del gruppo "Colori sintassi" devono avere come
        # genitore la StaticBox _boxSyntax (non il pannello self.general). Se si
        # mescolano genitori diversi all'interno dello stesso StaticBoxSizer, su
        # Windows e Linux gli elementi figli del pannello vengono posizionati in
        # un sistema di coordinate diverso da quelli figli della StaticBox e i
        # controlli finiscono sovrapposti. Stesso schema usato nella scheda
        # "Generale".
        bSizerTheme = wx.BoxSizer(wx.HORIZONTAL)
        self.labelTheme = wx.StaticText(_boxSyntax, wx.ID_ANY, _(u"Theme:"))
        bSizerTheme.Add(self.labelTheme, 0, wx.ALIGN_CENTER_VERTICAL | wx.RIGHT, 5)
        self.themeCh = wx.Choice(_boxSyntax, wx.ID_ANY, wx.DefaultPosition, wx.Size(150, -1), [])
        bSizerTheme.Add(self.themeCh, 1, wx.ALIGN_CENTER_VERTICAL | wx.RIGHT, 5)
        self.themeLoadBtn  = wx.Button(_boxSyntax, wx.ID_ANY, _(u"Load"),   wx.DefaultPosition, wx.Size(75, -1))
        self.themeSaveBtn  = wx.Button(_boxSyntax, wx.ID_ANY, _(u"Save"),   wx.DefaultPosition, wx.Size(75, -1))
        self.themeDeleteBtn = wx.Button(_boxSyntax, wx.ID_ANY, _(u"Delete"), wx.DefaultPosition, wx.Size(75, -1))
        # Icone pulsanti tema
        import os as _os
        from .Globals import glb
        # Frozen-aware: nella build congelata img/ è nella cartella dell'exe.
        _icons_dir = glb.AddPath('img')
        def _load_btn_icon(filename):
            path = _os.path.join(_icons_dir, filename)
            if _os.path.isfile(path):
                img = wx.Image(path, wx.BITMAP_TYPE_PNG)
                img.Rescale(16, 16, wx.IMAGE_QUALITY_HIGH)
                return wx.BitmapBundle.FromBitmap(wx.Bitmap(img))
            return None
        _bmp_load   = _load_btn_icon('carica.png')
        _bmp_save   = _load_btn_icon('salva.png')
        _bmp_delete = _load_btn_icon('elimina.png')
        if _bmp_load:   self.themeLoadBtn.SetBitmap(_bmp_load)
        if _bmp_save:   self.themeSaveBtn.SetBitmap(_bmp_save)
        if _bmp_delete: self.themeDeleteBtn.SetBitmap(_bmp_delete)
        bSizerTheme.Add(self.themeLoadBtn,   0, wx.ALIGN_CENTER_VERTICAL | wx.RIGHT, 3)
        bSizerTheme.Add(self.themeSaveBtn,   0, wx.ALIGN_CENTER_VERTICAL | wx.RIGHT, 3)
        bSizerTheme.Add(self.themeDeleteBtn, 0, wx.ALIGN_CENTER_VERTICAL)
        grpSyntax.Add(bSizerTheme, 0, wx.EXPAND | wx.ALL, 5)

        # Bind eventi temi
        self.themeLoadBtn.Bind(wx.EVT_BUTTON,  self.OnThemeLoad)
        self.themeSaveBtn.Bind(wx.EVT_BUTTON,  self.OnThemeSave)
        self.themeDeleteBtn.Bind(wx.EVT_BUTTON, self.OnThemeDelete)

        _syntax_rows = [
            ('normal',  _(u"Normal text"),  '#000000'),
            ('chorus',  _(u"Chorus"),       '#000000'),
            ('chord',   _(u"Chords"),       '#FF0000'),
            ('command', _(u"Commands"),     '#0000FF'),
            ('attr',    _(u"Attributes"),   '#008000'),
            ('comment', _(u"Comments"),     '#808080'),
            ('tabgrid', _(u"Tab / Grid"),   '#8B5A00'),
        ]
        _syntaxGrid = wx.FlexGridSizer(len(_syntax_rows), 4, 3, 5)
        _syntaxGrid.AddGrowableCol(0, 1)
        self.syntaxHexCtrls   = {}
        self.syntaxSwatches   = {}
        self.syntaxPickBtns   = {}
        for key, label, default in _syntax_rows:
            lbl = wx.StaticText(_boxSyntax, wx.ID_ANY, label)
            _syntaxGrid.Add(lbl, 0, wx.ALIGN_CENTER_VERTICAL)
            hx = wx.TextCtrl(_boxSyntax, wx.ID_ANY, default, wx.DefaultPosition, wx.Size(80, -1))
            _syntaxGrid.Add(hx, 0, wx.ALIGN_CENTER_VERTICAL)
            btn = wx.Button(_boxSyntax, wx.ID_ANY, _(u"Pick…"), wx.DefaultPosition, wx.Size(60, -1))
            _syntaxGrid.Add(btn, 0, wx.ALIGN_CENTER_VERTICAL)
            sw = wx.Panel(_boxSyntax, wx.ID_ANY, wx.DefaultPosition, wx.Size(24, 24), wx.BORDER_SIMPLE)
            _syntaxGrid.Add(sw, 0, wx.ALIGN_CENTER_VERTICAL)
            self.syntaxHexCtrls[key] = hx
            self.syntaxSwatches[key] = sw
            self.syntaxPickBtns[key] = btn
        grpSyntax.Add(_syntaxGrid, 0, wx.EXPAND | wx.ALL, 5)
        grpEditor.Add(grpSyntax, 0, wx.EXPAND | wx.ALL, 5)

        # Bind eventi sintassi
        for key in self.syntaxHexCtrls:
            self.syntaxHexCtrls[key].Bind(wx.EVT_TEXT, self.OnSyntaxHexChanged)
            self.syntaxPickBtns[key].Bind(wx.EVT_BUTTON, self.OnSyntaxPickColour)

        # Anteprima colore al passaggio del mouse sulle sigle colore.
        # NB: la checkbox deve essere figlia della StaticBox (_boxSyntax) e non
        # del pannello self.general: su wxGTK (Linux) la StaticBox è una finestra
        # nativa che copre l'area del riquadro e, se il controllo è un semplice
        # "fratello" sovrapposto, intercetta gli eventi di hover e il tooltip non
        # compare (il click invece passa lo stesso). Con la StaticBox come
        # genitore il tooltip funziona su Windows e su Linux, come per le altre
        # checkbox dei gruppi che usano già questo schema.
        self.colourPreviewCB = wx.CheckBox(_boxSyntax, wx.ID_ANY, _(u"Show a colour preview when hovering over a colour code"), wx.DefaultPosition, wx.DefaultSize, 0)
        self.colourPreviewCB.SetToolTip(_(u"When enabled, resting the mouse over a colour code (e.g. {textcolor:#A52A2A} or {textcolor:red}) shows a small rectangle previewing that colour, attached just below the text. Works on Windows and Linux."))
        grpSyntax.Add(self.colourPreviewCB, 0, wx.ALL, 5)

        # Preview
        bSizer13 = wx.BoxSizer(wx.HORIZONTAL)
        self.m_staticText9 = wx.StaticText(self.general, wx.ID_ANY, _(u"Preview"), wx.DefaultPosition, wx.DefaultSize, 0)
        self.m_staticText9.Wrap(-1)
        bSizer13.Add(self.m_staticText9, 0, wx.ALIGN_TOP | wx.RIGHT, 5)
        self.editor = Editor.Editor(self.general, False, self.general)
        # Altezza minima dell'anteprima: garantisce che resti leggibile anche con
        # molte righe di colore sopra. Se non c'è spazio a sufficienza, il pannello
        # scorre invece di comprimerla.
        self.editor.SetMinSize(wx.Size(300, 150))
        bSizer13.Add(self.editor, 1, wx.EXPAND)
        grpEditor.Add(bSizer13, 1, wx.EXPAND | wx.ALL, 5)

        bSizer11.Add(grpEditor, 1, wx.EXPAND | wx.ALL, 8)

        self.general.SetSizer(bSizer11)
        self.general.Layout()
        # FitInside (non Fit): imposta la virtual size del pannello scorrevole pari
        # alla dimensione minima del contenuto, così le scrollbar compaiono quando
        # la finestra è più piccola del contenuto.
        bSizer11.FitInside(self.general)

        # ── Tab "Generale" ─────────────────────────────────────────
        # Pagina scorrevole: se il contenuto non entra nella finestra (es. su
        # Linux con font e temi piu' grandi) compare da sola la barra di
        # scorrimento verticale (e orizzontale se serve).
        self.general2 = wx.ScrolledWindow(self.notebook, wx.ID_ANY, wx.DefaultPosition, wx.DefaultSize,
                                    wx.TAB_TRAVERSAL | wx.VSCROLL | wx.HSCROLL)
        self.general2.SetScrollRate(10, 10)
        bSizer11b = wx.BoxSizer(wx.VERTICAL)

        # ── Gruppo: Canzone ──────────────────────────────────────────
        grpSong = wx.StaticBoxSizer(wx.StaticBox(self.general2, wx.ID_ANY, _(u"Song")), wx.VERTICAL)

        bSizer141 = wx.BoxSizer(wx.HORIZONTAL)
        self.m_staticText101 = wx.StaticText(self.general2, wx.ID_ANY, _(u"Default notation"), wx.DefaultPosition, wx.DefaultSize, 0)
        self.m_staticText101.Wrap(-1)
        bSizer141.Add(self.m_staticText101, 0, wx.ALIGN_CENTER_VERTICAL | wx.RIGHT, 5)
        notationChChoices = []
        self.notationCh = wx.Choice(self.general2, wx.ID_ANY, wx.DefaultPosition, wx.DefaultSize, notationChChoices, 0)
        self.notationCh.SetSelection(0)
        bSizer141.Add(self.notationCh, 1, wx.ALIGN_CENTER_VERTICAL)
        grpSong.Add(bSizer141, 0, wx.EXPAND | wx.ALL, 5)

        bSizer1412 = wx.BoxSizer(wx.HORIZONTAL)
        self.m_staticText1012 = wx.StaticText(self.general2, wx.ID_ANY, _(u"Default file extension"), wx.DefaultPosition, wx.DefaultSize, 0)
        self.m_staticText1012.Wrap(-1)
        bSizer1412.Add(self.m_staticText1012, 0, wx.ALIGN_CENTER_VERTICAL | wx.RIGHT, 5)
        extensionChoices = []
        self.extension = wx.Choice(self.general2, wx.ID_ANY, wx.DefaultPosition, wx.DefaultSize, extensionChoices, 0)
        self.extension.SetSelection(0)
        bSizer1412.Add(self.extension, 1, wx.ALIGN_CENTER_VERTICAL)
        grpSong.Add(bSizer1412, 0, wx.EXPAND | wx.ALL, 5)

        bSizer14 = wx.BoxSizer(wx.HORIZONTAL)
        self.m_staticText10 = wx.StaticText(self.general2, wx.ID_ANY, _(u"Language"), wx.DefaultPosition, wx.DefaultSize, 0)
        self.m_staticText10.Wrap(-1)
        bSizer14.Add(self.m_staticText10, 0, wx.ALIGN_CENTER_VERTICAL | wx.RIGHT, 5)
        self.langCh = wx.adv.BitmapComboBox(self.general2, wx.ID_ANY, style=wx.CB_READONLY)
        self.langCh.SetSelection(0)
        bSizer14.Add(self.langCh, 1, wx.ALIGN_CENTER_VERTICAL)
        grpSong.Add(bSizer14, 0, wx.EXPAND | wx.ALL, 5)

        bSizer11b.Add(grpSong, 0, wx.EXPAND | wx.ALL, 8)

        # ── Gruppo: Generale ─────────────────────────────────────────
        _boxGeneral = wx.StaticBox(self.general2, wx.ID_ANY, _(u"General"))
        grpGeneral = wx.StaticBoxSizer(_boxGeneral, wx.VERTICAL)

        bSizerClearRecent = wx.BoxSizer(wx.HORIZONTAL)
        self.clearRecentFilesBtn = wx.Button(_boxGeneral, wx.ID_ANY, _(u"Clear recent files"), wx.DefaultPosition, wx.DefaultSize, 0)
        bSizerClearRecent.Add(self.clearRecentFilesBtn, 0)
        self.openTemplatesFolderBtn = wx.Button(_boxGeneral, wx.ID_ANY, _(u"Open templates folder"), wx.DefaultPosition, wx.DefaultSize, 0)
        bSizerClearRecent.Add(self.openTemplatesFolderBtn, 0, wx.LEFT, 8)
        grpGeneral.Add(bSizerClearRecent, 0, wx.ALL, 5)

        # Ordine alfabetico italiano:
        # A - Abilita il pulsante 'Salva'…
        # A - Abilita intellisense…
        # A - Abilita multicursore…
        # I - Istanza singola…
        # M - Mostra 'Riavvia Songpress++'…
        # M - Mostra messaggi di debug…
        # S - Salva dimensione e posizione…

        self.enableSaveOnModifiedCB = wx.CheckBox(_boxGeneral, wx.ID_ANY, _(u"Enable 'Save' button only when the song is modified"), wx.DefaultPosition, wx.DefaultSize, 0)
        self.enableSaveOnModifiedCB.SetToolTip(_(u"When enabled, the 'Save' button and menu item are greyed out until the song has unsaved changes."))
        grpGeneral.Add(self.enableSaveOnModifiedCB, 0, wx.ALL, 5)

        self.integrateChordsOnlyWhenNeededCB = wx.CheckBox(_boxGeneral, wx.ID_ANY, _(u"Enable the chord conversion commands only when needed"), wx.DefaultPosition, wx.DefaultSize, 0)
        self.integrateChordsOnlyWhenNeededCB.SetToolTip(_(u"When enabled, 'Integrate chords' is available only when the cursor is on a chord line (tab format) followed by a text line, 'Convert Tab to ChordPro' only when the song (or the selection) is in tab format, and 'Convert inline chords to ChordPro' only when there are chords attached to the text to convert. When disabled, all three are always available."))
        grpGeneral.Add(self.integrateChordsOnlyWhenNeededCB, 0, wx.ALL, 5)

        self.intellisenseCB = wx.CheckBox(_boxGeneral, wx.ID_ANY, _(u"Enable directive intellisense (Ctrl+Space)"), wx.DefaultPosition, wx.DefaultSize, 0)
        self.intellisenseCB.SetToolTip(_(u"When enabled, pressing Ctrl+Space inside the editor shows a list of available ChordPro directives for auto-completion."))
        grpGeneral.Add(self.intellisenseCB, 0, wx.ALL, 5)

        self.multiCursorCB = wx.CheckBox(_boxGeneral, wx.ID_ANY, _(u"Enable multi-cursor (Alt+Click, Ctrl+D)"), wx.DefaultPosition, wx.DefaultSize, 0)
        self.multiCursorCB.SetToolTip(_(u"When enabled, Alt+Click adds a new cursor and Ctrl+D selects the next occurrence of the current word."))
        grpGeneral.Add(self.multiCursorCB, 0, wx.ALL, 5)

        self.singleInstanceCB = wx.CheckBox(_boxGeneral, wx.ID_ANY, _(u"Single instance: open files in the existing window"), wx.DefaultPosition, wx.DefaultSize, 0)
        self.singleInstanceCB.SetToolTip(_(u"When enabled, opening a file from Explorer or the command line will reuse the existing Songpress++ window instead of launching a new instance."))
        grpGeneral.Add(self.singleInstanceCB, 0, wx.ALL, 5)

        self.showRestartMenuItemCB = wx.CheckBox(_boxGeneral, wx.ID_ANY, _(u"Show 'Restart Songpress++' in the File menu"), wx.DefaultPosition, wx.DefaultSize, 0)
        self.showRestartMenuItemCB.SetToolTip(_(u"When enabled, a 'Restart Songpress++' item appears in the File menu, allowing a quick restart without closing and reopening the application manually."))
        grpGeneral.Add(self.showRestartMenuItemCB, 0, wx.ALL, 5)

        self.showFullPathInTitleCB = wx.CheckBox(_boxGeneral, wx.ID_ANY, _(u"Show the full file path in the title bar"), wx.DefaultPosition, wx.DefaultSize, 0)
        self.showFullPathInTitleCB.SetToolTip(_(u"When enabled, the title bar shows the complete path of the open file (e.g. C:\\Songs\\ballad.crd) instead of just its name."))
        grpGeneral.Add(self.showFullPathInTitleCB, 0, wx.ALL, 5)

        self.showDebugMsgCB = wx.CheckBox(_boxGeneral, wx.ID_ANY, _(u"Show debug messages (theme save path)"), wx.DefaultPosition, wx.DefaultSize, 0)
        self.showDebugMsgCB.SetToolTip(_(u"When enabled, diagnostic messages such as the theme save path are shown in a popup during certain operations. Useful for troubleshooting."))
        grpGeneral.Add(self.showDebugMsgCB, 0, wx.ALL, 5)

        self.saveWindowGeometryCB = wx.CheckBox(_boxGeneral, wx.ID_ANY, _(u"Save window size and position on exit"), wx.DefaultPosition, wx.DefaultSize, 0)
        self.saveWindowGeometryCB.SetToolTip(_(u"When enabled, the window size and position are saved on exit and restored the next time Songpress++ is launched."))
        grpGeneral.Add(self.saveWindowGeometryCB, 0, wx.ALL, 5)

        self.replaceSpacesInFilenamesCB = wx.CheckBox(_boxGeneral, wx.ID_ANY, _(u"Replace spaces with '_' in saved file names"), wx.DefaultPosition, wx.DefaultSize, 0)
        self.replaceSpacesInFilenamesCB.SetToolTip(_(u"When enabled, any whitespace in the file name (not the folder path) is replaced with an underscore '_' whenever a file is saved or exported. Works the same way on Windows and Linux."))
        grpGeneral.Add(self.replaceSpacesInFilenamesCB, 0, wx.ALL, 5)

        self.suggestTitleAsFilenameCB = wx.CheckBox(_boxGeneral, wx.ID_ANY, _(u"Suggest the song {title:} as file name in 'Save as'"), wx.DefaultPosition, wx.DefaultSize, 0)
        self.suggestTitleAsFilenameCB.SetToolTip(_(u"When enabled, the 'Save as' dialog proposes the value of the {title:} directive as the default file name. Invalid characters are removed. This option works together with 'Replace spaces with _': if both are enabled, the suggested name will use underscores instead of spaces."))
        grpGeneral.Add(self.suggestTitleAsFilenameCB, 0, wx.ALL, 5)

        # ── Dimensione icone toolbar ─────────────────────────────────
        bSizerTbIconSize = wx.BoxSizer(wx.HORIZONTAL)
        self.labelTbIconSize = wx.StaticText(_boxGeneral, wx.ID_ANY, _(u"Toolbar icon size"), wx.DefaultPosition, wx.DefaultSize, 0)
        self.labelTbIconSize.Wrap(-1)
        bSizerTbIconSize.Add(self.labelTbIconSize, 0, wx.ALIGN_CENTER_VERTICAL | wx.RIGHT, 8)
        self.tbIconSizeSmall = wx.RadioButton(_boxGeneral, wx.ID_ANY, _(u"Small (16×16)"), wx.DefaultPosition, wx.DefaultSize, wx.RB_GROUP)
        self.tbIconSizeMedium = wx.RadioButton(_boxGeneral, wx.ID_ANY, _(u"Medium (19×19)"))
        self.tbIconSizeLarge = wx.RadioButton(_boxGeneral, wx.ID_ANY, _(u"Large (21×21)"))
        self.tbIconSizeSmall.SetToolTip(_(u"Standard toolbar icon size (16×16 pixels)."))
        self.tbIconSizeMedium.SetToolTip(_(u"Medium toolbar icon size (19×19 pixels, 1.2× larger)."))
        self.tbIconSizeLarge.SetToolTip(_(u"Large toolbar icon size (21×21 pixels, 1.3× larger)."))
        bSizerTbIconSize.Add(self.tbIconSizeSmall, 0, wx.ALIGN_CENTER_VERTICAL | wx.RIGHT, 5)
        bSizerTbIconSize.Add(self.tbIconSizeMedium, 0, wx.ALIGN_CENTER_VERTICAL | wx.RIGHT, 5)
        bSizerTbIconSize.Add(self.tbIconSizeLarge, 0, wx.ALIGN_CENTER_VERTICAL)
        grpGeneral.Add(bSizerTbIconSize, 0, wx.EXPAND | wx.ALL, 5)

        # ── Icona finestra "Verifica dipendenze" ─────────────────────
        bSizerDepIcon = wx.BoxSizer(wx.HORIZONTAL)
        self.labelDepIcon = wx.StaticText(_boxGeneral, wx.ID_ANY, _(u"'Dependency check...' icon"), wx.DefaultPosition, wx.DefaultSize, 0)
        self.labelDepIcon.Wrap(-1)
        bSizerDepIcon.Add(self.labelDepIcon, 0, wx.ALIGN_CENTER_VERTICAL | wx.RIGHT, 8)
        self.depIconNative = wx.RadioButton(_boxGeneral, wx.ID_ANY, _(u"Native icon"), wx.DefaultPosition, wx.DefaultSize, wx.RB_GROUP)
        self.depIconImage = wx.RadioButton(_boxGeneral, wx.ID_ANY, _(u"Image icon"))
        self.depIconNative.SetToolTip(_(u"Use text glyphs (✅ / ❌) rendered by the system font in the 'Check dependencies' window."))
        self.depIconImage.SetToolTip(_(u"Use the image icons loaded from img/checked_box.png and img/not_checked_box.png in the 'Check dependencies' window."))
        bSizerDepIcon.Add(self.depIconNative, 0, wx.ALIGN_CENTER_VERTICAL | wx.RIGHT, 5)
        bSizerDepIcon.Add(self.depIconImage, 0, wx.ALIGN_CENTER_VERTICAL)
        grpGeneral.Add(bSizerDepIcon, 0, wx.EXPAND | wx.ALL, 5)


        bSizer11b.Add(grpGeneral, 0, wx.EXPAND | wx.ALL, 8)

        # ── Gruppo "Righello a schermo" ───────────────────────────────
        _boxRuler = wx.StaticBox(self.general2, wx.ID_ANY, _(u"Screen ruler"))
        grpRuler = wx.StaticBoxSizer(_boxRuler, wx.VERTICAL)
        # Due righe di scelta con le etichette allineate in colonna
        gRuler = wx.FlexGridSizer(0, 3, 6, 8)

        # Pulsanti delle modalita': icone o scritte
        self.labelRulerBtn = wx.StaticText(_boxRuler, wx.ID_ANY, _(u"Mode buttons"))
        self.rulerBtnIcons = wx.RadioButton(_boxRuler, wx.ID_ANY, _(u"Icons"), wx.DefaultPosition, wx.DefaultSize, wx.RB_GROUP)
        self.rulerBtnText = wx.RadioButton(_boxRuler, wx.ID_ANY, _(u"Text labels"))
        self.rulerBtnIcons.SetToolTip(_(u"Show the Bounds, Spacing, Horizontal and Vertical buttons of the screen ruler as 16×16 icons; the name appears in the tooltip."))
        self.rulerBtnText.SetToolTip(_(u"Show the Bounds, Spacing, Horizontal and Vertical buttons of the screen ruler with their names."))
        gRuler.Add(self.labelRulerBtn, 0, wx.ALIGN_CENTER_VERTICAL)
        gRuler.Add(self.rulerBtnIcons, 0, wx.ALIGN_CENTER_VERTICAL)
        gRuler.Add(self.rulerBtnText, 0, wx.ALIGN_CENTER_VERTICAL)

        # Caselle delle opzioni: affiancate nella barra o in una lista
        self.labelRulerOpt = wx.StaticText(_boxRuler, wx.ID_ANY, _(u"Options"))
        self.rulerOptInline = wx.RadioButton(_boxRuler, wx.ID_ANY, _(u"Side by side"), wx.DefaultPosition, wx.DefaultSize, wx.RB_GROUP)
        self.rulerOptList = wx.RadioButton(_boxRuler, wx.ID_ANY, _(u"In a list"))
        self.rulerOptInline.SetToolTip(_(u"Show the Fit to content, Show cross, Smooth zoom and High resolution checkboxes side by side in the screen ruler toolbar."))
        self.rulerOptList.SetToolTip(_(u"Group the Fit to content, Show cross, Smooth zoom and High resolution checkboxes in a vertical list, opened by a button in the screen ruler toolbar. The toolbar becomes shorter."))
        gRuler.Add(self.labelRulerOpt, 0, wx.ALIGN_CENTER_VERTICAL)
        gRuler.Add(self.rulerOptInline, 0, wx.ALIGN_CENTER_VERTICAL)
        gRuler.Add(self.rulerOptList, 0, wx.ALIGN_CENTER_VERTICAL)
        grpRuler.Add(gRuler, 0, wx.ALL, 5)

        # Icone a 16x16 pixel reali anche con ridimensionamento > 100%
        self.rulerIconsNoDpiScaleCB = wx.CheckBox(_boxRuler, wx.ID_ANY, _(u"Keep icons at 16×16 real pixels"))
        self.rulerIconsNoDpiScaleCB.SetToolTip(_(u"With display scaling above 100% (e.g. 150%), the icons of the screen ruler toolbar are not enlarged: they stay sharp at 16×16 real pixels but look smaller than the text. When disabled, they are enlarged like the other icons and may look slightly blurred. No effect at 100% scaling."))
        grpRuler.Add(self.rulerIconsNoDpiScaleCB, 0, wx.ALL, 5)

        # Tolleranza (stesso valore della barra del righello)
        bSizerRulerTol = wx.BoxSizer(wx.HORIZONTAL)
        self.labelRulerTol = wx.StaticText(_boxRuler, wx.ID_ANY, _(u"Tolerance"))
        bSizerRulerTol.Add(self.labelRulerTol, 0, wx.ALIGN_CENTER_VERTICAL | wx.RIGHT, 8)
        self.rulerToleranceSpin = wx.SpinCtrl(_boxRuler, wx.ID_ANY, "", wx.DefaultPosition, wx.DefaultSize, wx.SP_ARROW_KEYS, 0, 255, 30)
        self.rulerToleranceSpin.SetToolTip(_(u"Maximum colour difference (0-255) beyond which a pixel is treated as an edge. Low values detect even shading (antialiasing); high values ignore small variations. Default: 30. It is the same value as the Tolerance field of the screen ruler toolbar: a change made in one place also appears in the other."))
        bSizerRulerTol.Add(self.rulerToleranceSpin, 0, wx.ALIGN_CENTER_VERTICAL | wx.RIGHT, 12)
        self.rulerShowToleranceCB = wx.CheckBox(_boxRuler, wx.ID_ANY, _(u'Show also in the "Screen ruler..." toolbar'))
        self.rulerShowToleranceCB.SetToolTip(_(u"When enabled, the Tolerance field is also shown in the screen ruler toolbar. When disabled, the tolerance can be changed only here and the toolbar becomes shorter."))
        bSizerRulerTol.Add(self.rulerShowToleranceCB, 0, wx.ALIGN_CENTER_VERTICAL)
        grpRuler.Add(bSizerRulerTol, 0, wx.ALL, 5)

        bSizer11b.Add(grpRuler, 0, wx.EXPAND | wx.LEFT | wx.RIGHT | wx.BOTTOM, 8)

        self.general2.SetSizer(bSizer11b)
        self.general2.Layout()
        bSizer11b.Fit(self.general2)
        self.notebook.AddPage(self.general2, _(u"General"), True)
        self.notebook.AddPage(self.general, _(u"Editor"), False)

        self.autoAdjust = wx.Panel(self.notebook, wx.ID_ANY, wx.DefaultPosition, wx.DefaultSize, wx.TAB_TRAVERSAL)
        bSizer18 = wx.BoxSizer(wx.VERTICAL)
        self.autoRemoveBlankLines = wx.CheckBox(self.autoAdjust, wx.ID_ANY, _(u"Offer to remove blank lines"), wx.DefaultPosition, wx.DefaultSize, 0)
        self.autoRemoveBlankLines.SetToolTip(_(u"When enabled, Songpress++ will offer to automatically remove unnecessary blank lines when opening or saving a song."))
        bSizer18.Add(self.autoRemoveBlankLines, 0, wx.ALL, 5)
        self.autoTab2Chordpro = wx.CheckBox(self.autoAdjust, wx.ID_ANY, _(u"Offer to convert songs in tab"), wx.DefaultPosition, wx.DefaultSize, 0)
        self.autoTab2Chordpro.SetToolTip(_(u"When enabled, Songpress++ will offer to convert songs written in tab (chord-over-lyrics) format to ChordPro format automatically."))
        bSizer18.Add(self.autoTab2Chordpro, 0, wx.ALL, 5)
        self.autoAdjustEasyKey = wx.CheckBox(self.autoAdjust, wx.ID_ANY, _(u"Offer to transpose songs to simplify chords"), wx.DefaultPosition, wx.DefaultSize, 0)
        self.autoAdjustEasyKey.SetToolTip(_(u"When enabled, Songpress++ will offer to transpose the song to the key that produces the simplest chord shapes (fewest sharps/flats)."))
        bSizer18.Add(self.autoAdjustEasyKey, 0, wx.ALL, 5)
        bSizerDecoBar = wx.BoxSizer(wx.HORIZONTAL)
        self.labelDecoBarColour = wx.StaticText(self.autoAdjust, wx.ID_ANY, _(u"Level bar colour"), wx.DefaultPosition, wx.DefaultSize, 0)
        self.labelDecoBarColour.Wrap(-1)
        bSizerDecoBar.Add(self.labelDecoBarColour, 1, wx.ALIGN_CENTER_VERTICAL | wx.RIGHT, 5)
        self.decoBarHexCtrl = wx.TextCtrl(self.autoAdjust, wx.ID_ANY, u"#2980B9", wx.DefaultPosition, wx.Size(80, -1), 0)
        bSizerDecoBar.Add(self.decoBarHexCtrl, 0, wx.ALIGN_CENTER_VERTICAL | wx.RIGHT, 5)
        self.decoBarColourBtn = wx.Button(self.autoAdjust, wx.ID_ANY, _(u"Pick\u2026"), wx.DefaultPosition, wx.Size(60, -1), 0)
        bSizerDecoBar.Add(self.decoBarColourBtn, 0, wx.ALIGN_CENTER_VERTICAL | wx.RIGHT, 5)
        self.decoBarColourSwatch = wx.Panel(self.autoAdjust, wx.ID_ANY, wx.DefaultPosition, wx.Size(24, 24), wx.BORDER_SIMPLE)
        bSizerDecoBar.Add(self.decoBarColourSwatch, 0, wx.ALIGN_CENTER_VERTICAL)
        bSizer18.Add(bSizerDecoBar, 0, wx.EXPAND | wx.ALL, 5)

        self.simplifyPanel = wx.ScrolledWindow(self.autoAdjust, wx.ID_ANY, wx.DefaultPosition, wx.DefaultSize, wx.HSCROLL | wx.SUNKEN_BORDER | wx.VSCROLL)
        self.simplifyPanel.SetScrollRate(5, 5)
        self.simplifyPanel.SetBackgroundColour(wx.SystemSettings.GetColour(wx.SYS_COLOUR_WINDOW))
        bSizer18.Add(self.simplifyPanel, 1, wx.EXPAND | wx.ALL, 5)
        self.autoAdjust.SetSizer(bSizer18)
        self.autoAdjust.Layout()
        bSizer18.Fit(self.autoAdjust)
        self.notebook.AddPage(self.autoAdjust, _(u"AutoAdjust"), False)

        # --- Tab "Format" ---
        # Ogni SpinCtrl è in un Panel dedicato per evitare il bug di sincronizzazione wx su Windows
        self.formatPanel = wx.ScrolledWindow(self.notebook, wx.ID_ANY, wx.DefaultPosition, wx.DefaultSize, wx.TAB_TRAVERSAL | wx.VSCROLL)
        self.formatPanel.SetScrollRate(0, 10)
        bSizerFormat = wx.BoxSizer(wx.VERTICAL)

        # ── Gruppo: Titolo e struttura ───────────────────────────────
        grpTitleStruct = wx.StaticBoxSizer(
            wx.StaticBox(self.formatPanel, wx.ID_ANY, _(u"Title and structure")),
            wx.VERTICAL
        )

        bSizerTitleLine = wx.BoxSizer(wx.HORIZONTAL)
        self.labelTitleLine = wx.StaticText(self.formatPanel, wx.ID_ANY, _(u"Title underline thickness"), wx.DefaultPosition, wx.DefaultSize, 0)
        self.labelTitleLine.Wrap(-1)
        bSizerTitleLine.Add(self.labelTitleLine, 1, wx.ALIGN_CENTER_VERTICAL | wx.RIGHT, 5)
        self._titleSpinPanel = wx.Panel(self.formatPanel, wx.ID_ANY)
        self.titleLineWidthSpin = wx.SpinCtrl(self._titleSpinPanel, wx.ID_ANY, "4", wx.DefaultPosition, wx.Size(60 + _SPIN_EXTRA_WIDTH, -1), wx.SP_ARROW_KEYS, 1, 5, 4)
        titleSpinSizer = wx.BoxSizer(wx.HORIZONTAL)
        titleSpinSizer.Add(self.titleLineWidthSpin, 0, 0, 0)
        self._titleSpinPanel.SetSizer(titleSpinSizer)
        bSizerTitleLine.Add(self._titleSpinPanel, 0, wx.ALIGN_CENTER_VERTICAL)
        grpTitleStruct.Add(bSizerTitleLine, 0, wx.EXPAND | wx.ALL, 5)

        bSizerVerseBox = wx.BoxSizer(wx.HORIZONTAL)
        self.labelVerseBox = wx.StaticText(self.formatPanel, wx.ID_ANY, _(u"Verse number box thickness"), wx.DefaultPosition, wx.DefaultSize, 0)
        self.labelVerseBox.Wrap(-1)
        bSizerVerseBox.Add(self.labelVerseBox, 1, wx.ALIGN_CENTER_VERTICAL | wx.RIGHT, 5)
        self._verseSpinPanel = wx.Panel(self.formatPanel, wx.ID_ANY)
        self.verseBoxWidthSpin = wx.SpinCtrl(self._verseSpinPanel, wx.ID_ANY, "1", wx.DefaultPosition, wx.Size(60 + _SPIN_EXTRA_WIDTH, -1), wx.SP_ARROW_KEYS, 1, 5, 1)
        verseSpinSizer = wx.BoxSizer(wx.HORIZONTAL)
        verseSpinSizer.Add(self.verseBoxWidthSpin, 0, 0, 0)
        self._verseSpinPanel.SetSizer(verseSpinSizer)
        bSizerVerseBox.Add(self._verseSpinPanel, 0, wx.ALIGN_CENTER_VERTICAL)
        grpTitleStruct.Add(bSizerVerseBox, 0, wx.EXPAND | wx.ALL, 5)

        # Nota: a differenza degli altri gruppi, qui i controlli restano figli
        # di formatPanel. Spostati nello StaticBox, su wxGTK provocano il
        # messaggio "gtk_widget_size_allocate(): attempt to allocate widget
        # with width 2 and height -1"; il gruppo non ha tooltip, quindi non
        # serve spostarli.
        bSizerFormat.Add(grpTitleStruct, 0, wx.EXPAND | wx.ALL, 8)

        # ── Gruppo: Accordi e tastiera ───────────────────────────────
        grpChords = wx.StaticBoxSizer(
            wx.StaticBox(self.formatPanel, wx.ID_ANY, _(u"Chords and keyboard")),
            wx.VERTICAL
        )
        # Controlli figli dello StaticBox (non del pannello): su wxGTK
        # lo StaticBox fratello copre i controlli e ne blocca i tooltip.
        _boxChords = grpChords.GetStaticBox()

        bSizerKlavier = wx.BoxSizer(wx.HORIZONTAL)
        self.labelKlavierColour = wx.StaticText(_boxChords, wx.ID_ANY, _(u"Klavier key colour"), wx.DefaultPosition, wx.DefaultSize, 0)
        self.labelKlavierColour.Wrap(-1)
        bSizerKlavier.Add(self.labelKlavierColour, 1, wx.ALIGN_CENTER_VERTICAL | wx.RIGHT, 5)
        self.klavierHexCtrl = wx.TextCtrl(_boxChords, wx.ID_ANY, u"#D23C3C", wx.DefaultPosition, wx.Size(80, -1), 0)
        bSizerKlavier.Add(self.klavierHexCtrl, 0, wx.ALIGN_CENTER_VERTICAL | wx.RIGHT, 5)
        self.klavierColourBtn = wx.Button(_boxChords, wx.ID_ANY, _(u"Pick…"), wx.DefaultPosition, wx.Size(60, -1), 0)
        bSizerKlavier.Add(self.klavierColourBtn, 0, wx.ALIGN_CENTER_VERTICAL | wx.RIGHT, 5)
        self.klavierColourSwatch = wx.Panel(_boxChords, wx.ID_ANY, wx.DefaultPosition, wx.Size(24, 24), wx.BORDER_SIMPLE)
        bSizerKlavier.Add(self.klavierColourSwatch, 0, wx.ALIGN_CENTER_VERTICAL)
        grpChords.Add(bSizerKlavier, 0, wx.EXPAND | wx.ALL, 5)

        # Secondo colore per il tasto d'ottava: nelle tastiere a 8 tasti (nota
        # di partenza diversa da DO/FA) la nota iniziale compare due volte; il
        # duplicato più a destra (es. SI alto in SI...SI) può avere un colore
        # proprio per distinguerlo dal primo.
        bSizerKlavierOct = wx.BoxSizer(wx.HORIZONTAL)
        self.klavierOctaveCB = wx.CheckBox(_boxChords, wx.ID_ANY, _(u"Different colour for the upper octave key"), wx.DefaultPosition, wx.DefaultSize, 0)
        self.klavierOctaveCB.SetToolTip(_(u"On 8-key keyboards (start note other than C or F) the start note appears twice: use this colour for the rightmost one (e.g. the high B on a B...B keyboard)."))
        bSizerKlavierOct.Add(self.klavierOctaveCB, 1, wx.ALIGN_CENTER_VERTICAL | wx.RIGHT, 5)
        self.klavierOctaveHexCtrl = wx.TextCtrl(_boxChords, wx.ID_ANY, u"#3C78D2", wx.DefaultPosition, wx.Size(80, -1), 0)
        bSizerKlavierOct.Add(self.klavierOctaveHexCtrl, 0, wx.ALIGN_CENTER_VERTICAL | wx.RIGHT, 5)
        self.klavierOctaveColourBtn = wx.Button(_boxChords, wx.ID_ANY, _(u"Pick\u2026"), wx.DefaultPosition, wx.Size(60, -1), 0)
        bSizerKlavierOct.Add(self.klavierOctaveColourBtn, 0, wx.ALIGN_CENTER_VERTICAL | wx.RIGHT, 5)
        self.klavierOctaveColourSwatch = wx.Panel(_boxChords, wx.ID_ANY, wx.DefaultPosition, wx.Size(24, 24), wx.BORDER_SIMPLE)
        bSizerKlavierOct.Add(self.klavierOctaveColourSwatch, 0, wx.ALIGN_CENTER_VERTICAL)
        grpChords.Add(bSizerKlavierOct, 0, wx.EXPAND | wx.ALL, 5)

        bSizerFingerNum = wx.BoxSizer(wx.HORIZONTAL)
        self.labelFingerNumColour = wx.StaticText(_boxChords, wx.ID_ANY, _(u"Finger number colour"), wx.DefaultPosition, wx.DefaultSize, 0)
        self.labelFingerNumColour.Wrap(-1)
        bSizerFingerNum.Add(self.labelFingerNumColour, 1, wx.ALIGN_CENTER_VERTICAL | wx.RIGHT, 5)
        self.fingerNumHexCtrl = wx.TextCtrl(_boxChords, wx.ID_ANY, u"#1A1A1A", wx.DefaultPosition, wx.Size(80, -1), 0)
        bSizerFingerNum.Add(self.fingerNumHexCtrl, 0, wx.ALIGN_CENTER_VERTICAL | wx.RIGHT, 5)
        self.fingerNumColourBtn = wx.Button(_boxChords, wx.ID_ANY, _(u"Pick\u2026"), wx.DefaultPosition, wx.Size(60, -1), 0)
        bSizerFingerNum.Add(self.fingerNumColourBtn, 0, wx.ALIGN_CENTER_VERTICAL | wx.RIGHT, 5)
        self.fingerNumColourSwatch = wx.Panel(_boxChords, wx.ID_ANY, wx.DefaultPosition, wx.Size(24, 24), wx.BORDER_SIMPLE)
        bSizerFingerNum.Add(self.fingerNumColourSwatch, 0, wx.ALIGN_CENTER_VERTICAL)
        grpChords.Add(bSizerFingerNum, 0, wx.EXPAND | wx.ALL, 5)

        bSizerFormat.Add(grpChords, 0, wx.EXPAND | wx.ALL, 8)

        # ── Gruppo: Tempo ────────────────────────────────────────────
        grpTempo = wx.StaticBoxSizer(
            wx.StaticBox(self.formatPanel, wx.ID_ANY, _(u"Tempo")),
            wx.VERTICAL
        )
        # Controlli figli dello StaticBox (non del pannello): su wxGTK
        # lo StaticBox fratello copre i controlli e ne blocca i tooltip.
        _boxTempo = grpTempo.GetStaticBox()

        # Dimensione icone tempo ({tempo_*})
        bSizerTempoIcon = wx.BoxSizer(wx.HORIZONTAL)
        self.labelTempoIconSize = wx.StaticText(_boxTempo, wx.ID_ANY, _(u"Tempo icon size"), wx.DefaultPosition, wx.DefaultSize, 0)
        self.labelTempoIconSize.Wrap(-1)
        bSizerTempoIcon.Add(self.labelTempoIconSize, 1, wx.ALIGN_CENTER_VERTICAL | wx.RIGHT, 5)
        self.tempoIconSize16 = wx.RadioButton(_boxTempo, wx.ID_ANY, u"16×16", wx.DefaultPosition, wx.DefaultSize, wx.RB_GROUP)
        self.tempoIconSize24 = wx.RadioButton(_boxTempo, wx.ID_ANY, u"24×24")
        self.tempoIconSize32 = wx.RadioButton(_boxTempo, wx.ID_ANY, u"32×32")
        bSizerTempoIcon.Add(self.tempoIconSize16, 0, wx.ALIGN_CENTER_VERTICAL | wx.RIGHT, 5)
        bSizerTempoIcon.Add(self.tempoIconSize24, 0, wx.ALIGN_CENTER_VERTICAL | wx.RIGHT, 5)
        bSizerTempoIcon.Add(self.tempoIconSize32, 0, wx.ALIGN_CENTER_VERTICAL)
        grpTempo.Add(bSizerTempoIcon, 0, wx.EXPAND | wx.ALL, 5)

        # Colore icone tempo ({tempo_*}) — tinta applicata ai PNG nota/metronomo
        bSizerTempoColour = wx.BoxSizer(wx.HORIZONTAL)
        self.labelTempoIconColour = wx.StaticText(_boxTempo, wx.ID_ANY, _(u"Tempo icon colour"), wx.DefaultPosition, wx.DefaultSize, 0)
        self.labelTempoIconColour.Wrap(-1)
        bSizerTempoColour.Add(self.labelTempoIconColour, 1, wx.ALIGN_CENTER_VERTICAL | wx.RIGHT, 5)
        self.tempoIconColourHexCtrl = wx.TextCtrl(_boxTempo, wx.ID_ANY, u"#000000", wx.DefaultPosition, wx.Size(80, -1), 0)
        bSizerTempoColour.Add(self.tempoIconColourHexCtrl, 0, wx.ALIGN_CENTER_VERTICAL | wx.RIGHT, 5)
        self.tempoIconColourBtn = wx.Button(_boxTempo, wx.ID_ANY, _(u"Pick\u2026"), wx.DefaultPosition, wx.Size(60, -1), 0)
        bSizerTempoColour.Add(self.tempoIconColourBtn, 0, wx.ALIGN_CENTER_VERTICAL | wx.RIGHT, 5)
        self.tempoIconColourSwatch = wx.Panel(_boxTempo, wx.ID_ANY, wx.DefaultPosition, wx.Size(24, 24), wx.BORDER_SIMPLE)
        bSizerTempoColour.Add(self.tempoIconColourSwatch, 0, wx.ALIGN_CENTER_VERTICAL)
        grpTempo.Add(bSizerTempoColour, 0, wx.EXPAND | wx.ALL, 5)

        bSizerFormat.Add(grpTempo, 0, wx.EXPAND | wx.ALL, 8)

        # ── Gruppo: Griglia accordi ──────────────────────────────────
        grpGrid = wx.StaticBoxSizer(
            wx.StaticBox(self.formatPanel, wx.ID_ANY, _(u"Chord grid ({start_of_grid}.{end_of_grid})")),
            wx.VERTICAL
        )
        # Controlli figli dello StaticBox (non del pannello): su wxGTK
        # lo StaticBox fratello copre i controlli e ne blocca i tooltip.
        _boxGrid = grpGrid.GetStaticBox()

        lbl = wx.StaticText(_boxGrid, wx.ID_ANY,
            _(u"Display mode for {start_of_grid} blocks:"))
        grpGrid.Add(lbl, 0, wx.LEFT | wx.TOP | wx.RIGHT, 5)

        self.gridModePipe = wx.RadioButton(
            _boxGrid, wx.ID_ANY,
            _(u"Pipe table  —  | C   | G   | Am  | F   |"),
            style=wx.RB_GROUP
        )
        self.gridModePipe.SetToolTip(
            _(u"Each bar is separated by | characters. The raw text in the source "
              u"must already contain | delimiters.")
        )
        grpGrid.Add(self.gridModePipe, 0, wx.ALL, 4)

        self.gridModePlain = wx.RadioButton(
            _boxGrid, wx.ID_ANY,
            _(u"Plain spacing  —  C   G   Am  F")
        )
        self.gridModePlain.SetToolTip(
            _(u"Chords are rendered spaced out without pipe separators.")
        )
        grpGrid.Add(self.gridModePlain, 0, wx.ALL, 4)

        self.gridModeTable = wx.RadioButton(
            _boxGrid, wx.ID_ANY,
            _(u"Table  —  cells with borders")
        )
        self.gridModeTable.SetToolTip(
            _(u"Each bar is rendered as a cell with a visible border, "
              u"like a grid table.")
        )
        grpGrid.Add(self.gridModeTable, 0, wx.ALL, 4)

        # ── Etichetta predefinita ────────────────────────────────────
        szLbl = wx.BoxSizer(wx.HORIZONTAL)
        lblDefault = wx.StaticText(
            _boxGrid, wx.ID_ANY,
            _(u"Default label (used when {start_of_grid} has no label):")
        )
        szLbl.Add(lblDefault, 0, wx.ALIGN_CENTER_VERTICAL | wx.RIGHT, 8)
        self.gridDefaultLabelCtrl = wx.TextCtrl(
            _boxGrid, wx.ID_ANY,
            value=_(u"Grid"),
            size=(160, -1)
        )
        self.gridDefaultLabelCtrl.SetToolTip(
            _(u"This text is shown as the section label when {start_of_grid} "
              u"is used without an explicit label argument.\n"
              u"Example: {start_of_grid: label} overrides this value.")
        )
        szLbl.Add(self.gridDefaultLabelCtrl, 0, wx.ALIGN_CENTER_VERTICAL)
        grpGrid.Add(szLbl, 0, wx.ALL, 5)

        self.gridSpaceAsPipeCB = wx.CheckBox(
            _boxGrid, wx.ID_ANY,
            _(u"Space bar inserts | separator (pipe mode)")
        )
        self.gridSpaceAsPipeCB.SetToolTip(
            _(u"When enabled, pressing the space bar inside a {start_of_grid} block\n"
              u"inserts a | pipe separator, shifting the current cell to the right.\n"
              u"Disable this to type spaces normally inside grid blocks.")
        )
        grpGrid.Add(self.gridSpaceAsPipeCB, 0, wx.ALL, 5)

        # ── Direzione di size=N ──────────────────────────────────────
        szSizeDir = wx.BoxSizer(wx.HORIZONTAL)
        lblSizeDir = wx.StaticText(_boxGrid, wx.ID_ANY,
            _(u"size=N affects:"))
        szSizeDir.Add(lblSizeDir, 0, wx.ALIGN_CENTER_VERTICAL | wx.RIGHT, 8)
        self.gridSizeDirBoth = wx.RadioButton(
            _boxGrid, wx.ID_ANY,
            _(u"Width and height"),
            style=wx.RB_GROUP
        )
        self.gridSizeDirBoth.SetToolTip(
            _(u"size=N multiplies both horizontal and vertical cell padding.")
        )
        self.gridSizeDirH = wx.RadioButton(
            _boxGrid, wx.ID_ANY,
            _(u"Width only")
        )
        self.gridSizeDirH.SetToolTip(
            _(u"size=N multiplies only horizontal cell padding; "
              u"vertical padding stays at its base value.")
        )
        self.gridSizeDirV = wx.RadioButton(
            _boxGrid, wx.ID_ANY,
            _(u"Height only")
        )
        self.gridSizeDirV.SetToolTip(
            _(u"size=N multiplies only vertical cell padding; "
              u"horizontal padding stays at its base value.")
        )
        szSizeDir.Add(self.gridSizeDirBoth, 0, wx.ALIGN_CENTER_VERTICAL | wx.RIGHT, 8)
        szSizeDir.Add(self.gridSizeDirH,    0, wx.ALIGN_CENTER_VERTICAL | wx.RIGHT, 8)
        szSizeDir.Add(self.gridSizeDirV,    0, wx.ALIGN_CENTER_VERTICAL)
        grpGrid.Add(szSizeDir, 0, wx.ALL, 5)

        bSizerFormat.Add(grpGrid, 0, wx.EXPAND | wx.ALL, 8)

        # --- Gruppo: inserimento simbolo musicale ---
        grpSymbol = wx.StaticBoxSizer(
            wx.StaticBox(self.formatPanel, wx.ID_ANY, _(u"Musical symbol insertion")),
            wx.VERTICAL,
        )
        # Controlli figli dello StaticBox (non del pannello): su wxGTK
        # lo StaticBox fratello copre i controlli e ne blocca i tooltip.
        _boxSymbol = grpSymbol.GetStaticBox()
        szSymbol = wx.BoxSizer(wx.HORIZONTAL)
        self.symbolScaleCB = wx.CheckBox(
            _boxSymbol, wx.ID_ANY,
            _(u"Custom size when inserting musical symbols (pt):"),
        )
        self.symbolScaleCB.SetToolTip(
            _(u"When enabled, inserted musical symbols are wrapped with\n"
              u"{textsize:N}...{textsize:} to apply the chosen point size.")
        )
        self.symbolSizeSpin = wx.SpinCtrl(
            _boxSymbol, wx.ID_ANY,
            min=6, max=144, initial=24,
            style=wx.SP_ARROW_KEYS,
        )
        self.symbolSizeSpin.SetMinSize(wx.Size(60 + _SPIN_EXTRA_WIDTH, -1))
        szSymbol.Add(self.symbolScaleCB, 0, wx.ALIGN_CENTER_VERTICAL | wx.RIGHT, 6)
        szSymbol.Add(self.symbolSizeSpin, 0, wx.ALIGN_CENTER_VERTICAL)
        grpSymbol.Add(szSymbol, 0, wx.ALL, 5)
        self.symbolScaleCB.Bind(
            wx.EVT_CHECKBOX,
            lambda e: self.symbolSizeSpin.Enable(self.symbolScaleCB.GetValue()),
        )
        self.symbolInsertVerseCB = wx.CheckBox(
            _boxSymbol, wx.ID_ANY,
            _(u"Wrap symbol in a verse block (not counted)"),
        )
        self.symbolInsertVerseCB.SetToolTip(
            _(u"When enabled, the inserted symbol is wrapped inside\n"
              u"{start_verse}...{end_verse} so it is not counted\n"
              u"in the verse numbering.")
        )
        grpSymbol.Add(self.symbolInsertVerseCB, 0, wx.ALL, 5)

        # Riga: abbassamento verticale del simbolo (spostato qui dalla finestra
        # "Simboli musicali"). Valore 0-25 %, aggiornato in tempo reale.
        szValign = wx.BoxSizer(wx.HORIZONTAL)
        self.symbolValignLbl = wx.StaticText(
            _boxSymbol, wx.ID_ANY, _(u"Symbol vertical drop (0-25%):")
        )
        self.symbolValignSpin = wx.SpinCtrl(
            _boxSymbol, wx.ID_ANY,
            min=0, max=25, initial=5,
            style=wx.SP_ARROW_KEYS,
        )
        self.symbolValignSpin.SetMinSize(wx.Size(60 + _SPIN_EXTRA_WIDTH, -1))
        self.symbolValignSpin.SetToolTip(
            _(u"Lowers musical symbols to line them up with the text row.\n"
              u"0 = raw position; about 5 aligns them (default); higher values lower them more.\n"
              u"Saved and applied to Songpress++ Page, print preview and printing.")
        )
        szValign.Add(self.symbolValignLbl, 0, wx.ALIGN_CENTER_VERTICAL | wx.RIGHT, 6)
        szValign.Add(self.symbolValignSpin, 0, wx.ALIGN_CENTER_VERTICAL)
        grpSymbol.Add(szValign, 0, wx.ALL, 5)

        # Riga: qualità (sovracampionamento) del simbolo SMP — SOLO Linux.
        # Su Linux i simboli SMP in anteprima passano da una bitmap e possono
        # apparire a bassa risoluzione; questo valore ne aumenta la nitidezza.
        # Su Windows/macOS il glifo è vettoriale e l'impostazione non ha effetto.
        szOversample = wx.BoxSizer(wx.HORIZONTAL)
        self.symbolOversampleLbl = wx.StaticText(
            _boxSymbol, wx.ID_ANY,
            _(u"SMP symbol quality \u2014 Linux only (1-4):")
        )
        self.symbolOversampleSpin = wx.SpinCtrl(
            _boxSymbol, wx.ID_ANY,
            min=1, max=4, initial=3,
            style=wx.SP_ARROW_KEYS,
        )
        self.symbolOversampleSpin.SetMinSize(wx.Size(60 + _SPIN_EXTRA_WIDTH, -1))
        self.symbolOversampleSpin.SetToolTip(
            _(u"Linux only: sharpens SMP musical symbols in the 'Songpress++ Page'.\n"
              u"On Linux these symbols are drawn from a bitmap and can look\n"
              u"low-resolution; higher values render them at higher resolution.\n"
              u"1 = off, 3 = recommended (default), 4 = maximum (more memory).\n"
              u"No effect on Windows/macOS, where the symbol is vector.")
        )
        szOversample.Add(self.symbolOversampleLbl, 0, wx.ALIGN_CENTER_VERTICAL | wx.RIGHT, 6)
        szOversample.Add(self.symbolOversampleSpin, 0, wx.ALIGN_CENTER_VERTICAL)
        grpSymbol.Add(szOversample, 0, wx.ALL, 5)
        bSizerFormat.Add(grpSymbol, 0, wx.EXPAND | wx.ALL, 8)

        # ── Gruppo: Beat count ({beats_time}) ───────────────────────
        grpDuration = wx.StaticBoxSizer(
            wx.StaticBox(self.formatPanel, wx.ID_ANY, _(u"Beat count ({beats_time})")),
            wx.VERTICAL
        )
        # Controlli figli dello StaticBox (non del pannello): su wxGTK
        # lo StaticBox fratello copre i controlli e ne blocca i tooltip.
        _boxDuration = grpDuration.GetStaticBox()

        # Riga 1: colore
        bSizerDurColour = wx.BoxSizer(wx.HORIZONTAL)
        lblDurColour = wx.StaticText(_boxDuration, wx.ID_ANY, _(u"Colour"), wx.DefaultPosition, wx.DefaultSize, 0)
        bSizerDurColour.Add(lblDurColour, 1, wx.ALIGN_CENTER_VERTICAL | wx.RIGHT, 5)
        self.durationBeatsHexCtrl = wx.TextCtrl(_boxDuration, wx.ID_ANY, u"#6464C8", wx.DefaultPosition, wx.Size(80, -1), 0)
        bSizerDurColour.Add(self.durationBeatsHexCtrl, 0, wx.ALIGN_CENTER_VERTICAL | wx.RIGHT, 5)
        self.durationBeatsColourBtn = wx.Button(_boxDuration, wx.ID_ANY, _(u"Pick…"), wx.DefaultPosition, wx.Size(60, -1), 0)
        bSizerDurColour.Add(self.durationBeatsColourBtn, 0, wx.ALIGN_CENTER_VERTICAL | wx.RIGHT, 5)
        self.durationBeatsColourSwatch = wx.Panel(_boxDuration, wx.ID_ANY, wx.DefaultPosition, wx.Size(24, 24), wx.BORDER_SIMPLE)
        bSizerDurColour.Add(self.durationBeatsColourSwatch, 0, wx.ALIGN_CENTER_VERTICAL)
        grpDuration.Add(bSizerDurColour, 0, wx.EXPAND | wx.ALL, 5)

        # Riga 2: dimensione font (% del font accordo)
        bSizerDurSize = wx.BoxSizer(wx.HORIZONTAL)
        lblDurSize = wx.StaticText(_boxDuration, wx.ID_ANY, _(u"Font size (% of chord font)"), wx.DefaultPosition, wx.DefaultSize, 0)
        bSizerDurSize.Add(lblDurSize, 1, wx.ALIGN_CENTER_VERTICAL | wx.RIGHT, 5)
        self.durationBeatsSizeSpin = wx.SpinCtrl(_boxDuration, wx.ID_ANY, "60", wx.DefaultPosition, wx.Size(70 + _SPIN_EXTRA_WIDTH, -1), wx.SP_ARROW_KEYS, 30, 150, 60)
        self.durationBeatsSizeSpin.SetToolTip(_(u"Size of the beat-count number as a percentage of the chord font size (default: 60%)"))
        bSizerDurSize.Add(self.durationBeatsSizeSpin, 0, wx.ALIGN_CENTER_VERTICAL)
        grpDuration.Add(bSizerDurSize, 0, wx.EXPAND | wx.ALL, 5)

        # Riga 3: grassetto
        self.durationBeatsBoldCB = wx.CheckBox(_boxDuration, wx.ID_ANY, _(u"Bold"))
        self.durationBeatsBoldCB.SetToolTip(_(u"Draw the beat-count number in bold"))
        grpDuration.Add(self.durationBeatsBoldCB, 0, wx.ALL, 5)

        # Riga 4: allineamento (sinistra / centro / destra)
        bSizerDurAlign = wx.BoxSizer(wx.HORIZONTAL)
        lblDurAlign = wx.StaticText(_boxDuration, wx.ID_ANY, _(u"Position"), wx.DefaultPosition, wx.DefaultSize, 0)
        bSizerDurAlign.Add(lblDurAlign, 1, wx.ALIGN_CENTER_VERTICAL | wx.RIGHT, 5)
        self.durationBeatsAlignLeft = wx.RadioButton(
            _boxDuration, wx.ID_ANY, _(u"Left"), style=wx.RB_GROUP)
        self.durationBeatsAlignLeft.SetToolTip(_(u"Show beat count to the left of the chord name"))
        self.durationBeatsAlignCenter = wx.RadioButton(
            _boxDuration, wx.ID_ANY, _(u"Center"))
        self.durationBeatsAlignCenter.SetToolTip(_(u"Show beat count centered above the chord name"))
        self.durationBeatsAlignRight = wx.RadioButton(
            _boxDuration, wx.ID_ANY, _(u"Right"))
        self.durationBeatsAlignRight.SetToolTip(_(u"Show beat count to the right of the chord name"))
        bSizerDurAlign.Add(self.durationBeatsAlignLeft,   0, wx.ALIGN_CENTER_VERTICAL | wx.RIGHT, 8)
        bSizerDurAlign.Add(self.durationBeatsAlignCenter, 0, wx.ALIGN_CENTER_VERTICAL | wx.RIGHT, 8)
        bSizerDurAlign.Add(self.durationBeatsAlignRight,  0, wx.ALIGN_CENTER_VERTICAL)
        grpDuration.Add(bSizerDurAlign, 0, wx.EXPAND | wx.ALL, 5)

        # Riga 5: modalità visualizzazione (numero / puntini / entrambi)
        bSizerDurMode = wx.BoxSizer(wx.HORIZONTAL)
        lblDurMode = wx.StaticText(_boxDuration, wx.ID_ANY, _(u"Display mode"), wx.DefaultPosition, wx.DefaultSize, 0)
        bSizerDurMode.Add(lblDurMode, 1, wx.ALIGN_CENTER_VERTICAL | wx.RIGHT, 5)
        self.durationModeNumber = wx.RadioButton(
            _boxDuration, wx.ID_ANY, _(u"Number"), style=wx.RB_GROUP)
        self.durationModeNumber.SetToolTip(_(u"Show beat count as a number above the chord"))
        self.durationModeDots   = wx.RadioButton(
            _boxDuration, wx.ID_ANY, _(u"Dots"))
        self.durationModeDots.SetToolTip(_(u"Show beat count as dots between chords"))
        self.durationModeBoth   = wx.RadioButton(
            _boxDuration, wx.ID_ANY, _(u"Both"))
        self.durationModeBoth.SetToolTip(_(u"Show both number and dots"))
        bSizerDurMode.Add(self.durationModeNumber, 0, wx.ALIGN_CENTER_VERTICAL | wx.RIGHT, 8)
        bSizerDurMode.Add(self.durationModeDots,   0, wx.ALIGN_CENTER_VERTICAL | wx.RIGHT, 8)
        bSizerDurMode.Add(self.durationModeBoth,   0, wx.ALIGN_CENTER_VERTICAL)
        grpDuration.Add(bSizerDurMode, 0, wx.EXPAND | wx.ALL, 5)

        bSizerFormat.Add(grpDuration, 0, wx.EXPAND | wx.ALL, 8)

        self.formatPanel.SetSizer(bSizerFormat)
        self.formatPanel.Layout()
        self.notebook.AddPage(self.formatPanel, _(u"Format"), False)
        # --- Fine Tab "Format" ---

        # --- Tab "Songpress" ---
        # Pagina scorrevole: se il contenuto non entra nella finestra (es. su
        # Linux con font e temi piu' grandi) compare da sola la barra di
        # scorrimento verticale (e orizzontale se serve).
        self.songpressPanel = wx.ScrolledWindow(self.notebook, wx.ID_ANY, wx.DefaultPosition, wx.DefaultSize,
                                    wx.TAB_TRAVERSAL | wx.VSCROLL | wx.HSCROLL)
        self.songpressPanel.SetScrollRate(10, 10)
        bSizerSongpress = wx.BoxSizer(wx.VERTICAL)

        # Gruppo: Anteprima
        _boxPreview = wx.StaticBox(self.songpressPanel, wx.ID_ANY, _(u"Songpress++ Page"))
        grpPreview = wx.StaticBoxSizer(_boxPreview, wx.VERTICAL)

        # Ordine alfabetico italiano:
        # D - Doppio clic…
        # I - Imposta la dimensione…
        # M - Mostra indicatore…
        # R - Ritarda aggiornamento…
        # S - Sfondo grigio…

        self.dblClickFocusCB = wx.CheckBox(
            _boxPreview, wx.ID_ANY,
            _(u"Double-click on preview jumps to source line in editor")
        )
        self.dblClickFocusCB.SetToolTip(
            _(u"When enabled, double-clicking on any word or chord in the preview "
              u"moves the cursor to the corresponding line in the editor.")
        )
        grpPreview.Add(self.dblClickFocusCB, 0, wx.ALL, 5)

        self.previewMinSizeCB = wx.CheckBox(
            _boxPreview, wx.ID_ANY,
            _(u"Set minimum size for the Page panel at startup (370×530)")
        )
        self.previewMinSizeCB.SetToolTip(
            _(u"When enabled, the Page panel cannot be resized below 370×530 pixels. "
              u"This prevents the panel from appearing too small when the application starts.")
        )
        grpPreview.Add(self.previewMinSizeCB, 0, wx.ALL, 5)

        self.showPageIndicatorCB = wx.CheckBox(
            _boxPreview, wx.ID_ANY,
            _(u"Show page indicator (e.g. 'Page 1 of 3')")
        )
        self.showPageIndicatorCB.SetToolTip(
            _(u"Show or hide the page counter label at the top right of the Page panel")
        )
        grpPreview.Add(self.showPageIndicatorCB, 0, wx.ALL, 5)

        self.debounceRefreshCB = wx.CheckBox(
            _boxPreview, wx.ID_ANY,
            _(u"Delay preview refresh while typing (debounce)")
        )
        self.debounceRefreshCB.SetToolTip(
            _(u"When enabled, the preview redraws only after a short pause in typing "
              u"(300 ms), reducing CPU usage. When disabled, every keystroke "
              u"immediately updates the preview.")
        )
        grpPreview.Add(self.debounceRefreshCB, 0, wx.ALL, 5)

        self.greyBackgroundCB = wx.CheckBox(
            _boxPreview, wx.ID_ANY,
            _(u"Grey background in preview (page style)")
        )
        self.greyBackgroundCB.SetToolTip(
            _(u"Show the preview on a grey background to simulate a printed page. "
              u"When disabled, the background is white.")
        )
        grpPreview.Add(self.greyBackgroundCB, 0, wx.ALL, 5)

        bSizerSongpress.Add(grpPreview, 0, wx.EXPAND | wx.ALL, 8)

        # Gruppo: Stampa
        _boxPrint = wx.StaticBox(self.songpressPanel, wx.ID_ANY, _(u"Print"))
        grpPrint = wx.StaticBoxSizer(_boxPrint, wx.VERTICAL)

        # Ordine alfabetico italiano:
        # A - Aggiornamento in tempo reale…
        # M - Mantieni sempre in primo piano…
        # M - Mostra anteprima di stampa…

        self.liveDriverPollCB = wx.CheckBox(
            _boxPrint, wx.ID_ANY,
            _(u"Live update of duplex/color status in print preview (every 1.5 s)")
        )
        self.liveDriverPollCB.SetToolTip(
            _(u"When enabled, the duplex and color status shown in the print preview "
              u"status bar is refreshed every 1.5 seconds by querying the printer driver. "
              u"This lets you see changes made in the driver panel without closing the preview. "
              u"When disabled, the status is read once when the preview opens and stays fixed.")
        )
        grpPrint.Add(self.liveDriverPollCB, 0, wx.ALL, 5)

        self.printPreviewAlwaysOnTopCB = wx.CheckBox(
            _boxPrint, wx.ID_ANY,
            _(u"Keep print preview window always on top")
        )
        self.printPreviewAlwaysOnTopCB.SetToolTip(
            _(u"When enabled, the print preview window stays on top of all other windows, "
              u"including the main Songpress++ window. "
              u"When disabled, the preview window behaves as a normal window.")
        )
        grpPrint.Add(self.printPreviewAlwaysOnTopCB, 0, wx.ALL, 5)

        self.showPrintPreviewCB = wx.CheckBox(
            _boxPrint, wx.ID_ANY,
            _(u"Show print preview before printing")
        )
        self.showPrintPreviewCB.SetToolTip(_(u"When enabled, a print preview window is shown before sending the document to the printer, allowing you to check the layout and page settings."))
        grpPrint.Add(self.showPrintPreviewCB, 0, wx.ALL, 5)

        bSizerSongpress.Add(grpPrint, 0, wx.EXPAND | wx.ALL, 8)

        # Gruppo: Nessun accordo — blocchi da nascondere
        _boxNoChords = wx.StaticBox(self.songpressPanel, wx.ID_ANY,
                         _(u"No chords: blocks to hide"))
        grpNoChords = wx.StaticBoxSizer(_boxNoChords, wx.VERTICAL)
        _noChordsTip = _(
            u"Active only when 'Show chords' is set to 'No chords'.\n"
            u"Check each block type you want to hide from the preview and print."
        )
        _noChordHdr = wx.StaticText(
            _boxNoChords, wx.ID_ANY,
            _(u"When 'No chords' is selected, also hide:")
        )
        _noChordHdr.SetToolTip(_noChordsTip)
        grpNoChords.Add(_noChordHdr, 0, wx.ALL, 5)

        # Ordine alfabetico italiano:
        # A - Accordi di intro…
        # B - Bridge…
        # G - Griglia…
        # I - Indicazione di tempo…
        # T - Tempo…

        self.hideIntroChordCB = wx.CheckBox(
            _boxNoChords, wx.ID_ANY,
            _(u"Intro chords  {start_chord}\\{end_chord}")
        )
        self.hideIntroChordCB.SetToolTip(
            _(u"Hide {start_chord}…{end_chord} blocks when no chords are shown.")
        )
        grpNoChords.Add(self.hideIntroChordCB, 0, wx.ALL, 5)

        self.hideBridgeCB = wx.CheckBox(
            _boxNoChords, wx.ID_ANY,
            _(u"Bridge  {start_bridge}\\{end_bridge}")
        )
        self.hideBridgeCB.SetToolTip(
            _(u"Hide {start_bridge}…{end_bridge} blocks when no chords are shown.")
        )
        grpNoChords.Add(self.hideBridgeCB, 0, wx.ALL, 5)

        self.hideGridCB = wx.CheckBox(
            _boxNoChords, wx.ID_ANY,
            _(u"Grid  {start_of_grid}\\{end_of_grid}")
        )
        self.hideGridCB.SetToolTip(
            _(u"Hide {start_of_grid}…{end_of_grid} blocks when no chords are shown.")
        )
        grpNoChords.Add(self.hideGridCB, 0, wx.ALL, 5)

        self.hideTimeCB = wx.CheckBox(
            _boxNoChords, wx.ID_ANY,
            _(u"Time signature  {time}")
        )
        self.hideTimeCB.SetToolTip(
            _(u"Hide {time:...} directives when no chords are shown.")
        )
        grpNoChords.Add(self.hideTimeCB, 0, wx.ALL, 5)

        self.hideTempoCB = wx.CheckBox(
            _boxNoChords, wx.ID_ANY,
            _(u"Tempo  {tempo_m}\\{tempo_s}\\{tempo_sp}\\{tempo_c}\\{tempo_cp}")
        )
        self.hideTempoCB.SetToolTip(
            _(u"Hide {tempo_m}, {tempo_s}, {tempo_sp}, {tempo_c}, {tempo_cp} directives when no chords are shown.")
        )
        grpNoChords.Add(self.hideTempoCB, 0, wx.ALL, 5)

        bSizerSongpress.Add(grpNoChords, 0, wx.EXPAND | wx.ALL, 8)

        self.songpressPanel.SetSizer(bSizerSongpress)
        self.songpressPanel.Layout()
        bSizerSongpress.Fit(self.songpressPanel)
        self.notebook.AddPage(self.songpressPanel, _(u"Songpress++ Page"), False)
        # --- Fine Tab "Songpress" ---

        # --- Tab "Guida rapida" ---
        # Pagina scorrevole: se il contenuto non entra nella finestra (es. su
        # Linux con font e temi piu' grandi) compare da sola la barra di
        # scorrimento verticale (e orizzontale se serve).
        self.guidePanel = wx.ScrolledWindow(self.notebook, wx.ID_ANY, wx.DefaultPosition, wx.DefaultSize,
                                    wx.TAB_TRAVERSAL | wx.VSCROLL | wx.HSCROLL)
        self.guidePanel.SetScrollRate(10, 10)
        bSizerGuide = wx.BoxSizer(wx.VERTICAL)

        # Gruppo: Visualizzatore Markdown
        grpMdViewer = wx.StaticBoxSizer(
            wx.StaticBox(self.guidePanel, wx.ID_ANY, _(u"Markdown viewer")),
            wx.VERTICAL
        )

        rowViewer = wx.BoxSizer(wx.HORIZONTAL)
        rowViewer.Add(
            wx.StaticText(self.guidePanel, wx.ID_ANY, _(u"Markdown viewer:")),
            0, wx.ALIGN_CENTER_VERTICAL | wx.RIGHT, 8
        )
        self.guideViewerCh = wx.Choice(self.guidePanel, wx.ID_ANY)
        self.guideViewerCh.Append(_(u"Automatic (python-markdown → mistune → built-in)"), "auto")
        self.guideViewerCh.Append(_(u"python-markdown"),  "markdown")
        self.guideViewerCh.Append(_(u"mistune"),           "mistune")
        self.guideViewerCh.Append(_(u"Built-in parser"),   "builtin")
        self.guideViewerCh.SetToolTip(
            _(u"Choose which Markdown engine is used to render the quick guide.\n"
              u"'Automatic' tries python-markdown first, then mistune, then the built-in parser.\n"
              u"python-markdown and mistune must be installed separately.")
        )
        rowViewer.Add(self.guideViewerCh, 1, wx.EXPAND)
        grpMdViewer.Add(rowViewer, 0, wx.EXPAND | wx.ALL, 5)
        bSizerGuide.Add(grpMdViewer, 0, wx.EXPAND | wx.ALL, 8)


        self.guidePanel.SetSizer(bSizerGuide)
        self.guidePanel.Layout()
        bSizerGuide.Fit(self.guidePanel)
        self.notebook.AddPage(self.guidePanel, _(u"Quick guide"), False)
        # --- Fine Tab "Guida rapida" ---

        # --- Tab "Context menu" ---
        # Pagina scorrevole: se il contenuto non entra nella finestra (es. su
        # Linux con font e temi piu' grandi) compare da sola la barra di
        # scorrimento verticale (e orizzontale se serve).
        self.contextMenuPanel = wx.ScrolledWindow(self.notebook, wx.ID_ANY, wx.DefaultPosition, wx.DefaultSize,
                                    wx.TAB_TRAVERSAL | wx.VSCROLL | wx.HSCROLL)
        self.contextMenuPanel.SetScrollRate(10, 10)
        bSizerCM = wx.BoxSizer(wx.VERTICAL)

        headerCM = wx.StaticText(self.contextMenuPanel, wx.ID_ANY,
            _(u"Select which items to show in the right-click context menu:"),
            wx.DefaultPosition, wx.DefaultSize, 0)
        headerCM.Wrap(480)
        bSizerCM.Add(headerCM, 0, wx.ALL, 8)

        bSizerCM.Add(wx.StaticLine(self.contextMenuPanel), 0, wx.EXPAND | wx.LEFT | wx.RIGHT, 5)

        # --- Gruppo Undo/Redo ---
        _boxUndoRedo = wx.StaticBox(self.contextMenuPanel, wx.ID_ANY, _(u"History"))
        grpUndoRedo = wx.StaticBoxSizer(_boxUndoRedo, wx.VERTICAL)
        self.cmUndo  = wx.CheckBox(_boxUndoRedo, wx.ID_ANY, _(u"Undo"))
        self.cmUndo.SetToolTip(_(u"Show the 'Undo' command in the right-click context menu."))
        self.cmRedo  = wx.CheckBox(_boxUndoRedo, wx.ID_ANY, _(u"Redo"))
        self.cmRedo.SetToolTip(_(u"Show the 'Redo' command in the right-click context menu."))
        grpUndoRedo.Add(self.cmUndo,  0, wx.ALL, 4)
        grpUndoRedo.Add(self.cmRedo,  0, wx.ALL, 4)
        bSizerCM.Add(grpUndoRedo, 0, wx.EXPAND | wx.ALL, 5)

        # --- Gruppo Modifica ---
        _boxEdit = wx.StaticBox(self.contextMenuPanel, wx.ID_ANY, _(u"Edit"))
        grpEdit = wx.StaticBoxSizer(_boxEdit, wx.VERTICAL)
        self.cmCut    = wx.CheckBox(_boxEdit, wx.ID_ANY, _(u"Cut"))
        self.cmCut.SetToolTip(_(u"Show the 'Cut' command in the right-click context menu."))
        self.cmCopy   = wx.CheckBox(_boxEdit, wx.ID_ANY, _(u"Copy"))
        self.cmCopy.SetToolTip(_(u"Show the 'Copy' command in the right-click context menu."))
        self.cmPaste  = wx.CheckBox(_boxEdit, wx.ID_ANY, _(u"Paste"))
        self.cmPaste.SetToolTip(_(u"Show the 'Paste' command in the right-click context menu."))
        self.cmDelete = wx.CheckBox(_boxEdit, wx.ID_ANY, _(u"Delete"))
        self.cmDelete.SetToolTip(_(u"Show the 'Delete' command in the right-click context menu."))
        self.cmConfirmDelete = wx.CheckBox(_boxEdit, wx.ID_ANY, _(u"Ask confirmation before deleting"))
        self.cmConfirmDelete.SetToolTip(_(u"When enabled, a confirmation dialog is shown before any delete operation performed via the context menu."))
        grpEdit.Add(self.cmCut,    0, wx.ALL, 4)
        grpEdit.Add(self.cmCopy,   0, wx.ALL, 4)
        grpEdit.Add(self.cmPaste,  0, wx.ALL, 4)
        grpEdit.Add(self.cmDelete, 0, wx.ALL, 4)
        grpEdit.Add(self.cmConfirmDelete, 0, wx.LEFT | wx.BOTTOM, 20)  # indentato sotto Delete
        bSizerCM.Add(grpEdit, 0, wx.EXPAND | wx.ALL, 5)

        # --- Gruppo Azioni speciali ---
        _boxSpecial = wx.StaticBox(self.contextMenuPanel, wx.ID_ANY, _(u"Special actions"))
        grpSpecial = wx.StaticBoxSizer(_boxSpecial, wx.VERTICAL)
        self.cmPasteChords           = wx.CheckBox(_boxSpecial, wx.ID_ANY, _(u"Paste chords"))
        self.cmPasteChords.SetToolTip(_(u"Show the 'Paste chords' command in the right-click context menu."))
        self.cmPropagateVerseChords  = wx.CheckBox(_boxSpecial, wx.ID_ANY, _(u"Propagate verse chords"))
        self.cmPropagateVerseChords.SetToolTip(_(u"Show the 'Propagate verse chords' command in the right-click context menu."))
        self.cmPropagateChorusChords = wx.CheckBox(_boxSpecial, wx.ID_ANY, _(u"Propagate chorus chords"))
        self.cmPropagateChorusChords.SetToolTip(_(u"Show the 'Propagate chorus chords' command in the right-click context menu."))
        self.cmCopyTextOnly          = wx.CheckBox(_boxSpecial, wx.ID_ANY, _(u"Copy text only"))
        self.cmCopyTextOnly.SetToolTip(_(u"Show the 'Copy text only' command in the right-click context menu (copies lyrics without chords)."))
        grpSpecial.Add(self.cmPasteChords,           0, wx.ALL, 4)
        grpSpecial.Add(self.cmPropagateVerseChords,  0, wx.ALL, 4)
        grpSpecial.Add(self.cmPropagateChorusChords, 0, wx.ALL, 4)
        grpSpecial.Add(self.cmCopyTextOnly,          0, wx.ALL, 4)
        bSizerCM.Add(grpSpecial, 0, wx.EXPAND | wx.ALL, 5)

        # --- Gruppo Selezione ---
        _boxSel = wx.StaticBox(self.contextMenuPanel, wx.ID_ANY, _(u"Selection"))
        grpSel = wx.StaticBoxSizer(_boxSel, wx.VERTICAL)
        self.cmSelectAll = wx.CheckBox(_boxSel, wx.ID_ANY, _(u"Select all"))
        self.cmSelectAll.SetToolTip(_(u"Show the 'Select all' command in the right-click context menu."))
        grpSel.Add(self.cmSelectAll, 0, wx.ALL, 4)
        bSizerCM.Add(grpSel, 0, wx.EXPAND | wx.ALL, 5)

        # --- Gruppo Aspetto ---
        _boxAppearance = wx.StaticBox(self.contextMenuPanel, wx.ID_ANY, _(u"Appearance"))
        grpAppearance = wx.StaticBoxSizer(_boxAppearance, wx.VERTICAL)
        self.cmShowIcons = wx.CheckBox(_boxAppearance, wx.ID_ANY, _(u"Show icons in context menu"))
        self.cmShowIcons.SetToolTip(_(u"When enabled, small icons are displayed next to each command in the right-click context menu."))
        grpAppearance.Add(self.cmShowIcons, 0, wx.ALL, 4)
        bSizerCM.Add(grpAppearance, 0, wx.EXPAND | wx.ALL, 5)

        self.contextMenuPanel.SetSizer(bSizerCM)
        self.contextMenuPanel.Layout()
        bSizerCM.Fit(self.contextMenuPanel)
        self.notebook.AddPage(self.contextMenuPanel, _(u"Context menu"), False)
        # --- Fine Tab "Context menu" ---

        # --- Tab "File associations" (Windows e Linux) ---
        import platform as _platform
        self._fileAssocAvailable = (_platform.system() in ('Windows', 'Linux'))
        # Pagina scorrevole: se il contenuto non entra nella finestra (es. su
        # Linux con font e temi piu' grandi) compare da sola la barra di
        # scorrimento verticale (e orizzontale se serve).
        self.fileAssocPanel = wx.ScrolledWindow(self.notebook, wx.ID_ANY, wx.DefaultPosition, wx.DefaultSize,
                                    wx.TAB_TRAVERSAL | wx.VSCROLL | wx.HSCROLL)
        self.fileAssocPanel.SetScrollRate(10, 10)
        bSizerFA = wx.BoxSizer(wx.VERTICAL)

        if self._fileAssocAvailable:
            headerFA = wx.StaticText(self.fileAssocPanel, wx.ID_ANY,
                _(u"Associate file extensions with Songpress++.\nChanges apply to the current user only."),
                wx.DefaultPosition, wx.DefaultSize, 0)
            headerFA.Wrap(480)
            bSizerFA.Add(headerFA, 0, wx.ALL, 8)
            bSizerFA.Add(wx.StaticLine(self.fileAssocPanel), 0, wx.EXPAND | wx.LEFT | wx.RIGHT, 5)

            self._fileAssocExts = ["crd", "cho", "chordpro", "chopro", "pro", "tab", "sng"]
            self._fileAssocCBs  = {}
            import platform as _plcb
            for ext in self._fileAssocExts:
                cb = wx.CheckBox(self.fileAssocPanel, wx.ID_ANY, u"." + ext)
                cb.SetToolTip(_(u"Associate the .%s file extension with Songpress++.") % ext)
                self._fileAssocCBs[ext] = cb
                if _plcb.system() == 'Linux':
                    cb.Disable()
                bSizerFA.Add(cb, 0, wx.ALL, 4)

            bSizerFA.Add(wx.StaticLine(self.fileAssocPanel), 0, wx.EXPAND | wx.LEFT | wx.RIGHT | wx.TOP, 5)

            bSizerFABulk = wx.BoxSizer(wx.HORIZONTAL)
            btnAssocAll = wx.Button(self.fileAssocPanel, wx.ID_ANY, _(u"Associate all"))
            bSizerFABulk.Add(btnAssocAll, 0, wx.ALL, 4)
            btnUnassocAll = wx.Button(self.fileAssocPanel, wx.ID_ANY, _(u"Unassociate all"))
            bSizerFABulk.Add(btnUnassocAll, 0, wx.ALL, 4)
            bSizerFA.Add(bSizerFABulk, 0, wx.LEFT, 4)
            btnAssocAll.Bind(wx.EVT_BUTTON, self.OnAssociateAll)
            btnUnassocAll.Bind(wx.EVT_BUTTON, self.OnUnassociateAll)
            self._btnAssocAll   = btnAssocAll
            self._btnUnassocAll = btnUnassocAll
            import platform as _pl
            if _pl.system() == 'Linux':
                btnAssocAll.Disable()
                btnUnassocAll.Disable()
            import platform as _pl
            if _pl.system() == 'Linux':
                btnAssocAll.Disable()
                btnUnassocAll.Disable()
            import platform as _pl
            if _pl.system() == 'Linux':
                btnAssocAll.Disable()
                btnUnassocAll.Disable()
            import platform as _pl
            if _pl.system() == 'Linux':
                btnAssocAll.Disable()
                btnUnassocAll.Disable()
            import platform as _pl
            if _pl.system() == 'Linux':
                btnAssocAll.Disable()
                btnUnassocAll.Disable()
            import platform as _pl
            if _pl.system() == 'Linux':
                btnAssocAll.Disable()
                btnUnassocAll.Disable()
            import platform as _pl
            if _pl.system() == 'Linux':
                btnAssocAll.Disable()
                btnUnassocAll.Disable()
            import platform as _pl
            if _pl.system() == 'Linux':
                btnAssocAll.Disable()
                btnUnassocAll.Disable()
            import platform as _pl
            if _pl.system() == 'Linux':
                btnAssocAll.Disable()
                btnUnassocAll.Disable()
            import platform as _pl
            if _pl.system() == 'Linux':
                btnAssocAll.Disable()
                btnUnassocAll.Disable()
            import platform as _pl
            if _pl.system() == 'Linux':
                btnAssocAll.Disable()
                btnUnassocAll.Disable()
            import platform as _pl
            if _pl.system() == 'Linux':
                btnAssocAll.Disable()
                btnUnassocAll.Disable()
            import platform as _pl
            if _pl.system() == 'Linux':
                btnAssocAll.Disable()
                btnUnassocAll.Disable()
            import platform as _pl
            if _pl.system() == 'Linux':
                btnAssocAll.Disable()
                btnUnassocAll.Disable()
            import platform as _pl
            if _pl.system() == 'Linux':
                btnAssocAll.Disable()
                btnUnassocAll.Disable()
            import platform as _pl
            if _pl.system() == 'Linux':
                btnAssocAll.Disable()
                btnUnassocAll.Disable()
            import platform as _pl
            if _pl.system() == 'Linux':
                btnAssocAll.Disable()
                btnUnassocAll.Disable()
            import platform as _pl
            if _pl.system() == 'Linux':
                btnAssocAll.Disable()
                btnUnassocAll.Disable()
            import platform as _pl
            if _pl.system() == 'Linux':
                btnAssocAll.Disable()
                btnUnassocAll.Disable()
            import platform as _pl
            if _pl.system() == 'Linux':
                btnAssocAll.Disable()
                btnUnassocAll.Disable()
            import platform as _pl
            if _pl.system() == 'Linux':
                btnAssocAll.Disable()
                btnUnassocAll.Disable()
            import platform as _pl
            if _pl.system() == 'Linux':
                btnAssocAll.Disable()
                btnUnassocAll.Disable()
            import platform as _pl
            if _pl.system() == 'Linux':
                btnAssocAll.Disable()
                btnUnassocAll.Disable()
            import platform as _pl
            if _pl.system() == 'Linux':
                btnAssocAll.Disable()
                btnUnassocAll.Disable()
            import platform as _pl
            if _pl.system() == 'Linux':
                btnAssocAll.Disable()
                btnUnassocAll.Disable()
            import platform as _pl
            if _pl.system() == 'Linux':
                btnAssocAll.Disable()
                btnUnassocAll.Disable()
            import platform as _pl
            if _pl.system() == 'Linux':
                btnAssocAll.Disable()
                btnUnassocAll.Disable()
            import platform as _pl
            if _pl.system() == 'Linux':
                btnAssocAll.Disable()
                btnUnassocAll.Disable()
            import platform as _pl
            if _pl.system() == 'Linux':
                btnAssocAll.Disable()
                btnUnassocAll.Disable()
            import platform as _pl
            if _pl.system() == 'Linux':
                btnAssocAll.Disable()
                btnUnassocAll.Disable()
            import platform as _pl
            if _pl.system() == 'Linux':
                btnAssocAll.Disable()
                btnUnassocAll.Disable()
            import platform as _pl
            if _pl.system() == 'Linux':
                btnAssocAll.Disable()
                btnUnassocAll.Disable()
            import platform as _pl
            if _pl.system() == 'Linux':
                btnAssocAll.Disable()
                btnUnassocAll.Disable()
            import platform as _pl
            if _pl.system() == 'Linux':
                btnAssocAll.Disable()
                btnUnassocAll.Disable()
            import platform as _pl
            if _pl.system() == 'Linux':
                btnAssocAll.Disable()
                btnUnassocAll.Disable()
            import platform as _pl
            if _pl.system() == 'Linux':
                btnAssocAll.Disable()
                btnUnassocAll.Disable()
            import platform as _pl
            if _pl.system() == 'Linux':
                btnAssocAll.Disable()
                btnUnassocAll.Disable()
            import platform as _pl
            if _pl.system() == 'Linux':
                btnAssocAll.Disable()
                btnUnassocAll.Disable()
            import platform as _pl
            if _pl.system() == 'Linux':
                btnAssocAll.Disable()
                btnUnassocAll.Disable()
            import platform as _pl
            if _pl.system() == 'Linux':
                btnAssocAll.Disable()
                btnUnassocAll.Disable()
            import platform as _pl
            if _pl.system() == 'Linux':
                btnAssocAll.Disable()
                btnUnassocAll.Disable()
            import platform as _pl
            if _pl.system() == 'Linux':
                btnAssocAll.Disable()
                btnUnassocAll.Disable()
            import platform as _pl
            if _pl.system() == 'Linux':
                btnAssocAll.Disable()
                btnUnassocAll.Disable()
            # Su Linux con pacchetto .deb le associazioni sono gestite dal sistema:
            # disabilita i pulsanti per evitare conflitti con /usr/share/mime
            import platform as _pl
            if _pl.system() == 'Linux':
                btnAssocAll.Disable()
                btnUnassocAll.Disable()

            bSizerFA.Add(wx.StaticLine(self.fileAssocPanel), 0, wx.EXPAND | wx.LEFT | wx.RIGHT | wx.TOP, 5)
            btnApply = wx.Button(self.fileAssocPanel, wx.ID_ANY, _(u"Apply now"))
            bSizerFA.Add(btnApply, 0, wx.ALL, 8)
            btnApply.Bind(wx.EVT_BUTTON, self.OnApplyFileAssoc)
            self._btnApplyFileAssoc = btnApply
            import platform as _pl2
            if _pl2.system() == 'Linux':
                btnApply.Disable()
            import platform as _pl2
            if _pl2.system() == 'Linux':
                btnApply.Disable()
            import platform as _pl2
            if _pl2.system() == 'Linux':
                btnApply.Disable()
            import platform as _pl2
            if _pl2.system() == 'Linux':
                btnApply.Disable()
            import platform as _pl2
            if _pl2.system() == 'Linux':
                btnApply.Disable()
            import platform as _pl2
            if _pl2.system() == 'Linux':
                btnApply.Disable()
            import platform as _pl2
            if _pl2.system() == 'Linux':
                btnApply.Disable()
            import platform as _pl2
            if _pl2.system() == 'Linux':
                btnApply.Disable()
            import platform as _pl2
            if _pl2.system() == 'Linux':
                btnApply.Disable()
            import platform as _pl2
            if _pl2.system() == 'Linux':
                btnApply.Disable()
            import platform as _pl2
            if _pl2.system() == 'Linux':
                btnApply.Disable()
            import platform as _pl2
            if _pl2.system() == 'Linux':
                btnApply.Disable()
            import platform as _pl2
            if _pl2.system() == 'Linux':
                btnApply.Disable()
            import platform as _pl2
            if _pl2.system() == 'Linux':
                btnApply.Disable()
            import platform as _pl2
            if _pl2.system() == 'Linux':
                btnApply.Disable()
            import platform as _pl2
            if _pl2.system() == 'Linux':
                btnApply.Disable()
            import platform as _pl2
            if _pl2.system() == 'Linux':
                btnApply.Disable()
            import platform as _pl2
            if _pl2.system() == 'Linux':
                btnApply.Disable()
            import platform as _pl2
            if _pl2.system() == 'Linux':
                btnApply.Disable()
            import platform as _pl2
            if _pl2.system() == 'Linux':
                btnApply.Disable()
            import platform as _pl2
            if _pl2.system() == 'Linux':
                btnApply.Disable()
            import platform as _pl2
            if _pl2.system() == 'Linux':
                btnApply.Disable()
            import platform as _pl2
            if _pl2.system() == 'Linux':
                btnApply.Disable()
            import platform as _pl2
            if _pl2.system() == 'Linux':
                btnApply.Disable()
            import platform as _pl2
            if _pl2.system() == 'Linux':
                btnApply.Disable()
            import platform as _pl2
            if _pl2.system() == 'Linux':
                btnApply.Disable()
            import platform as _pl2
            if _pl2.system() == 'Linux':
                btnApply.Disable()
            import platform as _pl2
            if _pl2.system() == 'Linux':
                btnApply.Disable()
            import platform as _pl2
            if _pl2.system() == 'Linux':
                btnApply.Disable()
            import platform as _pl2
            if _pl2.system() == 'Linux':
                btnApply.Disable()
            import platform as _pl2
            if _pl2.system() == 'Linux':
                btnApply.Disable()
            import platform as _pl2
            if _pl2.system() == 'Linux':
                btnApply.Disable()
            import platform as _pl2
            if _pl2.system() == 'Linux':
                btnApply.Disable()
            import platform as _pl2
            if _pl2.system() == 'Linux':
                btnApply.Disable()
            import platform as _pl2
            if _pl2.system() == 'Linux':
                btnApply.Disable()
            import platform as _pl2
            if _pl2.system() == 'Linux':
                btnApply.Disable()
            import platform as _pl2
            if _pl2.system() == 'Linux':
                btnApply.Disable()
            import platform as _pl2
            if _pl2.system() == 'Linux':
                btnApply.Disable()
            import platform as _pl2
            if _pl2.system() == 'Linux':
                btnApply.Disable()
            import platform as _pl2
            if _pl2.system() == 'Linux':
                btnApply.Disable()
            import platform as _pl2
            if _pl2.system() == 'Linux':
                btnApply.Disable()
            import platform as _pl2
            if _pl2.system() == 'Linux':
                btnApply.Disable()
            import platform as _pl2
            if _pl2.system() == 'Linux':
                btnApply.Disable()
            import platform as _pl2
            if _pl2.system() == 'Linux':
                btnApply.Disable()
        else:
            note = wx.StaticText(self.fileAssocPanel, wx.ID_ANY,
                _(u"File association is not available on this operating system."),
                wx.DefaultPosition, wx.DefaultSize, 0)
            bSizerFA.Add(note, 0, wx.ALL, 8)

        self.fileAssocPanel.SetSizer(bSizerFA)
        self.fileAssocPanel.Layout()
        bSizerFA.Fit(self.fileAssocPanel)
        self.notebook.AddPage(self.fileAssocPanel, _(u"File associations"), False)
        # --- Fine Tab "File associations" ---

        # Connect colour events
        self.klavierColourBtn.Bind(wx.EVT_BUTTON, self.OnKlavierPickColour)
        self.klavierHexCtrl.Bind(wx.EVT_TEXT, self.OnKlavierHexChanged)
        self.fingerNumColourBtn.Bind(wx.EVT_BUTTON, self.OnFingerNumPickColour)
        self.fingerNumHexCtrl.Bind(wx.EVT_TEXT, self.OnFingerNumHexChanged)
        self.klavierOctaveCB.Bind(wx.EVT_CHECKBOX, self._OnKlavierOctaveToggled)
        self.klavierOctaveColourBtn.Bind(wx.EVT_BUTTON, self._OnKlavierOctavePickColour)
        self.klavierOctaveHexCtrl.Bind(wx.EVT_TEXT, self._OnKlavierOctaveHexChanged)
        self.tempoIconColourBtn.Bind(wx.EVT_BUTTON, self.OnTempoIconColourPickColour)
        self.tempoIconColourHexCtrl.Bind(wx.EVT_TEXT, self.OnTempoIconColourHexChanged)
        self.durationBeatsColourBtn.Bind(wx.EVT_BUTTON, self.OnDurationBeatsPickColour)
        self.durationBeatsHexCtrl.Bind(wx.EVT_TEXT, self.OnDurationBeatsHexChanged)
        self.decoBarColourBtn.Bind(wx.EVT_BUTTON, self.OnDecoBarPickColour)
        self.decoBarHexCtrl.Bind(wx.EVT_TEXT, self.OnDecoBarHexChanged)
        self.editorBgBtn.Bind(wx.EVT_BUTTON, self.OnEditorBgPickColour)
        self.editorBgHexCtrl.Bind(wx.EVT_TEXT, self.OnEditorBgHexChanged)
        self.selColourBtn.Bind(wx.EVT_BUTTON, self.OnSelColourPickColour)
        self.selColourHexCtrl.Bind(wx.EVT_TEXT, self.OnSelColourHexChanged)
        self.caretColourBtn.Bind(wx.EVT_BUTTON, self.OnCaretColourPickColour)
        self.caretColourHexCtrl.Bind(wx.EVT_TEXT, self.OnCaretColourHexChanged)

        self.capEditorBtn.Bind(wx.EVT_BUTTON, self.OnCapEditorPickColour)
        self.capEditorHexCtrl.Bind(wx.EVT_TEXT, self.OnCapEditorHexChanged)
        self.capPreviewBtn.Bind(wx.EVT_BUTTON, self.OnCapPreviewPickColour)
        self.capPreviewHexCtrl.Bind(wx.EVT_TEXT, self.OnCapPreviewHexChanged)

        bSizer10.Add(self.notebook, 1, wx.EXPAND | wx.ALL, 5)

        # --- Barra bottoni con pin button ---
        btnBarSizer = wx.BoxSizer(wx.HORIZONTAL)
        self.btnPin = wx.Button(self, wx.ID_ANY, u"📌", size=(32, -1))
        self.btnPin.SetToolTip(_(u"Keep this dialog open after applying"))
        self.m_sdbSizer3OK = wx.Button(self, wx.ID_OK)
        self.m_sdbSizer3Cancel = wx.Button(self, wx.ID_CANCEL)
        self.m_sdbSizer3OK.SetDefault()
        btnBarSizer.Add(self.btnPin, 0, wx.ALL | wx.ALIGN_CENTER_VERTICAL, 4)
        btnBarSizer.AddStretchSpacer()
        btnBarSizer.Add(self.m_sdbSizer3OK, 0, wx.ALL | wx.ALIGN_CENTER_VERTICAL, 4)
        btnBarSizer.Add(self.m_sdbSizer3Cancel, 0, wx.ALL | wx.ALIGN_CENTER_VERTICAL, 4)

        bSizer10.Add(btnBarSizer, 0, wx.EXPAND | wx.ALL, 4)

        self.SetSizer(bSizer10)
        self.Layout()
        self.Centre(wx.BOTH)

        # Pagine scorrevoli: ricalcolo dell'area da scorrere a finestra visibile
        self._InitScrollPages([self.general2, self.general, self.formatPanel,
                               self.songpressPanel, self.guidePanel,
                               self.contextMenuPanel, self.fileAssocPanel])

        # Connect Events
        self.fontCB.Bind(wx.EVT_KILL_FOCUS, self.OnFontSelected)
        self.sizeCB.Bind(wx.EVT_COMBOBOX, self.OnFontSelected)
        self.sizeCB.Bind(wx.EVT_KILL_FOCUS, self.OnFontSelected)
        self.sizeCB.Bind(wx.EVT_TEXT_ENTER, self.OnFontSelected)
        self.m_sdbSizer3OK.Bind(wx.EVT_BUTTON, self.OnOk)
        # Colore tasto d'ottava: valori iniziali da self.pref (MyPreferencesDialog
        # imposta self.pref prima di chiamare questo costruttore); il salvataggio
        # avviene in MyPreferencesDialog.OnOk.
        self._InitKlavierOctaveColour()
        self.btnPin.Bind(wx.EVT_BUTTON, self.OnPin)
        self.clearRecentFilesBtn.Bind(wx.EVT_BUTTON, self.OnClearRecentFiles)
        self.openTemplatesFolderBtn.Bind(wx.EVT_BUTTON, self.OnOpenTemplatesFolder)
        self.showDebugMsgCB.Bind(wx.EVT_CHECKBOX, self.OnShowDebugMsgChanged)
        self.cmConfirmDelete.Bind(wx.EVT_CHECKBOX, self.OnCmConfirmDeleteChanged)
        self.cmShowIcons.Bind(wx.EVT_CHECKBOX, self.OnCmShowIconsChanged)

    # ── Pagine scorrevoli ────────────────────────────────────────────
    # Su Linux/GTK le dimensioni reali di molti controlli (caselle numeriche,
    # riquadri con titolo, testi con font di sistema piu' grandi) si conoscono
    # solo dopo che la finestra e' stata mostrata. L'area da scorrere,
    # calcolata prima, risultava piu' corta del contenuto e le ultime righe
    # restavano invisibili anche in fondo alla barra di scorrimento.
    # Qui l'area viene ricalcolata a finestra visibile, al cambio di scheda e
    # al ridimensionamento, con un piccolo margine in fondo.

    _SCROLL_BOTTOM_MARGIN = 100

    def _InitScrollPages(self, pages):
        # Dimensione di avvio, letta ORA: quando arriva EVT_SHOW, con un
        # window manager vero GTK non ha ancora dimensionato la finestra e
        # GetSize() restituisce valori minuscoli (es. 4x28).
        self._startSize = wx.Size(self.GetSize())
        self._scrollPages = [pg for pg in pages if isinstance(pg, wx.ScrolledWindow)]
        for pg in self._scrollPages:
            # La pagina non deve imporre al notebook (e quindi alla finestra)
            # l'altezza di tutto il contenuto: altrimenti su GTK la pagina
            # risulta piu' alta della parte visibile e il fondo resta tagliato.
            pg.SetMinSize(wx.Size(-1, 120))
        self._LimitNotebookHeight()
        self.Bind(wx.EVT_SHOW, self._OnShowScrollPages)
        self.notebook.Bind(wx.EVT_NOTEBOOK_PAGE_CHANGED, self._OnPageChangedScroll)
        self.Bind(wx.EVT_SIZE, self._OnSizeScrollPages)

    def _LimitNotebookHeight(self):
        """Il notebook calcola la sua altezza minima dalla pagina piu' alta
        (comprese quelle aggiunte dopo, es. la scheda Toolbar). Se supera lo
        spazio della finestra, su GTK il notebook sconfina sotto i pulsanti
        OK/Annulla: la pagina e' piu' alta della parte visibile e la barra di
        scorrimento non compare nemmeno. Con un'altezza minima piccola il
        notebook occupa esattamente lo spazio disponibile e le pagine
        scorrono."""
        best = self.notebook.GetBestSize()
        self.notebook.SetMinSize(wx.Size(best.width, 200))

    def _RefitScrollPages(self):
        """Area da scorrere = fin dove arrivano DAVVERO i controlli.

        Non ci si fida solo della dimensione minima calcolata dal sizer (su GTK
        puo' essere piu' bassa del reale): dopo il layout si misura il fondo
        effettivo dei controlli e lo si impone come altezza minima del sizer,
        cosi' anche i ricalcoli automatici di wx (FitInside) lo rispettano."""
        if getattr(self, '_refitting', False):
            return
        # Mai durante un clic in corso (es. sulle frecce < > delle linguette):
        # su GTK rifare il layout mentre il pulsante del mouse e' premuto puo'
        # lasciare il puntatore "agganciato" al notebook, e i clic successivi
        # (anche su OK / Annulla) andrebbero persi. Si riprova poco dopo.
        ms = wx.GetMouseState()
        if ms.LeftIsDown() or ms.RightIsDown() or ms.MiddleIsDown():
            self._ScheduleRefit(150)
            return
        self._refitting = True
        try:
            def invalidate(win):
                win.InvalidateBestSize()
                for child in win.GetChildren():
                    invalidate(child)
            for pg in getattr(self, '_scrollPages', []):
                if not pg:
                    continue
                sz = pg.GetSizer()
                if sz is None:
                    continue
                invalidate(pg)
                sz.SetMinSize(wx.Size(0, 0))
                pg.Layout()
                # Fondo reale di TUTTI i controlli, anche quelli dentro i
                # riquadri con titolo (figli dello StaticBox, non della
                # pagina): posizioni sullo schermo riportate alla pagina.
                right = bottom = 0
                origin = pg.GetScreenPosition()
                vx, vy = pg.GetViewStart()
                ux, uy = pg.GetScrollPixelsPerUnit()
                offX, offY = vx * ux, vy * uy
                stack = list(pg.GetChildren())
                while stack:
                    child = stack.pop()
                    if not child.IsShown():
                        continue
                    r = child.GetScreenRect()
                    right = max(right, r.x - origin.x + offX + r.width)
                    bottom = max(bottom, r.y - origin.y + offY + r.height)
                    stack.extend(child.GetChildren())
                calc = sz.CalcMin()
                need = wx.Size(max(calc.width, right),
                               max(calc.height, bottom) + self._SCROLL_BOTTOM_MARGIN)
                sz.SetMinSize(need)
                pg._scrollNeed = need
                # FitInside() su GTK non allarga l'area oltre la parte visibile:
                # la si imposta esplicitamente.
                pg.SetVirtualSize(need)
                pg.FitInside()
                if pg.GetVirtualSize().height < need.height:
                    pg.SetVirtualSize(need)
            # Layout della finestra solo se l'altezza minima del notebook e'
            # davvero cambiata (evita impaginazioni inutili a ogni evento).
            before = self.notebook.GetMinSize()
            self._LimitNotebookHeight()
            if self.notebook.GetMinSize() != before:
                self.Layout()
            # la pagina non deve coprire i pulsanti OK / Annulla
            self._FitPageInNotebook()
        finally:
            self._refitting = False

    def _WatchPageSizes(self):
        """Ogni pagina del notebook (anche quelle aggiunte dopo, es. Toolbar)
        viene sorvegliata: se GTK le ridà la misura sbagliata dopo un
        ridimensionamento, _FitPageInNotebook la riaccorcia subito."""
        watched = getattr(self, '_watchedPages', None)
        if watched is None:
            watched = self._watchedPages = set()
        for i in range(self.notebook.GetPageCount()):
            page = self.notebook.GetPage(i)
            if id(page) not in watched:
                watched.add(id(page))
                page.Bind(wx.EVT_SIZE, self._OnPageSize)

    def _OnPageSize(self, event):
        event.Skip()
        if not getattr(self, '_fitPending', False):
            self._fitPending = True
            wx.CallAfter(self._FitPageLater)

    def _FitPageLater(self):
        self._fitPending = False
        try:
            if not self or not self.IsShown():
                return
        except RuntimeError:
            return
        self._FitPageInNotebook()

    def _FitPageInNotebook(self):
        """Su GTK (soprattutto con temi come Breeze) wx calcola l'altezza
        della pagina come se le linguette fossero piu' basse di quanto GTK le
        disegna: la pagina viene spostata in basso da GTK ma resta alta come
        calcolato da wx, e sporge sotto il notebook, sopra OK / Annulla. I
        pulsanti restano visibili ma i clic vanno alla pagina che li copre:
        e' il blocco che si vede dopo aver cambiato scheda.
        Qui la pagina aperta viene accorciata fino al bordo reale del
        notebook."""
        idx = self.notebook.GetSelection()
        if idx < 0:
            return
        page = self.notebook.GetPage(idx)
        if not page or not page.IsShown():
            return
        nb = self.notebook.GetScreenRect()
        r = page.GetScreenRect()
        allowed = nb.GetBottom() - r.GetTop() - 2      # 2 px per il bordo
        if allowed > 50 and r.height > allowed:
            page.SetSize(r.width, allowed)
            if isinstance(page, wx.ScrolledWindow):
                page.FitInside()

    def _ScheduleRefit(self, delay=200):
        """Un solo ricalcolo, a eventi finiti: cambi di scheda e
        ridimensionamenti ravvicinati ne fanno partire uno soltanto."""
        timer = getattr(self, '_refitTimer', None)
        try:
            if timer is not None and timer.IsRunning():
                timer.Stop()
        except Exception:
            pass
        self._refitTimer = wx.CallLater(delay, self._SafeRefit)

    def _SafeRefit(self):
        # la finestra puo' essere gia' stata chiusa quando scatta il timer
        try:
            if not self or not self.IsShown():
                return
        except RuntimeError:
            return
        self._RefitScrollPages()

    def _LockMinHeight(self):
        """Solo Linux/GTK: la finestra non puo' diventare piu' piccola della
        dimensione con cui si apre, ne' in altezza ne' in larghezza.
        Riducendola, GTK ridisegna le schede con misure sbagliate e la pagina
        finisce sopra OK / Annulla, che non ricevono piu' i clic. Ingrandirla
        resta possibile. La misura bloccata non supera mai lo schermo
        disponibile (su schermi piccoli la finestra resta utilizzabile)."""
        if wx.Platform == '__WXMSW__' or getattr(self, '_heightLocked', False):
            return
        self._heightLocked = True
        size = getattr(self, '_startSize', None) or self.GetSize()
        w, h = size.width, size.height
        if w < 100 or h < 100:      # misura non ancora valida: niente blocco
            self._heightLocked = False
            return
        try:
            idx = wx.Display.GetFromWindow(self)
            area = wx.Display(idx if idx != wx.NOT_FOUND else 0).GetClientArea()
            w = min(w, area.width)
            h = min(h, area.height)
        except Exception:
            pass
        self.SetMinSize(wx.Size(w, h))
        self.SetSizeHints(wx.Size(w, h), wx.DefaultSize)

    def _OnShowScrollPages(self, event):
        event.Skip()
        if event.IsShown():
            self._LockMinHeight()
            self._WatchPageSizes()
            # due passaggi: GTK completa le misure dopo il primo ridisegno
            wx.CallAfter(self._SafeRefit)
            self._ScheduleRefit(250)
        else:
            timer = getattr(self, '_refitTimer', None)
            if timer is not None:
                try:
                    timer.Stop()
                except Exception:
                    pass

    def _OnPageChangedScroll(self, event):
        event.Skip()
        self._ScheduleRefit(200)

    def _OnSizeScrollPages(self, event):
        event.Skip()
        self._ScheduleRefit(200)

    def __del__(self):
        pass

    def OnFontSelected(self, event):
        event.Skip()

    def OnOk(self, event):
        event.Skip()

    def OnPin(self, event):
        event.Skip()

    def OnKlavierHexChanged(self, event):
        event.Skip()

    def OnKlavierPickColour(self, event):
        event.Skip()

    # ── Colore del tasto d'ottava (duplicato a destra, tastiere a 8 tasti) ──
    # Logica autonoma nella classe base: non richiede modifiche alla
    # sottoclasse MyPreferencesDialog.

    @staticmethod
    def _KlavierOctaveParseHex(text):
        """'#RRGGBB' (o 'RRGGBB') -> wx.Colour, None se non valido."""
        h = (text or u'').strip().lstrip('#')
        if len(h) != 6:
            return None
        try:
            return wx.Colour(int(h[0:2], 16), int(h[2:4], 16), int(h[4:6], 16))
        except ValueError:
            return None

    def _InitKlavierOctaveColour(self):
        pref = getattr(self, 'pref', None)
        enabled = bool(getattr(pref, 'klavierOctaveColourEnabled', False))
        hex_str = getattr(pref, 'klavierOctaveHex', '#3C78D2') or '#3C78D2'
        self.klavierOctaveCB.SetValue(enabled)
        self.klavierOctaveHexCtrl.ChangeValue(hex_str)
        self._UpdateKlavierOctaveSwatch()
        self._UpdateKlavierOctaveEnable()

    def _UpdateKlavierOctaveSwatch(self):
        c = self._KlavierOctaveParseHex(self.klavierOctaveHexCtrl.GetValue())
        if c is not None:
            self.klavierOctaveColourSwatch.SetBackgroundColour(c)
            self.klavierOctaveColourSwatch.Refresh()

    def _UpdateKlavierOctaveEnable(self):
        on = self.klavierOctaveCB.GetValue()
        self.klavierOctaveHexCtrl.Enable(on)
        self.klavierOctaveColourBtn.Enable(on)
        self.klavierOctaveColourSwatch.Enable(on)

    def _OnKlavierOctaveToggled(self, event):
        self._UpdateKlavierOctaveEnable()
        event.Skip()

    def _OnKlavierOctaveHexChanged(self, event):
        self._UpdateKlavierOctaveSwatch()
        event.Skip()

    def _OnKlavierOctavePickColour(self, event):
        data = wx.ColourData()
        data.SetChooseFull(True)
        c = self._KlavierOctaveParseHex(self.klavierOctaveHexCtrl.GetValue())
        if c is not None:
            data.SetColour(c)
        dlg = wx.ColourDialog(self, data)
        try:
            if dlg.ShowModal() == wx.ID_OK:
                col = dlg.GetColourData().GetColour()
                self.klavierOctaveHexCtrl.SetValue(
                    u'#%02X%02X%02X' % (col.Red(), col.Green(), col.Blue()))
        finally:
            dlg.Destroy()

    def GetKlavierOctaveColourValues(self):
        """(abilitato, '#RRGGBB' o None se il testo non e' un colore valido)."""
        c = self._KlavierOctaveParseHex(self.klavierOctaveHexCtrl.GetValue())
        hex_str = (u'#%02X%02X%02X' % (c.Red(), c.Green(), c.Blue())) if c is not None else None
        return self.klavierOctaveCB.GetValue(), hex_str

    def OnFingerNumHexChanged(self, event):
        event.Skip()

    def OnFingerNumPickColour(self, event):
        event.Skip()

    def OnEditorBgHexChanged(self, event):
        event.Skip()

    def OnEditorBgPickColour(self, event):
        event.Skip()

    def OnSelColourHexChanged(self, event):
        event.Skip()

    def OnSelColourPickColour(self, event):
        event.Skip()

    def OnCaretColourHexChanged(self, event):
        event.Skip()

    def OnCaretColourPickColour(self, event):
        event.Skip()

    def OnCapEditorHexChanged(self, event):
        event.Skip()

    def OnCapEditorPickColour(self, event):
        event.Skip()

    def OnCapPreviewHexChanged(self, event):
        event.Skip()

    def OnCapPreviewPickColour(self, event):
        event.Skip()

    def OnClearRecentFiles(self, event):
        event.Skip()

    def OnOpenTemplatesFolder(self, event):
        event.Skip()

    def OnApplyFileAssoc(self, event):
        event.Skip()

    def OnAssociateAll(self, event):
        event.Skip()

    def OnUnassociateAll(self, event):
        event.Skip()

    def OnSyntaxHexChanged(self, event):
        event.Skip()

    def OnSyntaxPickColour(self, event):
        event.Skip()

    def OnThemeLoad(self, event):
        event.Skip()

    def OnThemeSave(self, event):
        event.Skip()

    def OnThemeDelete(self, event):
        event.Skip()

    def OnShowDebugMsgChanged(self, event):
        event.Skip()

    def OnCmConfirmDeleteChanged(self, event):
        event.Skip()

    def OnCmShowIconsChanged(self, event):
        event.Skip()

    def OnDecoBarHexChanged(self, event):
        event.Skip()

    def OnDecoBarPickColour(self, event):
        event.Skip()
