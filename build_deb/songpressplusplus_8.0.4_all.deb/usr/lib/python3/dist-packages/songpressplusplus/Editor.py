###############################################################
# Name:             Editor.py
# Purpose:     Subclass of StyledTextCtrl providing songpress
#            editor: loading, saving and syntax hilighting
# Author:         Luca Allulli (webmaster@roma21.it)
# Modified by:  Denisov21
# Created:     2009-01-16
# Copyright: Luca Allulli (https://www.skeed.it/songpress)
#               Modifications copyright Denisov21
# License:     GNU GPL v2
##############################################################

# Crea ContexMenu e icone!


import codecs
import re

from wx.stc import *
import wx.lib, wx.lib.newevent

from .SDIMainFrame import *
from .SongTokenizer import *
from . import Transpose
from .utils import undo_action

_ = wx.GetTranslation

EventTextChanged, EVT_TEXT_CHANGED = wx.lib.newevent.NewEvent()


def get_text_from_clipboard():
    """
    Return text in clipboard, or None
    """
    if wx.TheClipboard.IsOpened():
        return None
    wx.TheClipboard.Open()
    do = wx.TextDataObject()
    if not wx.TheClipboard.GetData(do):
        wx.TheClipboard.Close()
        return None
    wx.TheClipboard.Close()
    return do.GetText()


class _ColourPreviewPopup(wx.PopupWindow):
    """Piccola finestra senza bordi che mostra un campione di colore e la sua
    sigla. Usata per l'anteprima al passaggio del mouse nell'editor.
    wx.PopupWindow e' disponibile sia su Windows sia su GTK (Linux)."""

    _SWATCH_W = 44
    _SWATCH_H = 24
    _PAD = 6
    _GAP = 8

    def __init__(self, parent):
        wx.PopupWindow.__init__(self, parent)
        self._colour = wx.Colour(0, 0, 0)
        self._label = ''
        self.Bind(wx.EVT_PAINT, self._on_paint)

    def ShowColour(self, colour, label, anchor_screen):
        self._colour = colour
        self._label = label or ''
        dc = wx.ClientDC(self)
        dc.SetFont(wx.SystemSettings.GetFont(wx.SYS_DEFAULT_GUI_FONT))
        tw, th = dc.GetTextExtent(self._label) if self._label else (0, 0)
        w = self._PAD + self._SWATCH_W + (self._GAP + tw if self._label else 0) + self._PAD
        h = self._PAD + max(self._SWATCH_H, th) + self._PAD
        self.SetSize((w, h))
        # Position() posiziona la finestra vicino al punto tenendo conto dei
        # bordi dello schermo (anchor_screen e' in coordinate schermo).
        self.Position(anchor_screen, (w, h))
        self.Refresh()
        self.Show()

    def _on_paint(self, evt):
        dc = wx.PaintDC(self)
        w, h = self.GetClientSize()
        # Sfondo chiaro + bordo esterno
        dc.SetBrush(wx.Brush(wx.Colour(250, 250, 250)))
        dc.SetPen(wx.Pen(wx.Colour(110, 110, 110)))
        dc.DrawRectangle(0, 0, w, h)
        # Campione del colore
        sy = (h - self._SWATCH_H) // 2
        dc.SetBrush(wx.Brush(self._colour))
        dc.SetPen(wx.Pen(wx.Colour(60, 60, 60)))
        dc.DrawRectangle(self._PAD, sy, self._SWATCH_W, self._SWATCH_H)
        # Etichetta con la sigla (es. #A52A2A)
        if self._label:
            dc.SetFont(wx.SystemSettings.GetFont(wx.SYS_DEFAULT_GUI_FONT))
            dc.SetTextForeground(wx.Colour(20, 20, 20))
            tw, th = dc.GetTextExtent(self._label)
            dc.DrawText(self._label,
                        self._PAD + self._SWATCH_W + self._GAP,
                        (h - th) // 2)


class Editor(StyledTextCtrl):
    def __init__(self, spframe, interactive=True, frame=None):
        self.frame = spframe.frame if frame is None else frame
        StyledTextCtrl.__init__(self, self.frame)
        self.spframe = spframe
        self.interactive = interactive
        if self.interactive:
            self.lastPos = 0
            self.frame.Bind(EVT_STC_CHANGE, self.OnTextChange, self)
            self.frame.Bind(EVT_STC_UPDATEUI, self.OnUpdateUI, self)
            self.Bind(EVT_STC_DOUBLECLICK, self.OnDoubleClick, self)
            self.Bind(wx.EVT_CHAR, self.OnChar, self)
            # self.Bind(EVT_STC_CLIPBOARD_COPY, self.frame.OnCopy, self)
            self.Bind(wx.EVT_CONTEXT_MENU, self.OnContextMenu, self)
            self.UsePopUp(0)  # disabilita il menu nativo di Scintilla
            self.autoChangeMode = False
            self._multi_cursor_enabled = False
            self.Bind(wx.EVT_LEFT_DOWN, self.OnEditorLeftDown)
            self.Bind(wx.EVT_KEY_DOWN, self.OnEditorKeyDown)
        self.frame.Bind(EVT_STC_STYLENEEDED, self.OnStyleNeeded, self)
        self.STC_STYLE_NORMAL = 11
        self.STC_STYLE_CHORD = 12
        self.STC_STYLE_COMMAND = 13
        self.STC_STYLE_ATTR = 14
        self.STC_STYLE_CHORUS = 15
        self.STC_STYLE_COMMENT = 16
        self.STC_STYLE_TAB_GRID = 17
        # Stile dedicato ai glifi musicali SMP (U+1D100+). Su Linux i font
        # monospazio (FreeMono, DejaVu Sans Mono, "Lucida Console") NON coprono
        # questi glifi e — senza il font-fallback di DirectWrite, che esiste solo
        # su Windows — Scintilla li rende a larghezza ~0, così restano nascosti
        # dai caratteri adiacenti (es. le graffe). Diamo a questi singoli
        # caratteri uno stile a parte con un font che li copre (FreeSerif),
        # lasciando tutto il resto del testo col font monospazio. NB: {textsize:N}
        # qui resta testo grezzo e NON ridimensiona nulla nell'editor.
        self.STC_STYLE_SMP = 18
        import sys
        self._is_linux = sys.platform.startswith('linux')
        self._smp_face = self._pick_smp_face() if self._is_linux else None
        # UTF-8: necessario per visualizzare correttamente i caratteri multibyte (simboli musicali SMP)
        self.SetCodePage(STC_CP_UTF8)
        # DirectWrite abilita il font-fallback automatico sui glifi SMP (U+1D100 ecc.) su Windows.
        # Su altri OS viene ignorato silenziosamente.
        try:
            self.SetTechnology(STC_TECHNOLOGY_DIRECTWRITE)
        except AttributeError:
            pass  # costante non disponibile in versioni vecchie di wxPython
        self.SetFont("Lucida Console", 12)
        # Su Linux: padding orizzontale attorno ai glifi musicali SMP (vedi
        # _setup_smp_representations). Va fatto dopo SetFont, quando lo stile SMP
        # ha già il suo font.
        if self._is_linux:
            self._setup_smp_representations()
        self.SetLexer(STC_LEX_CONTAINER)
        self.StyleSetForeground(self.STC_STYLE_NORMAL, wx.Colour(0, 0, 0))
        self.StyleSetForeground(self.STC_STYLE_CHORUS, wx.Colour(0, 0, 0))
        self.StyleSetForeground(self.STC_STYLE_CHORD, wx.Colour(255, 0, 0))
        self.StyleSetForeground(self.STC_STYLE_COMMAND, wx.Colour(0, 0, 255))
        self.StyleSetForeground(self.STC_STYLE_ATTR, wx.Colour(0, 128, 0))
        self.StyleSetForeground(self.STC_STYLE_COMMENT, wx.Colour(128, 128, 128))
        self.StyleSetForeground(self.STC_STYLE_TAB_GRID, wx.Colour(139, 90, 0))
        # Il glifo SMP segue il colore del testo normale (mantenuto in sync da
        # SetSyntaxColour quando cambia il tema).
        self.StyleSetForeground(self.STC_STYLE_SMP, wx.Colour(0, 0, 0))
        self.StyleSetItalic(self.STC_STYLE_TAB_GRID, True)
        self.StyleSetBold(self.STC_STYLE_CHORUS, True)
        #Dummy "token": we artificially replace every normalToken into a chorusToken when we are
        #inside chorus.  Then, we can associate the chorus style in self.tokenStyle dictionary.
        self.chorusToken = 'chorusToken'
        # Dummy token for content inside {start_of_tab}/{start_of_grid} blocks.
        self.tabGridToken = 'tabGridToken'
        self.tokenStyle = {
            SongTokenizer.openCurlyToken: self.STC_STYLE_COMMAND,
            SongTokenizer.closeCurlyToken: self.STC_STYLE_COMMAND,
            SongTokenizer.normalToken: self.STC_STYLE_NORMAL,
            SongTokenizer.commandToken: self.STC_STYLE_COMMAND,
            SongTokenizer.attrToken: self.STC_STYLE_ATTR,
            SongTokenizer.chordToken: self.STC_STYLE_CHORD,
            SongTokenizer.closeChordToken: self.STC_STYLE_CHORD,
            SongTokenizer.colonToken: self.STC_STYLE_COMMAND,
            SongTokenizer.commentToken: self.STC_STYLE_COMMENT,
            self.chorusToken: self.STC_STYLE_CHORUS,
            self.tabGridToken: self.STC_STYLE_TAB_GRID,
        }
        #self.chorus[i] == True iff, at the end of line i, we are still in chorus (i.e. bold) mode
        self.chorus = []
        # self.in_tab_grid[i] == True iff, at the end of line i, we are inside a tab/grid block
        self.in_tab_grid = []
        # Colore evidenziazione trova — attributo di istanza (default giallo)
        self.find_highlight_colour = wx.Colour(255, 220, 0)
        # Anteprima colore al passaggio del mouse sopra una sigla colore
        # (es. {textcolor:#A52A2A}). Funziona su Windows e Linux.
        self._colour_popup = None
        self._setup_colour_preview()

    # Font che coprono il blocco Unicode "Musical Symbols" (U+1D100+), in
    # ordine di preferenza per l'EDITOR. Sono proporzionali: vengono usati SOLO
    # per lo stile STC_STYLE_SMP (i singoli glifi musicali), mai per il testo
    # normale. Anteponiamo font con avanzamenti "larghi" (Noto Music ha ~25% di
    # respiro incorporato, come il fallback di DirectWrite su Windows); FreeSerif
    # copre gli stessi glifi ma li disegna molto stretti, quindi va in coda —
    # in quel caso ci pensa il padding via representation (vedi
    # _setup_smp_representations) a evitare che la graffa copra il simbolo.
    _SMP_FACES = ('Noto Music', 'Bravura Text', 'FreeSerif', 'Symbola', 'Noto Sans Symbols2')

    def _pick_smp_face(self):
        """Ritorna il primo face installato che copre i glifi musicali SMP,
        oppure None se nessuno è disponibile (in tal caso il glifo non sarà
        renderizzabile, ma senza crash). Prima la lista curata per l'editor
        (_SMP_FACES), poi gli eventuali face usati dall'app per la stampa."""
        try:
            from .MusicalSymbolDialog import get_smp_faces
            candidates = list(self._SMP_FACES) + list(get_smp_faces())
        except Exception:
            candidates = list(self._SMP_FACES)
        try:
            available = set(wx.FontEnumerator.GetFacenames())
        except Exception:
            return candidates[0] if candidates else None
        for face in candidates:
            if face in available:
                return face
        return None

    def _setup_smp_representations(self):
        """Su Linux aggiunge un filo di spazio ai lati dei glifi musicali SMP.
        I glifi di FreeSerif hanno un avanzamento strettissimo (315/1000 em per
        la nota da 1/4, contro ~880 di una lettera): la graffa adiacente finirebbe
        sopra il simbolo. Usiamo le 'representation' di Scintilla — che vengono
        misurate e disegnate come testo normale nello stile del carattere (quindi
        col font SMP) — inserendo uno spazio sottile prima e dopo il glifo, con
        aspetto PLAIN (nessun riquadro).

        Requisito: SCI_SETREPRESENTATIONAPPEARANCE (Scintilla 5.1+). Senza di esso
        le representation custom verrebbero disegnate dentro un riquadro, peggio
        del problema originale: in quel caso non tocchiamo nulla (il glifo resta
        stretto ma pulito, e conviene comunque installare Noto Music)."""
        plain = globals().get('STC_REPRESENTATION_PLAIN', None)
        if plain is None:
            return
        if not (hasattr(self, 'SetRepresentation') and
                hasattr(self, 'SetRepresentationAppearance')):
            return
        pad = '\u2009'  # THIN SPACE
        for cp in range(0x1D100, 0x1D200):  # blocco Musical Symbols
            ch = chr(cp)
            try:
                self.SetRepresentation(ch, pad + ch + pad)
                self.SetRepresentationAppearance(ch, plain)
            except Exception:
                pass

    def SetFont(self, face, size):
        font = wx.Font(
            size,
            wx.FONTFAMILY_DEFAULT,
            wx.FONTSTYLE_NORMAL,
            wx.FONTWEIGHT_NORMAL,
            faceName = face
        )
        self.StyleSetFont(STC_STYLE_DEFAULT, font)
        #I don't know why, but the following line is necessary in order to make
        #the font bold
        self.StyleSetFont(self.STC_STYLE_CHORUS, font)
        self.StyleSetFont(self.STC_STYLE_TAB_GRID, font)
        # Su Linux: font a copertura SMP (proporzionale) SOLO per lo stile dei
        # glifi musicali, alla stessa dimensione del testo. Il resto dell'editor
        # resta col font monospazio richiesto. Su Windows/macOS non serve
        # (DirectWrite fa il fallback) e non tocchiamo nulla.
        if self._is_linux and self._smp_face:
            smp_font = wx.Font(
                size,
                wx.FONTFAMILY_DEFAULT,
                wx.FONTSTYLE_NORMAL,
                wx.FONTWEIGHT_NORMAL,
                faceName = self._smp_face
            )
            self.StyleSetFont(self.STC_STYLE_SMP, smp_font)
        # Riapplica il colore di selezione dopo ogni cambio di stile
        sel_hex = getattr(getattr(self, 'spframe', None), 'pref', None)
        if sel_hex is not None:
            sel_hex = getattr(sel_hex, 'selColourHex', None)
        if sel_hex:
            self.SetSelColour(sel_hex)

    def SetBgColour(self, hex_str):
        """Imposta il colore di sfondo dell'editor su tutti gli stili STC."""
        try:
            h = hex_str.strip().lstrip('#')
            c = wx.Colour(int(h[0:2], 16), int(h[2:4], 16), int(h[4:6], 16)) if len(h) == 6 else wx.Colour(255, 255, 255)
        except Exception:
            c = wx.Colour(255, 255, 255)

        # 1. Sfondo wx nativo del controllo (aree non coperte da testo)
        self.SetBackgroundColour(c)

        # 2. STC_STYLE_DEFAULT (32) — stile base
        self.StyleSetBackground(STC_STYLE_DEFAULT, c)

        # 3. Tutti gli stili custom (11-16) + stili STC di sistema
        for style_id in (
            0,
            self.STC_STYLE_NORMAL,
            self.STC_STYLE_SMP,
            self.STC_STYLE_CHORD,
            self.STC_STYLE_COMMAND,
            self.STC_STYLE_ATTR,
            self.STC_STYLE_CHORUS,
            self.STC_STYLE_COMMENT,
            self.STC_STYLE_TAB_GRID,
            STC_STYLE_LINENUMBER,
            STC_STYLE_BRACELIGHT,
            STC_STYLE_BRACEBAD,
            STC_STYLE_CONTROLCHAR,
            STC_STYLE_INDENTGUIDE,
        ):
            self.StyleSetBackground(style_id, c)

        # 4. Forza il ridisegno completo
        self.Colourise(0, -1)
        self.Refresh()

    def SetSelColour(self, hex_str):
        """Imposta il colore di sfondo della selezione del testo."""
        try:
            h = hex_str.strip().lstrip('#')
            c = wx.Colour(int(h[0:2], 16), int(h[2:4], 16), int(h[4:6], 16)) if len(h) == 6 else wx.Colour(51, 153, 255)
        except Exception:
            c = wx.Colour(51, 153, 255)
        self.SetSelBackground(True, c)
        # Calcola luminosità per scegliere automaticamente bianco o nero come colore testo
        luminance = 0.299 * c.Red() + 0.587 * c.Green() + 0.114 * c.Blue()
        fg = wx.Colour(0, 0, 0) if luminance > 128 else wx.Colour(255, 255, 255)
        self.SetSelForeground(True, fg)

    def SetCaretColour(self, hex_str):
        """Imposta il colore del cursore di testo (caret)."""
        try:
            h = hex_str.strip().lstrip('#')
            c = wx.Colour(int(h[0:2], 16), int(h[2:4], 16), int(h[4:6], 16)) if len(h) == 6 else wx.Colour(0, 0, 0)
        except Exception:
            c = wx.Colour(0, 0, 0)
        self.SetCaretForeground(c)

    def SetSyntaxColour(self, style_id, hex_str):
        """Imposta il colore foreground di uno stile STC tramite hex string."""
        try:
            h = hex_str.strip().lstrip('#')
            c = wx.Colour(int(h[0:2], 16), int(h[2:4], 16), int(h[4:6], 16)) if len(h) == 6 else wx.Colour(0, 0, 0)
        except Exception:
            c = wx.Colour(0, 0, 0)
        self.StyleSetForeground(style_id, c)
        # Il glifo SMP non ha un colore proprio nel tema: segue il testo normale.
        if style_id == self.STC_STYLE_NORMAL:
            self.StyleSetForeground(self.STC_STYLE_SMP, c)
        self.Colourise(0, -1)
        self.Refresh()

    # --- Find highlight (indicatore STC n. 8, sfondo giallo) ---------------

    FIND_INDICATOR = 8

    def SetFindHighlight(self, word, flags=0):
        """Evidenzia tutte le occorrenze di *word* con il colore scelto dall'utente."""
        self.ClearFindHighlight()
        if not word:
            return
        # STC_INDIC_STRAIGHTBOX viene disegnato SOPRA la selezione (a differenza di
        # STC_INDIC_ROUNDBOX con UnderLine=True che va sotto e viene coperto dal
        # colore di selezione). In questo modo l'evidenziazione Find è sempre visibile
        # indipendentemente dal colore di selezione impostato dall'utente.
        self.IndicatorSetStyle(self.FIND_INDICATOR, wx.stc.STC_INDIC_STRAIGHTBOX)
        self.IndicatorSetForeground(self.FIND_INDICATOR, self.find_highlight_colour)
        self.IndicatorSetAlpha(self.FIND_INDICATOR, 120)
        self.IndicatorSetOutlineAlpha(self.FIND_INDICATOR, 220)
        self.IndicatorSetUnder(self.FIND_INDICATOR, False)
        self.SetIndicatorCurrent(self.FIND_INDICATOR)
        total = self.GetLength()
        p = 0
        while True:
            result = self.FindText(p, total, word, flags)
            pos = result[0] if isinstance(result, tuple) else result
            if pos == -1:
                break
            # len in bytes UTF-8 per IndicatorFillRange
            byte_len = len(word.encode('utf-8'))
            self.IndicatorFillRange(pos, byte_len)
            p = pos + max(1, byte_len)

    def ClearFindHighlight(self):
        """Rimuove tutte le evidenziazioni del trova."""
        self.SetIndicatorCurrent(self.FIND_INDICATOR)
        self.IndicatorClearRange(0, self.GetLength())

    def SetFindHighlightColour(self, colour):
        """Aggiorna il colore e ridisegna tutte le occorrenze già evidenziate."""
        self.find_highlight_colour = colour
        # Aggiorna lo stile dell'indicatore (coerente con SetFindHighlight)
        self.IndicatorSetStyle(self.FIND_INDICATOR, wx.stc.STC_INDIC_STRAIGHTBOX)
        self.IndicatorSetForeground(self.FIND_INDICATOR, colour)
        self.IndicatorSetAlpha(self.FIND_INDICATOR, 120)
        self.IndicatorSetOutlineAlpha(self.FIND_INDICATOR, 220)
        self.IndicatorSetUnder(self.FIND_INDICATOR, False)
        # Scintilla non aggiorna i fill esistenti al cambio colore:
        # bisogna cancellare e riscrivere gli indicatori già presenti.
        # Troviamo tutte le posizioni con indicatore attivo e le rifacciamo.
        self.SetIndicatorCurrent(self.FIND_INDICATOR)
        total = self.GetLength()
        pos = 0
        while pos < total:
            # Salta le posizioni senza indicatore
            if not (self.IndicatorValueAt(self.FIND_INDICATOR, pos)):
                next_pos = self.IndicatorEnd(self.FIND_INDICATOR, pos)
                if next_pos <= pos:
                    break
                pos = next_pos
                continue
            # Trovato inizio di un run con indicatore attivo
            start = pos
            end   = self.IndicatorEnd(self.FIND_INDICATOR, pos)
            if end <= start:
                break
            # Cancella e riscrive lo stesso range con il nuovo colore
            self.IndicatorClearRange(start, end - start)
            self.IndicatorFillRange(start,  end - start)
            pos = end

    # -----------------------------------------------------------------------

    # --- Duration dots (indicatore STC n. 9) --------------------------------
    # Mostra puntini nell'editor tra accordi con {beats_time} quando la modalità
    # è 'dots' o 'both'. I puntini sono applicati sul testo normale tra ] e [.

    DOTS_INDICATOR = 9

    def SetDurationDots(self, text, mode):
        """Aggiorna i puntini di durata nell'editor.

        *text*: testo completo del documento.
        *mode*: 'number' (nessun punto), 'dots' o 'both'.
        """
        self.ClearDurationDots()
        if mode not in ('dots', 'both'):
            return
        self.IndicatorSetStyle(self.DOTS_INDICATOR, wx.stc.STC_INDIC_DOTS)
        self.IndicatorSetForeground(self.DOTS_INDICATOR, wx.Colour(100, 100, 200))
        self.IndicatorSetUnder(self.DOTS_INDICATOR, True)
        self.SetIndicatorCurrent(self.DOTS_INDICATOR)
        import re as _re
        # Cerca righe con accordi precedute da {beats_time: ...}
        lines = text.splitlines(keepends=True)
        byte_offset = 0
        duration_pending = False
        duration_map = {}   # accordo_idx -> battiti sulla prossima riga
        for line in lines:
            stripped = line.strip()
            # Direttiva {beats_time: ...}
            if stripped.lower().startswith('{beats_time:') and stripped.endswith('}'):
                duration_pending = True
                byte_offset += len(line.encode('utf-8'))
                continue
            if duration_pending:
                duration_pending = False
                # Trova tutti gli accordi [X] nella riga e il testo tra essi
                # Disegna i puntini sul testo normale tra ] e il prossimo [
                tokens = list(_re.finditer(r'\[([^\]]+)\]', line))
                for i, m in enumerate(tokens):
                    chord_end_byte = byte_offset + len(line[:m.end()].encode('utf-8'))
                    if i + 1 < len(tokens):
                        next_start_byte = byte_offset + len(line[:tokens[i+1].start()].encode('utf-8'))
                        span = next_start_byte - chord_end_byte
                        if span > 0:
                            self.IndicatorFillRange(chord_end_byte, span)
            byte_offset += len(line.encode('utf-8'))

    def ClearDurationDots(self):
        """Rimuove i puntini di durata dall'editor."""
        self.SetIndicatorCurrent(self.DOTS_INDICATOR)
        self.IndicatorClearRange(0, self.GetLength())

    # -----------------------------------------------------------------------

    # --- Anteprima colore al passaggio del mouse ---------------------------
    # Mostra un riquadro con l'anteprima del colore quando il mouse si ferma
    # sopra una sigla colore: esadecimale ({textcolor:#A52A2A}) o per nome
    # ({textcolor:red}). Cross-platform: usa gli eventi "dwell" di Scintilla
    # e una wx.PopupWindow (supportata su Windows e su GTK/Linux).

    # #RGB, #RRGGBB o #RRGGBBAA (la forma piu' lunga ha priorita').
    _HEX_COLOUR_RE = re.compile(
        r'#(?:[0-9A-Fa-f]{8}|[0-9A-Fa-f]{6}|[0-9A-Fa-f]{3})\b')
    # Nome colore dentro una direttiva che contiene "color"/"colour"
    # (es. {textcolor:red}, {text_colour: dark green}); il gruppo 1 e' il nome.
    _NAMED_COLOUR_RE = re.compile(
        r'\{[^{}]*colou?r[^:{}]*:\s*([A-Za-z][A-Za-z ]*?)\s*\}', re.IGNORECASE)

    def _setup_colour_preview(self):
        """Abilita gli eventi dwell e collega gli handler dell'anteprima."""
        if not hasattr(wx, 'PopupWindow'):
            return  # piattaforma senza PopupWindow: niente anteprima, nessun crash
        try:
            self.SetMouseDwellTime(400)  # ms di sosta prima di mostrare l'anteprima
        except Exception:
            return
        self.Bind(EVT_STC_DWELLSTART, self.OnColourDwellStart)
        self.Bind(EVT_STC_DWELLEND, self.OnColourDwellEnd)
        self.Bind(wx.EVT_LEAVE_WINDOW, self._on_leave_hide_colour)
        self.Bind(wx.EVT_MOUSEWHEEL, self._on_wheel_hide_colour)

    def _parse_colour(self, s):
        """Converte una sigla colore (esadecimale o nome) in wx.Colour, o None."""
        s = s.strip()
        if s.startswith('#'):
            h = s[1:]
            try:
                if len(h) == 3:
                    return wx.Colour(int(h[0] * 2, 16), int(h[1] * 2, 16), int(h[2] * 2, 16))
                if len(h) == 6:
                    return wx.Colour(int(h[0:2], 16), int(h[2:4], 16), int(h[4:6], 16))
                if len(h) == 8:
                    return wx.Colour(int(h[0:2], 16), int(h[2:4], 16),
                                     int(h[4:6], 16), int(h[6:8], 16))
            except ValueError:
                return None
            return None
        try:
            c = wx.TheColourDatabase.Find(s.upper())
        except Exception:
            return None
        return c if (c is not None and c.IsOk()) else None

    def _colour_at_position(self, pos):
        """Se in *pos* (posizione byte STC) c'e' una sigla colore valida,
        ritorna (wx.Colour, etichetta); altrimenti None."""
        if pos is None or pos < 0:
            return None
        line = self.LineFromPosition(pos)
        line_start = self.PositionFromLine(line)
        text = self.GetLine(line)
        rel_byte = pos - line_start

        # Le posizioni STC sono in byte (UTF-8): converto gli indici carattere
        # dei match regex in indici byte per confrontarli con rel_byte.
        def byte_idx(char_idx):
            return len(text[:char_idx].encode('utf-8'))

        for m in self._HEX_COLOUR_RE.finditer(text):
            if byte_idx(m.start()) <= rel_byte < byte_idx(m.end()):
                col = self._parse_colour(m.group(0))
                if col is not None:
                    return (col, m.group(0))
        for m in self._NAMED_COLOUR_RE.finditer(text):
            if byte_idx(m.start(1)) <= rel_byte < byte_idx(m.end(1)):
                col = self._parse_colour(m.group(1))
                if col is not None:
                    return (col, m.group(1).strip())
        return None

    def _colour_preview_enabled(self):
        """True se l'anteprima colore e' attiva nelle preferenze.
        Lettura dal vivo: il cambio nelle preferenze ha effetto subito, senza
        riavvio. Se non c'e' un oggetto pref (es. editor di anteprima interno
        al dialogo) il default e' True."""
        pref = getattr(getattr(self, 'spframe', None), 'pref', None)
        return bool(getattr(pref, 'colourPreview', True))

    def OnColourDwellStart(self, evt):
        if not self._colour_preview_enabled():
            self._hide_colour_popup()
            evt.Skip()
            return
        pos = evt.GetPosition()
        info = self._colour_at_position(pos)
        if info is None:
            self._hide_colour_popup()
            evt.Skip()
            return
        colour, label = info
        # Ancora il popup appena SOTTO il testo della sigla colore (non al
        # puntatore), cosi' appare "attaccato" alla riga. PointFromPosition da'
        # il pixel in alto a sinistra del carattere; TextHeight l'altezza riga.
        pt = self.PointFromPosition(pos)
        lh = self.TextHeight(self.LineFromPosition(pos))
        anchor = self.ClientToScreen(wx.Point(pt.x, pt.y + lh + 1))
        self._show_colour_popup(colour, label, anchor)
        evt.Skip()

    def OnColourDwellEnd(self, evt):
        self._hide_colour_popup()
        evt.Skip()

    def _on_leave_hide_colour(self, evt):
        self._hide_colour_popup()
        evt.Skip()

    def _on_wheel_hide_colour(self, evt):
        self._hide_colour_popup()
        evt.Skip()

    def _show_colour_popup(self, colour, label, anchor_screen):
        if self._colour_popup is None:
            try:
                self._colour_popup = _ColourPreviewPopup(self)
            except Exception:
                self._colour_popup = None
                return
        self._colour_popup.ShowColour(colour, label, anchor_screen)

    def _hide_colour_popup(self):
        if self._colour_popup is not None:
            self._colour_popup.Hide()

    # -----------------------------------------------------------------------

    def New(self):
        self.ClearAll()

    def Open(self):
        self.ClearAll()
        self.LoadFile(self.spframe.document)

    def Save(self):
        #self.SaveFile(self.spframe.document)
        t = self.GetText()
        f = codecs.open(self.spframe.document, 'w', 'utf-8')
        f.write(t)
        f.close()

    def GetTextOrSelection(self):
        start, end = self.GetSelection()
        if start == end:
            return self.GetText()
        return self.GetSelectedText()

    def ReplaceTextOrSelection(self, text):
        start, end = self.GetSelection()
        if start == end:
            self.SetText(text)
        else:
            self.ReplaceSelection(text)

    def GetChordUnderCursor(self, position=None):
        """Return info about chord under cursor, or None

        If `position` is specified, use it instead of the cursor position.

        Return a 3-tuple: (begin, end, chord)
            begin: position before open bracket
            end: position after close bracket
            chord: chord, without brackets
        """
        if position is None:
            pos, dummy = self.GetSelection()
        else:
            pos = position
        char = ""
        if position is None and self.GetSelectedText().find('[') != -1:
            start = pos
            while char != '[':
                next = self.PositionAfter(start)
                char = self.GetTextRange(start, next)
                start = next
            start = self.PositionBefore(start)
        else:
            start = self.PositionBefore(pos)
            while start >= 0 and char != '[' and char != '\n' and char != ']':
                char = self.GetTextRange(start, self.PositionAfter(start))
                if start == 0:
                    start = -1
                else:
                    start = self.PositionBefore(start)
            if start >= 0:
                start = self.PositionAfter(start)
            else:
                start = 0
        if char == '[':
            end = self.PositionBefore(pos)
            l = self.GetLength()
            while end < l and char != ']' and char != '\n':
                char = self.GetTextRange(end, self.PositionAfter(end))
                end = self.PositionAfter(end)
            if char == ']':
                return (start, end, self.GetTextRange(self.PositionAfter(start), self.PositionBefore(end)))
        return None

    def SelectNextChord(self):
        dummy, pos = self.GetSelection()
        n = self.GetLength()
        c = ''
        while pos < n:
            while pos < n and c != '[':
                c = self.GetTextRange(pos, self.PositionAfter(pos))
                pos = self.PositionAfter(pos)
            if c == '[':
                start = pos
                while pos < n and c != ']' and c != '\n':
                    c = self.GetTextRange(pos, self.PositionAfter(pos))
                    pos = self.PositionAfter(pos)
                if c == ']':
                    self.SetSelection(self.PositionBefore(start), pos)
                    return True
        return False

    def SelectPreviousChord(self):
        pos, dummy = self.GetSelection()
        c = ''
        done = False
        while not done:
            while not done and c != ']':
                c = self.GetTextRange(pos, self.PositionAfter(pos))
                if pos <= 0:
                    done = True
                else:
                    pos = self.PositionBefore(pos)
            if c == ']':
                end = pos
                while not done and c != '[' and c != '\n':
                    c = self.GetTextRange(pos, self.PositionAfter(pos))
                    if pos <= 0:
                        pos = -1
                        done = True
                    else:
                        pos = self.PositionBefore(pos)
                if pos == -1:
                    pos = 0
                else:
                    pos = self.PositionAfter(pos)
                if c == '[':
                    self.SetSelection(pos, self.PositionAfter(self.PositionAfter(end)))
                    return True
        return False

    def RemoveChordsInSelection(self):
        self.ReplaceSelection(Transpose.removeChords(self.GetSelectedText()))
        
    def CopyOnlyText(self):
        text = Transpose.removeChordPro(self.GetSelectedText())
        c = wx.TheClipboard
        if c.Open():
            c.SetData(wx.TextDataObject(text))
            c.Close()

    def OnTextChange(self, evt):
        if self.interactive:
            self.spframe.SetModified()
            self.spframe.TextUpdated()
            if not self.autoChangeMode:
                currentPos = self.GetCurrentPos()
                if currentPos - self.lastPos > 2:
                    evt = EventTextChanged(lastPos=self.lastPos, currentPos=currentPos)
                    wx.PostEvent(self.frame, evt)

    def OnUpdateUI(self, evt):
        self.lastPos = self.GetCurrentPos()
        evt.Skip(False)

    def OnDoubleClick(self, evt):
        t = self.GetChordUnderCursor()
        if t is not None:
            self.SetSelection(t[0], t[1])
        evt.Skip()

    def OnChar(self, evt):
        t = self.GetSelectedText()
        if t != '' and t[0] == '[' and t[-1] == ']':
            c = evt.GetKeyCode()
            if (c >= 65 and c <= 90) or (c >= 97 and c <= 122):
                s, e = self.GetSelection()
                self.SetSelection(self.PositionAfter(s), self.PositionBefore(e))

        evt.Skip()

    def AutoChangeMode(self, acm):
        self.autoChangeMode = acm
        
    def PasteChords(self):
        src = get_text_from_clipboard()
        if src is None:
            return
        with undo_action(self):
            start, end = self.GetSelection()
            if start == end:
                l = self.LineFromPosition(start)
                end = self.PositionFromLine(l + len(src.splitlines()))
                if end == -1:
                    end = self.GetLength()
                else:
                    end = self.PositionBefore(end)
            prev = self.PositionBefore(end)
            while end > start and self.GetCharAt(prev) in [10, 13]:
                end = prev
                prev = self.PositionBefore(end)
            self.SetSelection(start, end)
            sel = self.GetSelectedText()
            if sel == "":
                sel = " "
            self.ReplaceSelection(Transpose.pasteChords(src, sel))

    def ApplyMultiCursor(self, enabled):
        """Abilita o disabilita il multicursore. Chiamare dopo ogni cambio preferenza."""
        self._multi_cursor_enabled = enabled
        self.SetMultipleSelection(enabled)
        self.SetAdditionalSelectionTyping(enabled)
        self.SetMultiPaste(STC_MULTIPASTE_EACH if enabled else STC_MULTIPASTE_ONCE)
        self.SetAdditionalCaretsVisible(enabled)

    def OnEditorLeftDown(self, evt):
        if self._multi_cursor_enabled and evt.AltDown():
            pos = self.PositionFromPoint(evt.GetPosition())
            if pos != STC_INVALID_POSITION:
                self.AddSelection(pos, pos)
            # Non propagare: il click nativo resetterebbe le selezioni
            return
        if self._multi_cursor_enabled and self.GetSelections() > 1:
            # Click normale: resetta a selezione singola sul cursore principale
            caret = self.GetSelectionNCaret(self.GetMainSelection())
            anchor = self.GetSelectionNAnchor(self.GetMainSelection())
            self.SetSelection(anchor, caret)
        evt.Skip()

    def OnEditorKeyDown(self, evt):
        # Spazio dentro {start_of_grid} → inserisce pipe e sposta il cursore nella cella vuota.
        # Intercettato in KEY_DOWN (prima che STC scriva il carattere).
        if evt.GetKeyCode() == wx.WXK_SPACE and not evt.ControlDown() and not evt.AltDown():
            pref = getattr(self.spframe, 'pref', None)
            space_as_pipe = getattr(pref, 'gridSpaceAsPipe', True)
            if space_as_pipe and self.spframe._GetGridContext() is not None:
                self.spframe._MoveGridCellRight()
                return   # non propagare: lo spazio non deve essere inserito nell'STC

        if (self._multi_cursor_enabled
                and evt.ControlDown()
                and not evt.AltDown()
                and evt.GetKeyCode() == ord('D')):
            self._SelectNextOccurrence()
            return
        evt.Skip()

    def _SelectNextOccurrence(self):
        """Aggiunge una selezione sulla prossima occorrenza del testo selezionato (Ctrl+D)."""
        n = self.GetSelections()
        idx = self.GetMainSelection()
        s = self.GetSelectionNStart(idx)
        e = self.GetSelectionNEnd(idx)
        if s == e:
            return
        word = self.GetTextRange(s, e)
        last_e = max(self.GetSelectionNEnd(i) for i in range(n))
        found = self.FindText(last_e, self.GetLength(), word, 0)[0]
        if found == -1:
            found = self.FindText(0, s, word, 0)[0]
        if found != -1:
            self.AddSelection(found + len(word), found)
            self.SetMainSelection(self.GetSelections() - 1)

    def OnContextMenu(self, evt):
        menu = wx.Menu()

        import os
        from .Globals import glb
        # Usa glb (frozen-aware) invece di __file__: nella build congelata
        # img/ è nella cartella dell'exe, non dentro lib/songpressPlusPlus/.
        _img_dir = glb.AddPath('img')
        img = lambda name: os.path.join(_img_dir, name)

        # Recupera le preferenze di visibilità (default True se non presenti)
        pref = getattr(self.spframe, 'pref', None)
        def cm_pref(name):
            if pref is None:
                return True
            return getattr(pref, name, True)

        show_icons = cm_pref('cmShowIcons')

        def add_item(label, handler, art_id=None, png_path=None, enabled=True):
            item = wx.MenuItem(menu, wx.ID_ANY, label)
            if show_icons:
                bmp = wx.NullBitmap
                if png_path:
                    b = wx.Bitmap(png_path, wx.BITMAP_TYPE_PNG)
                    if b.IsOk():
                        bmp = b
                elif art_id is not None:
                    b = wx.ArtProvider.GetBitmap(art_id, wx.ART_MENU, (16, 16))
                    if b.IsOk():
                        bmp = b
                if bmp.IsOk():
                    item.SetBitmap(bmp)
            menu.Append(item)
            item.Enable(enabled)
            menu.Bind(wx.EVT_MENU, handler, item)

        has_selection = self.GetSelectedText() != ''
        can_paste = wx.TheClipboard.IsSupported(wx.DataFormat(wx.DF_TEXT))
        can_undo = self.CanUndo()
        can_redo = self.CanRedo()

        # --- Gruppo Cronologia ---
        show_undo = cm_pref('cmUndo')
        show_redo = cm_pref('cmRedo')
        if show_undo:
            add_item(_("&Undo"), lambda e: self.Undo(), png_path=img('undo.png'), enabled=can_undo)
        if show_redo:
            add_item(_("&Redo"), lambda e: self.Redo(), png_path=img('redo.png'), enabled=can_redo)
        if show_undo or show_redo:
            menu.AppendSeparator()

        # --- Gruppo Modifica ---
        show_cut    = cm_pref('cmCut')
        show_copy   = cm_pref('cmCopy')
        show_paste  = cm_pref('cmPaste')
        show_delete = cm_pref('cmDelete')
        if show_cut:
            add_item(_("Cu&t"),    lambda e: self.Cut(),                png_path=img('cut.png'),    enabled=has_selection)
        if show_copy:
            add_item(_("&Copy"),   lambda e: self.Copy(),               png_path=img('copy.png'),   enabled=has_selection)
        if show_paste:
            add_item(_("&Paste"),  lambda e: self.Paste(),              png_path=img('paste.png'),  enabled=can_paste)
        if show_delete:
            def _do_delete(e):
                if cm_pref('cmConfirmDelete'):
                    if wx.MessageBox(
                        _("Delete the selected text?"),
                        _("Songpress++"),
                        wx.YES_NO | wx.ICON_QUESTION
                    ) != wx.YES:
                        return
                self.ReplaceSelection('')
            add_item(_("&Delete"), _do_delete, png_path=img('delete.png'), enabled=has_selection)
        if show_cut or show_copy or show_paste or show_delete:
            menu.AppendSeparator()

        # --- Gruppo Azioni speciali ---
        show_paste_chords         = cm_pref('cmPasteChords')
        show_copy_text_only       = cm_pref('cmCopyTextOnly')
        show_propagate_verse      = cm_pref('cmPropagateVerseChords')
        show_propagate_chorus     = cm_pref('cmPropagateChorusChords')
        if show_paste_chords:
            add_item(_("Paste &chords"),            lambda e: self.PasteChords(),                              png_path=img('pasteChords.png'), enabled=can_paste)
        if show_propagate_verse:
            add_item(_("Propagate &verse chords"),  lambda e: self.spframe.OnPropagateVerseChords(e))
        if show_propagate_chorus:
            add_item(_("Propagate c&horus chords"), lambda e: self.spframe.OnPropagateChorusChords(e))
        if show_copy_text_only:
            add_item(_("Copy &text only"),          lambda e: self.CopyOnlyText(),                             png_path=img('copy.png'),        enabled=has_selection)
        if show_paste_chords or show_copy_text_only or show_propagate_verse or show_propagate_chorus:
            menu.AppendSeparator()

        # --- Gruppo Selezione ---
        if cm_pref('cmSelectAll'):
            add_item(_("Select &all"), lambda e: self.SelectAll(), png_path=img('selectAll.png'))

        # Rimuove eventuali separatori finali ridondanti
        count = menu.GetMenuItemCount()
        if count > 0:
            last = menu.FindItemByPosition(count - 1)
            if last and last.IsSeparator():
                menu.Remove(last)

        if menu.GetMenuItemCount() > 0:
            self.PopupMenu(menu)
        menu.Destroy()

    def _set_styling_smp(self, content, base_style):
        """Colora *content* con *base_style*, ma assegna STC_STYLE_SMP ai
        caratteri non-BMP (i glifi musicali SMP, codepoint >= 0x10000), così su
        Linux vengono resi col font FreeSerif e non restano nascosti dai
        caratteri adiacenti. Le lunghezze passate a SetStyling sono in BYTE
        (l'editor è in codepage UTF-8): un carattere SMP occupa 4 byte."""
        smp_style = self.STC_STYLE_SMP
        run_len = 0
        run_style = base_style
        for ch in content:
            b = len(ch.encode('utf-8'))
            st = smp_style if ord(ch) >= 0x10000 else base_style
            if st == run_style:
                run_len += b
            else:
                if run_len:
                    self.SetStyling(run_len, run_style)
                run_style = st
                run_len = b
        if run_len:
            self.SetStyling(run_len, run_style)

    def OnStyleNeeded(self, evt):
        end = evt.GetPosition()
        pos = self.GetEndStyled()
        ln = self.LineFromPosition(pos)
        start = self.PositionFromLine(ln)
        if ln > 0 and len(self.chorus) > ln-1:
            bold = self.chorus[ln-1]
        else:
            bold = False
        if ln > 0 and len(self.in_tab_grid) > ln-1:
            in_tg = self.in_tab_grid[ln-1]
        else:
            in_tg = False
        #changedBold is True iff self.chorus has changed for the current line, and thus we need
        #to process (at least) another line
        changedBold = False
        lc = self.GetLineCount()

        # Comandi di apertura/chiusura blocchi tab e grid (tutte le varianti ChordPro)
        _SOT = frozenset(['SOT', 'START_OF_TAB'])
        _EOT = frozenset(['EOT', 'END_OF_TAB'])
        _SOG = frozenset(['SOG', 'START_OF_GRID', 'GRID'])
        _EOG = frozenset(['EOG', 'END_OF_GRID'])
        # Varianti di apertura/chiusura del ritornello (grassetto): forme standard
        # ChordPro + alias 'start_chorus'/'end_chorus'. NB: NON includere il bare
        # 'CHORUS', che in ChordPro e' il richiamo {chorus} (non apre un blocco).
        _SOC = frozenset(['SOC', 'START_OF_CHORUS', 'START_CHORUS'])
        _EOC = frozenset(['EOC', 'END_OF_CHORUS', 'END_CHORUS'])

        while (changedBold and ln < lc) or start < end:
            self.StartStyling(start)
            l = self.GetLine(ln)
            tkz = SongTokenizer(l)
            for tok in tkz:
                n = len(tok.content.encode('utf-8'))
                t = tok.token
                if in_tg and t == SongTokenizer.normalToken:
                    t = self.tabGridToken
                elif bold and t == SongTokenizer.normalToken:
                    t = self.chorusToken
                base_style = self.tokenStyle[t]
                if self._is_linux:
                    self._set_styling_smp(tok.content, base_style)
                else:
                    self.SetStyling(n, base_style)
                if t == SongTokenizer.commandToken:
                    # Togli l'eventuale etichetta dopo ':' (es. {start_of_grid:CODA})
                    # cosi' il comando resta confrontabile con gli insiemi sotto.
                    cmd = tok.content.upper().split(':', 1)[0].strip()
                    if cmd in _SOC:
                        bold = True
                    elif cmd in _EOC:
                        bold = False
                    elif cmd in _SOT or cmd in _SOG:
                        in_tg = True
                    elif cmd in _EOT or cmd in _EOG:
                        in_tg = False
            if len(self.chorus) > ln:
                changedBold = self.chorus[ln] != bold
                self.chorus[ln] = bold
            else:
                self.chorus.append(bold)
                changedBold = False
            if len(self.in_tab_grid) > ln:
                if self.in_tab_grid[ln] != in_tg:
                    changedBold = True
                self.in_tab_grid[ln] = in_tg
            else:
                self.in_tab_grid.append(in_tg)
            ln = ln + 1
            start = self.PositionFromLine(ln)


