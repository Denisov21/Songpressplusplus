###############################################################
# Name:             PreviewCanvas.py
# Purpose:          Window containing preview
# Author:           Luca Allulli (webmaster@roma21.it)
# Modified by:      Denisov21
# Created:          2009-02-21
# Copyright:        Luca Allulli (https://www.skeed.it/songpress)
#                   Modifications copyright Denisov21
# License:          GNU GPL v2
###############################################################
#
# CHANGELOG (miglioramenti rispetto alla versione originale):
#
# [Fix 1] Slider zoom: sostituisce i pulsanti +/- con uno slider orizzontale
#         (range 30-300%, step 10%). I pulsanti +/- rimangono ai lati.
#         Lo slider si sincronizza bidirezionalmente con tutti i metodi zoom.
#
# [Fix 2] BestSize pannello AUI: 240x400 → 320x500 (in SongpressFrame)
#
# [Fix 3] Margine orizzontale dinamico: 3% della larghezza client (min 8px)
#         invece di 24px fisso. Si adatta al pannello stretto o largo.
#
#
# [Fix 5] EVT_CHAR_HOOK: intercetta Ctrl+PgUp/PgDn per scroll di pagina
#         prima che ScrolledWindow consumi i tasti freccia.
#
# [Fix 6] pixedScrolled scalato: la granularita' dello scroll e' proporzionale
#         allo zoom (zoom alto = scroll piu' fine).
#
# [Fix 7] Rimosso 'import platform' inutilizzato.
#
# [Fix 8] Rimossa costante _PAGE_W_MM (mai usata).
#
# [Fix 9] Shortcut Ctrl+Shift+G = fit-to-width (mnemonico per tastiera).

#
# [UX] Toolbar compatta sopra il pannello anteprima, con:
#        - pulsante "Copia negli appunti" (sostituisce il vecchio HyperlinkCtrl)
#        - pulsanti Zoom In / Zoom Out / Reset zoom (100%)
#        - label zoom corrente (es. "100%")
#        - pulsante Fit-to-width (adatta larghezza alla finestra)
#
# [Layout & Zoom] Supporto zoom tramite self._zoom_factor (default 1.0).
#        - Ctrl+Scroll sul canvas: zoom in/out a step del 10%
#        - Ctrl++ / Ctrl+- / Ctrl+0: zoom da tastiera
#        - Range: 30% – 300%
#
# [Layout] Sfondo a "pagine":
#        - Canvas con sfondo grigio (simulazione fogli)
#        - Il renderer disegna ogni "pagina" come rettangolo bianco

#        - Calcolo altezza pagina in px in base al formato carta corrente
#        - Il renderer esistente viene lasciato invariato; le pagine
#          vengono simulate nel DC di PreviewCanvas
#
# [Performance] Debounce del refresh (default 300 ms):
#        - Refresh() non ridisegna immediatamente ma avvia un wx.CallLater
#        - Se arriva un nuovo Refresh() prima dello scadere del timer,
#          il vecchio viene cancellato e uno nuovo viene avviato
#        - Questo evita ridisegni continui durante la digitazione rapida
#
# [Indicatore pagina] Label "Pagina X di Y" aggiornata allo scroll
#        - Calcola la pagina corrente in base alla posizione verticale
#          dello scrolled window
#
###############################################################

import re

import wx
import wx.adv

from .Renderer import *
from .Globals import glb   # per glb.AddPath('img/...')

_ = wx.GetTranslation

# ---------------------------------------------------------------------------
# Costanti
# ---------------------------------------------------------------------------
_ZOOM_MIN      = 0.30
_ZOOM_MAX      = 3.00
_ZOOM_STEP     = 0.10
_ZOOM_DEFAULT  = 1.00
_DEBOUNCE_MS   = 300      # millisecondi di attesa prima del ridisegno

# Costanti layout pannello anteprima
_PAGE_H_MM     = 297.0   # altezza A4 default (mm) — usata come fallback
_PAGE_GAP_PX   = 16      # spazio verticale tra una pagina e l'altra (px)
# _PAGE_MARGIN_H e' ora calcolato dinamicamente in OnPaint (3% della larghezza)


class PreviewCanvas(object):
    def __init__(self, parent, sf, notations, sd=None, embedded=False, minSizeEnabled=True):
        object.__init__(self)
        if sd is None:
            sd = SongDecorator()
        self.main_panel = wx.Window(parent)
        if minSizeEnabled:
            self.main_panel.SetMinSize(wx.Size(370, 530))
        self._zoom_factor = _ZOOM_DEFAULT
        self._debounce_timer = None     # wx.CallLater attivo (o None)
        self._pending_text   = ""       # testo in attesa di refresh

        # Flags opzioni anteprima (applicati dopo la creazione del panel)
        self._showPageIndicator = True
        self._greyBackground    = True
        self._debounceEnabled   = True   # se False: ridisegno immediato ad ogni tasto
        self._watermark_cfg     = None   # config filigrana (None = disattivata)

        # Dimensioni foglio e margini correnti in mm (aggiornate da SetPageSizeMm /
        # SetPageMarginsMm). Default A4 portrait con margini 15mm.
        # Vengono sincronizzati da SongpressFrame dopo OnPageSetup.
        self._page_w_mm     = 210.0
        self._page_h_mm     = 297.0
        self._margin_top_mm    = 15.0
        self._margin_bottom_mm = 15.0

        # Flags per le linee di interruzione (persistenti anche al cambio decorator)
        self._showPageBreakLines  = True
        self._showColumnBreakLines = True

        # Callback chiamata al doppio-click sull'anteprima:
        # signature: callback(line_number: int) dove line_number e' 0-based
        # Impostata da SongpressFrame con SetClickCallback()
        self._on_click_callback = None
        # Callback chiamata al clic sul pulsante "copia" della toolbar.
        # signature: callback() senza argomenti (di norma SongpressFrame.CopyAsImage).
        self._on_copy_callback = None
        # Callback chiamata al clic sul pulsante "aggiorna anteprima" della toolbar.
        # signature: callback() -> str  — restituisce il testo corrente dell'editor.
        # Impostata da SongpressFrame con SetRefreshCallback().
        self._on_refresh_callback = None
        # Se False il doppio-click non fa nulla (disabilitato da opzioni)
        self._dblClickFocusEnabled = True

        # Riferimento alla finestra fullscreen (None = non aperta)
        self._fullscreen_frame = None

        # ── Layout principale ────────────────────────────────────────────
        outer = wx.BoxSizer(wx.VERTICAL)
        parent_win = self.main_panel

        if not embedded:
            # ── Toolbar compatta ────────────────────────────────────────
            toolbar = wx.Panel(parent_win, style=wx.BORDER_NONE)
            # NB: NON fissiamo il colore con SYS_COLOUR_BTNFACE. Su wxGTK quel
            # valore viene letto una sola volta all'avvio e resta congelato, per
            # cui la toolbar non seguirebbe i cambi di tema del desktop. Lasciando
            # il colore di default è GTK stesso a ridipingerla col tema corrente,
            # esattamente come fa già coi pulsanti nativi. (Su Windows: invariato.)
            toolbar.SetBackgroundColour(wx.NullColour)
            tb_sizer = wx.BoxSizer(wx.HORIZONTAL)

            # Pulsante copia (sostituisce HyperlinkCtrl)
            # L'icona ART_COPY del tema simbolico esce grigio chiarissimo sul
            # tema chiaro (poco contrasto): la disegniamo noi nel colore del
            # testo dei pulsanti, così sul tema chiaro è nera e ben visibile
            # (e resta leggibile anche sul tema scuro).
            btn_copy = wx.BitmapButton(
                toolbar, wx.ID_ANY,
                self._load_copy_bitmap(16),
                style=wx.BORDER_NONE,
            )
            btn_copy.SetToolTip(_("Copy formatted song to clipboard"))
            tb_sizer.Add(btn_copy, 0, wx.ALIGN_CENTER_VERTICAL | wx.LEFT, 4)

            # Pulsante "Aggiorna anteprima" (accanto alla copia)
            btn_refresh = wx.BitmapButton(
                toolbar, wx.ID_ANY,
                self._load_refresh_bitmap(16),
                style=wx.BORDER_NONE,
            )
            btn_refresh.SetToolTip(_("Refresh preview"))
            tb_sizer.Add(btn_refresh, 0, wx.ALIGN_CENTER_VERTICAL | wx.LEFT, 2)

            tb_sizer.Add(wx.StaticLine(toolbar, style=wx.LI_VERTICAL), 0,
                         wx.EXPAND | wx.LEFT | wx.RIGHT, 4)

            # Zoom out (pulsante piccolo a sinistra dello slider)
            btn_zoom_out = wx.BitmapButton(
                toolbar, wx.ID_ANY,
                self._make_sign_bitmap(self._ZOOM_RED, plus=False, px=16),
                style=wx.BORDER_NONE,
            )
            btn_zoom_out.SetToolTip(_("Zoom out (Ctrl+-)"))
            tb_sizer.Add(btn_zoom_out, 0, wx.ALIGN_CENTER_VERTICAL)

            # Slider zoom: range 30-300 in step da 10
            _zoom_pct = int(round(_ZOOM_DEFAULT * 100))
            self._zoom_slider = wx.Slider(
                toolbar, wx.ID_ANY,
                value=_zoom_pct, minValue=int(_ZOOM_MIN * 100), maxValue=int(_ZOOM_MAX * 100),
                size=(90, -1),
                style=wx.SL_HORIZONTAL,
            )
            self._zoom_slider.SetToolTip(_("Zoom level — drag or use Ctrl+Scroll"))
            tb_sizer.Add(self._zoom_slider, 0, wx.ALIGN_CENTER_VERTICAL | wx.LEFT | wx.RIGHT, 2)

            # Zoom in (pulsante piccolo a destra dello slider)
            btn_zoom_in = wx.BitmapButton(
                toolbar, wx.ID_ANY,
                self._make_sign_bitmap(self._ZOOM_RED, plus=True, px=16),
                style=wx.BORDER_NONE,
            )
            btn_zoom_in.SetToolTip(_("Zoom in (Ctrl++)"))
            tb_sizer.Add(btn_zoom_in, 0, wx.ALIGN_CENTER_VERTICAL)

            # Label zoom (mostra la percentuale corrente)
            self._zoom_label = wx.StaticText(toolbar, label="100%", size=(38, -1),
                                             style=wx.ALIGN_CENTRE_HORIZONTAL)
            tb_sizer.Add(self._zoom_label, 0, wx.ALIGN_CENTER_VERTICAL | wx.LEFT, 3)

            # Reset zoom 1:1
            btn_zoom_reset = wx.Button(toolbar, wx.ID_ANY, "1:1",
                                       size=(30, -1), style=wx.BORDER_SIMPLE)
            btn_zoom_reset.SetToolTip(_("Reset zoom to 100% (Ctrl+0)"))
            tb_sizer.Add(btn_zoom_reset, 0, wx.ALIGN_CENTER_VERTICAL | wx.LEFT, 4)

            tb_sizer.Add(wx.StaticLine(toolbar, style=wx.LI_VERTICAL), 0,
                         wx.EXPAND | wx.LEFT | wx.RIGHT, 4)

            # Pulsante tutto schermo
            btn_fullscreen = wx.Button(toolbar, wx.ID_ANY, u"⛶",
                                       size=(28, -1), style=wx.BORDER_SIMPLE)
            btn_fullscreen.SetToolTip(_("Full screen preview (F11)"))
            tb_sizer.Add(btn_fullscreen, 0, wx.ALIGN_CENTER_VERTICAL | wx.RIGHT, 2)

            tb_sizer.Add(wx.StaticLine(toolbar, style=wx.LI_VERTICAL), 0,
                         wx.EXPAND | wx.LEFT | wx.RIGHT, 4)

            # Fit-to-width — nessuna size fissa: wx calcola la larghezza dal testo
            # tradotto (es. "Adatta" e' piu' largo di "Fit")
            btn_fit = wx.Button(toolbar, wx.ID_ANY, _("Fit"),
                                style=wx.BORDER_SIMPLE)
            btn_fit.SetToolTip(_("Fit preview width to panel (Ctrl+Shift+G)"))
            tb_sizer.Add(btn_fit, 0, wx.ALIGN_CENTER_VERTICAL | wx.LEFT | wx.RIGHT, 2)

            # Spacer + label pagina (allineata a destra)
            # La label viene pre-dimensionata sul testo piu' lungo possibile
            # ("Pagina 99 di 99") cosi' non viene mai troncata.
            tb_sizer.AddStretchSpacer()
            _sample = _("Page %d of %d") % (99, 99)
            self._page_label = wx.StaticText(toolbar, label=_sample)
            _w, _h = self._page_label.GetTextExtent(_sample)
            self._page_label.SetMinSize(wx.Size(_w + 8, -1))
            self._page_label.SetLabel("")
            self._page_label.SetForegroundColour(wx.Colour(100, 100, 100))
            tb_sizer.Add(self._page_label, 0, wx.ALIGN_CENTER_VERTICAL | wx.RIGHT, 6)

            toolbar.SetSizer(tb_sizer)
            toolbar.Layout()
            outer.Add(toolbar, 0, wx.EXPAND)

            # Riferimento alla toolbar per poterne riaggiornare i colori
            # quando cambia il tema del desktop (vedi RefreshSystemColours).
            self._toolbar = toolbar

            # ── Separatore ───────────────────────────────────────────────
            outer.Add(wx.StaticLine(parent_win), 0, wx.EXPAND)

            # Salva riferimento al link per retrocompatibilità con SongpressFrame
            # (SongpressFrame fa: self.previewCanvas.main_panel.Bind(EVT_HYPERLINK, ..., self.previewCanvas.link))
            # Creiamo un attributo link fittizio che espone lo stesso id del btn_copy
            self.link = btn_copy

            # Bind toolbar
            btn_copy.Bind(wx.EVT_BUTTON,       self._OnCopyButton)
            btn_refresh.Bind(wx.EVT_BUTTON,    self._OnRefreshButton)
            btn_zoom_out.Bind(wx.EVT_BUTTON,   lambda e: self._ZoomBy(-_ZOOM_STEP))
            btn_zoom_in.Bind(wx.EVT_BUTTON,    lambda e: self._ZoomBy(+_ZOOM_STEP))
            btn_zoom_reset.Bind(wx.EVT_BUTTON, lambda e: self._SetZoom(_ZOOM_DEFAULT))
            btn_fit.Bind(wx.EVT_BUTTON,        self._OnFitWidth)
            self._zoom_slider.Bind(wx.EVT_SLIDER, self._OnZoomSlider)
            btn_fullscreen.Bind(wx.EVT_BUTTON, self._OnFullscreen)

            # Applica subito i colori freschi del tema GTK (sfondo toolbar +
            # icona copia col colore-testo corrente). Ripetuto a ogni cambio
            # tema tramite RefreshSystemColours (chiamata dal watcher GTK).
            try:
                self._ApplyGtkTheme()
            except Exception:
                pass
        else:
            self.link = None
            self._zoom_label  = None
            self._zoom_slider = None
            self._page_label  = None
            self._toolbar     = None

        # Cache dimensioni ultimo render (px pre-zoom) — inizializzate PRIMA
        # dei bind degli eventi perché EVT_SIZE su Windows può scattare
        # immediatamente durante la costruzione del pannello, prima che
        # __init__ abbia completato l'assegnazione degli attributi.
        self._last_w = 0
        self._last_h = 0

        # ── ScrolledWindow principale ────────────────────────────────────
        self.panel = wx.ScrolledWindow(parent_win, style=wx.BORDER_DOUBLE)
        self.panel.SetBackgroundStyle(wx.BG_STYLE_CUSTOM)
        self.pixedScrolled = 10
        self.panel.SetScrollbars(self.pixedScrolled, self.pixedScrolled, 0, 0)
        self.panel.SetBackgroundColour(wx.Colour(160, 160, 160))  # grigio per sfondo pagine

        self.panel.Bind(wx.EVT_PAINT,        self.OnPaint)
        self.panel.Bind(wx.EVT_MOUSEWHEEL,   self._OnMouseWheel)
        self.panel.Bind(wx.EVT_KEY_DOWN,     self._OnKeyDown)
        # Fix 5: EVT_CHAR_HOOK cattura i tasti freccia prima che
        # ScrolledWindow li consumi, permettendo Ctrl+Su/Giu come scroll di pagina
        self.panel.Bind(wx.EVT_CHAR_HOOK,    self._OnCharHook)
        self.panel.Bind(wx.EVT_SCROLLWIN,    self._OnScroll)
        self.panel.Bind(wx.EVT_SIZE,         self._OnPanelSize)
        self.panel.Bind(wx.EVT_LEFT_DCLICK,  self._OnDoubleClick)

        self.text = ""
        outer.Add(self.panel, 1, wx.EXPAND)

        # SongFormat
        self.renderer = Renderer(sf, sd, notations)
        self._SyncBgColourToDecorator()
        self.main_panel.SetSizer(outer)
        self.main_panel.Layout()

        # Su Linux/GTK, se il tema del desktop cambia mentre il programma è
        # aperto, i pannelli con colore impostato esplicitamente (la toolbar,
        # che usa SYS_COLOUR_BTNFACE) restano "congelati" sul vecchio colore
        # finché non si riavvia. Intercettando EVT_SYS_COLOUR_CHANGED
        # rileggiamo i colori di sistema e ridisegniamo, così il cambio tema
        # è immediato senza riavvio. Innocuo su Windows.
        self.main_panel.Bind(wx.EVT_SYS_COLOUR_CHANGED, self._OnSysColourChanged)

    # -----------------------------------------------------------------------
    # Icona "copia" disegnata a mano (per controllarne il colore)
    # -----------------------------------------------------------------------

    @staticmethod
    def _load_copy_bitmap(px=16):
        """Carica l'icona 'copia' dal PNG del progetto (img/copyAsImage.png).

        Viene scalata a px×px (alta qualità) se necessario. Se il file non è
        caricabile per qualunque motivo, ripiega sull'icona disegnata a mano
        nel colore-testo dei pulsanti, così il pulsante resta comunque usabile.
        """
        try:
            img = wx.Image(glb.AddPath('img/copyAsImage.png'))
            if img.IsOk():
                if img.GetWidth() != px or img.GetHeight() != px:
                    img = img.Scale(px, px, wx.IMAGE_QUALITY_HIGH)
                return wx.Bitmap(img)
        except Exception:
            pass
        # Fallback: icona disegnata nel colore-testo corrente
        return PreviewCanvas._make_copy_bitmap(
            wx.SystemSettings.GetColour(wx.SYS_COLOUR_BTNTEXT), px)

    @staticmethod
    def _load_refresh_bitmap(px=16):
        """Carica l'icona 'aggiorna anteprima' dal PNG del progetto
        (img/update_previewer.png), scalata a px×px se necessario.

        Se il file non è caricabile per qualunque motivo, ripiega sull'icona
        di sistema ART_REDO, così il pulsante resta comunque usabile.
        """
        try:
            img = wx.Image(glb.AddPath('img/update_previewer.png'))
            if img.IsOk():
                if img.GetWidth() != px or img.GetHeight() != px:
                    img = img.Scale(px, px, wx.IMAGE_QUALITY_HIGH)
                return wx.Bitmap(img)
        except Exception:
            pass
        return wx.ArtProvider.GetBitmap(wx.ART_REDO, wx.ART_TOOLBAR, (px, px))

    @staticmethod
    def _make_copy_bitmap(colour, px=16):
        """Disegna l'icona 'copia' (due fogli sovrapposti) nel colore dato.

        Sfondo trasparente, contorni nel colore richiesto: così sul tema chiaro
        l'icona è nera e ben visibile, senza dipendere dal set simbolico GTK.
        """
        try:
            if colour is None or not colour.IsOk():
                colour = wx.Colour(0, 0, 0)
        except Exception:
            colour = wx.Colour(0, 0, 0)

        bmp = wx.Bitmap.FromRGBA(px, px, 0, 0, 0, 0)   # tutto trasparente
        dc = wx.MemoryDC(bmp)
        gc = wx.GraphicsContext.Create(dc)
        if gc is not None:
            gc.SetPen(wx.Pen(colour, 1))
            gc.SetBrush(wx.TRANSPARENT_BRUSH)
            # foglio posteriore e foglio anteriore, leggermente sfalsati
            gc.DrawRectangle(5.5, 2.5, 7, 9)
            gc.DrawRectangle(2.5, 5.5, 7, 9)
        dc.SelectObject(wx.NullBitmap)
        return bmp

    # Rosso usato per le icone zoom (allineato al rosso "negativo" di Breeze)
    _ZOOM_RED = wx.Colour(218, 68, 83)   # #DA4453

    @staticmethod
    def _make_sign_bitmap(colour, plus=False, px=16):
        """Disegna un '−' (o un '+') nel colore dato, sfondo trasparente.

        Serve per rendere i pulsanti zoom coerenti (entrambi rossi), invece di
        affidarsi alle icone simboliche del tema che colorano diversamente
        'list-remove' e 'list-add'.
        """
        try:
            if colour is None or not colour.IsOk():
                colour = wx.Colour(0, 0, 0)
        except Exception:
            colour = wx.Colour(0, 0, 0)

        bmp = wx.Bitmap.FromRGBA(px, px, 0, 0, 0, 0)   # tutto trasparente
        dc = wx.MemoryDC(bmp)
        gc = wx.GraphicsContext.Create(dc)
        if gc is not None:
            gc.SetPen(wx.Pen(colour, 2))
            c = px / 2.0
            r = px * 0.30
            gc.StrokeLine(c - r, c, c + r, c)          # barra orizzontale (−)
            if plus:
                gc.StrokeLine(c, c - r, c, c + r)      # barra verticale (+)
        dc.SelectObject(wx.NullBitmap)
        return bmp

    # -----------------------------------------------------------------------
    # Cambio tema desktop (Linux/GTK): riapplica i colori di sistema a caldo
    # -----------------------------------------------------------------------

    def _OnSysColourChanged(self, evt):
        """Gestore EVT_SYS_COLOUR_CHANGED: il tema del desktop è cambiato."""
        self.RefreshSystemColours()
        # Lascia propagare l'evento ai figli (comportamento standard wx).
        evt.Skip()

    @staticmethod
    def _fresh_gtk_colours():
        """Legge (bg, fg) FRESCHI dal tema GTK corrente.

        wx.SystemSettings.GetColour su GTK congela i colori all'avvio; GTK
        invece li conosce sempre aggiornati. Restituisce due wx.Colour, oppure
        (None, None) se PyGObject/GTK non sono disponibili.
        """
        try:
            import gi
            gi.require_version('Gtk', '3.0')
            from gi.repository import Gtk
            ctx = Gtk.Button().get_style_context()

            def _col(names):
                for n in names:
                    ok, rgba = ctx.lookup_color(n)
                    if ok:
                        return wx.Colour(int(round(rgba.red * 255)),
                                         int(round(rgba.green * 255)),
                                         int(round(rgba.blue * 255)))
                return None

            bg = _col(['theme_bg_color', 'theme_base_color', 'bg_color'])
            fg = _col(['theme_fg_color', 'theme_text_color', 'fg_color'])
            return bg, fg
        except Exception:
            return None, None

    @staticmethod
    def _tint_toolbar(toolbar, bg, fg, copy_btn=None):
        """Applica bg/fg del tema ai figli 'non nativi' di una toolbar.

        I pulsanti nativi (wx.Button) e lo slider si tematizzano da soli e non
        vengono toccati. StaticText/StaticLine/BitmapButton ricevono lo sfondo;
        le StaticText anche il colore testo. Se copy_btn è dato, ne ridisegna
        l'icona nel colore-testo fresco.
        """
        if toolbar is None:
            return
        if bg is not None and bg.IsOk():
            toolbar.SetBackgroundColour(bg)
        for ch in toolbar.GetChildren():
            if isinstance(ch, wx.Slider):
                continue
            # wx.BitmapButton deriva da wx.Button: lo vogliamo colorare, i
            # pulsanti di testo nativi no (si tematizzano da soli).
            if isinstance(ch, wx.Button) and not isinstance(ch, wx.BitmapButton):
                continue
            if bg is not None and bg.IsOk():
                ch.SetBackgroundColour(bg)
            if fg is not None and fg.IsOk() and isinstance(ch, wx.StaticText):
                ch.SetForegroundColour(fg)
        if copy_btn is not None and hasattr(copy_btn, 'SetBitmap'):
            # L'icona copia ora è un PNG fisso (img/copy_2.png): la ricarichiamo
            # tale e quale, senza ricolorarla col fg del tema.
            copy_btn.SetBitmap(PreviewCanvas._load_copy_bitmap(16))
        toolbar.Refresh(True)
        toolbar.Update()

    def _ApplyGtkTheme(self):
        """Riporta toolbar, etichette e icona copia ai colori GTK correnti."""
        bg, fg = self._fresh_gtk_colours()
        self._tint_toolbar(getattr(self, '_toolbar', None), bg, fg,
                            copy_btn=getattr(self, 'link', None))
        if getattr(self, 'main_panel', None) is not None:
            self.main_panel.Refresh()
            self.main_panel.Update()
        fs = getattr(self, '_fullscreen_frame', None)
        if fs is not None and hasattr(fs, 'RefreshSystemColours'):
            fs.RefreshSystemColours()

    def RefreshSystemColours(self):
        """Chiamata dal watcher GTK a ogni cambio tema: riapplica i colori."""
        try:
            self._ApplyGtkTheme()
        except Exception:
            # Se qualche widget è già stato distrutto ignoriamo silenziosamente.
            pass

    # -----------------------------------------------------------------------
    # Paint
    # -----------------------------------------------------------------------

    def OnPaint(self, e):
        dc = wx.AutoBufferedPaintDC(self.panel)
        self.panel.PrepareDC(dc)

        # Fix 3 (rev): margine orizzontale dinamico calcolato sulla larghezza
        # LORDA del pannello (GetSize, senza scrollbar), non su GetClientSize.
        # Usando GetClientSize la presenza della scrollbar verticale riduceva
        # panel_w, causando una vw insufficiente che tagliava il klavier a destra.
        panel_gross_w, _ = self.panel.GetSize()
        margin_h = max(8, int(panel_gross_w * 0.03))

        # Sfondo: grigio o bianco in base al flag _greyBackground
        bg_colour = wx.Colour(160, 160, 160) if self._greyBackground else wx.WHITE
        dc.SetBackground(wx.Brush(bg_colour))
        dc.Clear()

        if not self.text.strip():
            self._UpdatePageLabel(0)
            return

        # La filigrana puo' essere disegnata solo se conosciamo gia' la
        # dimensione del brano (self._last_h), che pero' viene calcolata solo
        # AL TERMINE di questo paint. Ricordiamo se la dimensione era gia' nota
        # all'inizio: se non lo era e la filigrana e' attiva, in coda al metodo
        # forzeremo un secondo paint per mostrarla (vedi fine di OnPaint).
        _had_size = self._last_h > 0

        # PrepareDC ha già impostato l'origine device in base allo scroll (X e Y).
        # Aggiungiamo margin_h all'origine X corrente SENZA annullare lo scroll:
        # GetDeviceOrigin() restituisce l'offset impostato da PrepareDC, a cui
        # sommiamo il margine sinistro in pixel reali.
        ox, oy = dc.GetDeviceOrigin()
        dc.SetDeviceOrigin(ox + margin_h, oy)

        # Applica zoom
        dc.SetUserScale(self._zoom_factor, self._zoom_factor)

        # Filigrana DIETRO al brano (non oscura il testo, che viene disegnato
        # sopra). Dimensioniamo con l'ultimo (w, h) noto: al primo paint puo'
        # mancare, ma il paint successivo la mostra correttamente. Il brano
        # viene poi renderizzato sopra.
        cfg = getattr(self, '_watermark_cfg', None)
        if (cfg and cfg.get('enabled') and cfg.get('showInPreview', True)
                and self._last_h > 0):
            try:
                from . import Watermark
                Watermark.draw_watermark(dc, self._last_w, self._last_h, cfg)
            except Exception:
                pass

        # Render nella zona virtuale scalata
        w, h = self.renderer.Render(self.text, dc)
        self._last_w = w
        self._last_h = h

        # Ripristina scala e origine device originale
        dc.SetUserScale(1.0, 1.0)
        dc.SetDeviceOrigin(ox, oy)

        # Aggiorna dimensione virtuale con margine dinamico
        vw = int(w * self._zoom_factor) + margin_h * 2
        vh = int(h * self._zoom_factor) + _PAGE_GAP_PX * 2
        self.panel.SetVirtualSize(wx.Size(vw, vh))

        # Aggiorna label pagina
        self._UpdatePageLabel(h)

        # Se la filigrana e' attiva ma NON ha potuto disegnarsi perche' la
        # dimensione del brano non era ancora nota (tipico al primo paint dopo
        # l'apertura di un file), ora che _last_h e' valido forziamo un unico
        # ulteriore repaint. Alla ripittura _had_size sara' True, quindi non si
        # innesca alcun ciclo infinito.
        _cfg = getattr(self, '_watermark_cfg', None)
        _wm_active = bool(_cfg and _cfg.get('enabled')
                          and _cfg.get('showInPreview', True))
        if _wm_active and not _had_size and h > 0:
            wx.CallAfter(self.panel.Refresh)

    # -----------------------------------------------------------------------
    # Zoom
    # -----------------------------------------------------------------------

    def _SetZoom(self, factor):
        factor = max(_ZOOM_MIN, min(_ZOOM_MAX, factor))
        if abs(factor - self._zoom_factor) < 1e-6:
            return
        self._zoom_factor = factor
        # Fix 6: granularita' scroll proporzionale allo zoom
        self.pixedScrolled = max(1, int(10 / factor))
        self.panel.SetScrollbars(self.pixedScrolled, self.pixedScrolled, 0, 0)
        if self._zoom_label:
            self._zoom_label.SetLabel("%d%%" % round(factor * 100))
        # Fix 1: sincronizza lo slider
        if self._zoom_slider:
            self._zoom_slider.SetValue(int(round(factor * 100)))
        self.panel.Refresh()


    def _ZoomBy(self, delta):
        # Arrotonda al passo piu' vicino per evitare accumulo di errori float
        new = round((self._zoom_factor + delta) / _ZOOM_STEP) * _ZOOM_STEP
        self._SetZoom(new)

    def _OnZoomSlider(self, evt):
        # Converte il valore intero dello slider (30-300) in fattore float
        pct = self._zoom_slider.GetValue()
        factor = round(pct / 100 / _ZOOM_STEP) * _ZOOM_STEP
        self._SetZoom(factor)

    def _OnFitWidth(self, evt):
        """Calcola lo zoom che fa entrare la larghezza del render nel pannello.

        Il calcolo e' stabile: usa la larghezza lorda del pannello (senza
        scrollbar verticale) e il margine dinamico calcolato sulla stessa
        larghezza lorda. Pressioni ripetute su 'Adatta' non cambiano lo zoom.
        """
        if self._last_w <= 0:
            return

        # Larghezza client attuale (potrebbe escludere la scrollbar verticale)
        panel_w, panel_h = self.panel.GetClientSize()

        # Se la scrollbar verticale e' visibile, panel_w e' gia' ridotta;
        # recuperiamo la larghezza lorda sommando la sua ampiezza.
        virtual_h = int(self._last_h * self._zoom_factor) + _PAGE_GAP_PX * 2
        if virtual_h > panel_h:
            sb_w = wx.SystemSettings.GetMetric(wx.SYS_VSCROLL_X)
            panel_w += sb_w if sb_w > 0 else 17

        # Margine calcolato sulla larghezza lorda (stessa formula di OnPaint)
        margin_h = max(8, int(panel_w * 0.03))
        available = panel_w - margin_h * 2
        if available <= 0:
            return

        factor = available / self._last_w

        # Idempotenza: non aggiornare se lo zoom e' gia' convergente (< 0.5%)
        if abs(factor - self._zoom_factor) / max(self._zoom_factor, 0.01) < 0.005:
            return

        self._SetZoom(factor)

    # -----------------------------------------------------------------------
    # Event handlers
    # -----------------------------------------------------------------------

    def _OnCopyButton(self, evt):
        """Esegue la copia negli appunti al clic sul pulsante 'copia'.

        Usa la callback diretta registrata da SongpressFrame con
        SetCopyCallback() (di norma SongpressFrame.CopyAsImage): chiama
        direttamente la logica di copia, senza dipendere dagli eventi wx.
        Come ripiego (callback non impostata) rilancia EVT_HYPERLINK.
        """
        cb = getattr(self, '_on_copy_callback', None)
        if callable(cb):
            cb()
            return
        # Fallback legacy: rilancia EVT_HYPERLINK dove SongpressFrame lo aggancia.
        ev = wx.adv.HyperlinkEvent(self.link, self.link.GetId(), "")
        ev.SetEventObject(self.link)
        self.main_panel.GetEventHandler().ProcessEvent(ev)

    def _OnRefreshButton(self, evt):
        """Clic sul pulsante 'aggiorna anteprima': forza il ridisegno immediato."""
        self._ForceRefreshNow()

    def _ForceRefreshNow(self):
        """Rilegge il testo fresco dall'editor (se è registrata la callback) e
        ridisegna subito, ignorando il debounce.

        Passa da self.Refresh(text) così vengono ricalcolati anche
        renderer.columns in base ai {column_break}; poi annulla l'eventuale
        timer di debounce e chiama _DoRefresh() per disegnare senza attesa.
        """
        cb = getattr(self, '_on_refresh_callback', None)
        if callable(cb):
            try:
                self.Refresh(cb())          # aggiorna _pending_text + layout colonne
            except Exception:
                pass
        if self._debounce_timer is not None:
            try:
                self._debounce_timer.Stop()
            except Exception:
                pass
            self._debounce_timer = None
        self._DoRefresh()

    def _OnMouseWheel(self, evt):
        if evt.ControlDown():
            rot = evt.GetWheelRotation()
            if rot > 0:
                self._ZoomBy(+_ZOOM_STEP)
            elif rot < 0:
                self._ZoomBy(-_ZOOM_STEP)
        else:
            evt.Skip()

    def _OnKeyDown(self, evt):
        key  = evt.GetKeyCode()
        ctrl = evt.ControlDown()
        if ctrl and key == ord('+'):
            self._ZoomBy(+_ZOOM_STEP)
        elif ctrl and key == ord('-'):
            self._ZoomBy(-_ZOOM_STEP)
        elif ctrl and key == ord('0'):
            self._SetZoom(_ZOOM_DEFAULT)
        else:
            evt.Skip()

    def _OnCharHook(self, evt):
        # Fix 5: intercetta Ctrl+PgUp/PgDn per scroll di pagina,
        # Fix 9: Ctrl+Shift+G = fit-to-width
        key  = evt.GetKeyCode()
        ctrl = evt.ControlDown()
        shift = evt.ShiftDown()
        if ctrl and key == wx.WXK_PAGEDOWN:
            # Scorre di un'altezza pagina verso il basso
            _, ph = self.panel.GetClientSize()
            self.panel.Scroll(-1, self.panel.GetScrollPos(wx.VERTICAL) + ph // self.pixedScrolled)
        elif ctrl and key == wx.WXK_PAGEUP:
            # Scorre di un'altezza pagina verso l'alto
            _, ph = self.panel.GetClientSize()
            self.panel.Scroll(-1, max(0, self.panel.GetScrollPos(wx.VERTICAL) - ph // self.pixedScrolled))
        elif ctrl and shift and key == ord('G'):
            # Fix 9: Ctrl+Shift+G = fit-to-width
            self._OnFitWidth(None)
        elif key == wx.WXK_F11:
            self._OnFullscreen(None)
        else:
            evt.Skip()

    def _OnScroll(self, evt):
        self._UpdatePageLabel(self._last_h)
        evt.Skip()

    def _OnPanelSize(self, evt):
        # Al ridimensionamento, aggiorna la virtual size se c'e' gia' del contenuto.
        # Usa GetSize() (larghezza lorda) per coerenza con OnPaint.
        if self._last_w > 0:
            panel_gross_w, _ = self.panel.GetSize()
            margin_h = max(8, int(panel_gross_w * 0.03))
            vw = int(self._last_w * self._zoom_factor) + margin_h * 2
            vh = int(self._last_h * self._zoom_factor) + _PAGE_GAP_PX * 2
            self.panel.SetVirtualSize(wx.Size(vw, vh))
        evt.Skip()

    # -----------------------------------------------------------------------
    # Label pagina
    # -----------------------------------------------------------------------

    def _UpdatePageLabel(self, content_h_px):
        """Aggiorna la label 'Pagina X di Y' in base alla posizione di scroll."""
        if self._page_label is None:
            return
        if content_h_px <= 0:
            self._page_label.SetLabel("")
            return

        # Stima l'altezza di una "pagina" in pixel schermo (96 DPI, A4 portrait)
        page_h_px = self._page_height_px()
        if page_h_px <= 0:
            self._page_label.SetLabel("")
            return

        total_pages = max(1, int(round(content_h_px / page_h_px)))
        # Posizione scroll corrente
        scroll_y = self.panel.GetScrollPos(wx.VERTICAL) * self.pixedScrolled
        current_page = min(total_pages, int(scroll_y / (page_h_px * self._zoom_factor)) + 1)
        self._page_label.SetLabel(_("Page %d of %d") % (current_page, total_pages))

    def _page_height_px(self):
        """Altezza area utile della pagina in pixel a 96 DPI (zoom 1.0).
        = altezza foglio - margine superiore - margine inferiore.
        Usa i valori aggiornati da SetPageSizeMm/SetPageMarginsMm,
        che vengono sincronizzati da SongpressFrame dopo OnPageSetup."""
        usable_h_mm = self._page_h_mm - self._margin_top_mm - self._margin_bottom_mm
        return int(max(10.0, usable_h_mm) / 25.4 * 96)

    # -----------------------------------------------------------------------
    # Debounce refresh
    # -----------------------------------------------------------------------

    def Refresh(self, text):
        """Aggiorna l'anteprima.

        Se _debounceEnabled e' True (default), il ridisegno viene ritardato di
        _DEBOUNCE_MS millisecondi: ogni chiamata successiva prima dello scadere
        del timer annulla e riavvia il timer, cosi' il ridisegno avviene solo
        quando la digitazione si ferma.

        Se _debounceEnabled e' False, il ridisegno avviene immediatamente ad
        ogni chiamata (utile su macchine veloci o per chi preferisce feedback
        istantaneo).
        """
        self._pending_text = text
        # Riapplica layout colonne subito (informazione leggera)
        has_col_break = bool(re.search(r'\{\s*(?:column_break|colb)\s*\}', text, re.IGNORECASE))
        self.renderer.columns = 2 if has_col_break else 1
        self.renderer.columnHeight = 0
        # Riapplica flag
        self.renderer.sd.showPageBreakLines  = self._showPageBreakLines
        self.renderer.sd.showColumnBreakLines = self._showColumnBreakLines

        if not self._debounceEnabled:
            # Ridisegno immediato: cancella eventuale timer pendente e ridisegna subito
            if self._debounce_timer is not None:
                try:
                    self._debounce_timer.Stop()
                except Exception:
                    pass
                self._debounce_timer = None
            self._DoRefresh()
            return

        if self._debounce_timer is not None:
            try:
                self._debounce_timer.Stop()
            except Exception:
                pass
        self._debounce_timer = wx.CallLater(_DEBOUNCE_MS, self._DoRefresh)

    def _DoRefresh(self):
        """Ridisegno effettivo chiamato al termine del debounce."""
        self._debounce_timer = None
        self.text = self._pending_text
        # Riapplica flag anche qui (nel caso il decorator sia cambiato nel frattempo)
        self.renderer.sd.showPageBreakLines  = self._showPageBreakLines
        self.renderer.sd.showColumnBreakLines = self._showColumnBreakLines
        self.panel.Refresh()

    # -----------------------------------------------------------------------
    # Click → focus editor
    # -----------------------------------------------------------------------

    def SetClickCallback(self, callback):
        """Registra una callback chiamata al doppio-click sull'anteprima.

        callback(line_number: int)  — line_number e' 0-based, corrisponde
        alla riga sorgente ChordPro piu' vicina al punto cliccato.
        Impostata da SongpressFrame subito dopo la creazione di PreviewCanvas.
        """
        self._on_click_callback = callback

    def SetCopyCallback(self, callback):
        """Registra la callback eseguita al clic sul pulsante "copia" della toolbar.

        callback()  — senza argomenti; di norma SongpressFrame.CopyAsImage.
        È il meccanismo affidabile per la copia: chiama direttamente la logica
        di copia senza dipendere dal routing/propagazione degli eventi wx.
        """
        self._on_copy_callback = callback

    def SetRefreshCallback(self, callback):
        """Registra la callback eseguita al clic sul pulsante "aggiorna anteprima".

        callback() -> str  — restituisce il testo corrente dell'editor (di norma
        SongpressFrame._get_display_text). Serve a rileggere il testo fresco
        quando l'utente forza manualmente l'aggiornamento dell'anteprima.
        """
        self._on_refresh_callback = callback

    # -----------------------------------------------------------------------
    # Hit-test preciso sui SongBox
    # -----------------------------------------------------------------------

    def _HitTestBox(self, click_x, click_y):
        """Restituisce il SongText o SongLine piu' vicino al punto (click_x, click_y)
        nelle coordinate del renderer (pre-zoom, pre-scroll).

        Scende nell'albero SongSong -> SongBlock -> SongLine -> SongText.
        Restituisce (block, line, token) o (None, None, None).
        Le coordinate dei box sono relative al genitore; accumuliamo
        l'offset assoluto durante la discesa.
        """
        song = getattr(self.renderer, 'song', None)
        if song is None:
            return None, None, None

        song_margin_top  = getattr(song, 'marginTop',  0)
        song_margin_left = getattr(song, 'marginLeft', 0)

        best_block = None
        best_line  = None
        best_token = None
        best_dist  = float('inf')

        for block in song.boxes:
            bx = song_margin_left + block.x
            by = song_margin_top  + block.y
            # Distanza verticale dal blocco (0 se siamo dentro)
            dy = max(0, by - click_y, click_y - (by + block.h))
            if dy > best_dist:
                continue
            for line in block.boxes:
                lx = bx + line.x
                ly = by + line.y
                dy2 = max(0, ly - click_y, click_y - (ly + line.h))
                if dy2 > best_dist:
                    continue
                # Cerca il token piu' vicino orizzontalmente
                for token in line.boxes:
                    tx = lx + token.x
                    ty = ly + token.y
                    dx = max(0, tx - click_x, click_x - (tx + token.w))
                    dy3 = max(0, ty - click_y, click_y - (ty + token.h))
                    dist = dx * dx + dy3 * dy3
                    if dist < best_dist:
                        best_dist  = dist
                        best_block = block
                        best_line  = line
                        best_token = token
        return best_block, best_line, best_token

    def _FindSourceLine(self, token_text, block_index):
        """Trova la riga sorgente (0-based) corrispondente a un token renderizzato.

        Strategia a cerchi concentrici attorno alla stima iniziale:
          1. Finestra stretta (±5 righe): cattura il caso esatto
          2. Finestra media (±20 righe): cattura blocchi vicini
          3. Tutto il file: fallback per testo molto ripetuto
        Cosi' un accordo comune come 'DO' che appare 30 volte nel brano
        viene trovato nella posizione giusta invece che alla prima occorrenza.
        """
        if not self.text.strip():
            return 0
        lines = self.text.splitlines()
        n = len(lines)

        # Stima iniziale proporzionale al blocco
        song = self.renderer.song
        total_blocks = max(len(song.boxes), 1)
        start_line = int(block_index / total_blocks * n)
        start_line = max(0, min(start_line, n - 1))

        if not (token_text and token_text.strip()):
            return start_line

        search_text = token_text.strip()

        def _search_range(lo, hi):
            """Cerca search_text nelle righe [lo, hi) in ordine di distanza da start_line."""
            lo = max(0, lo)
            hi = min(n, hi)
            # Ordina per distanza crescente da start_line
            indices = sorted(range(lo, hi), key=lambda i: abs(i - start_line))
            for i in indices:
                if search_text in lines[i]:
                    return i
            return None

        # 1. Finestra stretta: ±5 righe
        result = _search_range(start_line - 5, start_line + 6)
        if result is not None:
            return result

        # 2. Finestra media: ±20 righe
        result = _search_range(start_line - 20, start_line + 21)
        if result is not None:
            return result

        # 3. Tutto il file, sempre per distanza da start_line
        result = _search_range(0, n)
        if result is not None:
            return result

        return start_line

    def _OnDoubleClick(self, evt):
        """Doppio-click sul canvas: hit-test preciso sui SongBox e focus editor.

        Flusso:
          1. Converte le coordinate del click in coordinate renderer
             (corregge scroll e zoom, sottrae il margine dinamico)
          2. Scende nell'albero SongSong->SongBlock->SongLine->SongText
             trovando il token piu' vicino al click
          3. Cerca il testo del token nel sorgente ChordPro
          4. Chiama la callback con il numero di riga 0-based
        """
        if self._on_click_callback is None or self._last_h <= 0:
            evt.Skip()
            return
        if not self._dblClickFocusEnabled:
            evt.Skip()
            return

        # 1. Coordinate del click in pixel virtuali (scroll-corrected)
        click_x_sc, click_y_sc = self.panel.CalcUnscrolledPosition(evt.GetPosition())

        # Rimuovi il margine orizzontale dinamico applicato in OnPaint.
        # Usa GetSize() (larghezza lorda) per coerenza con il calcolo in OnPaint.
        panel_gross_w, _ = self.panel.GetSize()
        margin_h = max(8, int(panel_gross_w * 0.03))

        # Converti in coordinate renderer (pre-zoom)
        rx = (click_x_sc - margin_h) / self._zoom_factor
        ry = click_y_sc / self._zoom_factor

        # 2. Hit-test sull'albero dei box
        block, line, token = self._HitTestBox(rx, ry)

        if token is not None:
            # 3. Trova la riga sorgente
            token_text = getattr(token, 'text', '')
            block_idx  = self.renderer.song.boxes.index(block) if block is not None else 0
            line_num   = self._FindSourceLine(token_text, block_idx)
        else:
            # Fallback: stima lineare sulla Y
            src_lines = self.text.count('\n') + 1 if self.text.strip() else 1
            avg_h = self._last_h / max(src_lines, 1)
            line_num = max(0, min(int(ry / avg_h), src_lines - 1))

        self._on_click_callback(line_num)
        evt.Skip()

    # -----------------------------------------------------------------------
    # Tutto schermo
    # -----------------------------------------------------------------------

    def _OnFullscreen(self, evt):
        """Apre o chiude la finestra fullscreen dell'anteprima."""
        if self._fullscreen_frame is not None:
            # Gia' aperta: chiudi
            try:
                self._fullscreen_frame.Close()
            except Exception:
                pass
            self._fullscreen_frame = None
            return

        # Crea la frame fullscreen
        fs_frame = _FullscreenPreviewFrame(self)
        self._fullscreen_frame = fs_frame
        fs_frame.Show()
        fs_frame.ShowFullScreen(True, wx.FULLSCREEN_ALL)

    # -----------------------------------------------------------------------
    # API pubblica (invariata rispetto alla versione originale)
    # -----------------------------------------------------------------------

    def SetColumns(self, columns):
        """Imposta il numero di colonne per il layout dell'anteprima."""
        self.renderer.columns = columns
        self.renderer.columnHeight = 0

    def SetDecorator(self, sd):
        self.renderer.SetDecorator(sd)
        sd.showPageBreakLines  = self._showPageBreakLines
        sd.showColumnBreakLines = self._showColumnBreakLines
        self._SyncBgColourToDecorator()

    def SetLineWidths(self, titleLineWidth, verseBoxWidth):
        self.renderer.sd.titleLineWidth = titleLineWidth
        self.renderer.sd.verseBoxWidth  = verseBoxWidth

    def SetChordsBelow(self, below):
        self.renderer.SetChordsBelow(below)

    def SetWatermark(self, cfg):
        """Imposta la configurazione filigrana da mostrare in anteprima.

        `cfg` e' un dict (vedi Watermark.DEFAULTS). La filigrana viene disegnata
        DIETRO al brano, cosi' non oscura il testo.
        """
        self._watermark_cfg = dict(cfg) if cfg else None

    def SetShowPageBreakLines(self, show):
        """Mostra o nasconde la linea di interruzione di pagina nell'anteprima."""
        self._showPageBreakLines = show
        self.renderer.sd.showPageBreakLines = show

    def SetShowColumnBreakLines(self, show):
        """Mostra o nasconde la linea di interruzione di colonna nell'anteprima."""
        self._showColumnBreakLines = show
        self.renderer.sd.showColumnBreakLines = show

    def SetShowDurationBeats(self, show):
        """Mostra o nasconde il numero di battiti sopra gli accordi ({beats_time})."""
        self._showDurationBeats = show
        self.renderer.sd.showDurationBeats = show

    def SetDurationBeatsPrefs(self, colour_hex, size_pct, bold, align, mode='number'):
        """Aggiorna colore, dimensione, grassetto, allineamento e modalità del beat count."""
        self.renderer.sd.durationBeatsColourHex = colour_hex
        self.renderer.sd.durationBeatsSizePct   = size_pct
        self.renderer.sd.durationBeatsBold      = bold
        self.renderer.sd.durationBeatsAlign     = align
        self.renderer.sd.durationBeatsMode      = mode

    def SetTempoDisplay(self, tempoDisplay):
        self.renderer.tempoDisplay = tempoDisplay

    def SetTempoIconSize(self, size):
        """Imposta la dimensione in pixel delle icone {tempo_*} (16, 24 o 32)."""
        self.renderer.tempoIconSize = size

    def SetTempoIconColour(self, colour):
        """Imposta il colore (wx.Colour) delle icone {tempo_*}."""
        self.renderer.tempoIconColour = colour

    def SetGridDisplayMode(self, mode):
        """Imposta la modalità di visualizzazione dei blocchi {start_of_grid}.

        Valori: 'pipe' | 'plain' | 'table'
        Forza immediatamente il ridisegno del pannello anteprima.
        """
        self.renderer.gridDisplayMode = mode if mode in ('pipe', 'plain', 'table') else 'pipe'
        self.panel.Refresh()

    def SetGridDefaultLabel(self, label):
        """Imposta l'etichetta predefinita per i blocchi {start_of_grid} senza label.

        Forza immediatamente il ridisegno del pannello anteprima.
        """
        self.renderer.gridDefaultLabel = label if label and label.strip() else None
        self.panel.Refresh()

    def SetGridSizeDir(self, sizedir):
        """Imposta la direzione di applicazione di size=N per i blocchi {start_of_grid}.

        Valori: 'both' | 'horizontal' | 'vertical'
        Forza immediatamente il ridisegno del pannello anteprima.
        """
        self.renderer.gridSizeDir = sizedir if sizedir in ('both', 'horizontal', 'vertical') else 'both'
        self.panel.Refresh()

    def SetTimeDisplay(self, show):
        self.renderer.timeDisplay = show

    def SetKeyDisplay(self, show):
        self.renderer.keyDisplay = show

    # -----------------------------------------------------------------------
    # Zoom pubblico (usabile da SongpressFrame se necessario)
    # -----------------------------------------------------------------------

    def SetPageSizeMm(self, w_mm, h_mm):
        """Aggiorna le dimensioni del foglio (mm) usate per il calcolo
        dell'indicatore di pagina. Chiamare dopo ogni modifica in OnPageSetup."""
        self._page_w_mm = float(w_mm)
        self._page_h_mm = float(h_mm)
        if self._last_h > 0:
            self._UpdatePageLabel(self._last_h)

    def SetPageMarginsMm(self, top_mm, bottom_mm):
        """Aggiorna i margini superiore e inferiore (mm) per il calcolo
        dell'indicatore di pagina. Chiamare dopo ogni modifica in OnPageSetup."""
        self._margin_top_mm    = float(top_mm)
        self._margin_bottom_mm = float(bottom_mm)
        if self._last_h > 0:
            self._UpdatePageLabel(self._last_h)

    def GetZoom(self):
        """Restituisce il fattore di zoom corrente (1.0 = 100%)."""
        return self._zoom_factor

    def SetZoom(self, factor):
        """Imposta il fattore di zoom (es. 0.75 = 75%, 1.5 = 150%)."""
        self._SetZoom(factor)

    def SetShowPageIndicator(self, show):
        """Mostra o nasconde la label 'Pagina X di Y' nella toolbar."""
        if self._page_label is None:
            return
        self._page_label.Show(show)
        # Aggiorna subito il testo se stiamo mostrando
        if show:
            self._UpdatePageLabel(self._last_h)
        else:
            self._page_label.SetLabel("")
        # Forza ricalcolo layout della toolbar
        parent = self._page_label.GetParent()
        if parent:
            parent.Layout()

    def SetDocumentDir(self, doc_path):
        """Comunica al renderer la directory del documento aperto.

        Usato da {image: filename.png}: se il percorso e' relativo, viene
        risolto rispetto alla directory del file .crd/.cho corrente.
        Passare stringa vuota o None quando il documento non e' ancora
        stato salvato su disco (nuovo documento senza nome).
        """
        import os
        self.renderer._document_dir = os.path.dirname(doc_path) if doc_path else ""

    def SetGreyBackground(self, grey):
        """Imposta sfondo grigio (True) o bianco (False) nel pannello anteprima."""
        self._greyBackground = bool(grey)   # aggiorna il flag letto da OnPaint
        self._SyncBgColourToDecorator()
        # Bug fix: se c'è un debounce pendente, il testo è in _pending_text ma
        # non ancora in self.text. Chiamare panel.Refresh() direttamente farebbe
        # scattare OnPaint con self.text == "" → l'anteprima sembrerebbe vuota.
        # Forziamo il commit del testo pendente prima di ridisegnare.
        if self._debounce_timer is not None:
            try:
                self._debounce_timer.Stop()
            except Exception:
                pass
            self._debounce_timer = None
            self.text = self._pending_text
        self.panel.Refresh()                # forza ridisegno con il nuovo sfondo

    def _SyncBgColourToDecorator(self):
        """Propaga il colore di sfondo corrente al SongDecorator.
        Il decorator lo usa per precomporre l'alpha delle icone tempo (e delle
        immagini {image:}) invece del bianco fisso, in modo che le icone
        risultino visivamente integrate con lo sfondo grigio o bianco."""
        bg = wx.Colour(160, 160, 160) if self._greyBackground else wx.WHITE
        if hasattr(self, 'renderer') and hasattr(self.renderer, 'sd'):
            self.renderer.sd.bgColour = bg

    def SetDblClickFocus(self, enabled):
        """Abilita (True) o disabilita (False) il focus editor al doppio-click.

        Se disabilitato, il doppio-click sull'anteprima non sposta il cursore
        nell'editor. Utile per chi usa il doppio-click per selezionare testo
        nell'anteprima senza voler perdere il contesto nell'editor.
        """
        self._dblClickFocusEnabled = bool(enabled)

    def SetDebounce(self, enabled):
        """Abilita (True) o disabilita (False) il debounce del refresh.

        Con debounce attivo il ridisegno avviene solo dopo _DEBOUNCE_MS ms
        di inattivita' sulla tastiera (risparmia CPU durante la digitazione
        rapida). Con debounce disattivo ogni modifica al testo provoca un
        ridisegno immediato.
        """
        self._debounceEnabled = bool(enabled)

    def SetFindWord(self, word, flags=0, colour=None):
        """Evidenzia *word* nel preview (chiamato da SongpressFindReplaceDialog).

        Passa la parola cercata al SongDecorator, scrolla il preview per portare
        la prima occorrenza in vista, e forza un ridisegno immediato.
        flags:  stessi flag wx.stc usati in FindText (es. STC_FIND_MATCHCASE).
        colour: wx.Colour per l'evidenziazione (None = usa il colore corrente).
        """
        self.renderer.sd.find_word  = word or ''
        self.renderer.sd.find_flags = flags
        if colour is not None:
            self.renderer.sd.find_colour = colour
        self.panel.Refresh()
        if word:
            self._ScrollToFindWord(word, flags)

    def _ScrollToFindWord(self, word, flags=0):
        """Scrolla il preview in modo che la prima occorrenza di *word* sia visibile.

        Percorre l'albero song→block→line→token cercando la prima corrispondenza
        e chiama panel.Scroll() per portare il token al centro del viewport.
        """
        song = getattr(self.renderer, 'song', None)
        if song is None:
            return
        import wx.stc as _stc
        match_case = bool(flags & _stc.STC_FIND_MATCHCASE)
        needle = word if match_case else word.lower()

        song_margin_top  = getattr(song, 'marginTop',  0)
        song_margin_left = getattr(song, 'marginLeft', 0)

        found_ty = None
        found_th = None
        for block in song.boxes:
            bx = song_margin_left + block.x
            by = song_margin_top  + block.y
            for line in block.boxes:
                ly = by + line.y
                for token in line.boxes:
                    raw = getattr(token, 'text', '') or ''
                    hay = raw if match_case else raw.lower()
                    if needle in hay:
                        found_ty = ly + line.marginTop + token.y
                        found_th = token.h
                        break
                if found_ty is not None:
                    break
            if found_ty is not None:
                break

        if found_ty is None:
            return

        # Converti coordinate renderer → pixel virtuali (zoom)
        token_top_px = int(found_ty * self._zoom_factor)
        token_h_px   = max(1, int(found_th * self._zoom_factor))

        # Dimensione visibile del viewport
        _, vh = self.panel.GetClientSize()

        # Posizione scroll corrente in pixel
        cur_scroll_y = self.panel.GetScrollPos(wx.VERTICAL) * self.pixedScrolled

        # Già visibile? Non scorrere
        if cur_scroll_y <= token_top_px and token_top_px + token_h_px <= cur_scroll_y + vh:
            return

        # Centra il token nel viewport
        target_y = max(0, token_top_px - (vh - token_h_px) // 2)
        scroll_unit = max(1, self.pixedScrolled)
        self.panel.Scroll(-1, target_y // scroll_unit)

    def SetFindHighlightColour(self, colour):
        """Aggiorna solo il colore di evidenziazione nel preview e ridisegna."""
        self.renderer.sd.find_colour = colour
        self.panel.Refresh()

    def ClearFindWord(self):
        """Rimuove l'evidenziazione dal preview (chiamato alla chiusura del dialogo)."""
        self.renderer.sd.find_word  = ''
        self.renderer.sd.find_flags = 0
        self.panel.Refresh()

    def SetMinSizeEnabled(self, enabled):
        """Imposta (True) o rimuove (False) la dimensione minima del pannello anteprima.

        Quando abilitato il pannello non puo' essere ridimensionato al di sotto
        di 370x530 px, ne' all'avvio ne' trascinando il separatore AUI.
        Quando disabilitato il pannello non ha vincoli di dimensione minima.
        La modifica e' immediata; per avere effetto al prossimo avvio sull'AUI
        manager occorre che SongpressFrame chiami .MinSize() sul pane.
        """
        if bool(enabled):
            self.main_panel.SetMinSize(wx.Size(370, 530))
        else:
            self.main_panel.SetMinSize(wx.Size(-1, -1))
        parent = self.main_panel.GetParent()
        if parent is not None:
            parent.Layout()


# ---------------------------------------------------------------------------
# Finestra fullscreen per l anteprima
# ---------------------------------------------------------------------------

class _FullscreenPreviewFrame(wx.Frame):
    """Finestra a tutto schermo che mostra una copia sincronizzata dell anteprima.

    Non crea un nuovo PreviewCanvas (per non duplicare il renderer) ma disegna
    direttamente usando lo stesso renderer del canvas originale. Il contenuto e
    sempre aggiornato perche _FullscreenPreviewFrame chiama renderer.Render()
    ad ogni OnPaint con self.owner.text e self.owner._zoom_factor.

    Chiusura: Esc, F11, o il pulsante Chiudi nella toolbar.
    """

    def __init__(self, owner):
        wx.Frame.__init__(
            self, None, wx.ID_ANY,
            title=_("Preview — press Esc or F11 to exit full screen"),
            style=wx.DEFAULT_FRAME_STYLE,
        )
        self.owner = owner

        # ── Toolbar minimale ──────────────────────────────────────────────
        toolbar = wx.Panel(self, style=wx.BORDER_NONE)
        # Colore di default (non SYS_COLOUR_BTNFACE congelato) → segue il tema GTK.
        toolbar.SetBackgroundColour(wx.NullColour)
        self._fs_toolbar = toolbar
        tb_sz = wx.BoxSizer(wx.HORIZONTAL)

        btn_close = wx.Button(toolbar, wx.ID_ANY, _("Exit full screen (Esc / F11)"),
                              style=wx.BORDER_SIMPLE)
        tb_sz.Add(btn_close, 0, wx.ALL | wx.ALIGN_CENTER_VERTICAL, 4)

        # Copia + Aggiorna anteprima (riusano le icone del canvas principale)
        btn_copy_fs = wx.BitmapButton(toolbar, wx.ID_ANY,
            PreviewCanvas._load_copy_bitmap(16), style=wx.BORDER_NONE)
        btn_copy_fs.SetToolTip(_("Copy formatted song to clipboard"))
        btn_refresh_fs = wx.BitmapButton(toolbar, wx.ID_ANY,
            PreviewCanvas._load_refresh_bitmap(16), style=wx.BORDER_NONE)
        btn_refresh_fs.SetToolTip(_("Refresh Preview Songpress++"))
        tb_sz.Add(btn_copy_fs,    0, wx.ALIGN_CENTER_VERTICAL | wx.LEFT, 4)
        tb_sz.Add(btn_refresh_fs, 0, wx.ALIGN_CENTER_VERTICAL | wx.LEFT, 2)
        tb_sz.Add(wx.StaticLine(toolbar, style=wx.LI_VERTICAL), 0,
                  wx.EXPAND | wx.LEFT | wx.RIGHT, 4)

        # Zoom out/slider/in nella finestra fullscreen
        btn_zm = wx.BitmapButton(toolbar, wx.ID_ANY,
            wx.ArtProvider.GetBitmap(wx.ART_MINUS, wx.ART_TOOLBAR, (16, 16)),
            style=wx.BORDER_NONE)
        self._fs_slider = wx.Slider(
            toolbar, wx.ID_ANY,
            value=int(round(owner._zoom_factor * 100)),
            minValue=int(_ZOOM_MIN * 100), maxValue=int(_ZOOM_MAX * 100),
            size=(120, -1), style=wx.SL_HORIZONTAL,
        )
        btn_zp = wx.BitmapButton(toolbar, wx.ID_ANY,
            wx.ArtProvider.GetBitmap(wx.ART_PLUS, wx.ART_TOOLBAR, (16, 16)),
            style=wx.BORDER_NONE)
        self._fs_zoom_label = wx.StaticText(toolbar,
            label="%d%%" % int(round(owner._zoom_factor * 100)),
            size=(40, -1), style=wx.ALIGN_CENTRE_HORIZONTAL)

        btn_fit = wx.Button(toolbar, wx.ID_ANY, _("Fit"), style=wx.BORDER_SIMPLE)
        btn_fit.SetToolTip(_("Fit preview width to panel (Ctrl+Shift+G)"))

        tb_sz.AddSpacer(8)
        tb_sz.Add(btn_zm,              0, wx.ALIGN_CENTER_VERTICAL)
        tb_sz.Add(self._fs_slider,     0, wx.ALIGN_CENTER_VERTICAL | wx.LEFT | wx.RIGHT, 2)
        tb_sz.Add(btn_zp,              0, wx.ALIGN_CENTER_VERTICAL)
        tb_sz.Add(self._fs_zoom_label, 0, wx.ALIGN_CENTER_VERTICAL | wx.LEFT, 4)
        tb_sz.AddSpacer(8)
        tb_sz.Add(btn_fit,             0, wx.ALIGN_CENTER_VERTICAL)

        toolbar.SetSizer(tb_sz)
        toolbar.Layout()
        # Colori freschi del tema GTK anche per la finestra fullscreen.
        PreviewCanvas._tint_toolbar(toolbar, *PreviewCanvas._fresh_gtk_colours())

        # ── Canvas scrolled ───────────────────────────────────────────────
        self._panel = wx.ScrolledWindow(self, style=wx.BORDER_NONE)
        self._panel.SetBackgroundStyle(wx.BG_STYLE_CUSTOM)
        self._pix = 10
        self._panel.SetScrollbars(self._pix, self._pix, 0, 0)

        outer = wx.BoxSizer(wx.VERTICAL)
        outer.Add(toolbar, 0, wx.EXPAND)
        outer.Add(wx.StaticLine(self), 0, wx.EXPAND)
        outer.Add(self._panel, 1, wx.EXPAND)
        self.SetSizer(outer)

        # ── Bind ─────────────────────────────────────────────────────────
        btn_close.Bind(wx.EVT_BUTTON,  self._OnClose)
        btn_copy_fs.Bind(wx.EVT_BUTTON,    self._OnCopy)
        btn_refresh_fs.Bind(wx.EVT_BUTTON, self._OnRefresh)
        btn_zm.Bind(wx.EVT_BUTTON,     lambda e: self._ZoomBy(-_ZOOM_STEP))
        btn_zp.Bind(wx.EVT_BUTTON,     lambda e: self._ZoomBy(+_ZOOM_STEP))
        btn_fit.Bind(wx.EVT_BUTTON,    self._OnFit)
        self._fs_slider.Bind(wx.EVT_SLIDER, self._OnSlider)
        self._panel.Bind(wx.EVT_PAINT,       self._OnPaint)
        self._panel.Bind(wx.EVT_MOUSEWHEEL,  self._OnWheel)
        self._panel.Bind(wx.EVT_LEFT_DCLICK, self._OnDblClick)
        # EVT_CHAR_HOOK sulla FRAME (non sul panel): in fullscreen il focus
        # iniziale e' sulla frame, non sul ScrolledWindow, quindi ESC/F11
        # non raggiungevano il panel. Bindando sulla frame li catturiamo sempre.
        self.Bind(wx.EVT_CHAR_HOOK, self._OnChar)
        self.Bind(wx.EVT_CLOSE,     self._OnCloseEvt)

        self._zoom = owner._zoom_factor
        self.SetSize(wx.GetDisplaySize())

    # ── Copia / Aggiorna ──────────────────────────────────────────────────

    def _OnCopy(self, evt):
        """Copia negli appunti dalla finestra fullscreen (riusa la logica owner)."""
        self.owner._OnCopyButton(None)

    def _OnRefresh(self, evt):
        """Aggiorna l'anteprima: rilegge il testo fresco e ridisegna la finestra."""
        self.owner._ForceRefreshNow()
        self._panel.Refresh()

    # ── Zoom helpers ──────────────────────────────────────────────────────

    def _SetZoom(self, factor):
        factor = max(_ZOOM_MIN, min(_ZOOM_MAX, factor))
        self._zoom = factor
        self._fs_zoom_label.SetLabel("%d%%" % int(round(factor * 100)))
        self._fs_slider.SetValue(int(round(factor * 100)))
        self._panel.Refresh()

    def _ZoomBy(self, delta):
        new = round((self._zoom + delta) / _ZOOM_STEP) * _ZOOM_STEP
        self._SetZoom(new)

    def _OnSlider(self, evt):
        pct = self._fs_slider.GetValue()
        self._SetZoom(round(pct / 100 / _ZOOM_STEP) * _ZOOM_STEP)

    def _OnFit(self, evt):
        pw, ph = self._panel.GetClientSize()
        last_w = getattr(self.owner, '_last_w', 0)
        if last_w > 0 and pw > 16:
            margin = max(8, int(pw * 0.03))
            available = pw - margin * 2
            if available > 0:
                factor = available / last_w
                # Idempotenza: non aggiornare se gia' convergente
                if abs(factor - self._zoom) / max(self._zoom, 0.01) >= 0.005:
                    self._SetZoom(factor)

    # ── Paint ─────────────────────────────────────────────────────────────

    def _OnPaint(self, evt):
        dc = wx.AutoBufferedPaintDC(self._panel)
        self._panel.PrepareDC(dc)
        bg = wx.Colour(160, 160, 160) if self.owner._greyBackground else wx.WHITE
        dc.SetBackground(wx.Brush(bg))
        dc.Clear()
        text = self.owner.text
        if not text.strip():
            return
        dc.SetUserScale(self._zoom, self._zoom)
        # Filigrana dietro al brano (non oscura il testo)
        cfg = getattr(self.owner, '_watermark_cfg', None)
        if (cfg and cfg.get('enabled') and cfg.get('showInPreview', True)
                and self.owner._last_h > 0):
            try:
                from . import Watermark
                Watermark.draw_watermark(dc, self.owner._last_w, self.owner._last_h, cfg)
            except Exception:
                pass
        w, h = self.owner.renderer.Render(text, dc)
        self.owner._last_w = w    # aggiorna così Fit funziona correttamente
        self.owner._last_h = h
        dc.SetUserScale(1.0, 1.0)
        pw, _ = self._panel.GetClientSize()
        margin = max(8, int(pw * 0.03))
        vw = int(w * self._zoom) + margin * 2
        vh = int(h * self._zoom) + _PAGE_GAP_PX * 2
        self._panel.SetVirtualSize(wx.Size(vw, vh))

    # ── Input ─────────────────────────────────────────────────────────────

    def _OnWheel(self, evt):
        if evt.ControlDown():
            self._ZoomBy(+_ZOOM_STEP if evt.GetWheelRotation() > 0 else -_ZOOM_STEP)
        else:
            evt.Skip()

    def _OnChar(self, evt):
        key = evt.GetKeyCode()
        if key in (wx.WXK_ESCAPE, wx.WXK_F11):
            self._OnClose(evt)
        else:
            evt.Skip()

    def _OnDblClick(self, evt):
        """Doppio-click nella finestra fullscreen: usa lo stesso hit-test preciso."""
        if self.owner._on_click_callback is None:
            evt.Skip()
            return
        if not getattr(self.owner, '_dblClickFocusEnabled', True):
            evt.Skip()
            return
        if getattr(self.owner, '_last_h', 0) <= 0:
            evt.Skip()
            return

        # Coordinate del click corrette per scroll e zoom della finestra fullscreen
        click_x_sc, click_y_sc = self._panel.CalcUnscrolledPosition(evt.GetPosition())
        pw, _ = self._panel.GetClientSize()
        margin_h = max(8, int(pw * 0.03))
        rx = (click_x_sc - margin_h) / self._zoom
        ry = click_y_sc / self._zoom

        # Riusa il hit-test del canvas principale (stesso renderer)
        block, line, token = self.owner._HitTestBox(rx, ry)
        if token is not None:
            token_text = getattr(token, 'text', '')
            block_idx  = self.owner.renderer.song.boxes.index(block) if block is not None else 0
            line_num   = self.owner._FindSourceLine(token_text, block_idx)
        else:
            src_lines = self.owner.text.count('\n') + 1 if self.owner.text.strip() else 1
            avg_h = self.owner._last_h / max(src_lines, 1)
            line_num = max(0, min(int(ry / avg_h), src_lines - 1))

        self.owner._on_click_callback(line_num)
        evt.Skip()

    # ── Cambio tema desktop (Linux/GTK) ───────────────────────────────────

    def RefreshSystemColours(self):
        """Fa rileggere il tema GTK alla toolbar della finestra fullscreen."""
        try:
            bg, fg = PreviewCanvas._fresh_gtk_colours()
            PreviewCanvas._tint_toolbar(getattr(self, '_fs_toolbar', None), bg, fg)
            if getattr(self, '_panel', None) is not None:
                self._panel.Refresh()
        except Exception:
            pass

    # ── Chiusura ──────────────────────────────────────────────────────────

    def _OnClose(self, evt):
        self.owner._fullscreen_frame = None
        self.ShowFullScreen(False)
        self.Destroy()

    def _OnCloseEvt(self, evt):
        self.owner._fullscreen_frame = None
        evt.Skip()
