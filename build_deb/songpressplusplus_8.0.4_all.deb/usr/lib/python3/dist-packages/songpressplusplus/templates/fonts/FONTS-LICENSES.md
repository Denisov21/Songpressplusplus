# Font opzionali — Licenze / Optional fonts — Licenses

🇮🇹 [Italiano](#italiano) · 🇬🇧 [English](#english)

---

<a name="italiano"></a>

# 🇮🇹 Italiano

Questo documento riguarda i **font opzionali** che SongpressPlusPlus può caricare
automaticamente per ampliare la copertura del piano **SMP** (Supplementary
Multilingual Plane) e dei simboli musicali.

> **Nota importante**
> Questi font **non sono inclusi di default** nell'applicazione. Vengono caricati
> solo se l'utente li aggiunge manualmente alla propria installazione. Di
> conseguenza SongpressPlusPlus, così com'è distribuito (AppImage, `.deb`, ecc.),
> **non ridistribuisce** questi file e non assume gli obblighi di licenza legati
> alla loro ridistribuzione. Gli obblighi ricadono su chi decide effettivamente di
> impacchettare o redistribuire i font.

## Riepilogo

| Font | Nome file tipico | Licenza | Titolare del copyright |
|------|------------------|---------|------------------------|
| Bravura | `Bravura.ttf` | SIL Open Font License 1.1 | Steinberg Media Technologies GmbH |
| Noto Music | `NotoMusic.ttf` / `NotoMusicRegular.ttf` | SIL Open Font License 1.1 | The Noto Project Authors / Google Inc. |
| Altri `.ttf` aggiunti dall'utente | qualsiasi | **secondo la licenza del singolo font** | il rispettivo autore |

Tutti i font consigliati e verificati qui sono sotto **SIL Open Font License,
versione 1.1** (in breve *OFL-1.1*), una licenza libera e open source approvata da
OSI, FSF e conforme alle Debian Free Software Guidelines.

## Bravura

- **File:** `Bravura.ttf` (ed eventualmente `BravuraText.ttf`)
- **Licenza:** SIL Open Font License, Version 1.1
- **Copyright:** © Steinberg Media Technologies GmbH
- **Sorgente ufficiale:** <https://github.com/steinbergmedia/bravura>
- **Informazioni SMuFL:** <https://www.smufl.org/fonts/>

Bravura è il font di riferimento per la specifica SMuFL (Standard Music Font
Layout). È distribuito sotto SIL OFL: è libero di essere scaricato, usato,
incorporato nei documenti, ridistribuito insieme ad altro software (anche
commerciale) e usato come base per font derivati. Le uniche restrizioni rilevanti
sono che il font non può essere venduto da solo, che un font derivato non può
chiamarsi "Bravura" né contenere tale nome riservato, e che ogni derivato deve
essere rilasciato sotto la stessa licenza OFL.

## Noto Music

- **File:** `NotoMusic.ttf` o `NotoMusicRegular.ttf`
- **Licenza:** SIL Open Font License, Version 1.1
- **Copyright:** © The Noto Project Authors (Google Inc.)
- **Sorgente ufficiale:** <https://github.com/notofonts/notofonts.github.io> (progetto Noto)
- **Sito del progetto:** <https://notofonts.github.io/>

Noto Music fa parte della famiglia Noto di Google, pensata per coprire tutti gli
script codificati in Unicode. L'intera famiglia Noto è distribuita sotto SIL
OFL-1.1 (dal 2015; alcune versioni molto precoci, 2013–2015, erano sotto Apache
License 2.0). Valgono le stesse libertà e restrizioni descritte per Bravura.

## Altri font `.ttf` aggiunti dall'utente

SongpressPlusPlus caricherà automaticamente qualunque altro `.ttf` presente nella
cartella dei font. **La licenza di questi file è responsabilità di chi li
aggiunge.** Prima di redistribuire un pacchetto che li includa, verifica che la
licenza del singolo font ne consenta l'incorporazione/ridistribuzione (molti font
musicali SMuFL — ad es. Petaluma, Leland, Sebastian — sono sotto OFL-1.1, ma non è
una regola universale: alcuni, come November 2.0, hanno licenza commerciale).

## SIL Open Font License 1.1 — punti chiave

Testo completo e FAQ: <https://openfontlicense.org/> (in precedenza
`https://scripts.sil.org/OFL`).

Sintesi (non sostituisce il testo di licenza):

1. **Uso libero.** I font possono essere usati, studiati, modificati e
   ridistribuiti liberamente.
2. **Bundling consentito.** Possono essere impacchettati, incorporati e
   ridistribuiti — anche con software commerciale.
3. **Non vendibili da soli.** Non possono essere venduti come prodotto a sé stante;
   possono però essere inclusi (anche a pagamento) insieme ad altro software.
4. **Nomi riservati (Reserved Font Names).** Un font derivato non può usare il nome
   riservato dell'originale.
5. **Stessa licenza per i derivati.** Le versioni modificate devono essere
   distribuite anch'esse sotto OFL.
6. **Copia della licenza allegata.** Ogni copia del font (originale o modificata)
   deve essere accompagnata dal testo della licenza OFL.
7. **Nessuna garanzia.** Il software è fornito "così com'è", senza garanzie.

### Obbligo pratico in caso di ridistribuzione

Se — e solo se — decidi di **includere** questi font in un pacchetto che
distribuisci, ricordati di:

- inserire il file di licenza `OFL.txt` accanto a ciascun font;
- mantenere le note di copyright presenti nei metadati del font;
- non rinominare i font con i loro Reserved Font Names se li modifichi.

Se invece i font restano **aggiunti localmente dall'utente** (comportamento
predefinito), non hai obblighi di ridistribuzione da assolvere.

*Documento a scopo informativo; non costituisce consulenza legale. In caso di
dubbi sulla ridistribuzione, fai riferimento al testo integrale della SIL Open
Font License 1.1 e ai file di licenza forniti con ciascun font.*

---

<a name="english"></a>

# 🇬🇧 English

This document covers the **optional fonts** that SongpressPlusPlus can load
automatically to extend coverage of the **SMP** (Supplementary Multilingual Plane)
and of musical symbols.

> **Important note**
> These fonts are **not bundled by default** with the application. They are loaded
> only if the user manually adds them to their installation. As a result,
> SongpressPlusPlus as distributed (AppImage, `.deb`, etc.) **does not
> redistribute** these files and does not take on the licensing obligations tied to
> redistributing them. Those obligations fall on whoever actually chooses to
> package or redistribute the fonts.

## Summary

| Font | Typical file name | License | Copyright holder |
|------|-------------------|---------|------------------|
| Bravura | `Bravura.ttf` | SIL Open Font License 1.1 | Steinberg Media Technologies GmbH |
| Noto Music | `NotoMusic.ttf` / `NotoMusicRegular.ttf` | SIL Open Font License 1.1 | The Noto Project Authors / Google Inc. |
| Other user-added `.ttf` | any | **per the individual font's license** | the respective author |

All the fonts recommended and verified here are under the **SIL Open Font License,
version 1.1** (*OFL-1.1* for short), a free and open source license approved by OSI
and the FSF and compliant with the Debian Free Software Guidelines.

## Bravura

- **File:** `Bravura.ttf` (and optionally `BravuraText.ttf`)
- **License:** SIL Open Font License, Version 1.1
- **Copyright:** © Steinberg Media Technologies GmbH
- **Official source:** <https://github.com/steinbergmedia/bravura>
- **SMuFL info:** <https://www.smufl.org/fonts/>

Bravura is the reference font for the SMuFL (Standard Music Font Layout)
specification. It is distributed under the SIL OFL: it is free to download, use,
embed in documents, redistribute alongside other software (including commercial
software) and use as the basis for derivative fonts. The only notable restrictions
are that the font may not be sold on its own, that a derivative font may not be
called "Bravura" or contain that reserved name, and that any derivative must be
released under the same OFL license.

## Noto Music

- **File:** `NotoMusic.ttf` or `NotoMusicRegular.ttf`
- **License:** SIL Open Font License, Version 1.1
- **Copyright:** © The Noto Project Authors (Google Inc.)
- **Official source:** <https://github.com/notofonts/notofonts.github.io> (Noto project)
- **Project site:** <https://notofonts.github.io/>

Noto Music is part of Google's Noto font family, designed to cover every script
encoded in Unicode. The entire Noto family is distributed under SIL OFL-1.1 (since
2015; a few very early versions, 2013–2015, were under the Apache License 2.0). The
same freedoms and restrictions described for Bravura apply.

## Other user-added `.ttf` fonts

SongpressPlusPlus will automatically load any other `.ttf` present in the fonts
folder. **The license of these files is the responsibility of whoever adds them.**
Before redistributing a package that includes them, verify that the individual
font's license permits embedding/redistribution (many SMuFL music fonts — e.g.
Petaluma, Leland, Sebastian — are under OFL-1.1, but this is not universal: some,
such as November 2.0, are commercially licensed).

## SIL Open Font License 1.1 — key points

Full text and FAQ: <https://openfontlicense.org/> (formerly
`https://scripts.sil.org/OFL`).

Summary (does not replace the license text):

1. **Free use.** The fonts may be used, studied, modified and redistributed
   freely.
2. **Bundling allowed.** They may be packaged, embedded and redistributed —
   including with commercial software.
3. **Not sellable on their own.** They may not be sold as a standalone product, but
   they may be included (even for a fee) together with other software.
4. **Reserved Font Names.** A derivative font may not use the original's reserved
   name.
5. **Same license for derivatives.** Modified versions must also be distributed
   under the OFL.
6. **License copy included.** Every copy of the font (original or modified) must be
   accompanied by the OFL license text.
7. **No warranty.** The software is provided "as is", without warranty.

### Practical obligation when redistributing

If — and only if — you decide to **include** these fonts in a package you
distribute, remember to:

- place the `OFL.txt` license file next to each font;
- keep the copyright notices present in the font's metadata;
- do not rename the fonts with their Reserved Font Names if you modify them.

If instead the fonts remain **locally added by the user** (the default behavior),
you have no redistribution obligations to fulfill.

*This document is for informational purposes only and does not constitute legal
advice. If in doubt about redistribution, refer to the full text of the SIL Open
Font License 1.1 and to the license files provided with each font.*
