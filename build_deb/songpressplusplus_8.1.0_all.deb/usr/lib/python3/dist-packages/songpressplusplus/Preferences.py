###############################################################
# Name:             Preferences.py
# Purpose:     Hold program preferences
# Author:         Luca Allulli (webmaster@roma21.it)
# Created:     2010-01-31
# Modified by:  Denisov21
# Copyright: Luca Allulli (https://www.skeed.it/songpress)
#               Modifications copyright Denisov21
# License:     GNU GPL v2
##############################################################

import json
import os
import re

from . import i18n
from .SongFormat import *
from .decorators import StandardVerseNumbers
from .Transpose import *

_ = wx.GetTranslation


def get_chords_positions():
    return {
        'above': _("Above text"),
        'below': _("Below text"),
    }
    
class Preferences(object):
    """
        Available preferences

        * format
        * decoratorFormat
        * decorator
        * chorusLabel (None or string)
        * labelVerses
        * editorFace
        * editorSize
        * fontFace
        * defaultNotation
        * notations
        * defaultNotation
        * autoAdjustSpuriousLines
        * autoAdjustTab2Chordpro
        * autoAdjustEasyKey
        * chordsPosition ('above' or 'below')
        * locale
        * Set/GetEasyChordsGroup
        * GetEasyChords
        * showRecentFiles (bool)
        * colourPreview (bool)
    """
    def __init__(self):
        object.__init__(self)
        self.config = wx.Config.Get()
        self.format = SongFormat()
        self.decoratorFormat = StandardVerseNumbers.Format(self.format, _("Chorus"))
        self.decorator = StandardVerseNumbers.Decorator(self.decoratorFormat)
        self.notations = [enNotation, itNotation, itUcNotation, deNotation, tradDeNotation, frNotation, ptNotation, nashvilleNotation, romanNotation]
        self.easyChordsGroup = {}
        self.titleLineWidth = 4
        self.verseBoxWidth = 1
        self.Load()

    def SetFont(self, font, showChords=None):
        self.fontFace = font
        self.format.face = font
        self.format.comment.face = font
        self.format.chord.face = font
        self.format.chorus.face = font
        self.format.chorus.chord.face = font
        self.format.chorus.comment.face = font
        for v in self.format.verse:
            v.face = font
            v.chord.face = font
            v.comment.face = font
        self.format.title.face = font
        self.format.subtitle.face = font
        self.decoratorFormat.face = font
        self.decoratorFormat.chorus.face = font
        if showChords is not None:
            self.format.showChords = showChords

    def Load(self):
        self.notices = {}
        self.config.SetPath('/Format')
        l = self.config.Read('ChorusLabel')
        if l:
            self.chorusLabel = l
            self.decoratorFormat.SetChorusLabel(l)
        else:
            self.chorusLabel = None
        showChords = int(self.config.Read('ShowChords', "2"))
        self.config.SetPath('/Format/Font')
        face = self.config.Read('Face')
        if face:
            self.fontFace = face
        else:
            self.fontFace = "Arial"
        self.SetFont(self.fontFace, showChords)
        self.config.SetPath('/Format/Style')
        labelVerses = self.config.Read('LabelVerses')
        if labelVerses:
            self.labelVerses = bool(int(labelVerses))
        else:
            self.labelVerses = True
        self.config.SetPath('/Editor')
        self.editorFace = self.config.Read('Face')
        self.editorSize = self.config.Read('Size')
        if not self.editorFace:
            self.editorFace = wx.SystemSettings().GetFont(wx.SYS_ANSI_FIXED_FONT).GetFaceName() # "Lucida Console"
            self.editorSize = 12
        else:
            self.editorSize = int(self.editorSize)
        n = self.config.Read('DefaultNotation')
        if n:
            self.defaultNotation = n
            self.notations = [x for x in self.notations if x.id == n] + [x for x in self.notations if x.id != n]
        else:
            lang = i18n.getLang()
            self.defaultNotation = None
            if lang in defaultLangNotation:
                n = defaultLangNotation[lang].id
                self.notations = [x for x in self.notations if x.id == n] + [x for x in self.notations if x.id != n]
        self.config.SetPath('/AutoAdjust')
        spuriousLines = self.config.Read('spuriousLines')
        if spuriousLines:
            self.autoAdjustSpuriousLines = bool(int(spuriousLines))
        else:
            self.autoAdjustSpuriousLines = True
        tab2chordpro = self.config.Read('tab2chordpro')
        if tab2chordpro:
            self.autoAdjustTab2Chordpro = bool(int(tab2chordpro))
        else:
            self.autoAdjustTab2Chordpro = True
        easyKey = self.config.Read('easyKey')
        if easyKey:
            self.autoAdjustEasyKey = bool(int(easyKey))
        else:
            self.autoAdjustEasyKey = False
            self.notices['firstTimeEasyKey'] = True
        chordsPosition = self.config.Read('chordsPosition')
        if chordsPosition in ('above', 'below'):
            self.chordsPosition = chordsPosition
        else:
            self.chordsPosition = 'above'
        self.config.SetPath('/AutoAdjust/EasyChordsGroups')
        for k in easyChordsOrder:
            l = self.config.Read(k)
            if l:
                l = int(l)
            else:
                l = easyChords[k][2]
            self.SetEasyChordsGroup(k, l)
        self.config.SetPath('/App')
        ext = self.config.Read('defaultExtension')
        if not ext:
            self.defaultExtension = 'crd'
        else:
            self.defaultExtension = ext
        lang = self.config.Read('locale')
        if not lang:
            self.locale = None
        else:
            self.locale = lang
        self.config.SetPath('/App')
        showRecentFiles = self.config.Read('showRecentFiles')
        if showRecentFiles:
            self.showRecentFiles = bool(int(showRecentFiles))
        else:
            self.showRecentFiles = True
        self.config.SetPath('/Format/Style')
        titleLineWidth = self.config.Read('TitleLineWidth')
        self.titleLineWidth = int(titleLineWidth) if titleLineWidth else 4
        verseBoxWidth = self.config.Read('VerseBoxWidth')
        self.verseBoxWidth = int(verseBoxWidth) if verseBoxWidth else 1
        self._LoadKlavierColour()
        self._LoadFingerNumColour()
        self._LoadContextMenu()
        self._LoadSpellCheck()
        self._LoadEditorBg()
        self._LoadSelColour()
        self._LoadCaretColour()
        self._LoadCaptionColours()
        self._LoadPrintOptions()
        self._LoadMultiCursor()
        self._LoadTempoIconSize()
        self._LoadTempoIconColour()
        self._LoadWindowGeometryPref()
        self._LoadPreviewOptions()
        self._LoadWatermarkPrefs()
        self._LoadGridDisplayMode()
        self._LoadDurationBeats()
        self._LoadMusicalSymbol()
        self._LoadSmpValign()
        self._LoadSmpOversample()
        self._LoadChordArrow()
        self._LoadSyntaxColours()
        self._LoadColourPreview()
        self._LoadDebugOptions()
        self._LoadIntellisense()
        self._LoadIntellisenseHelp()
        self._LoadDecoSliderColour()
        self._LoadNoChordHide()
        self._LoadSingleInstance()
        self._LoadShowRestartMenuItem()
        self._LoadShowFullPathInTitle()
        self._LoadSaveOnModified()
        self._LoadIntegrateChordsOnlyWhenNeeded()
        self._LoadPasteChordsOnlyWhenNeeded()
        self._LoadReplaceSpacesInFilenames()
        self._LoadSuggestTitleAsFilename()
        self._LoadToolbarVis()
        self._LoadToolbarIconSize()
        self._LoadChordUppercase()
        self._LoadDepIconMode()
        self._LoadRulerModeButtons()
        self._LoadStatusDotColours()
        self._LoadThemeName()

    def _LoadKlavierColour(self):
        self.config.SetPath('/KlavierColour')
        h = self.config.Read('highlightHex')
        self.klavierHighlightHex = h if h else '#D23C3C'
        # Secondo colore per il tasto d'ottava (duplicato a destra nelle
        # tastiere a 8 tasti, es. SI alto in SI...SI). Disattivato di default.
        v = self.config.Read('octaveColourEnabled')
        self.klavierOctaveColourEnabled = bool(int(v)) if v != '' else False
        h = self.config.Read('octaveHex')
        self.klavierOctaveHex = h if h else '#3C78D2'
        v = self.config.Read('scalePct')
        try:
            self.klavierScalePct = max(50, min(int(v), 200)) if v != '' else 100
        except ValueError:
            self.klavierScalePct = 100
        self.config.SetPath('/')

    def _LoadFingerNumColour(self):
        self.config.SetPath('/FingerNumColour')
        h = self.config.Read('fingerNumHex')
        self.fingerNumColourHex = h if h else '#1A1A1A'
        self.config.SetPath('/')

    def _LoadContextMenu(self):
        self.config.SetPath('/ContextMenu')
        def rb(key):
            v = self.config.Read(key)
            return bool(int(v)) if v != '' else True
        self.cmUndo         = rb('undo')
        self.cmRedo         = rb('redo')
        self.cmCut          = rb('cut')
        self.cmCopy         = rb('copy')
        self.cmPaste        = rb('paste')
        self.cmDelete       = rb('delete')
        v = self.config.Read('confirmDelete')
        self.cmConfirmDelete = bool(int(v)) if v != '' else False
        self.cmPasteChords           = rb('pasteChords')
        self.cmPropagateVerseChords  = rb('propagateVerseChords')
        self.cmPropagateChorusChords = rb('propagateChorusChords')
        self.cmCopyTextOnly          = rb('copyTextOnly')
        self.cmEditDirective         = rb('editDirective')
        self.cmSelectAll    = rb('selectAll')
        v = self.config.Read('showIcons')
        self.cmShowIcons = bool(int(v)) if v != '' else True
        self.config.SetPath('/')

    def _LoadSpellCheck(self):
        # Opzioni del controllo ortografico gestite dalle Preferenze generali.
        # 'showButtonIcons' e' la stessa chiave usata in precedenza dal dialogo
        # "Opzioni controllo ortografico", cosi' l'eventuale scelta e' mantenuta.
        self.config.SetPath('/SpellCheck')
        v = self.config.Read('showButtonIcons')
        if v == '':
            self.showSpellButtonIcons = True
        else:
            self.showSpellButtonIcons = v.strip().lower() in ('1', 'true', 'yes')
        self.config.SetPath('/')

    def _LoadEditorBg(self):
        self.config.SetPath('/Editor')
        h = self.config.Read('BgHex')
        self.editorBgHex = h if h else '#FFFFFF'
        self.config.SetPath('/')

    def _LoadSelColour(self):
        self.config.SetPath('/Editor')
        h = self.config.Read('SelColourHex')
        self.selColourHex = h if h else '#C0C0C0'
        self.config.SetPath('/')

    def _LoadCaretColour(self):
        self.config.SetPath('/Editor')
        h = self.config.Read('CaretColourHex')
        self.caretColourHex = h if h else '#000000'
        self.config.SetPath('/')

    def _LoadPrintOptions(self):
        self.config.SetPath('/Print')
        v = self.config.Read('showPrintPreview')
        self.showPrintPreview = bool(int(v)) if v != '' else True
        v = self.config.Read('printPreviewAlwaysOnTop')
        self.printPreviewAlwaysOnTop = bool(int(v)) if v != '' else False
        self.config.SetPath('/')

    def _LoadMultiCursor(self):
        self.config.SetPath('/Editor')
        v = self.config.Read('multiCursor')
        self.multiCursor = bool(int(v)) if v != '' else False
        self.config.SetPath('/')

    def _LoadColourPreview(self):
        # Anteprima del colore al passaggio del mouse su una sigla colore
        # (es. {textcolor:#A52A2A}). Default True = mostra l'anteprima.
        self.config.SetPath('/Editor')
        v = self.config.Read('colourPreview')
        self.colourPreview = bool(int(v)) if v != '' else True
        self.config.SetPath('/')

    def _LoadTempoIconSize(self):
        self.config.SetPath('/Format')
        v = self.config.Read('tempoIconSize')
        self.tempoIconSize = int(v) if v in ('16', '24', '32') else 24
        self.config.SetPath('/')

    def _LoadTempoIconColour(self):
        self.config.SetPath('/Format')
        h = self.config.Read('TempoIconColour')
        self.tempoIconColourHex = h if h else '#000000'
        self.config.SetPath('/')

    def _LoadWindowGeometryPref(self):
        self.config.SetPath('/App')
        v = self.config.Read('saveWindowGeometry')
        self.saveWindowGeometry = bool(int(v)) if v != '' else True
        self.config.SetPath('/')

    def _LoadPreviewOptions(self):
        self.config.SetPath('/Preview')
        v = self.config.Read('showPageIndicator')
        self.showPageIndicator = bool(int(v)) if v != '' else True
        v = self.config.Read('greyBackground')
        self.greyBackground = bool(int(v)) if v != '' else True
        v = self.config.Read('debounceRefresh')
        self.debounceRefresh = bool(int(v)) if v != '' else True
        v = self.config.Read('dblClickFocus')
        self.dblClickFocus = bool(int(v)) if v != '' else True
        v = self.config.Read('previewMinSize')
        self.previewMinSize = bool(int(v)) if v != '' else True
        v = self.config.Read('guideViewer')
        self.guideViewer = v if v in ('auto', 'builtin', 'markdown', 'mistune') else 'auto'
        v = self.config.Read('liveDriverPoll')
        self.liveDriverPoll = bool(int(v)) if v != '' else True
        self.config.SetPath('/')

    def _LoadWatermarkPrefs(self):
        """Carica SOLO le preferenze di stile della filigrana mostrate nel
        pannello: opacita', angolo, dimensione, colore e mosaico (Affianca).

        Le chiavi 'enabled', 'text' e 'showInPreview' NON vengono persistite
        qui: restano per-documento. Il risultato e' esposto in
        self.watermarkStyle, un dict con le sole chiavi di stile, utile per
        inizializzare i valori di default del WatermarkDialog.
        """
        def _int(v, default):
            try:
                return int(v)
            except (TypeError, ValueError):
                return default
        self.config.SetPath('/Watermark')
        opacity = _int(self.config.Read('opacity'), 12)
        angle   = _int(self.config.Read('angle'), 45)
        sizePct = _int(self.config.Read('sizePct'), 100)
        h       = self.config.Read('colourHex')
        colourHex = h if h else '#000000'
        v = self.config.Read('tile')
        tile = bool(int(v)) if v != '' else False
        self.config.SetPath('/')
        self.watermarkStyle = {
            'opacity':   max(2,   min(100, opacity)),
            'angle':     max(-90, min(90,  angle)),
            'sizePct':   max(20,  min(300, sizePct)),
            'colourHex': colourHex,
            'tile':      tile,
        }

    def _LoadGridDisplayMode(self):
        """Carica la modalità di visualizzazione del blocco {start_of_grid}.

        Valori:
            'pipe'  -- | C   | G   | Am  | F   |  (separatori pipe, default)
            'plain' -- C   G   Am  F               (testo spaziato senza pipe)
            'table' -- griglia con celle evidenziate (bordi disegnati)
        """
        self.config.SetPath('/Format')
        v = self.config.Read('gridDisplayMode')
        self.gridDisplayMode = v if v in ('pipe', 'plain', 'table') else 'pipe'
        v2 = self.config.Read('gridDefaultLabel')
        self.gridDefaultLabel = v2 if v2 else _("Grid")
        v3 = self.config.Read('gridSpaceAsPipe')
        self.gridSpaceAsPipe = bool(int(v3)) if v3 != '' else True
        v4 = self.config.Read('gridSizeDir')
        self.gridSizeDir = v4 if v4 in ('both', 'horizontal', 'vertical') else 'both'
        self.config.SetPath('/')

    def Bool2String(self, param):
        return "1" if param else "0"

    def Save(self):
        self.config.SetPath('/Format')
        if self.chorusLabel is not None:
            self.config.Write('ChorusLabel', self.chorusLabel)
        self.config.Write('ShowChords', str(self.format.showChords))
        self.config.SetPath('/Format/Font')
        self.config.Write('Face', self.fontFace)
        self.config.SetPath('/Format/Style')
        self.config.Write('LabelVerses', self.Bool2String(self.labelVerses))
        self.config.SetPath('/Editor')
        self.config.Write('Face', self.editorFace)
        self.config.Write('Size', str(self.editorSize))
        if self.defaultNotation is not None:
            self.config.Write('DefaultNotation', self.defaultNotation)
        self.config.SetPath('/AutoAdjust')
        self.config.Write('spuriousLines', self.Bool2String(self.autoAdjustSpuriousLines))
        self.config.Write('tab2chordpro', self.Bool2String(self.autoAdjustTab2Chordpro))
        self.config.Write('easyKey', self.Bool2String(self.autoAdjustEasyKey))
        self.config.Write('chordsPosition', self.chordsPosition)
        self.config.SetPath('/AutoAdjust/EasyChordsGroups')
        for k in easyChordsOrder:
            self.config.Write(k, str(self.GetEasyChordsGroup(k)))
        self.config.SetPath('/App')
        self.config.Write('defaultExtension', self.defaultExtension)
        if self.locale is not None:
            lang = self.config.Write('locale', self.locale)
        self.config.SetPath('/App')
        self.config.Write('showRecentFiles', self.Bool2String(self.showRecentFiles))
        self.config.SetPath('/Format/Style')
        self.config.Write('TitleLineWidth', str(self.titleLineWidth))
        self.config.Write('VerseBoxWidth', str(self.verseBoxWidth))
        self._SaveKlavierColour()
        self._SaveFingerNumColour()
        self._SaveContextMenu()
        self._SaveSpellCheck()
        self._SaveEditorBg()
        self._SaveSelColour()
        self._SaveCaretColour()
        self._SaveCaptionColours()
        self._SavePrintOptions()
        self._SaveMultiCursor()
        self._SaveTempoIconSize()
        self._SaveTempoIconColour()
        self._SaveWindowGeometryPref()
        self._SavePreviewOptions()
        self._SaveWatermarkPrefs()
        self._SaveGridDisplayMode()
        self._SaveDurationBeats()
        self._SaveMusicalSymbol()
        self._SaveSmpValign()
        self._SaveSmpOversample()
        self._SaveChordArrow()
        self._SaveSyntaxColours()
        self._SaveColourPreview()
        self._SaveDebugOptions()
        self._SaveIntellisense()
        self._SaveIntellisenseHelp()
        self._SaveDecoSliderColour()
        self._SaveNoChordHide()
        self._SaveSingleInstance()
        self._SaveShowRestartMenuItem()
        self._SaveShowFullPathInTitle()
        self._SaveSaveOnModified()
        self._SaveIntegrateChordsOnlyWhenNeeded()
        self._SavePasteChordsOnlyWhenNeeded()
        self._SaveReplaceSpacesInFilenames()
        self._SaveSuggestTitleAsFilename()
        self._SaveToolbarVis()
        self._SaveToolbarIconSize()
        self._SaveChordUppercase()
        self._SaveDepIconMode()
        self._SaveRulerModeButtons()
        self._SaveStatusDotColours()
        self._SaveThemeName()
        self.config.Flush()

    def _SaveKlavierColour(self):
        self.config.SetPath('/KlavierColour')
        self.config.Write('highlightHex', getattr(self, 'klavierHighlightHex', '#D23C3C'))
        self.config.Write('octaveColourEnabled',
                          '1' if getattr(self, 'klavierOctaveColourEnabled', False) else '0')
        self.config.Write('octaveHex', getattr(self, 'klavierOctaveHex', '#3C78D2'))
        self.config.Write('scalePct', str(getattr(self, 'klavierScalePct', 100)))
        self.config.SetPath('/')

    def _SaveFingerNumColour(self):
        self.config.SetPath('/FingerNumColour')
        self.config.Write('fingerNumHex', getattr(self, 'fingerNumColourHex', '#1A1A1A'))
        self.config.SetPath('/')

    def _SaveContextMenu(self):
        self.config.SetPath('/ContextMenu')
        self.config.Write('undo',         '1' if getattr(self, 'cmUndo',         True) else '0')
        self.config.Write('redo',         '1' if getattr(self, 'cmRedo',         True) else '0')
        self.config.Write('cut',          '1' if getattr(self, 'cmCut',          True) else '0')
        self.config.Write('copy',         '1' if getattr(self, 'cmCopy',         True) else '0')
        self.config.Write('paste',        '1' if getattr(self, 'cmPaste',        True) else '0')
        self.config.Write('delete',       '1' if getattr(self, 'cmDelete',       True) else '0')
        self.config.Write('confirmDelete', '1' if getattr(self, 'cmConfirmDelete', False) else '0')
        self.config.Write('pasteChords',           '1' if getattr(self, 'cmPasteChords',           True) else '0')
        self.config.Write('propagateVerseChords',  '1' if getattr(self, 'cmPropagateVerseChords',  True) else '0')
        self.config.Write('propagateChorusChords', '1' if getattr(self, 'cmPropagateChorusChords', True) else '0')
        self.config.Write('copyTextOnly',          '1' if getattr(self, 'cmCopyTextOnly',          True) else '0')
        self.config.Write('editDirective',         '1' if getattr(self, 'cmEditDirective',         True) else '0')
        self.config.Write('selectAll',    '1' if getattr(self, 'cmSelectAll',    True) else '0')
        self.config.Write('showIcons',    '1' if getattr(self, 'cmShowIcons',    True) else '0')
        self.config.SetPath('/')

    def _SaveSpellCheck(self):
        self.config.SetPath('/SpellCheck')
        self.config.Write('showButtonIcons',
                          '1' if getattr(self, 'showSpellButtonIcons', True) else '0')
        self.config.SetPath('/')

    def _SaveEditorBg(self):
        self.config.SetPath('/Editor')
        self.config.Write('BgHex', getattr(self, 'editorBgHex', '#FFFFFF'))
        self.config.SetPath('/')

    def _SaveSelColour(self):
        self.config.SetPath('/Editor')
        self.config.Write('SelColourHex', getattr(self, 'selColourHex', '#C0C0C0'))
        self.config.SetPath('/')

    def _SaveCaretColour(self):
        self.config.SetPath('/Editor')
        self.config.Write('CaretColourHex', getattr(self, 'caretColourHex', '#000000'))
        self.config.SetPath('/')

    def _LoadCaptionColours(self):
        self.config.SetPath('/CaptionColours')
        h = self.config.Read('EditorActiveHex')
        self.captionEditorActiveHex = h if h else '#4682C8'
        h = self.config.Read('PreviewActiveHex')
        self.captionPreviewActiveHex = h if h else '#329B82'
        self.config.SetPath('/')

    def _SaveCaptionColours(self):
        self.config.SetPath('/CaptionColours')
        self.config.Write('EditorActiveHex',  getattr(self, 'captionEditorActiveHex',  '#4682C8'))
        self.config.Write('PreviewActiveHex', getattr(self, 'captionPreviewActiveHex', '#329B82'))
        self.config.SetPath('/')

    # Colori predefiniti per ogni stile sintattico dell'editor
    SYNTAX_COLOUR_DEFAULTS = {
        'normal':   '#000000',
        'chorus':   '#000000',
        'chord':    '#FF0000',
        'command':  '#0000FF',
        'attr':     '#008000',
        'comment':  '#808080',
        'tabgrid':  '#8B5A00',
    }

    def _LoadSyntaxColours(self):
        self.config.SetPath('/EditorSyntaxColours')
        self.syntaxColours = {}
        for key, default in self.SYNTAX_COLOUR_DEFAULTS.items():
            h = self.config.Read(key)
            self.syntaxColours[key] = h if h else default
        self.config.SetPath('/')

    def _SaveSyntaxColours(self):
        self.config.SetPath('/EditorSyntaxColours')
        for key, default in self.SYNTAX_COLOUR_DEFAULTS.items():
            self.config.Write(key, self.syntaxColours.get(key, default))
        self.config.SetPath('/')

    def _LoadDebugOptions(self):
        self.config.SetPath('/Debug')
        v = self.config.Read('showDebugMsg')
        self.showDebugMsg = bool(int(v)) if v != '' else False
        self.config.SetPath('/')

    def _SaveDebugOptions(self):
        self.config.SetPath('/Debug')
        self.config.Write('showDebugMsg', '1' if getattr(self, 'showDebugMsg', False) else '0')
        self.config.SetPath('/')

    def _LoadIntellisense(self):
        self.config.SetPath('/Editor')
        v = self.config.Read('intellisense')
        self.intellisense = bool(int(v)) if v != '' else True
        self.config.SetPath('/')

    def _SaveIntellisense(self):
        self.config.SetPath('/Editor')
        self.config.Write('intellisense', '1' if getattr(self, 'intellisense', True) else '0')
        self.config.SetPath('/')

    def _LoadIntellisenseHelp(self):
        """Guida a comparsa accanto al popup intellisense (default True).
        Ha effetto solo se anche 'intellisense' e' attivo."""
        self.config.SetPath('/Editor')
        v = self.config.Read('intellisenseHelp')
        self.intellisenseHelp = bool(int(v)) if v != '' else True
        self.config.SetPath('/')

    def _SaveIntellisenseHelp(self):
        self.config.SetPath('/Editor')
        self.config.Write('intellisenseHelp', '1' if getattr(self, 'intellisenseHelp', True) else '0')
        self.config.SetPath('/')

    @property
    def showIntellisenseHelp(self):
        """True solo se intellisense E guida sono entrambi abilitati."""
        return bool(getattr(self, 'intellisense', True)) and bool(getattr(self, 'intellisenseHelp', True))

    def _LoadChordUppercase(self):
        """Stato della casella 'Accordo in maiuscolo' del dialogo Inserisci accordo."""
        self.config.SetPath('/Editor')
        v = self.config.Read('chordUppercase')
        self.chordUppercase = bool(int(v)) if v != '' else False
        self.config.SetPath('/')

    def _SaveChordUppercase(self):
        self.config.SetPath('/Editor')
        self.config.Write('chordUppercase', '1' if getattr(self, 'chordUppercase', False) else '0')
        self.config.SetPath('/')

    def _LoadDepIconMode(self):
        """Icona della colonna Stato nella finestra 'Verifica dipendenze':
        'native' = glifi di testo (✅/❌), 'image' = immagini da img/
        (checked_box.png / not_checked_box.png)."""
        self.config.SetPath('/App')
        v = self.config.Read('depIconMode')
        self.depIconMode = v if v in ('native', 'image') else 'native'
        self.config.SetPath('/')

    def _SaveDepIconMode(self):
        self.config.SetPath('/App')
        self.config.Write('depIconMode', getattr(self, 'depIconMode', 'native'))
        self.config.SetPath('/')

    STATUS_DOT_ON_DEFAULT = '#00AA00'     # verde
    STATUS_DOT_OFF_DEFAULT = '#E53935'    # rosso

    @staticmethod
    def _ValidHex(v, default):
        v = (v or '').strip()
        if len(v) == 7 and v[0] == '#':
            try:
                int(v[1:], 16)
                return v.upper()
            except ValueError:
                pass
        return default

    def _LoadStatusDotColours(self):
        """Colori dei pallini Intellisense/Multicursore nella barra di stato."""
        self.config.SetPath('/Editor')
        self.statusDotOnHex = self._ValidHex(self.config.Read('statusDotOnHex'),
                                             self.STATUS_DOT_ON_DEFAULT)
        self.statusDotOffHex = self._ValidHex(self.config.Read('statusDotOffHex'),
                                              self.STATUS_DOT_OFF_DEFAULT)
        self.config.SetPath('/')

    def _SaveStatusDotColours(self):
        self.config.SetPath('/Editor')
        self.config.Write('statusDotOnHex', self._ValidHex(
            getattr(self, 'statusDotOnHex', ''), self.STATUS_DOT_ON_DEFAULT))
        self.config.Write('statusDotOffHex', self._ValidHex(
            getattr(self, 'statusDotOffHex', ''), self.STATUS_DOT_OFF_DEFAULT))
        self.config.SetPath('/')

    def _LoadThemeName(self):
        """Nome dell'ultimo tema colori caricato/salvato nella scheda Editor."""
        self.config.SetPath('/Editor')
        self.syntaxThemeName = self.config.Read('syntaxThemeName') or ''
        self.config.SetPath('/')

    def _SaveThemeName(self):
        self.config.SetPath('/Editor')
        self.config.Write('syntaxThemeName', getattr(self, 'syntaxThemeName', '') or '')
        self.config.SetPath('/')

    def SaveEditorToggles(self):
        """Salva subito Intellisense e Multicursore (cambiati dalla status bar,
        fuori dal dialogo Opzioni). Stesse chiavi di _SaveIntellisense/_SaveMultiCursor."""
        self._SaveIntellisense()
        self._SaveMultiCursor()
        self.config.Flush()

    def _LoadRulerModeButtons(self):
        """Pulsanti delle modalita' del Righello a schermo (Riquadro,
        Spaziatura, Orizzontale, Verticale): 'icons' = icone 16x16,
        'text' = scritte."""
        self.config.SetPath('/App')
        v = self.config.Read('rulerModeButtons')
        self.rulerModeButtons = v if v in ('icons', 'text') else 'icons'
        # Caselle delle opzioni del righello: 'inline' = affiancate nella
        # barra, 'list' = in una lista aperta dal pulsante ruler_list.png
        v = self.config.Read('rulerOptionsLayout')
        self.rulerOptionsLayout = v if v in ('inline', 'list') else 'inline'
        # Tolleranza del righello (0-255), condivisa con la barra del righello,
        # e se mostrarla anche nella barra oppure solo qui nelle Opzioni.
        v = self.config.Read('rulerTolerance')
        try:
            self.rulerTolerance = max(0, min(255, int(v))) if v != '' else 30
        except ValueError:
            self.rulerTolerance = 30
        v = self.config.Read('rulerShowTolerance')
        self.rulerShowTolerance = bool(int(v)) if v != '' else True
        self.config.SetPath('/')

    def _SaveRulerModeButtons(self):
        self.config.SetPath('/App')
        self.config.Write('rulerModeButtons', getattr(self, 'rulerModeButtons', 'icons'))
        self.config.Write('rulerOptionsLayout', getattr(self, 'rulerOptionsLayout', 'inline'))
        self.config.Write('rulerTolerance', str(getattr(self, 'rulerTolerance', 30)))
        self.config.Write('rulerShowTolerance',
                          '1' if getattr(self, 'rulerShowTolerance', True) else '0')
        self.config.SetPath('/')

    def SaveRulerTolerance(self):
        """Salva subito la sola tolleranza del righello (chiamato alla
        chiusura del righello, se il valore e' stato cambiato nella barra)."""
        self.config.SetPath('/App')
        self.config.Write('rulerTolerance', str(getattr(self, 'rulerTolerance', 30)))
        self.config.SetPath('/')
        self.config.Flush()

    def _SavePrintOptions(self):
        self.config.SetPath('/Print')
        self.config.Write('showPrintPreview', '1' if getattr(self, 'showPrintPreview', True) else '0')
        self.config.Write('printPreviewAlwaysOnTop', '1' if getattr(self, 'printPreviewAlwaysOnTop', False) else '0')
        self.config.SetPath('/')

    def _SaveMultiCursor(self):
        self.config.SetPath('/Editor')
        self.config.Write('multiCursor', '1' if getattr(self, 'multiCursor', False) else '0')
        self.config.SetPath('/')

    def _SaveColourPreview(self):
        self.config.SetPath('/Editor')
        self.config.Write('colourPreview', '1' if getattr(self, 'colourPreview', True) else '0')
        self.config.SetPath('/')

    def _SaveTempoIconSize(self):
        self.config.SetPath('/Format')
        self.config.Write('tempoIconSize', str(getattr(self, 'tempoIconSize', 24)))
        self.config.SetPath('/')

    def _SaveTempoIconColour(self):
        self.config.SetPath('/Format')
        self.config.Write('TempoIconColour', getattr(self, 'tempoIconColourHex', '#000000'))
        self.config.SetPath('/')

    def _SaveWindowGeometryPref(self):
        self.config.SetPath('/App')
        self.config.Write('saveWindowGeometry', '1' if getattr(self, 'saveWindowGeometry', True) else '0')
        self.config.SetPath('/')

    def _SavePreviewOptions(self):
        self.config.SetPath('/Preview')
        self.config.Write('showPageIndicator', '1' if getattr(self, 'showPageIndicator', True) else '0')
        self.config.Write('greyBackground',    '1' if getattr(self, 'greyBackground',    True) else '0')
        self.config.Write('debounceRefresh',   '1' if getattr(self, 'debounceRefresh',   True) else '0')
        self.config.Write('dblClickFocus',     '1' if getattr(self, 'dblClickFocus',     True) else '0')
        self.config.Write('previewMinSize',    '1' if getattr(self, 'previewMinSize',    True) else '0')
        self.config.Write('guideViewer',           getattr(self, 'guideViewer', 'auto'))
        self.config.Write('liveDriverPoll',        '1' if getattr(self, 'liveDriverPoll', True) else '0')
        self.config.SetPath('/')

    def _SaveWatermarkPrefs(self):
        """Salva SOLO opacita', angolo, dimensione, colore e mosaico (Affianca).
        Non tocca 'enabled', 'text' e 'showInPreview' (per-documento)."""
        ws = getattr(self, 'watermarkStyle', {})
        self.config.SetPath('/Watermark')
        self.config.Write('opacity',   str(int(ws.get('opacity',   12))))
        self.config.Write('angle',     str(int(ws.get('angle',     45))))
        self.config.Write('sizePct',   str(int(ws.get('sizePct',   100))))
        self.config.Write('colourHex',     str(ws.get('colourHex', '#000000')))
        self.config.Write('tile', '1' if ws.get('tile', False) else '0')
        self.config.SetPath('/')

    def _SaveGridDisplayMode(self):
        self.config.SetPath('/Format')
        self.config.Write('gridDisplayMode', getattr(self, 'gridDisplayMode', 'pipe'))
        self.config.Write('gridDefaultLabel', getattr(self, 'gridDefaultLabel', _("Grid")))
        self.config.Write('gridSpaceAsPipe', '1' if getattr(self, 'gridSpaceAsPipe', True) else '0')
        self.config.Write('gridSizeDir', getattr(self, 'gridSizeDir', 'both'))
        self.config.SetPath('/')

    def _LoadDurationBeats(self):
        self.config.SetPath('/Format')
        v = self.config.Read('durationBeatsColourHex')
        self.durationBeatsColourHex = v if v else '#6464C8'
        v2 = self.config.Read('durationBeatsSizePct')
        try:
            self.durationBeatsSizePct = max(30, min(int(v2), 150)) if v2 != '' else 60
        except ValueError:
            self.durationBeatsSizePct = 60
        v3 = self.config.Read('durationBeatsBold')
        self.durationBeatsBold = bool(int(v3)) if v3 != '' else False
        v4 = self.config.Read('durationBeatsAlign')
        self.durationBeatsAlign = v4 if v4 in ('left', 'center', 'right') else 'right'
        v5 = self.config.Read('durationBeatsMode')
        self.durationBeatsMode = v5 if v5 in ('number', 'dots', 'both') else 'number'
        self.config.SetPath('/')

    def _LoadMusicalSymbol(self):
        self.config.SetPath('/MusicalSymbol')
        v = self.config.Read('scaleEnabled')
        self.symbolScaleEnabled = bool(int(v)) if v != '' else False
        v2 = self.config.Read('fontSize')
        try:
            self.symbolFontSize = max(6, min(int(v2), 144)) if v2 != '' else 24
        except ValueError:
            self.symbolFontSize = 24
        v3 = self.config.Read('insertVerse')
        self.symbolInsertVerse = bool(int(v3)) if v3 != '' else False
        self.config.SetPath('/')

    def _SaveDurationBeats(self):
        self.config.SetPath('/Format')
        self.config.Write('durationBeatsColourHex', getattr(self, 'durationBeatsColourHex', '#6464C8'))
        self.config.Write('durationBeatsSizePct',   str(getattr(self, 'durationBeatsSizePct', 60)))
        self.config.Write('durationBeatsBold',      '1' if getattr(self, 'durationBeatsBold', False) else '0')
        self.config.Write('durationBeatsAlign',     getattr(self, 'durationBeatsAlign', 'right'))
        self.config.Write('durationBeatsMode',      getattr(self, 'durationBeatsMode', 'number'))
        self.config.SetPath('/')

    def _SaveMusicalSymbol(self):
        self.config.SetPath('/MusicalSymbol')
        self.config.Write('scaleEnabled', '1' if getattr(self, 'symbolScaleEnabled', False) else '0')
        self.config.Write('fontSize', str(getattr(self, 'symbolFontSize', 24)))
        self.config.Write('insertVerse', '1' if getattr(self, 'symbolInsertVerse', False) else '0')
        self.config.SetPath('/')

    # Abbassamento verticale del simbolo SMP, in percentuale (0-100).
    # Stessi percorso/chiave usati da SongDecorator (_SMP_VALIGN_CFG_*) e, in
    # precedenza, da MusicalSymbolDialog: il renderer legge /Rendering/smp_valign_offset_pct
    # per far scendere i simboli SMP e allinearli alla riga di testo.
    _SMP_VALIGN_CFG_PATH = '/Rendering'
    _SMP_VALIGN_CFG_KEY  = 'smp_valign_offset_pct'   # ritocco fine (anche negativo)
    _SMP_VALIGN_DEFAULT  = 5
    _SMP_VALIGN_MIN      = 0
    _SMP_VALIGN_MAX      = 25

    def _LoadSmpValign(self):
        self.config.SetPath(self._SMP_VALIGN_CFG_PATH)
        try:
            v = self.config.ReadInt(self._SMP_VALIGN_CFG_KEY, self._SMP_VALIGN_DEFAULT)
        except Exception:
            v = self._SMP_VALIGN_DEFAULT
        self.symbolValignPct = max(self._SMP_VALIGN_MIN, min(int(v), self._SMP_VALIGN_MAX))
        self.config.SetPath('/')

    def _SaveSmpValign(self):
        self.config.SetPath(self._SMP_VALIGN_CFG_PATH)
        self.config.WriteInt(
            self._SMP_VALIGN_CFG_KEY,
            max(self._SMP_VALIGN_MIN, min(int(getattr(self, 'symbolValignPct', self._SMP_VALIGN_DEFAULT)), self._SMP_VALIGN_MAX)),
        )
        self.config.SetPath('/')

    # Sovracampionamento del glifo SMP in anteprima (SOLO Linux/wxGTK). Su Linux
    # i simboli SMP a schermo passano da una bitmap e possono apparire sgranati;
    # questo valore è il fattore MINIMO di sovracampionamento della sorgente
    # (1 = nessuno, 3 = consigliato/default, 4 = massimo). Su Windows/macOS il
    # glifo è vettoriale e l'impostazione non ha effetto. Stessi percorso/chiave
    # letti da SongDecorator (_SMP_OVERSAMPLE_CFG_*).
    _SMP_OVERSAMPLE_CFG_PATH = '/Rendering'
    _SMP_OVERSAMPLE_CFG_KEY  = 'smp_oversample'
    _SMP_OVERSAMPLE_DEFAULT  = 3
    _SMP_OVERSAMPLE_MIN      = 1
    _SMP_OVERSAMPLE_MAX      = 4

    def _LoadSmpOversample(self):
        self.config.SetPath(self._SMP_OVERSAMPLE_CFG_PATH)
        try:
            v = self.config.ReadInt(self._SMP_OVERSAMPLE_CFG_KEY, self._SMP_OVERSAMPLE_DEFAULT)
        except Exception:
            v = self._SMP_OVERSAMPLE_DEFAULT
        self.symbolOversample = max(self._SMP_OVERSAMPLE_MIN, min(int(v), self._SMP_OVERSAMPLE_MAX))
        self.config.SetPath('/')

    def _SaveSmpOversample(self):
        self.config.SetPath(self._SMP_OVERSAMPLE_CFG_PATH)
        self.config.WriteInt(
            self._SMP_OVERSAMPLE_CFG_KEY,
            max(self._SMP_OVERSAMPLE_MIN, min(int(getattr(self, 'symbolOversample', self._SMP_OVERSAMPLE_DEFAULT)), self._SMP_OVERSAMPLE_MAX)),
        )
        self.config.SetPath('/')

    def _LoadChordArrow(self):
        self.config.SetPath('/Rendering')
        try:
            v = self.config.ReadInt('chord_arrow_size_pct', 90)
        except Exception:
            v = 90
        self.chordArrowSizePct = max(30, min(int(v), 150))
        # Posizione della freccia: accanto al nome dell'accordo ('chord', default)
        # oppure accanto al numero dei battiti di {beats_time} ('beats').
        p = (self.config.Read('chord_arrow_pos') or '').strip()
        self.chordArrowPos = p if p in ('chord', 'beats') else 'chord'
        old = (self.config.Read('chord_arrow_colour') or '').strip()   # compat. versione precedente
        for name, key, default in (('Up', 'chord_arrow_up_colour', old),
                                   ('Down', 'chord_arrow_down_colour', old)):
            if self.config.HasEntry(key):
                h = (self.config.Read(key) or '').strip()
            else:
                h = default
            setattr(self, 'chordArrow%sColourHex' % name, h)
        self.config.SetPath('/')

    def _SaveChordArrow(self):
        self.config.SetPath('/Rendering')
        self.config.WriteInt('chord_arrow_size_pct', max(30, min(int(getattr(self, 'chordArrowSizePct', 90)), 150)))
        _pos = getattr(self, 'chordArrowPos', 'chord')
        self.config.Write('chord_arrow_pos', _pos if _pos in ('chord', 'beats') else 'chord')
        self.config.Write('chord_arrow_up_colour', getattr(self, 'chordArrowUpColourHex', '') or '')
        self.config.Write('chord_arrow_down_colour', getattr(self, 'chordArrowDownColourHex', '') or '')
        self.config.SetPath('/')

    def _LoadDecoSliderColour(self):
        self.config.SetPath('/DecoSlider')
        h = self.config.Read('barColourHex')
        self.decoSliderBarColourHex = h if h else '#2980B9'
        self.config.SetPath('/')

    def _SaveDecoSliderColour(self):
        self.config.SetPath('/DecoSlider')
        self.config.Write('barColourHex', getattr(self, 'decoSliderBarColourHex', '#2980B9'))
        self.config.SetPath('/')

    def _LoadNoChordHide(self):
        self.config.SetPath('/Format')
        def _rb(key, default):
            v = self.config.Read(key)
            return bool(int(v)) if v != '' else default
        self.hideIntroChord = _rb('hideIntroChord', False)
        self.hideBridge     = _rb('hideBridge',     False)
        self.hideGrid       = _rb('hideGrid',        False)
        self.hideTempo      = _rb('hideTempo',       False)
        self.hideTime       = _rb('hideTime',        False)
        self.hideRestSymbol = _rb('hideRestSymbol',  False)
        self.hideImage      = _rb('hideImage',       False)
        self.hideTransposerImage = _rb('hideTransposerImage', False)
        self.hideFingering  = _rb('hideFingering',  False)
        self.hideTaste      = _rb('hideTaste',      False)
        self.hideDefine     = _rb('hideDefine',     False)
        self.config.SetPath('/')

    def _SaveNoChordHide(self):
        self.config.SetPath('/Format')
        self.config.Write('hideIntroChord', '1' if getattr(self, 'hideIntroChord', False) else '0')
        self.config.Write('hideBridge',     '1' if getattr(self, 'hideBridge',     False) else '0')
        self.config.Write('hideGrid',        '1' if getattr(self, 'hideGrid',        False) else '0')
        self.config.Write('hideTempo',       '1' if getattr(self, 'hideTempo',       False) else '0')
        self.config.Write('hideTime',        '1' if getattr(self, 'hideTime',        False) else '0')
        self.config.Write('hideRestSymbol',  '1' if getattr(self, 'hideRestSymbol',  False) else '0')
        self.config.Write('hideImage',       '1' if getattr(self, 'hideImage',       False) else '0')
        self.config.Write('hideTransposerImage', '1' if getattr(self, 'hideTransposerImage', False) else '0')
        self.config.Write('hideFingering',  '1' if getattr(self, 'hideFingering',  False) else '0')
        self.config.Write('hideTaste',      '1' if getattr(self, 'hideTaste',      False) else '0')
        self.config.Write('hideDefine',     '1' if getattr(self, 'hideDefine',     False) else '0')
        self.config.SetPath('/')

    def _LoadSaveOnModified(self):
        self.config.SetPath('/App')
        v = self.config.Read('enableSaveOnModified')
        self.enableSaveOnModified = bool(int(v)) if v != '' else True
        self.config.SetPath('/')

    def _SaveSaveOnModified(self):
        self.config.SetPath('/App')
        self.config.Write('enableSaveOnModified', '1' if getattr(self, 'enableSaveOnModified', True) else '0')
        self.config.SetPath('/')

    def _LoadIntegrateChordsOnlyWhenNeeded(self):
        """Se True (default) il comando 'Integra accordi' e' attivo solo quando
        il cursore e' su una riga di accordi in formato tab seguita da una riga
        di testo; se False e' sempre attivo."""
        self.config.SetPath('/Editor')
        v = self.config.Read('integrateChordsOnlyWhenNeeded')
        self.integrateChordsOnlyWhenNeeded = bool(int(v)) if v != '' else True
        self.config.SetPath('/')

    def _SaveIntegrateChordsOnlyWhenNeeded(self):
        self.config.SetPath('/Editor')
        self.config.Write('integrateChordsOnlyWhenNeeded', '1' if getattr(self, 'integrateChordsOnlyWhenNeeded', True) else '0')
        self.config.SetPath('/')

    def _LoadPasteChordsOnlyWhenNeeded(self):
        """Se True (default) il comando 'Incolla accordi' e' attivo solo quando
        negli appunti ci sono accordi; se False e' sempre attivo."""
        self.config.SetPath('/Editor')
        v = self.config.Read('pasteChordsOnlyWhenNeeded')
        self.pasteChordsOnlyWhenNeeded = bool(int(v)) if v != '' else True
        self.config.SetPath('/')

    def _SavePasteChordsOnlyWhenNeeded(self):
        self.config.SetPath('/Editor')
        self.config.Write('pasteChordsOnlyWhenNeeded', '1' if getattr(self, 'pasteChordsOnlyWhenNeeded', True) else '0')
        self.config.SetPath('/')

    def _LoadReplaceSpacesInFilenames(self):
        self.config.SetPath('/App')
        v = self.config.Read('replaceSpacesInFilenames')
        self.replaceSpacesInFilenames = bool(int(v)) if v != '' else False
        self.config.SetPath('/')

    def _SaveReplaceSpacesInFilenames(self):
        self.config.SetPath('/App')
        self.config.Write('replaceSpacesInFilenames', '1' if getattr(self, 'replaceSpacesInFilenames', False) else '0')
        self.config.SetPath('/')

    def _LoadSuggestTitleAsFilename(self):
        self.config.SetPath('/App')
        v = self.config.Read('suggestTitleAsFilename')
        self.suggestTitleAsFilename = bool(int(v)) if v != '' else False
        self.config.SetPath('/')

    def _SaveSuggestTitleAsFilename(self):
        self.config.SetPath('/App')
        self.config.Write('suggestTitleAsFilename', '1' if getattr(self, 'suggestTitleAsFilename', False) else '0')
        self.config.SetPath('/')

    def _LoadToolbarVis(self):
        """Carica la visibilità delle icone delle quattro toolbar dal config.

        Le chiavi seguono il prefisso del gruppo:
          tbm_*  →  Standard toolbar
          tbf_*  →  Format toolbar
          tbv_*  →  View toolbar
          tb_*   →  Insert toolbar
        Il default per tutte le voci è True (icona visibile).
        """
        self.config.SetPath('/ToolbarVis')
        def _rb(key):
            v = self.config.Read(key)
            return bool(int(v)) if v != '' else True
        # Standard toolbar
        self.tbm_new           = _rb('tbm_new')
        self.tbm_open          = _rb('tbm_open')
        self.tbm_save          = _rb('tbm_save')
        self.tbm_printPreview  = _rb('tbm_printPreview')
        self.tbm_print         = _rb('tbm_print')
        self.tbm_undo          = _rb('tbm_undo')
        self.tbm_redo          = _rb('tbm_redo')
        self.tbm_cut           = _rb('tbm_cut')
        self.tbm_copy          = _rb('tbm_copy')
        self.tbm_copyAsImage   = _rb('tbm_copyAsImage')
        self.tbm_paste         = _rb('tbm_paste')
        self.tbm_pasteChords   = _rb('tbm_pasteChords')
        self.tbm_syntaxCheck   = _rb('tbm_syntaxCheck')
        self.tbm_readOnly      = _rb('tbm_readOnly')
        self.tbm_options       = _rb('tbm_options')
        # Format toolbar
        self.tbf_fontChooser      = _rb('tbf_fontChooser')
        self.tbf_showChords       = _rb('tbf_showChords')
        self.tbf_insertLinespacing = _rb('tbf_insertLinespacing')
        # View toolbar
        self.tbv_preview     = _rb('tbv_preview')
        self.tbv_labelVerses = _rb('tbv_labelVerses')
        self.tbv_hoverHelp   = _rb('tbv_hoverHelp')
        self.tbv_pageBreakLines   = _rb('tbv_pageBreakLines')
        self.tbv_columnBreakLines = _rb('tbv_columnBreakLines')
        self.tbv_durationBeats    = _rb('tbv_durationBeats')
        self.tbv_arrows           = _rb('tbv_arrows')
        self.tbv_comments         = _rb('tbv_comments')
        # Insert toolbar
        self.tb_title               = _rb('tb_title')
        self.tb_subtitle            = _rb('tb_subtitle')
        self.tb_artist              = _rb('tb_artist')
        self.tb_composer            = _rb('tb_composer')
        self.tb_album               = _rb('tb_album')
        self.tb_copyright           = _rb('tb_copyright')
        self.tb_chord               = _rb('tb_chord')
        self.tb_chorus              = _rb('tb_chorus')
        self.tb_verse               = _rb('tb_verse')
        self.tb_comment             = _rb('tb_comment')
        self.tb_pageBreak           = _rb('tb_pageBreak')
        self.tb_columnBreak         = _rb('tb_columnBreak')
        self.tb_insertVerse         = _rb('tb_insertVerse')
        self.tb_insertVerseNum      = _rb('tb_insertVerseNum')
        self.tb_insertChorusBlock   = _rb('tb_insertChorusBlock')
        self.tb_insertChordBlock    = _rb('tb_insertChordBlock')
        self.tb_insertBridge        = _rb('tb_insertBridge')
        self.tb_insertGrid          = _rb('tb_insertGrid')
        self.tb_insertTempo         = _rb('tb_insertTempo')
        self.tb_insertTempoLabel    = _rb('tb_insertTempoLabel')
        self.tb_insertTime          = _rb('tb_insertTime')
        self.tb_insertKey           = _rb('tb_insertKey')
        self.tb_insertDuration      = _rb('tb_insertDuration')
        self.tb_insertTaste         = _rb('tb_insertTaste')
        self.tb_insertFingering     = _rb('tb_insertFingering')
        self.tb_insertDefine        = _rb('tb_insertDefine')
        self.tb_insertImage         = _rb('tb_insertImage')
        self.tb_insertTransposerImage = _rb('tb_insertTransposerImage')
        self.tb_insertMusicalSymbol = _rb('tb_insertMusicalSymbol')
        self.config.SetPath('/')

    def _SaveToolbarVis(self):
        """Salva la visibilità delle icone delle quattro toolbar nel config."""
        self.config.SetPath('/ToolbarVis')
        def _w(key):
            self.config.Write(key, '1' if getattr(self, key, True) else '0')
        # Standard toolbar
        _w('tbm_new');          _w('tbm_open');         _w('tbm_save')
        _w('tbm_printPreview'); _w('tbm_print')
        _w('tbm_undo');         _w('tbm_redo')
        _w('tbm_cut');          _w('tbm_copy');         _w('tbm_copyAsImage')
        _w('tbm_paste');        _w('tbm_pasteChords')
        _w('tbm_syntaxCheck');  _w('tbm_readOnly');  _w('tbm_options')
        # Format toolbar
        _w('tbf_fontChooser'); _w('tbf_showChords'); _w('tbf_insertLinespacing')
        # View toolbar
        _w('tbv_preview'); _w('tbv_labelVerses'); _w('tbv_hoverHelp')
        _w('tbv_pageBreakLines'); _w('tbv_columnBreakLines')
        _w('tbv_durationBeats');  _w('tbv_arrows');  _w('tbv_comments')
        # Insert toolbar
        _w('tb_title');             _w('tb_subtitle')
        _w('tb_artist');            _w('tb_composer');          _w('tb_album');             _w('tb_copyright')
        _w('tb_chord');             _w('tb_chorus')
        _w('tb_verse');             _w('tb_comment')
        _w('tb_pageBreak');         _w('tb_columnBreak')
        _w('tb_insertVerse');       _w('tb_insertVerseNum')
        _w('tb_insertChorusBlock'); _w('tb_insertChordBlock')
        _w('tb_insertBridge');      _w('tb_insertGrid')
        _w('tb_insertTempo');       _w('tb_insertTempoLabel')
        _w('tb_insertTime');        _w('tb_insertKey')
        _w('tb_insertDuration')
        _w('tb_insertTaste');       _w('tb_insertFingering')
        _w('tb_insertDefine')
        _w('tb_insertImage');       _w('tb_insertTransposerImage')
        _w('tb_insertMusicalSymbol')
        self.config.SetPath('/')

    def _LoadToolbarIconSize(self):
        """Carica la dimensione delle icone toolbar: 'small' (16px), 'medium' (19px), 'large' (21px) o 'xlarge' (32px)."""
        self.config.SetPath('/ToolbarVis')
        v = self.config.Read('toolbarIconSize')
        self.toolbarIconSize = v if v in ('small', 'medium', 'large', 'xlarge') else 'small'
        self.config.SetPath('/')

    def _SaveToolbarIconSize(self):
        self.config.SetPath('/ToolbarVis')
        self.config.Write('toolbarIconSize', getattr(self, 'toolbarIconSize', 'small'))
        self.config.SetPath('/')

    @property
    def toolbarIconPx(self):
        """Restituisce la dimensione in pixel delle icone toolbar (16, 19 o 21)."""
        sz = getattr(self, 'toolbarIconSize', 'small')
        if sz == 'medium':
            return 19
        if sz == 'large':
            return 21
        if sz == 'xlarge':
            return 32
        return 16

    def SanitizeFilename(self, path):
        """Se l'opzione 'replaceSpacesInFilenames' è attiva, sostituisce ogni
        spazio bianco nel nome del file (non nella cartella) con '_'.
        Funziona allo stesso modo su Windows e Linux, perché opera solo
        sulla stringa del nome file, senza toccare i separatori di percorso.
        """
        if not path:
            return path
        if not getattr(self, 'replaceSpacesInFilenames', False):
            return path
        directory, filename = os.path.split(path)
        filename = re.sub(r'\s+', '_', filename)
        return os.path.join(directory, filename) if directory else filename

    # Caratteri non ammessi nei nomi file (unione di Windows e POSIX)
    _INVALID_FILENAME_CHARS = re.compile(r'[<>:"/\\|?*\x00-\x1f]')

    def ExtractTitle(self, text):
        """Estrae il valore della direttiva {title: ...} (o {t: ...}) dal testo
        della canzone. Restituisce una stringa vuota se non presente.

        Regole:
          * le righe che iniziano con '#' sono commenti ChordPro e vengono ignorate;
          * la direttiva può essere scritta {title:X}, {t:X}, { Title : X };
          * se manca la '}' di chiusura, si prende il resto della riga;
          * eventuali accordi inline [Do] presenti nel titolo vengono rimossi.
        """
        if not text:
            return ''
        rx = re.compile(r'\{\s*(?:title|t)\s*:([^}\n]*)(?:\}|$)', re.IGNORECASE)
        for line in text.splitlines():
            stripped = line.lstrip()
            if stripped.startswith('#'):
                continue  # riga di commento: la direttiva non è attiva
            m = rx.search(stripped)
            if m:
                title = re.sub(r'\[[^\]]*\]', '', m.group(1))  # via gli accordi
                title = title.strip()
                if title:
                    return title
        return ''

    def SuggestFilenameFromTitle(self, text, default=''):
        """Restituisce il nome file (senza estensione) suggerito nella finestra
        'Salva con nome', basato sulla direttiva {title:} del brano.

        Se l'opzione 'suggestTitleAsFilename' è disattivata, oppure il titolo
        non è presente/è vuoto, restituisce `default`.

        Nota: NON entra in conflitto con 'replaceSpacesInFilenames'; le due
        opzioni sono complementari e si compongono. Questa funzione produce il
        nome, SanitizeFilename() decide se gli spazi diventano '_'.
        """
        if not getattr(self, 'suggestTitleAsFilename', False):
            return default
        title = self.ExtractTitle(text)
        if not title:
            return default
        # Rimuove i caratteri non validi e normalizza gli spazi
        name = self._INVALID_FILENAME_CHARS.sub('', title)
        name = re.sub(r'\s+', ' ', name).strip().strip('.')
        if not name:
            return default
        # Applica l'eventuale sostituzione spazi -> '_' (opzione indipendente)
        return self.SanitizeFilename(name)

    def SetChorusLabel(self, c):
        self.chorusLabel = c
        self.decoratorFormat.SetChorusLabel(c)

    def SetChordsPosition(self, position):
        """Set chords position: 'above' or 'below'."""
        if position in ('above', 'below'):
            self.chordsPosition = position

    def SetDefaultNotation(self, notation):
        self.defaultNotation = notation
        self.notations = [x for x in self.notations if x.id == notation] + [x for x in self.notations if x.id != notation]

    def SetEasyChordsGroup(self, group, level):
        self.easyChordsGroup[group] = level
        self.easyChords = None

    def GetEasyChordsGroup(self, group):
        return self.easyChordsGroup[group]

    def GetEasyChords(self):
        if self.easyChords is None:
            self.easyChords = {'Eb': -1}
            for k in easyChords:
                chords = easyChords[k][1]
                l = self.easyChordsGroup[k] / 4.0
                for c in chords:
                    if c in self.easyChords:
                        self.easyChords[c] = max(self.easyChords[c], l)
                    else:
                        self.easyChords[c] = l

        return self.easyChords

    def _LoadSingleInstance(self):
        self.config.SetPath('/App')
        v = self.config.Read('singleInstance')
        self.singleInstance = bool(int(v)) if v != '' else True
        self.config.SetPath('/')

    def _SaveSingleInstance(self):
        self.config.SetPath('/App')
        self.config.Write('singleInstance', '1' if getattr(self, 'singleInstance', True) else '0')
        self.config.SetPath('/')

    def _LoadShowRestartMenuItem(self):
        self.config.SetPath('/App')
        v = self.config.Read('showRestartMenuItem')
        self.showRestartMenuItem = bool(int(v)) if v != '' else True
        self.config.SetPath('/')

    def _SaveShowRestartMenuItem(self):
        self.config.SetPath('/App')
        self.config.Write('showRestartMenuItem', '1' if getattr(self, 'showRestartMenuItem', True) else '0')
        self.config.SetPath('/')

    def _LoadShowFullPathInTitle(self):
        self.config.SetPath('/App')
        v = self.config.Read('showFullPathInTitle')
        # Default False: nella barra del titolo si mostra solo il nome del file,
        # come prima. Se True viene mostrato il percorso completo.
        self.showFullPathInTitle = bool(int(v)) if v != '' else False
        self.config.SetPath('/')

    def _SaveShowFullPathInTitle(self):
        self.config.SetPath('/App')
        self.config.Write('showFullPathInTitle', '1' if getattr(self, 'showFullPathInTitle', False) else '0')
        self.config.SetPath('/')

    # ── Esporta / Importa le opzioni ─────────────────────────────────────
    # Le opzioni vivono in wx.Config (registro di Windows, file su Linux).
    # L'esportazione le copia TUTTE in un file JSON leggibile, senza elenco
    # fisso di chiavi: le opzioni aggiunte in futuro vengono incluse da sole.
    # Restano fuori le sezioni legate alla macchina o alla sessione
    # (posizione/dimensione finestre, layout, file recenti, ecc.) e quelle
    # che il programma riscrive per conto proprio alla chiusura.
    EXPORT_FORMAT_ID = 'songpress-preferences'
    EXPORT_FORMAT_VERSION = 1
    _EXPORT_SKIP_TOP = ('Window', 'SDIMainFrame', 'TempoDisplay', 'TimeDisplay',
                        'KeyDisplay', 'GuidePrefs', 'Transposer')

    def _ExportSkip(self, path):
        parts = path.split('/')
        # path assoluto 'a/b/c' -> ['', 'a', 'b', 'c']; le voci direttamente
        # nella radice (storico file recenti, ecc.) non si esportano
        if len(parts) < 3 or '..' in parts or not parts[-1]:
            return True
        top = parts[1]
        return top in self._EXPORT_SKIP_TOP or top.startswith('CustomColours')

    def _CollectConfig(self, group='/'):
        cfg = self.config
        out = []
        old = cfg.GetPath()
        try:
            cfg.SetPath(group)
            entries, groups = [], []
            more, name, idx = cfg.GetFirstEntry()
            while more:
                entries.append(name)
                more, name, idx = cfg.GetNextEntry(idx)
            more, name, idx = cfg.GetFirstGroup()
            while more:
                groups.append(name)
                more, name, idx = cfg.GetNextGroup(idx)
            base = group.rstrip('/')
            for n in entries:
                full = base + '/' + n
                if self._ExportSkip(full):
                    continue
                if cfg.GetEntryType(n) == wx.ConfigBase.Type_Integer:
                    out.append([full, 'int', int(cfg.ReadInt(n))])
                else:
                    out.append([full, 'str', cfg.Read(n)])
            for g in groups:
                gp = base + '/' + g
                if gp.count('/') == 1 and (g in self._EXPORT_SKIP_TOP
                                           or g.startswith('CustomColours')):
                    continue
                out.extend(self._CollectConfig(gp))
        finally:
            cfg.SetPath(old)
        return out

    def ExportToFile(self, path):
        """Scrive tutte le opzioni salvate in un file JSON. Ritorna il numero
        di voci esportate."""
        entries = sorted(self._CollectConfig('/'), key=lambda e: e[0])
        data = {
            'format': self.EXPORT_FORMAT_ID,
            'version': self.EXPORT_FORMAT_VERSION,
            'entries': entries,
        }
        with open(path, 'w', encoding='utf-8') as f:
            json.dump(data, f, ensure_ascii=False, indent=1)
        return len(entries)

    def ImportFromFile(self, path):
        """Legge un file creato da ExportToFile, scrive le voci in wx.Config e
        ricarica le opzioni. Ritorna il numero di voci importate; solleva
        ValueError se il file non e' valido (in tal caso non cambia nulla)."""
        try:
            with open(path, 'r', encoding='utf-8') as f:
                data = json.load(f)
        except (OSError, ValueError) as e:
            raise ValueError(str(e))
        if (not isinstance(data, dict)
                or data.get('format') != self.EXPORT_FORMAT_ID
                or not isinstance(data.get('entries'), list)):
            raise ValueError(_("This is not a Songpress++ preferences file."))
        todo = []
        for e in data['entries']:
            if (not isinstance(e, list) or len(e) != 3
                    or not isinstance(e[0], str) or e[1] not in ('int', 'str')):
                continue
            if self._ExportSkip(e[0]):
                continue
            try:
                v = int(e[2]) if e[1] == 'int' else str(e[2])
            except (TypeError, ValueError):
                continue
            todo.append((e[0], e[1], v))
        if not todo:
            raise ValueError(_("The file contains no preferences."))
        cfg = self.config
        for full, t, v in todo:
            group, name = full.rsplit('/', 1)
            cfg.SetPath(group or '/')
            if t == 'int':
                cfg.WriteInt(name, v)
            else:
                cfg.Write(name, v)
        cfg.SetPath('/')
        cfg.Flush()
        self.Load()
        return len(todo)
