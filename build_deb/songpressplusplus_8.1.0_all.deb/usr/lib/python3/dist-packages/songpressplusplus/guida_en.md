# Quick Guide — Songpress++

This guide describes all ChordPro commands supported by Songpress++ and the main editor features.

> **Legend** — The **Std** column indicates whether the directive is part of the official ChordPro standard (✅) or is specific to Songpress++ (🔧). The **Menu** column indicates whether the directive can be inserted via an application menu (⌨️) or must be typed manually in the editor (🖊).

> **Tooltips** — Every checkbox in the preferences dialogs has a **descriptive tooltip**: hold the mouse pointer still over a checkbox for a moment and a short explanation of the corresponding option will appear.

---

## ChordPro Format — Basic Concepts

A ChordPro file is a text file where **chords** are inserted directly in the song text, enclosed in square brackets `[chord]`. Metadata and structure **directives** are enclosed in curly braces `{directive:value}`.

```chordpro
{title: Amazing Grace}
{artist: Traditional}
{key: G}

[G]Amazing [G7]grace, how [C]sweet the [G]sound
```

### How to type `{` and `}` on the keyboard

| System | `{` (opening brace) | `}` (closing brace) |
| ------ | ------------------- | ------------------- |
| **Windows / Linux** — Italian layout | <kbd>Alt Gr</kbd> + <kbd>Shift</kbd> + <kbd>[</kbd> | <kbd>Alt Gr</kbd> + <kbd>Shift</kbd> + <kbd>]</kbd> |
| **Windows / Linux** — US layout | <kbd>Shift</kbd> + <kbd>[</kbd> | <kbd>Shift</kbd> + <kbd>]</kbd> |
| **Mac** — Italian layout | <kbd>Option</kbd> + <kbd>Shift</kbd> + <kbd>[</kbd> | <kbd>Option</kbd> + <kbd>Shift</kbd> + <kbd>]</kbd> |
| **Mac** — US layout | <kbd>Option</kbd> + <kbd>[</kbd> | <kbd>Option</kbd> + <kbd>]</kbd> |
| **Windows** — ASCII code (any layout) | <kbd>Alt</kbd> + <kbd>1</kbd><kbd>2</kbd><kbd>3</kbd> | <kbd>Alt</kbd> + <kbd>1</kbd><kbd>2</kbd><kbd>5</kbd> |

> **Note on the ASCII method** — Hold <kbd>Alt</kbd>, type the number on the numeric keypad (not the digit row at the top of the keyboard), then release <kbd>Alt</kbd>. Works on Windows only.

> **Tip — Intellisense** — In Songpress++ you can use autocomplete: type `{` followed by the first letters of the directive and press <kbd>Ctrl</kbd>+<kbd>Space</kbd> to open the completion menu. The directive will be inserted complete with `:` and `}` where needed. Each entry shows an icon: **✅** marks an official ChordPro directive, **🔧** marks a Songpress++-exclusive extension.

---

## Song Metadata

| Directive           | Alias        | Std | Menu | Description                                                                              |
| ------------------- | ------------ | --- | ---- | ---------------------------------------------------------------------------------------- |
| `{title:Title}`     | `{t:Title}`  | ✅  | ⌨️   | Song title                                                                               |
| `{subtitle:Text}`   | `{st:...}`   | ✅  | ⌨️   | Subtitle or secondary artist                                                             |
| `{artist:Name}`     |              | ✅  | ⌨️   | Artist / performer (rendered as subtitle)                                                |
| `{composer:Name}`   |              | ✅  | ⌨️   | Composer (rendered as subtitle)                                                          |
| `{lyricist:Name}`   |              | ✅  | 🖊    | Lyricist / text author (rendered as «Lyrics: …»)                                         |
| `{arranger:Name}`   |              | ✅  | 🖊    | Arranger (rendered as «Arrangement: …»)                                                  |
| `{album:Title}`     |              | ✅  | ⌨️   | Album title (rendered as «Album: …»)                                                     |
| `{year:Year}`       |              | ✅  | 🖊    | Publication year (rendered as subtitle)                                                  |
| `{copyright:Text}`  |              | ✅  | 🖊    | Copyright notice (rendered as «© …»)                                                     |
| `{key:Key}`         |              | ✅  | ⌨️   | Key (e.g. `Am`, `C`, `G`, `F#m`); rendered as «Key: …» if display is enabled             |
| `{capo:N}`          |              | ✅  | 🖊    | Capo at fret N (e.g. `{capo:2}`); rendered as «Capo: N»                                  |
| `{tempo:BPM[,M]}`   |              | ✅  | ⌨️   | Tempo in BPM; icon and format configurable via *Insert → Tempo* dialog (e.g. `{tempo:120}`). The optional `,M` parameter overrides the display mode for that single command (0=Text, 1=♩, 2=BPM, 3=metronome, -1=hidden) |
| `{tempo_m:BPM}`     |              | 🔧  | 🖊    | Tempo with fixed **half note** icon — independent of the global display mode             |
| `{tempo_s:BPM}`     |              | 🔧  | 🖊    | Tempo with fixed **quarter note** icon                                                   |
| `{tempo_sp:BPM}`    |              | 🔧  | 🖊    | Tempo with fixed **dotted quarter note** icon                                            |
| `{tempo_c:BPM}`     |              | 🔧  | 🖊    | Tempo with fixed **eighth note** icon                                                    |
| `{tempo_cp:BPM}`    |              | 🔧  | 🖊    | Tempo with fixed **dotted eighth note** icon                                             |
| `{tempo_label:Text}` |             | 🔧  | ⌨️   | Textual tempo marking (e.g. `{tempo_label:Andante}`, `{tempo_label:Allegro moderato}`); displayed as text alongside other tempo directives |
| `{time:N/M}`        |              | ✅  | ⌨️   | Time signature (e.g. `{time:4/4}`, `{time:3/4}`); rendered with a graphical time symbol. Inside a verse, chorus or grid it applies only to that block (shown beside the block, under its label) and does not split the block |
| `{beats_time: Ch=N …}` |           | 🔧  | ⌨️   | Beat duration of chords (e.g. `{beats_time: C=2 G=1}`); displays a number, dots, or both above chords (configurable in preferences) |
| `{duration:mm:ss}`  |              | ✅  | 🖊    | Total song duration (e.g. `{duration:12:45}`); not shown in preview or print, but displayed in **Song Statistics** as the actual «Duration» instead of the automatic estimate. Commenting out the line with `#` restores automatic duration calculation. |
| `{sorttitle:Text}`  |              | ✅  | 🖊    | Alternative title used for alphabetical sorting (metadata only, not displayed)           |
| `{keywords:...}`    |              | ✅  | 🖊    | Search keywords (metadata only, not displayed)                                           |
| `{topic:...}`       |              | ✅  | 🖊    | Topic / category (metadata only, not displayed)                                          |
| `{collection:...}`  |              | ✅  | 🖊    | Collection or songbook (metadata only, not displayed)                                    |
| `{language:...}`    |              | ✅  | 🖊    | Language of the lyrics (metadata only, not displayed)                                    |
| `{meta:key value}`  |              | ✅  | 🖊    | Generic free-form metadata (not displayed)                                               |

> **Note on extended metadata** — The directives `{sorttitle}`, `{keywords}`, `{topic}`, `{collection}`, `{language}`, and `{meta}` are recognised and accepted by the parser for compatibility with ChordPro 6 files, but their value is not shown in the preview or in print: they are treated as pure metadata and consumed silently. The `{duration}` directive has a special behaviour: its value is used by the **Song Statistics** feature (see below).

> **Note on tempo** — `{tempo:}` has four display modes selectable in the insert dialog: **Tempo:** (plain text), **♩** (note icon with value `♩ = 120`), **BPM** (text `BPM: 120`), **🎼** (metronome icon with value `🎼 = 120`). Checking *Metadata* treats the value as pure metadata with no visual output. The dialog choice sets the **global mode**; to override it for a single command use the form `{tempo:BPM,M}` (e.g. `{tempo:120,1}`). The `{tempo_m:}`, `{tempo_s:}` etc. variants always display their own fixed icon regardless of this setting. The `{tempo_label:}` directive allows inserting a **textual tempo marking** (e.g. `Andante`, `Allegro moderato`) independently of any numeric BPM value.
>
> **Traditional tempo markings and reference BPM ranges** (♩ = beats per minute):
>
> | Tempo marking | BPM range      |
> | ------------- | -------------- |
> | Largo         | 40 – 60 BPM    |
> | Larghetto     | 60 – 66 BPM    |
> | Adagio        | 66 – 76 BPM    |
> | Andante       | 76 – 108 BPM   |
> | Moderato      | 108 – 120 BPM  |
> | Allegro       | 120 – 168 BPM  |
> | Presto        | 168 – 200 BPM  |
> | Prestissimo   | 200 – 208 BPM  |

> **Note on key (`{key}`)** — The *Insert → Key* dialog lets you insert the `{key:key}` directive in three ways:
>
> - **Manual** — type the key directly in the text field (e.g. `C`, `Am`, `F#m`, `G`). The notation can be English or Italian depending on the notation active in the document.
> - **Auto-detect** — checking *Detect automatically from chords* makes Songpress++ analyse the chords in the current song and calculate the most likely key, showing it immediately in the text field with the number of chords examined (e.g. «✔ Detected: C (from 326 chords)»). The field becomes read-only while this option is active.
> - **Metadata** — checking *Metadata* inserts the key as a hidden metadata value: it does not appear in the preview or in print, but remains available for the transpose function.
>
> **Detection in multi-song files** — When the file contains multiple songs separated by `{new_song}`, the auto-detect analyses **only the current song**: it starts from the cursor position and reads up to the next `{new_song}` (or to the end of the document if the song is the last one). This ensures that chords from other songs do not affect the result.
>
> Key display in the preview can be toggled in *Options → Format → Show key*.

---

## Song Structure

### Text Blocks

| Directive                                 | Std | Menu | Description                                                                                                            |
| ----------------------------------------- | --- | ---- | ---------------------------------------------------------------------------------------------------------------------- |
| `{start_of_verse}`/`{end_of_verse}`       | ✅  | ⌨️   | Automatically numbered verse (same as `{start_verse_num}`)                                                             |
| `{start_verse:Label}`/`{end_verse}`       | 🔧  | ⌨️   | Unnumbered verse with optional label                                                                                   |
| `{start_verse_num}`/`{end_verse_num}`     | 🔧  | ⌨️   | Automatically numbered verse (long form)                                                                               |
| `{sov}`/`{eov}`                           | ✅  | ⌨️   | Abbreviation for `start_of_verse`/`end_of_verse`: automatically numbered verse                                         |
| `{verse:Label}`                           | ✅  | ⌨️   | Opens a verse with a custom label (e.g. `{verse:1}`)                                                                   |
| `{start_of_chorus}`/`{end_of_chorus}`     | ✅  | ⌨️   | Chorus                                                                                                                 |
| `{soc}`/`{eoc}`                           | ✅  | ⌨️   | Abbreviation for `start_of_chorus`/`end_of_chorus`                                                                     |
| `{soc:Label}`                             | ✅  | ⌨️   | Chorus with custom label                                                                                               |
| `{start_chorus:Label}`/`{end_chorus}`     | 🔧  | ⌨️   | Alternative chorus form (with optional label)                                                                          |
| `{start_bridge:Label}`/`{end_bridge}`     | 🔧  | ⌨️   | Bridge with optional label; if omitted, the block has neither label nor number (it is not numbered)                    |
| `{start_of_bridge}`/`{end_of_bridge}`     | ✅  | 🖊    | Standard ChordPro form for bridge; equivalent to `{start_bridge}`/`{end_bridge}`                                       |
| `{sob}`/`{eob}`                           | ✅  | 🖊    | Abbreviation for `start_of_bridge`/`end_of_bridge`                                                                     |
| `{start_chord:Label}`/`{end_chord}`       | 🔧  | ⌨️   | Intro/chord block; defaults to «Intro» if label is omitted                                                             |
| `{start_of_tab}`/`{end_of_tab}`           | ✅  | 🖊    | ASCII tab block; content is rendered in monospace font (Courier New) with the label «Tab»                              |
| `{sot}`/`{eot}`                           | ✅  | 🖊    | Abbreviation for `start_of_tab`/`end_of_tab`                                                                           |
| `{start_of_grid}`/`{end_of_grid}`         | ✅  | ⌨️   | Chord grid block; rendered with the label «Grid»                                                                       |
| `{sog}`/`{eog}`                           | ✅  | 🖊    | Abbreviation for `start_of_grid`/`end_of_grid`                                                                         |
| `{grid}`                                  | ✅  | 🖊    | Alternative form of `start_of_grid` (no explicit closing tag required)                                                 |
| `{row}` / `{r}` *(inside grid)*           | 🔧  | 🖊    | Inserts an empty separator row inside a grid block                                                                     |
| `{bar}` *(inside grid)*                   | ✅  | 🖊    | Explicit bar separator inside a grid block                                                                             |
| `{start_of_part:Label}`/`{end_of_part}`   | ✅  | 🖊    | Generic section (ChordPro 6): rendered as an unnumbered verse with a free label; defaults to «Part» if omitted         |
| `{sop}`/`{eop}`                           | ✅  | 🖊    | Abbreviation for `start_of_part`/`end_of_part`                                                                         |
| `{new_song}`                              | 🔧  | 🖊    | Starts a new song in the same document: resets verse and chorus counters (numbering restarts from 1) and clears the chord-pattern cache used by the *First verse only* filter |

> **Note on bridge** — Both forms are supported: `{start_bridge}`/`{end_bridge}` (Songpress++ form, insertable from the menu) and `{start_of_bridge}`/`{end_of_bridge}` (standard ChordPro form, with abbreviations `{sob}`/`{eob}`). The two forms are equivalent and interchangeable.

### Inserting the Intro/Chord Block — `{start_chord}` / `{end_chord}`

The intro/chord block insertion command opens the **Intro chords label** dialog:

- **Label** — the text field proposes «Intro» as the default value. Confirming with *OK* inserts `{start_chord:Label}`; leaving the field empty inserts `{start_chord}` with no label; pressing *Cancel* aborts the insertion.
- **Use the chords from the first line** — optional checkbox. When selected, the body of the block is **pre-filled with the square-bracket chords `[..]` found in the first line of the document that contains at least one**. The detected chords are shown as a preview (in italics) below the checkbox.

If no line in the document contains square-bracket chords, the checkbox is **disabled** and the preview is replaced by the notice *«no chords found in the first line»*.

With the checkbox off (or when there are no usable chords) the block is inserted empty, with the caret placed inside it:

```chordpro
{start_chord:Intro}
|
{end_chord}
```

With the checkbox on and, for example, `[Am] [F] [G] [C]` in the first usable line, the block is inserted already filled in:

```chordpro
{start_chord:Intro}
[Am] [F] [G] [C]
{end_chord}
```

### Page and Column Breaks

| Directive        | Alias    | Std | Menu | Description                                     |
| ---------------- | -------- | --- | ---- | ----------------------------------------------- |
| `{new_page}`     | `{np}`   | ✅  | ⌨️   | Explicit page break for printing                |
| `{column_break}` | `{colb}` | ✅  | ⌨️   | Column break (two-column layout)                |

---

## Chords and Inline Formatting

### Chords

Chords are inserted in the text with square brackets, immediately before the syllable they belong to:

```chordpro
[Am]In the [F]blue [C]painted [G]blue
```

### Chord Direction Arrow — `[C^]` / `[Cv]`

A small **arrow** can be added to a chord to show whether the chord should be played upwards or downwards. The arrow is written as a suffix inside the square brackets:

| Written | Result |
| ------- | ------ |
| `[C]` | chord without an arrow |
| `[C^]` | chord with an **up** arrow |
| `[Cv]` | chord with a **down** arrow |

```chordpro
[F]thy will be [C^]done in [Amv]me, [G]amen
```

- The chord name stays the normal one (`C`): transposition, syntax check, statistics and `{beats_time:}` work as usual, and the arrow is preserved. Transposing `[C^]` gives, for example, `[D^]`.
- The characters `↑` and `↓` can also be typed instead of `^` and `v`.
- Arrows are not supported inside `{start_of_grid}` cells.
- In the `{beats_time:}` number, alignment takes the width of the arrow into account.
- The arrow can be drawn **next to the chord** (default) or **next to the beat count** of `{beats_time:}`: choose it in *Options → Format → Chords and keyboard → Chord arrow position*. With the second choice, a chord without a visible beat number (no `{beats_time:}`, beats hidden, or *Dots* mode) keeps the arrow next to its name.

**Insertion from the menu.** In the **Insert chord** dialog the **Direction** box offers three choices: *None*, *↑ Up*, *↓ Down* (with tooltips on mouse hover). After each insertion the choice goes back to *None*. The "Uppercase chord" checkbox does not alter the arrow suffix.

**Appearance.** The arrow is drawn as a vector shape, sharp at any zoom, and prints correctly in PDF and print preview too. Size and colours are set in *Options → Format → Chords and keyboard* (see the Options window table).

### Local Fonts and Colors

These directives change the font for the following section; used without an argument they restore the default value.

| Opening directive    | Closing directive  | Std | Menu | Description                                                                    |
| -------------------- | ------------------ | --- | ---- | ------------------------------------------------------------------------------ |
| `{textfont:Name}`    | `{textfont}`       | ✅  | ⌨️   | Text font family                                                               |
| `{textsize:Pt}`      | `{textsize}`       | ✅  | ⌨️   | Text size in pt (also accepts percentage, e.g. `{textsize:80%}`)               |
| `{textcolour:#HEX}`  | `{textcolour}`     | ✅  | ⌨️   | Text color in `#RRGGBB` format                                                 |
| `{chordfont:Name}`   | `{chordfont}`      | ✅  | ⌨️   | Chord font family                                                              |
| `{chordsize:Pt}`     | `{chordsize}`      | ✅  | ⌨️   | Chord size in pt (also accepts percentage)                                     |
| `{chordcolour:#HEX}` | `{chordcolour}`    | ✅  | ⌨️   | Chord color in `#RRGGBB` format                                                |

### Spacing

| Directive             | Std | Menu | Description                                                                                                                    |
| --------------------- | --- | ---- | ------------------------------------------------------------------------------------------------------------------------------ |
| `{linespacing:N}`     | 🔧  | ⌨️   | Line spacing in points (e.g. `{linespacing:1}`); without argument restores the default value                                   |
| `{chordtopspacing:N}` | 🔧  | ⌨️   | Space above chords in points (e.g. `{chordtopspacing:0}` to remove it); without argument restores the default value            |
| `{row}` or `{r}`      | 🔧  | 🖊    | Inserts half a vertical blank line (spacer) outside grid blocks — not available in the menu                                    |
| `{bar}`               | ✅  | 🖊    | Explicit bar separator inside a `{start_of_grid}` block; ignored outside a grid context                                       |

---

## Spacing Directives in Songpress++

---

## `{linespacing: <value>}` — **Menu item:** *Line Spacing*

### Description — linespacing

Sets the **line spacing** between text lines of the song from the point where the directive is inserted. It acts on the overall vertical spacing between one text line (with its chords) and the next.

### Syntax — linespacing

```chordpro
{linespacing: 13}
{linespacing: 13 rel}
```

### Parameter — linespacing

| Value           | Effect                                                                         |
| --------------- | ------------------------------------------------------------------------------ |
| `0`             | Removes extra space between lines                                              |
| positive number | Adds vertical space between lines, in typographic points (dialog default: `13`) |
| `N rel`         | Relative mode: the N px exclude the beat-number band (`{beats_time}`)          |

### Usage Notes — linespacing

- The directive can be inserted anywhere in the song; it affects subsequent lines.
- Typical values range between `10` and `20` depending on the font and size used.
- Useful for adjusting text density in print, especially with two-column layout or two-pages-per-sheet format.
- **`rel` mode** — with `{beats_time}` active, the row of beat numbers above the chords normally adds to the line pitch. Adding `rel` (`{linespacing: 13 rel}`), that band is not counted: the N px are measured from the chord row to the text row, excluding the beats, which are drawn inside the `linespacing` gap. See the *"`{beats_time}` and `{linespacing}` — How Spacing Interacts"* section for details.
- **Insertion dialog** — *Line spacing* opens a dialog with the value (0–100) and a **rel** checkbox, which writes `{linespacing: N rel}`; the checkbox tooltip summarizes relative mode. With the caret inside an existing `{linespacing:...}` (or via *Edit directive...* in the context menu) the dialog opens pre-filled, with **rel** checked if present, and on confirmation changes only the directive's content: a second directive is never nested.
- **Global scope** — `{linespacing}` propagates throughout the entire song from the point of insertion, even across page breaks (`{new_page}`). If the directive is used multiple times, each occurrence overwrites the previous value; the last `{linespacing}` in the file determines the line spacing for the rest of the song.
- **Coexistence with `{new_page}` on the same line** — Placing both directives on the same line is allowed and works correctly, in either order:
- **Coexistence with `{new_page}` on the same line** — Placing both directives on the same line is allowed and works correctly, in either order:
  ```chordpro
  {new_page} {linespacing:15}
  {linespacing:15} {new_page}
  ```
  The parser processes them left to right in sequence. In both cases the new line-spacing value is written to the global format before the first block of the new page is built, so lines on the new page adopt the specified value as expected. There is no behavioural difference between the two orders.

---

## `{chordtopspacing: <value>}` — **Menu item:** *Space Above Chords*

### Description — chordtopspacing

Sets the **vertical space above chords**, i.e. the distance between the top edge of the chord line and the content that precedes it (e.g. the text line of the previous verse). Allows you to loosen or compress the margin that visually separates the chords from the verse above them.

### Syntax — chordtopspacing

```chordpro
{chordtopspacing: 4}
```

### Parameter — chordtopspacing

| Value           | Effect                                                                                   |
| --------------- | ---------------------------------------------------------------------------------------- |
| `0`             | Removes extra space above chords (default value in the insertion dialog)                 |
| positive number | Increases the visual breathing room above the chord line                                 |

### Usage Notes — chordtopspacing

- Acts independently from `linespacing`: the two parameters add up in the overall spacing.
- Useful when chords appear visually "squashed" against the text of the previous line.
- Like `linespacing`, it can be used multiple times in the same song at different points to vary spacing section by section.
- **Editing** — with the caret inside an existing `{chordtopspacing:...}` (or via *Edit directive...* in the context menu) the dialog opens pre-filled with the current value and, on confirmation, changes only the directive's content: a second directive is never nested.

## Difference Between chordtopspacing and linespacing

```text
[previous text line]
                         ↕  chordtopspacing  (space above chords)
[chord line:  G    D    A]
[text line:   When the sun...]
                         ↕  linespacing      (spacing between complete lines)
[chord line:  Em   B...]
[text line:   ...rises and...]
```

In summary: `chordtopspacing` controls the margin **above** the chord+text pair, while `linespacing` controls the space **between** successive pairs.

## `{row}` / `{r}` 🖊

**Menu item:** *none — must be typed manually*

### Description — row

Inserts a **half vertical space** (spacer) between song lines. Useful for adding a small visual breath between verses without using `{linespacing}`.

### Syntax — row

```chordpro
{row}
```

or in abbreviated form:

```chordpro
{r}
```

### Usage Notes — row

- Inserts a space equal to approximately **half a line** relative to the current line spacing.
- Has no parameters: `{row}` and `{r}` are equivalent and do not accept values.
- Not accessible from the **Insert** menu: must be typed directly in the editor.

---

## `{start_of_tab}` / `{end_of_tab}` 🖊

**Short aliases:** `{sot}` / `{eot}`

### Description — start_of_tab

Delimits an **ASCII tablature block**. The content is rendered in the preview and in print using a monospace font (Courier New) with the label «Tab», so that the column alignment of the strings is preserved.

### Syntax — start_of_tab

```chordpro
{start_of_tab}
e|--0--2--3--2--0--|
B|--1--3--3--3--1--|
G|--0--2--0--2--0--|
D|--2--0--0--0--2--|
A|--3--x--2--x--3--|
E|--x--x--3--x--x--|
{end_of_tab}
```

or with short aliases:

```chordpro
{sot}
e|--0--2--3--|
B|--1--3--3--|
{eot}
```

or with a custom label:

```chordpro
{start_of_tab: Solo}
e|--12-14-15-14-12--|
{end_of_tab}
```

### Usage Notes — start_of_tab

- The monospace font ensures that tab lines are perfectly aligned in print.
- Any inline chords `[Am]` present inside the block are **not rendered** above the text: the tablature is already a complete notation.
- The block is treated as an unnumbered verse; it receives the label «Tab» (or the custom one).
- In the editor, the block content appears in **brown italic** to visually distinguish it from normal text.

---

## `{start_of_grid}` / `{end_of_grid}` 🖊

**Short aliases:** `{sog}` / `{eog}` · Alternative form: `{grid}`

### Description — start_of_grid

Delimits a **chord grid block**. Useful for indicating rhythmic chord sequences in symbolic form, e.g. for rhythm guitar or ukulele. The block is rendered with the label «Grid» (configurable in preferences).

### Syntax — start_of_grid

Basic form:

```chordpro
{start_of_grid}
| Am . . . | F . . . | C . . . | G . . . |
{end_of_grid}
```

Short aliases:

```chordpro
{sog}
| G . . . | D . . . | Em . . . | C . . . |
{eog}
```

Alternative form (closes automatically at the next blank line):

```chordpro
{grid}
| C . . . | G . . . | Am . . . | F . . . |
```

### How Cells Are Counted — start_of_grid

**Each pair of `|` delimits exactly one bar = one cell.** The number of cells depends **only** on how many `|` you type, not on how many characters or spaces are inside them:

```chordpro
{start_of_grid}
| F C | C F G | C |
{end_of_grid}
```

produces **3 cells** (`F C`, `C F G`, `C`), even though the second bar is much wider than the others. Inner spacing is normalised: `| C      F |` and `| C F |` give the same result.

A bar may contain **more than one chord** (`| F C |` = one cell with two chords), and chords can be written with or without square brackets:

```chordpro
| F C | G |
|[F] [C] |[G] |
```

To leave an **empty bar**, write a cell with no content:

```chordpro
| Am |   | G |
```

produces 3 cells, the middle one empty.

> **Note (behaviour change)** — In earlier versions the bar's width in characters was used to estimate how many cells it spanned: a bar wider than the others automatically generated **extra empty cells** before it. This behaviour has been removed because it produced unwanted phantom bars. If an old song relied on deliberately wide bars to push chords to the right, replace them with explicit empty cells (`|   |`).

### Options — start_of_grid

All options are specified as `key=value` pairs inside the directive argument, after the optional label. They can be combined freely.

| Option              | Type    | Default         | Description                                                                                                                                              |
| ------------------- | ------- | --------------- | -------------------------------------------------------------------------------------------------------------------------------------------------------- |
| *(label)*           | text    | «Grid»          | Custom section label (free text, before any `key=value` parameters)                                                                                      |
| `nolabel`           | word    | —               | Grid **without a label**: the grey box above the grid is not drawn (no «Grid» text). Takes precedence over any label text                                 |
| `size=N`            | number  | `1`             | Cell size multiplier: multiplies horizontal and/or vertical padding by N. Accepts integers or decimals up to 2 places, with `.` or `,` (e.g. `1.5`, `2,50`) |
| `size=N affects`    | choice  | Width and height | Controls which dimension is scaled by `size=N`: **Width and height** (both paddings), **Width only** (only `_pad_x`), **Height only** (only `_pad_y`). Set in Preferences. |
| `chordtopspacing=N` | integer | `0`             | Extra space in pixels **above** each row of cells                                                                                                        |
| `linespacing=N`     | integer | `0`             | Extra space in pixels **below** each row of cells                                                                                                        |
| `sizedir=horizontal\|vertical\|both` | string | value from preferences | Overrides the global **size=N affects** preference for this block: `horizontal` (width only), `vertical` (height only), `both` (width and height) |

> **Note:** `chordtopspacing` and `linespacing` inside `{start_of_grid}` act locally on that grid block only, independently of the global `{chordtopspacing}` and `{linespacing}` directives which affect normal verse/chorus blocks. `sizedir` is also local to the block and overrides the global preference only for that grid.

### Examples — start_of_grid

Grid without a label:

```chordpro
{start_of_grid: nolabel}
{time:4/4}
|[G] |[C] |[F] [G] |[C] |
{end_of_grid}
```

Custom label only:

```chordpro
{start_of_grid: Verse}
| Am . . | F . . | G . . |
{end_of_grid}
```

Enlarged cells (`size=2` or decimal, e.g. `size=1.5`):

```chordpro
{start_of_grid: size=2}
| Am | F | G | C |
{end_of_grid}
```

```chordpro
{start_of_grid: size=1.5}
| Am | F | G | C |
{end_of_grid}
```

Label + enlarged cells:

```chordpro
{start_of_grid: Chorus size=2}
| G . . . | D . . . | Em . . . | C . . . |
{end_of_grid}
```

Extra vertical spacing between rows:

```chordpro
{start_of_grid: chordtopspacing=8 linespacing=4}
| Am | F |
| C  | G |
{end_of_grid}
```

All options combined:

```chordpro
{start_of_grid: Intro size=2 chordtopspacing=6 linespacing=3}
| Am . . . | F . . . |
| C . . .  | G . . . |
{end_of_grid}
```

Local `sizedir` (overrides global preference for this block):

```chordpro
{start_of_grid: Chorus size=2 sizedir=horizontal}
| G . . . | D . . . | Em . . . | C . . . |
{end_of_grid}
```

### Inserting from the Menu — start_of_grid

**Insert menu → Grid `{start_of_grid}\{end_of_grid}`**

Opens a dialog that proposes as default label the value set in **Preferences → Format → Chord grid → Default label** (default: «Grid»).

- **Confirm the default or cancel** → inserts the block without a label:
  ```chordpro
  {start_of_grid}
  | | | |
  {end_of_grid}
  ```
- **Type a different label** → inserts the block with a custom label:
  ```chordpro
  {start_of_grid:Chorus}
  | | | |
  {end_of_grid}
  ```

The pre-filled `| | | |` line provides 4 empty cells as a starting point; edit it or add more rows as needed. With the space bar (if enabled in preferences) you can quickly navigate between cells.

### Display Modes — start_of_grid

The rendering mode for all grid blocks is set globally in **Format tab → Chord grid** in preferences:

| Mode                     | Appearance                                                                 |
| ------------------------ | ---------------------------------------------------------------------------|
| **Pipe table** (default) | `\| Am  \| F   \| G   \| C   \|` — bars separated by `\|` characters       |
| **Plain spacing**        | `Am   F   G   C` — chords spaced without separators                        |
| **Table**                | cells with visible drawn borders                                           |

### Keyboard Behaviour Inside a Grid Block

When the cursor is inside a `{start_of_grid}` block:

| Key               | Action                                                                                       |
| ----------------- | -------------------------------------------------------------------------------------------- |
| **Space bar**     | Inserts a `\|` pipe separator, shifting the current cell right (configurable in preferences) |
| `{row}` / `{r}`   | Inserts an empty separator row (vertical spacer between rows)                                |

> The space-bar-as-pipe behaviour can be disabled in **Format → Chord grid → Space bar inserts \| separator**.
> The dimension scaled by `size=N` is configured in **Format → Chord grid → size=N affects**: choose between *Width and height* (default), *Width only*, or *Height only*.

### Chord Beats Inside a Grid — `{beats_time:}`

The `{beats_time:}` directive also works **inside** a grid block: put it on a line of its own, immediately **before** the row of cells it refers to.

```chordpro
{start_of_grid:Intro linespacing=10}
{beats_time: C=2 G=2 Dm=2 Am=2}
|[C] [G] |[Dm] [Am] |
{end_of_grid}
```

Beats are drawn **above each individual chord**, even when a bar contains more than one, using the same appearance (number, dots, or both), colour, alignment and size set in **Preferences → Format → Beat count (`{beats_time}`)**. The space needed is reserved automatically above the cells.

The directive applies **only to the row of cells immediately below it**: to assign beats to several rows, repeat it before each one.

The command *Insert → Chord duration `{beats_time:}`…* also recognises grid rows written **without square brackets** (`| Am | F | G |`), so the dialog works exactly as it does in the body of the song.

### Time Signature Inside a Grid — `{time:}`

The `{time:N/M}` directive also works **inside** a grid block: put it on a line of its own. The value **does not become a cell**: it is shown **beside the grid**, in the label column, exactly as it is for verses and choruses.

```chordpro
{start_of_grid:chords}
{time:4/4}
{beats_time: G=4 C=4 F=2 G=2 C=4 F=2 C=2 F=2 C=2}
|[G] |[C] |[F] [G] |[C] |[F] |[C] |[F] |[C] |
{end_of_grid}
```

- The **first** `{time:}` in the grid applies to the whole block.
- A later `{time:}` in the middle of the grid marks a **time change** starting from the row that follows it.
- If time display is turned off in the preferences, the directive is still consumed but not drawn.
- It can be placed anywhere in the grid, even before or after `{beats_time:}`: it does not affect the effect of `{beats_time:}` on the next row.

### Usage Notes — start_of_grid

- The block is treated as an unnumbered verse with the label «Grid» (or the custom one specified in the directive or in preferences).
- In the editor, the block content is rendered in **brown italic**, like tab blocks.
- `size=N` multiplies `_pad_x` (horizontal padding, base 8 px) and/or `_pad_y` (vertical padding, base 4 px) by N. Which dimension is scaled depends on the **Preferences → Format → Chord grid → size=N affects** option: *Width and height* (default, both paddings), *Width only* (only `_pad_x`), *Height only* (only `_pad_y`). N can be an integer or a decimal with up to 2 digits after the separator (`.` or `,`): e.g. `size=1.5`, `size=2,50`, `size=1.7`.
- `chordtopspacing=N` adds N pixels above each row; `linespacing=N` adds N pixels below each row. Both default to `0` (no extra spacing).
- `sizedir=horizontal|vertical|both` locally overrides the global **size=N affects** preference for the single block; if omitted, the value from preferences is used.
- Multiple options and a label can coexist in any order after the colon: `{start_of_grid: My Label size=3 linespacing=5 sizedir=horizontal}`.
- In pipe mode, the raw text inside the block must already contain `|` delimiters; in plain mode, chords separated by spaces are laid out automatically.

---

## `{start_of_part}` / `{end_of_part}` 🖊

**Abbreviations:** `{sop}` / `{eop}`

### Description — start_of_part

Delimits a **generic section** of the song as defined by the ChordPro 6 specification. Use it when no other structural directive (`{start_of_verse}`, `{start_of_chorus}`, `{start_of_bridge}` …) adequately describes the section: for example an instrumental introduction, an interlude, a coda, or any part that needs a free-form label.

In Songpress++ the block is treated as an unnumbered verse with the specified label. If the label is omitted, «Part» is used as the default.

### Syntax — start_of_part

```chordpro
{start_of_part: Intro}
[Am][G][F][E7]
{end_of_part}
```

With abbreviated aliases:

```chordpro
{sop: Coda}
[G]Return to [D]you
{eop}
```

Without a label (uses the default «Part»):

```chordpro
{start_of_part}
[C][G][Am][F]
{end_of_part}
```

### Usage Notes — start_of_part

- The block is not numbered and does not increment the verse counter.
- The label is free-form: it can be any text (e.g. «Intro», «Interlude», «Coda», «Solo», «Outro»).
- It is functionally equivalent to `{start_verse:Label}` — the distinction is semantic, to maintain compatibility with ChordPro 6 files from other applications.
- Not accessible from the **Insert** menu: it must be typed directly in the editor or inserted via intellisense (`Ctrl+Space`).

---

## Comments and Editorial Notes

![Songpress++ Comment Window](./img/GUIDE/commento_en.png)

| Form                     | Alias        | Std | Menu | Description                                                                                          |
| ------------------------ | ------------ | --- | ---- | ---------------------------------------------------------------------------------------------------- |
| `{comment:Text}`         | `{c:Text}`   | ✅  | ⌨️   | Comment visible in the preview, automatically enclosed in parentheses                                |
| `{comment_italic:Text}`  | `{ci:Text}`  | ✅  | 🖊    | Like `{comment}`, but with italic text                                                               |
| `{comment_box:Text}`     | `{cb:Text}`  | ✅  | 🖊    | Boxed comment                                                                                        |
| `# Text`                 |              | ✅  | 🖊    | Comment line (preceded by `#`): treated as a blank line, does not appear in preview or print         |

**Editing an existing comment** — with the caret inside `{comment:...}`, `{comment_box:...}` (or their aliases `{c:...}` and `{cb:...}`) or on a `# ...` line (after the `#`), the *Edit directive...* item in the context menu (or the *Comment* dialog) opens pre-filled with the current type and text. If the type is unchanged, only the text is replaced; if you change it, the comment is rewritten in the new type. A second directive is never nested. `{comment_italic}` is not handled by the dialog.

---

## Chord Diagrams, Keyboard and Images

![Songpress++ Guitar Chord Diagram](./img/GUIDE/accordi_1_en.png)
![Songpress++ Keyboard Chord Diagram](./img/GUIDE/accordi_2_en.png)

| Directive                                    | Std | Menu | Description                                                            |
| -------------------------------------------- | --- | ---- | ---------------------------------------------------------------------- |
| `{define: C base-fret 1 frets X 3 2 0 1 0}`  | ✅  | ⌨️   | Defines a guitar chord diagram                                         |
| `{taste:Chord}`                              | 🔧  | ⌨️   | Shows highlighted keys on the keyboard (klavier) — e.g. `{taste:Am}`   |
| `{fingering: Chord}`                         | 🔧  | ⌨️   | Shows the **first chord** keyboard with finger numbers — e.g. `{fingering: Am 3=C 1=E 2=A}` |
| `{image: filename}`                          | ✅  | ⌨️   | Inserts a raster image (PNG, JPG, GIF, BMP, TIFF) or a vector image (SVG) into the song |

The keyboard (klavier) displays the keys corresponding to the specified chord, highlighted with the color set in preferences.

Both the `{taste:}` and `{fingering:}` directives accept the `start=` (keyboard start note) and `octave=` (octave highlighting) options described below; their insertion dialogs offer the **Start note**, **Highlight note on both octaves** and **Uppercase chord** controls.

![Songpress++ Chord Key Color Option](./img/GUIDE/accordi_3_en.png)

### First Chord Fingering — `{fingering:}`

The `{fingering:}` directive is a variant of the klavier keyboard designed to show **how to position the hand on the first chord** of the song. In addition to highlighting the chord keys, it can display a finger number on each key and a label indicating which hand to use.

**Format:**

```chordpro
{fingering: Am}
{fingering: Am 3=La 1=Mi 2=Do}
{fingering: G 2=G 1=B 3=D}
{fingering: Am hand=R 3=La 1=Mi 2=Do}
{fingering: Am hand=L}
{fingering: B hand=R start=B 1=B 2=D# 3=F#}
{fingering: - hand=R 1=C 3=E 5=G}
```

The `finger=note` part is optional. The `hand=` token is also optional and can appear anywhere after the chord name. Numbers correspond to the fingers of the hand:

| Number | Finger |
| ------ | ------ |
| 1      | Thumb  |
| 2      | Index  |
| 3      | Middle |
| 4      | Ring   |
| 5      | Little |

**Hand indication (`hand=`):**

| Value    | Meaning    | Label displayed |
| -------- | ---------- | --------------- |
| `hand=R` | Right hand | *Right hand*    |
| `hand=L` | Left hand  | *Left hand*     |

The label appears centered below the keyboard in grey italics. If the `hand=` token is absent, no label is shown. The value is case-insensitive (`hand=r` and `hand=R` are equivalent).

**Keyboard start note (`start=`):**

By default the keyboard starts from **C**. With the optional `start=Note` token you can make it start from another natural note, given in English notation (`C D E F G A B`) or Italian notation (`Do Re Mi Fa Sol La Si`). The token can appear anywhere after the chord name and is case-insensitive.

```chordpro
{taste: B start=B}
{fingering: B hand=R start=B 1=B 2=D# 3=F#}
```

| Start            | White keys | Black keys |
| ---------------- | ---------- | ---------- |
| `C` or `F`       | 7          | 5 (all)    |
| any other note   | 8          | 5 (all)    |

Starting from C or F the keyboard shows the canonical 7 white keys. Starting from any other note, a 7-key window would "cut off" a black key: Songpress++ therefore **automatically adds an eighth white key at the end** — the octave of the start note (e.g. `B … B`) — so that all 12 pitches of the octave remain representable and every chord note can be highlighted. The overall width of the diagram is unchanged: with 8 keys they are simply a little narrower.

Only natural notes (white keys) are allowed; an altered or unrecognized value falls back to C.

**Octave highlighting (`octave=`):**

On 8-key keyboards the start note appears at **both ends**. If that note is part of the chord, by default it is highlighted at both (the natural behavior of an "octave-to-octave" view). With the `octave=one` token it is highlighted **only** on the left one.

| Value         | Effect                                                    |
| ------------- | --------------------------------------------------------- |
| `octave=both` | Highlight the start note on both octaves (default)        |
| `octave=one`  | Highlight only the left start note                        |

The token only has an effect on 8-key layouts (start other than C/F); otherwise it is ignored.

```chordpro
{fingering: B hand=R start=B octave=one 1=B 2=D# 3=F#}
```

**Middle C (`middlec=`):**

When the keyboard starts from a note **other than C** a visual reference can be useful. With the `middlec=show` token Songpress++ draws a **dot** at the bottom of the C key (middle C). With `middlec=hide`, or without the token, no dot is shown. Starting from C the token has no effect, since the first key on the left is already C. If the C key also carries a finger number, the number moves above the dot.

**Dot colour:** choose it by clicking the coloured square next to the *Show middle C* checkbox, in the *Chord keys* and *First chord fingering* dialogs (the colour chooser opens). It is a general setting: it applies to all songs and to preview, print and export. Default: dark grey (`#464646`).

```chordpro
{taste: E start=B middlec=show}
{fingering: B hand=R start=B middlec=show 1=B 2=D# 3=F#}
```

**Upper octave key colour:** with `octave=both` the two identical notes share the same colour by default. To tell the rightmost one apart (e.g. the **high B** on a B…B keyboard) enable *Options → Format → Chords and keyboard → Different colour for the upper octave key* and pick the colour (default `#3C78D2`, blue). The setting applies to preview, print, export and the dialog preview.

**Keyboard size:** in *Options → Format → Chords and keyboard → Keyboard size (%)* you set the size of the diagrams at the bottom of the page (50–200%, default 100%). Lower values fit more of them on each row; keyboards that do not fit in the column wrap to the next row instead of being cut off. For printing a single song only, a value different from the Preferences can be used (see *Print Options → Print settings stored in the song*, key `kbd`).

Notes can be written in Italian notation (`Do`, `Re`, `Mi`, `Fa`, `Sol`, `La`, `Si`, with `#` for sharps) or English notation (`C`, `D`, `E`, `F`, `G`, `A`, `B`).

> **Note on notation** — The insertion dialog and the finger grid follow the **default notation** set in Songpress++ preferences (*Options → Default notation*). Note names shown in the grid and written into the generated directive change automatically according to the selected notation: with American notation you will see `A, C#, E`; with Italian `La, Do#, Mi`; with German `A, Cis, E`, and so on. Chord recognition in the *Chord* field also respects the current notation. Nashville and Roman notations are not supported for fingering.

**Notes only, no chord (`-`):** to remember how to position the hand without going through a chord, write the placeholder `-` instead of the name and list the notes to show, e.g. `{fingering: - hand=R 1=C 3=E 5=G}`. The keyboard **writes no name** above it: keys with a finger (1–5) are coloured and each shows its number. With `0=NOTE` (e.g. `0=D`) the key is **not coloured** and shows only a **dot** (●): use it to mark a note without assigning a finger. Any note is allowed in this mode, since there is no chord it must belong to. It also works in preview, print and export.

**Inserting from the menu:** *Insert → Other → First chord fingering {fingering:}*
A dialog opens that automatically shows the notes of the chord and lets you:

- assign a finger to each note using a drop-down menu;
- tick **Notes only (no chord)**: the chord field is disabled and all 12 notes appear; for each one choose "—" (unused), "●" (just a dot on the key, without colouring it and without a finger) or a finger from 1 to 5;
- select the hand (Right / Left / None);
- choose the keyboard **Start note** from the drop-down of the same name;
- enable **Highlight note on both octaves** (only enabled when the start note produces 8 keys);
- enable **Show middle C** (only enabled when the start note is not C): adds `middlec=show` and draws a dot on the C key;
- enable **Uppercase chord** (on by default): always writes the chord name in uppercase in the directive. Chord recognition is case-insensitive anyway, so `Am` → `AM` is still A minor.

When enabled, the *Show keyboard preview* box at the bottom of the dialog reflects all these choices in real time. The *Chord keys* dialog (`{taste:}`) offers the same **Start note**, **Highlight note on both octaves**, **Show middle C** and **Uppercase chord** controls.

> **Note — keyboard position.** In both dialogs a note with the ℹ icon reminds you that the chord keyboard is always drawn at the bottom of the page, even though the directive (`{taste:}` or `{fingering:}`) can be inserted anywhere in the editor.

> **Note — info icons.** All the info ('i') icons in Songpress++ (dialogs and informational notes) follow the same rule: SVG at 16×16 adapted to the DPI, then `img/info.png` as a fallback, then the system icon.

**Direction arrow (`^` / `v`):**

As with chords in the text (`[Am^]`, `[Amv]`), in the `{taste:}` and `{fingering:}` directives you can also append `^` (up) or `v` (down) to the chord name. The symbol itself is not shown: an arrow ↑ or ↓ appears next to the name, above the keyboard. Colour and size are the same as for the chord arrows in the text.

```chordpro
{taste:DO^}
{taste:SOLv}
{fingering: LA-^ hand=R 1=DO 2=MI 5=LA}
```

Result: the DO keyboard with ↑ next to its name, the SOL one with ↓, and the LA- fingering with ↑. The symbol must be written **attached** to the name (`LA-^`, not `LA- ^`) and does not change the highlighted notes. Without the symbol no arrow is shown.

**Starting a new keyboard row (blank line):**

Keyboards are laid out one after another and wrap automatically when space runs out. To choose where the row changes yourself, **leave a blank line in the editor** between two consecutive `{taste:}` / `{fingering:}` directives: the keyboard that follows the blank line starts a **new row**, and the next ones continue after it. Without a blank line nothing changes from the normal behaviour.

*Without a blank line:*

```chordpro
{fingering: LA- hand=R 1=DO 2=MI 5=LA}
{taste:SI-}
{taste:MI start=SI}
{taste:RE start=LA}
{taste:DO start=SOL}
{taste:LA}
{taste:SOL start=SI}
```

Result (with three keyboards per row): `LA-` `SI-` `MI` / `RE` `DO` `LA` / `SOL`.

*With a blank line after `{taste:SI-}`:*

```chordpro
{fingering: LA- hand=R 1=DO 2=MI 5=LA}
{taste:SI-}

{taste:MI start=SI}
{taste:RE start=LA}
{taste:DO start=SOL}
{taste:LA}
{taste:SOL start=SI}
```

Result: `LA-` `SI-` / `MI` `RE` `DO` / `LA` `SOL`. The `MI` keyboard moves to the row below and the others follow it.

Rules:

- The blank line only counts **between two consecutive keyboard directives**. If there is text or another directive in between, the keyboards do not wrap.
- Several blank lines in a row are the same as one.
- It works for `{taste:}` and `{fingering:}`, which can be mixed.
- Even after a manual break, keyboards still wrap on their own when a row is too wide.
- As always, the keyboard group stays at the bottom of the page: the blank line only changes its arrangement.

**Finger number color:**
The color of the numbers displayed on the keys is set in *Options → Format → Chords and tempo → Finger number colour*. The default is near-black (`#1A1A1A`); on black keys the number appears in white to ensure contrast.

**Syntax checking for `hand=`:**

The built-in syntax checker (*Tools → Check Syntax*) validates the `hand=` token and reports the following errors:

| Error | Example | Message |
| ----- | ------- | ------- |
| Invalid value | `{fingering: Am hand=X}` | `hand` must be R or L |
| Duplicate `hand=` token | `{fingering: Am hand=R hand=L}` | `hand` specified more than once |
| Finger out of range | `{fingering: Am 6=A}` | With a chord the finger must be 1–5; with `-` `0` is also allowed (0–5) |

### Tempo — `{tempo:}` and variants

![Songpress++ Tempo](./img/GUIDE/tempo_en.png)

The `{tempo:BPM}` directive sets the song's speed in beats per minute. Songpress++ displays it in the preview and in print using an icon and format chosen by the user.

**Inserting from the menu:**

The command *Insert → Tempo {tempo:}…* opens a dialog with two areas:

- **Text field** — enter the BPM value (e.g. `120`). If left empty, a placeholder `{tempo:|}` is inserted with the cursor ready for typing.
- **Display as** — four options arranged in a 2×2 grid:

| Option | Icon / Text | Appearance in preview |
| ------ | ----------- | --------------------- |
| **Tempo:** | plain text | `Tempo: 120` |
| **BPM** | plain text | `BPM: 120` |
| **♩** (note icon) | musical note | `♩ = 120` |
| **🎼** (metronome) | metronome icon | `🎼 = 120` |

- **Metadata** — when checked, the directive is accepted by the parser but not shown in the preview or in print. All display options are disabled automatically.

The choice made in the dialog is **saved as a global preference** and applies to all subsequent renderings of `{tempo:}` in preview and print, until changed again.

**Overriding for a single command — the `,M` parameter:**

To force a different mode on a single command without changing the global preference, use the form `{tempo:BPM,M}`, where `M` is an integer corresponding to the dialog option:

| Value `M` | Dialog option | Appearance in preview |
| --------- | ------------- | --------------------- |
| `0` | **Tempo:** | `Tempo: 120` |
| `1` | **♩** (note icon) | `♩ = 120` |
| `2` | **BPM** | `BPM: 120` |
| `3` | **🎼** (metronome) | `🎼 = 120` |
| `-1` | **Metadata** | *(not displayed)* |

If `,M` is omitted, the mode set in the global preferences is used.

**Tempo icons (♩ and 🎼).** The icons are loaded **vector first** from `img/vector/` (`tempo_note`, `minima`, `semiminima`, `semiminima_punto`, `croma`, `croma_punto`, `metronomeWindows`), tinted with the chosen colour and rasterised at the real device resolution, so they stay sharp with zoom, in print and in PDF. Only if the SVG is missing does it fall back to the PNG: first `img/32/<name>.png`, then `img/<name>.png`.

> **Note:** not all symbols can be resized. Modes `1` and `3` use scalable icons (16×16 / 24×24 / 32×32); modes `0` and `2` render as plain text and are not affected by the icon size setting.

**Icon size:**

The size of the note (or metronome) icon is set in *Options → Format → Tempo → Tempo icon size*, with three values available:

| Value | Recommended use |
| ----- | --------------- |
| **16×16** | Documents with small fonts or compact layouts |
| **24×24** | Default size, suitable for most cases |
| **32×32** | Documents with large fonts or for greater readability |

The preference applies to all `{tempo:}` directives and their variants (`{tempo_m:}`, `{tempo_s:}` etc.) in both preview and print. The `{tempo_label:}` directive is not affected by this preference: it always displays the textual marking as-is.

> **Note — Fixed-icon variants** — The directives `{tempo_m:}`, `{tempo_s:}`, `{tempo_sp:}`, `{tempo_c:}`, `{tempo_cp:}` always display their own specific note icon (half note, quarter note, dotted quarter, eighth note, dotted eighth respectively) **regardless** of the global display mode set for `{tempo:}`. The only thing affected by the global preference is the number format: `= 120` or `BPM: 120`. These variants have no dedicated menu entry and must be typed directly in the editor. The `{tempo_label:}` directive is instead available via menu (*Insert → Tempo marking*) and displays a textual label with no numeric value.

### Chord Beat Duration — `{beats_time:}`

The `{beats_time:}` directive specifies the **beat duration** of each chord on the following line. Songpress++ uses this information to calculate and display **beat numbers** above the chords in the preview, helping the performer understand the rhythm without reading sheet music.

**Format:**

```chordpro
{beats_time: ChordName=N ChordName=N …}
```

- `ChordName` — chord name in Italian notation (`Do`, `Sol`, `La-`, `Re7`…) or English (`C`, `G`, `Am`, `D7`…); chords with an explicit bass note (`Re-/Fa#`, `C/E`) are used in their **full form** as the key, including the part after `/`
- `N` — positive integer number of beats (≥ 1)
- Chords are separated by spaces
- Only the listed chords receive a beat indicator; others are ignored

**Examples:**

```chordpro
{beats_time: C=4 G=2 Am=2 F=4}
[C]Amaz[G]ing [Am]grace, how [F]sweet
```

```chordpro
{beats_time: G=2 Em=2 C=4}
[G]Nel [Em]mezzo del [C]cammino
```

```chordpro
{beats_time: Am=4 F=2 C=2 G=4}
[Am]Tanti [F]au[C]guri a [G]te
```

```chordpro
{beats_time: Am=2 Dm/F#=2 Am=2}
[Am]Par[Dm/F#]late ed an[Am]nunciate
```

Each `{beats_time:}` directive applies to the **line of text/chords immediately below it**. To assign durations to multiple lines, place a `{beats_time:}` before each one.

The directive also works inside `{start_chord}`, `{start_bridge}` and `{start_of_grid}` blocks — see *Chord Beats Inside a Grid*.

**Inserting from the menu — guided dialog:**

The command *Insert → Chord duration {beats_time:}…* is also accessible via the keyboard shortcut <kbd>Ctrl</kbd>+<kbd>Shift</kbd>+<kbd>D</kbd>.

The command automatically detects the context:

- **If no line near the cursor contains `[…]` chords** — inserts `{beats_time: }` directly without opening any dialog.
- **If the current line (or the line above or below) contains `[…]` chords** — opens a dialog with a numeric field (`SpinCtrl`) for each unique chord found, preset to 1 beat. As you change the values, the **Preview** field updates in real time showing the directive that will be inserted (e.g. `{beats_time: C=4 G=2 Am=2 F=1}`). Setting a chord to **0** excludes it from the directive. If the line contains more than **8** chords, the list becomes scrollable. Chords with an explicit bass note (e.g. `Dm/F#`) are shown in their full form — both as a label and as the key in the generated directive.

> **Note — Cursor placement** — To open the dialog, the command searches for chords in this order: **current line** → **next line** → **previous line**. Once confirmed, insertion searches in this order: **current line** → **previous line** → **next line**. The simplest approach is to place the cursor directly on the chord line.

> **Note — In-place replacement** — If the line immediately preceding the chord line is already a `{beats_time:}` directive, clicking **OK** **replaces** it rather than inserting a duplicate. If there are blank lines between an existing `{beats_time:}` and the chord line, the insertion jumps over the blank lines to place the directive as close as possible to the chord line, avoiding unwanted visual gaps.

The dialog provides three additional controls:

- **All: [N] [Apply to all]** — sets the same number of beats on all chords in the dialog in one click.
- **Include direction arrow (^ / v) in the directive** — if a chord has an arrow (`[MI-v]`), with the box checked the directive carries it: `{beats_time: MI-v=4 LA-=1 SI=1 MI-=2}`; with the box unchecked it does not: `{beats_time: MI-=4 LA-=1 SI=1 MI-=2}`. In the preview and in print the beats are assigned to the chords in the same way in both cases. The box is enabled only if the song has at least one chord with an arrow; the choice is remembered (default: unchecked).
- **[Apply to whole song…]** — automatically inserts a `{beats_time:}` directive before every chord line in the entire song, using the values set in the dialog. Lines already preceded by a `{beats_time:}` are skipped. The whole operation is undoable with a single `Ctrl+Z`. For chords that appear in the song but are **not present in the dialog** (because the cursor's reference line had different chords), the default beat count is **1** — unless all the dialog's spin fields are set to **0**, in which case those chords are also omitted from the directive, producing an empty `{beats_time: }`.
- **[OK +] [↕N] [s]** — confirms and inserts the directive exactly like the **OK** button, but automatically reopens the dialog after the chosen delay. The delay is set with the **SpinCtrl** (1–60 seconds, default 5) placed next to the button: adjust it before clicking, and the value is **saved** in preferences and restored on next opening. This is useful when working through a long song and assigning beat durations line by line: during the configured pause you can move the cursor to the next chord line in the editor, and the dialog will reopen already loaded with the new chords.

> **Note — Selection mode** — If a text range is selected before opening the dialog, the dialog displays a **blue badge** ("● Selection mode: N chord lines selected") and collects all unique chords from the selected lines into a single list. Clicking **OK** inserts (or replaces in-place) a directive before **every chord line** in the selection in a single `Ctrl+Z`. Each line receives its own directive containing only its own chords, using the values set in the dialog.

> **Note — Multi-cursor** — The command is compatible with multi-cursor mode (Alt+Click, Ctrl+D). If multiple cursors are active over the same chord sequence, the dialog displays a **green badge** ("● Multi-cursor active: N positions") and inserts the directive at all positions in a single `Ctrl+Z`. If the cursors point to **different chord sequences** (heterogeneous multi-cursor), the dialog opens a **Notebook** with one tab per cursor (up to a maximum of 5): each tab shows the SpinCtrl fields specific to that position and its own real-time preview. A **Preview (cursor 1)** summary field is always visible below the Notebook. If the active cursors exceed 5, a warning is shown: «⚠ Showing first 5 cursors of N».
>
> In heterogeneous multi-cursor mode, the dialog also shows the checkbox **☑ Highlight chord rows in editor**, next to a **colour picker**. When enabled, the chord rows each cursor refers to are highlighted with a background colour directly in the editor: the row of the **active cursor** (the tab selected in the Notebook) uses the **full colour** chosen with the picker, while the rows of the **other cursors** use the same hue in a lighter tint (automatically blended towards white). The chosen colour and the checkbox state are **saved in preferences** and restored on the next opening. Highlights are automatically removed when the dialog is closed (OK, Cancel or X).
>
> **Multiple cursors on the same line** — If two or more cursors fall on the **same chord line**, they are treated as **a single one**: the line receives one `{beats_time:}` directive and the dialog shows a single tab (the badge count reflects the effective cursors, not the ones placed). This is the intended behaviour, since a chord line can only be preceded by one directive.

**Preview display:**

The menu item **View → Show chord beats** enables or disables the display of beat numbers in the preview. When enabled, a beat indicator appears above each chord according to the mode set in preferences.

**Preferences — *Options → Format → Beat count ({beats_time})*:**

| Option | Values | Default | Description |
| ------ | ------ | ------- | ----------- |
| **Colour** | `#RRGGBB` | `#6464C8` (blue-violet) | Colour of the number/dot displayed above the chord. Set via the *Pick…* button or by typing the hex code directly. |
| **Size** | 30 % – 150 % | 60 % | Size of the beat number as a percentage of the chord font size. |
| **Bold** | ☐ / ☑ | ☐ (off) | When checked, the beat number is drawn in bold. |
| **Alignment** | Left / Centre / Right | Right | Position of the beat number relative to the chord name. |
| **Mode** | Number / Dots / Both | Number | Controls *what* is displayed above the chord (see detail below). |

**Display modes:**

| Mode | Appearance | Description |
| ---- | ---------- | ----------- |
| **Number** | `4` above the chord | Shows the beat count as a digit. |
| **Dots** | `· · · ·` between chords | Shows one dot per beat in the space between consecutive chords. |
| **Both** | number + dots | Combines both representations. |

**Syntax checking:**

The built-in syntax checker (*Tools → Check syntax*) reports errors in the value of `{beats_time:}`:

| Error | Example | Message |
| ----- | ------- | ------- |
| Token without `=` | `{beats_time: G}` | invalid format |
| Unrecognised chord | `{beats_time: Xyz=2}` | unrecognized chord |
| Duplicate chord | `{beats_time: G=2 G=1}` | chord appears more than once |
| Missing beat count | `{beats_time: G=}` | missing beat count |
| Non-integer or ≤ 0 beats | `{beats_time: G=0}`, `G=1.5` | must be a positive integer |
| Sequence differs from the chord line | `{beats_time: Em-=4 …}` above a line with `[Em]` | chord N does not match line … (fixable with **Fix**) |

> **Note** — “Unrecognised chord” is reported as a **warning** (⚠️), not a blocking error: the beat count is not applied to that chord, but the song still renders. See the *Syntax Check* section for the distinction between errors and warnings.

### `{beats_time}` and `{linespacing}` — How Spacing Interacts

When using `{beats_time}` together with `{linespacing}`, it is important to understand which **chord+text pair** the extra space applies to.

The rule is straightforward: `{linespacing}` acts on the gap between the current line and the **next** one; beat numbers (produced by `{beats_time}`) appear **above** the chords and do not alter the `linespacing` of the line itself.

#### Visual diagram

```text
{beats_time: C=4 G=2 Am=2 F=4}
[C]Gloria a [G]Dio nell'[Am]alto dei [F]cieli

                 ┌──────────────────────────────────────────┐
                 │   4     2     2     4    ← beat numbers   │
                 │   C     G    Am     F    ← chords         │
                 │  Gloria a Dio nell'alto  ← lyrics         │
                 └──────────────────────────────────────────┘
                          ↕  linespacing  (space AFTER this line, towards the next)
                 ┌──────────────────────────────────────────┐
                 │   4     2     2     4    ← beat numbers   │
                 │   C     G    Am     F    ← chords         │
                 │  dei cieli, pace in te  ← lyrics          │
                 └──────────────────────────────────────────┘
```

`linespacing` is inserted **between** line blocks — that is, between the bottom of the current line and the top margin of the next line (including any beat numbers above it). Beat numbers remain compressed **inside** their own line.

#### Comparison: without and with `{linespacing}`

```text
── Without {linespacing} ────────────────────────────────────

  4     2     2     4
  C     G    Am     F
  Here I am, Lord!           ← line 1 (beat numbers above chords)
  4     2                    ← line 2 starts immediately below
  F     C
  I have heard you calling

── With {linespacing: 12} ───────────────────────────────────

  4     2     2     4
  C     G    Am     F
  Here I am, Lord!
                             ← {linespacing: 12} adds 12 pt here ↕
  4     2
  F     C
  I have heard you calling
```

#### Where to place `{linespacing}` relative to `{beats_time}`

`{linespacing}` should be placed **before** the line it applies to, or at a separate point in the file to regulate an entire section. If placed **on the same line** as `{beats_time}`, the behaviour is well-defined: the new line-spacing value takes effect starting from the **next** chord line, without altering the beat numbers already assigned to the current line.

```chordpro
{linespacing: 12}
{beats_time: C=4 G=2 Am=2 F=4}
[C]Here I [G]am, [Am]Lord! [F]I hear you
```

```text
  ↑ {linespacing: 12} applies starting from this line
  │
  │   4     2     2     4
  │   C     G    Am     F
  │   Here I am, Lord!...
  │
  ╰──── 12 pt ────╮
                  │
     next line...
```

> **Technical note** — Internally, `{beats_time}` and `{linespacing}` use separate structures: the former acts on `SongText` tokens (individual chord tokens), the latter on the `ParagraphFormat` of the block. They do not overwrite each other.

#### Relative mode `{linespacing: N rel}` — excluding the beat band

Normally the beat numbers occupy a band **above** the chords that adds to the overall spacing: two lines with `{beats_time}` therefore end up farther apart than two lines without, even at the same `{linespacing}`. If you want the line spacing to stay **constant** regardless of the presence of beats, add the `rel` flag:

```chordpro
{linespacing: 13 rel}
```

With `rel`, the number band is **not** counted in the line pitch: the N px are measured from the chord row to the text row, and the beats are drawn **inside** the `linespacing` gap instead of adding to it.

```text
── {linespacing: 13} (normal) ───────────────────────────────
   Previous line text
        ↕  13 pt + beat-number height     ← the band adds up
   4    2    2    4
  DO  SOL  LA-   FA
  Current line text

── {linespacing: 13 rel} ────────────────────────────────────
   Previous line text
        ↕  13 pt                          ← the numbers sit inside
   4    2    2    4                          this gap
  DO  SOL  LA-   FA
  Current line text
```

> **Warning:** since the beats occupy the `linespacing` gap, a value of `N` smaller than the height of the numbers may bring them very close to the text of the line above. Choose `N` so that it comfortably contains the beat band. On lines **without** `{beats_time}`, `rel` mode makes no difference.

### Image Directive

![Songpress++ Insert Image](./img/GUIDE/inserisciImmagine_en.png)

The `{image:}` directive inserts a **raster** or **vector (SVG)** image at the point where it appears in the song. Songpress++ supports two modes: **external link** (file path) and **embedded image** (base64).

#### Directive options

| Option         | Std | Description                                                                           |
| -------------- | --- | ------------------------------------------------------------------------------------- |
| `width=N`      | ✅  | Width in typographic points (1/72 of an inch), or percentage e.g. `width=50%`         |
| `height=N`     | ✅  | Height in typographic points, or percentage                                           |
| `scale=N%`     | ✅  | Scale factor, e.g. `scale=50%` (cannot be combined with width/height)                 |
| `align=left`   | ✅  | Left alignment                                                                        |
| `align=center` | ✅  | Center alignment (default)                                                            |
| `align=right`  | ✅  | Right alignment                                                                       |
| `border`       | ✅  | Draws a 1pt border around the image                                                   |
| `border=N`     | ✅  | Draws a border of N typographic points                                                |

**Supported formats:**

| Format | Extensions      |
| ------ | --------------- |
| PNG    | `.png`          |
| JPEG   | `.jpg`, `.jpeg` |
| GIF    | `.gif`          |
| BMP    | `.bmp`          |
| TIFF   | `.tiff`, `.tif` |
| SVG    | `.svg`, `.svgz` |

#### Vector images (SVG)

SVG files are inserted like any other image, with the same options (`width=`, `height=`, `scale=`, `align=`, `border`) and can also be embedded in base64.

- **Natural size** — if you give no `width`, `height` or `scale`, the size is read from the `width`/`height` attributes of the `<svg>` tag (also in `pt`, `mm`, `cm`, `in`), otherwise from the `viewBox`; if both are missing, 300×150 is used.
- **Sharpness** — the SVG is not enlarged like a bitmap: it is redrawn at the **real device resolution** (preview zoom, print), so it stays sharp at any scale.
- **PDF export** — with reportlab every page is a high-resolution bitmap (about 216 dpi) anyway: the SVG is as sharp as the rest of the page, but it does not stay a vector path in the PDF.
- **Limits** — the built-in drawing engine may not draw text (`<text>`) or CSS styles (`<style>`). If an SVG exported from another program loses its lettering, convert the text to paths before exporting (in Inkscape: *Path → Object to Path*).

#### Image not found or not drawable

If the file does not exist or cannot be read, a **dashed red box** with the reason appears in place of the image, with no error windows: *Image not found: filename*, *Image not readable: filename*, *SVG error: …*, *SVG cannot be drawn: …*, *SVG drawing error: …*. Once the name is corrected or the file restored, the box disappears at the next redraw.

#### Selecting from the preview

**Double-clicking** an image in the preview (also in full screen) moves the caret to the matching `{image: ...}` line in the editor and selects it.

---

#### Mode 1 — External link (file path)

The image file stays on disk and is loaded each time the document is opened. If the image is in the same folder as the document, the filename alone is sufficient. Paths containing spaces or backslashes must be enclosed in double quotes.

```chordpro
{image: logo.png}
{image: logo.png width=200 align=left}
{image: logo.png scale=50% border}
{image: intro.svg width=300}
{image: "C:\Users\User\Pictures\photo.jpg" align=center}
```

A relative name is looked up in the folder of the saved document: if the document has not been saved yet, the absolute path is needed. The dialog writes only the name when the image is in the same folder as the document, otherwise the full path.

---

#### Mode 2 — Embedded image (base64) 🔧

When the **Embed image in file** checkbox is enabled in the insert dialog, the image content is encoded in base64 and saved directly inside the document file. The file becomes fully self-contained: it does not depend on any external file and can be shared or moved without losing the image.

```chordpro
{image: data:image/png;base64,iVBORw0KGgoAAAANS... width=200 align=center}
```

The base64 data is generated automatically by the dialog — no manual editing is needed. Alignment, border and dimensions are set through the dialog controls as usual and are included in the directive even in embedded mode.

> **Note on file size** — Base64 encoding increases the data size by approximately 33%. The dialog shows an estimate of the KB/MB that will be added to the document file before confirming. The file extension shown in the estimate reflects the default extension set in **Options → General 2 → Default file extension**.

---

#### Insert Image dialog

The image can be inserted via **Insert → Other → Image {image:}**. The dialog lets you select the file, configure all options, and see the resulting directive in real time in the **Directive preview** field.

| Field  | Initial value | Range  | Unit     | Notes                                                          |
| ------ | ------------- | ------ | -------- | -------------------------------------------------------------- |
| Width  | 0             | 0–9999 | `pt` / `%` | 0 = not included in the directive; default unit: `pt`        |
| Height | 0             | 0–9999 | `pt` / `%` | 0 = not included in the directive; default unit: `pt`        |
| Scale  | 100           | 1–500  | `%`      | 100 = not included (it's the default)                         |
| Border | 1             | 0–50   | pt       | active only if the **Border** checkbox is checked; step 0.5   |

The **Embed image in file (base64, no external dependency)** checkbox is located at the bottom of the dialog, below the Border section. When active, the preview shows `{image: data:<embedded> ...}` with the real options (alignment, border, etc.) visible and editable in real time.

**Information about the chosen image**

- **File filter** — the *Browse…* button offers four entries: *Image files* (all, SVG included, default), *Vector images (\*.svg)*, *Raster images* (PNG, JPG, JPEG, GIF, BMP, TIFF, TIF) and *All files*.
- **Image type** — below the file field, with the “i” icon, the message *Raster image loaded!* or *Vector image loaded!* appears. It stays empty until the path points to a valid image file. The icon is `img/vector/info.svg`, falling back to `img/info.png`.
- **Absolute path** — the *Absolute path: …* line shows where the file is. If it is long it is shortened in the middle; hover to see it in full.
- **Open folder** — the button, to the right of the image-type message, opens the folder containing the file (on Windows and macOS with the file already selected). It is disabled until there is a valid image. The icon is `img/vector/folder_photo.svg`, falling back to `img/folder_photo.png`.

**Editing an existing directive** — with the caret inside `{image: ...}` (or via *Edit directive...* in the context menu) the dialog opens pre-filled with path, width, height (`pt` or `%`), scale, alignment and border; on confirmation it replaces only the directive's content, never nesting a second one. If the image is **embedded**, the file field stays empty with the text *(embedded image)* and the *Embed* checkbox is locked: you can change the options and the original data is kept; choosing a new file replaces the embedded image.

---

### Transposer Indicator 🖊

![Songpress++ Insert Transposer Indicator](./img/GUIDE/transposer_en.png)

The **Transposer indicator** is a text-based dot representation showing which key to press on the physical Transposer device of an organ. It is inserted directly into the song text as a `{start_of_tab: TRANSPOSER}` block, so it appears in the preview and in print using a monospace font (Courier New), guaranteeing perfect alignment between the symbols and the note names.

#### Access

**Insert → Other → Transposer image {image:}...**

#### Indicator structure

The inserted block consists of two monospace lines:

- **Line 1** — key symbols: a filled dot for the selected key, empty dots for the others
- **Line 2** — note labels: `Gb  G   Ab  A   A#  B`

```
{start_of_tab: TRANSPOSER}
 ·   ·   ·   •   ·   ·
 Gb  G   Ab  A   A#  B
{end_of_tab}
```

#### Dot preview

| Key   | Symbol row                      | Pressed note |
|-------|---------------------------------|--------------|
| G♭    | `•   ·   ·   ·   ·   ·`        | G♭           |
| G     | `·   •   ·   ·   ·   ·`        | G            |
| A♭    | `·   ·   •   ·   ·   ·`        | A♭           |
| **A** | `·   ·   ·   •   ·   ·`        | **A** *(default)* |
| A♯    | `·   ·   ·   ·   •   ·`        | A♯           |
| B     | `·   ·   ·   ·   ·   •`        | B            |

> Key **A** always has a red border in the dialog's graphic panel: it marks the reference pitch of the physical Transposer.

#### Symbol choice

The dialog lets you choose the symbol for the pressed key from four options:

| Symbol | Unicode | Description        | Column width |
|--------|---------|--------------------|--------------|
| `•`    | U+2022  | Bullet             | 4            |
| `●`    | U+25CF  | Black circle       | 4            |
| `◉`    | U+25C9  | Fisheye            | 4            |
| `⬤`    | U+2B24  | Large black circle | 5            |

The symbol for **unpressed** keys is always `·` (U+00B7) or `○` (U+25CB) depending on the choice.

#### Position in document

| Option               | Description                                                                    |
|----------------------|--------------------------------------------------------------------------------|
| Before title         | Inserts the block at the very beginning of the file, before any content        |
| After title          | Searches for `{title:}` or `{t:}` and inserts immediately after               |
| At cursor position   | Inserts at the current cursor position *(default)*                             |
| End of song          | Inserts at the end of the text, before any trailing blank lines                |

---


## File Structure — Complete Example

```chordpro
{title: O Sole Mio}
{artist: Eduardo di Capua}
{key: C}
{time: 4/4}
{tempo: 80}
{capo: 0}

{start_verse_num}
{beats_time: C=2 G7=2}
[C]Che bella [G7]cosa na jurnata 'e [C]sole
[C]N'aria serena [G7]doppo na tempesta!
{end_verse_num}

{soc:Chorus}
[C]O sole [C7]mio sta [F]'nfronte a [C]te
[G7]O sole, o sole [C]mio
{eoc}

{start_of_tab: Intro}
e|--0--3--2--0--|
B|--1--0--3--1--|
G|--0--0--2--0--|
{end_of_tab}

{new_page}

{start_verse_num}
[C]Ma n'atu sole [G7]cchiu bello, oje [C]ne'
{end_verse_num}
```

---

### Time signature scoped to a block

`{time:}` can have a **block scope**. Written **outside** verses and choruses (usually at the top of the song) it is the general time signature and is shown as a subtitle, with the graphical symbol. Written **inside** a verse or chorus it applies **only to that block**: it does not split it and, when the block ends, the general time signature is unchanged.

```chordpro
{time:4/4}

{start_verse_num}
{time:4/4}
[C]Verse text...
{end_verse_num}

{start_chorus}
{time:2/4}
[G]Chorus text...
{end_chorus}
```

- It must be **inside** the block, right after the opening tag: for numbered verses between `{start_verse_num}` and `{end_verse_num}` or, in the short form, between `{sov}` and `{eov}` (equivalent to `{start_verse_num}`), for unnumbered verses between `{start_verse}` and `{end_verse}`, for choruses between `{start_chorus}` and `{end_chorus}` or, in the short form, between `{soc}` and `{eoc}`. Written before the block opens, it is the general time signature.
- The block's time signature is drawn **at the side**, as a stacked fraction (numerator, line, denominator), in the label column, **below** the label box («Rit.», verse number). The text starts on the same line as the label.
- The **first** `{time:}` found in the block is the one used. A second `{time:}` in the same block (a mid-block change) is shown **inline**, in parentheses, like a comment.
- If *Time signature* is switched off (option «No chords: blocks to hide»), `{time:}` inside blocks is hidden too.
- There is no dedicated directive: the normal `{time:}` is used.

---

## Editor Features

### Guided Insertion (Insert Menu)

All main directives are accessible via the **Insert** menu, which opens support dialogs to fill in values. The cursor `|` in InsertWithCaret indicates the position where the cursor will be placed after insertion.

#### Insert menu layout

The items are arranged in five groups separated by lines:

1. **Header** — Title, Subtitle, Artist, Composer, Album, Comment
2. **Chords** — Chord, Intro chords, First chord fingering, Chord keyboard, Guitar chord diagram, Chord duration
3. **Song structure** — Numbered verse, Unnumbered verse, Verse with custom label or without label, Chorus, Bridge, Grid
4. **Tempo and key** — Tempo, Tempo marking, Time signature, Key
5. **Images and symbols** — Image, Transposer image, Musical symbol (Unicode)

#### Artist, Composer, Album

**Insert → Artist**, **Composer** and **Album** insert `{artist:|}`, `{composer:|}` and `{album:|}` respectively, without opening any dialog, like Title and Subtitle: the cursor `|` is placed after the colon, ready for the value. If the cursor is already inside one of these directives, the command does not insert a second one but **selects the existing value**, so it can be retyped. Each of the three items also has an icon in the Insert toolbar, which can be hidden from *Options → Toolbars → Insert*.

#### Numbered verse

**Insert → Numbered verse…** opens a small dialog with a **Form** group, where radio buttons let you choose how the block is written:

| Form | Description |
| --- | --- |
| **`{start_verse_num} ... {end_verse_num}`** | Long form (default). |
| **`{sov} ... {eov}`** | Short form of `start_of_verse` / `end_of_verse`. |

The two forms are equivalent: the verse is numbered automatically in the same way, and the result in the preview, in print and in exports is identical. Only the text shown in the editor changes.

Examples of the inserted text (the `|` cursor is placed inside the block):

```chordpro
{start_verse_num}
|
{end_verse_num}
```

```chordpro
{sov}
|
{eov}
```

The dialog has no label field: for a verse with a custom label or without a label use **Verse with custom label or without label…**, or add the label by hand (`{sov:Label}`; in that case the verse is no longer numbered automatically). The chosen form is remembered while the program stays open. Hovering the two radio buttons shows a tooltip.

#### Chorus (<kbd>Ctrl</kbd>+<kbd>U</kbd>)

A single item, **Insert → Chorus…**, inserts the chorus block. The same dialog opens from the *Chorus…* icon of the Insert toolbar. The dialog contains:

| Field | Description |
| --- | --- |
| **Label** | Text shown as the chorus label. If left empty or unchanged, the default label is used (the one set in *Options → Format*, usually "Chorus") and the command is written without a label. |
| **Form** | Radio buttons to choose how the block is written: **`{start_chorus} ... {end_chorus}`** (long form, default) or **`{soc} ... {eoc}`** (short form of `start_of_chorus` / `end_of_chorus`). |

Examples of the inserted text (the `|` cursor is placed inside the block):

```chordpro
{start_chorus}
|
{end_chorus}
```

```chordpro
{soc:Final}
|
{eoc}
```

The chosen form is remembered while the program stays open. Hovering the label field and the two radio buttons shows a tooltip, identical on Windows and Linux.

### Chord Management

- **Insert chord** — inserts `[|]` with the cursor inside the brackets; the dialog also lets you choose a direction arrow (*None*, *Up*, *Down*)
- **Move chord right / left** — moves the chord under the cursor by one character
- **Remove chords** — deletes all chords from the selection. The command is enabled only if the selection contains at least one chord between `[ ]`; otherwise it stays greyed out
- **Paste chords** — pastes only the chords (without text) from the copied selection
- **Propagate chords to verses** — copies chords from the first verse to all verses with the same number of lines
- **Propagate chords to choruses** — same for choruses
- **Integrate chords** — converts two separate lines (chords above / text below) to inline ChordPro format. It acts on the cursor line (chords) and the next one (text), and is enabled only when the cursor is on a chords-only line in tab format followed by a text line

### Transposition and Notation

- **Transpose** — opens the dialog to transpose chords. The dialog provides the following options:

  | Option | Description |
  |---|---|
  | **Chord notation** | Auto-detected notation; can be changed manually |
  | **From key** | Source key, auto-detected from the text |
  | **Semitones** | Number of semitones to transpose (from −11 to +12) |
  | **To key** | Target key; updates automatically when semitones change |
  | **Accidentals** | Choose between automatic, sharps (#) or flats (b) for chromatic notes |
  | **Apply to selection only** | If enabled (and only when text is selected), transposes exclusively the `[...]` chords and `{beats_time:}` directives within the selection, leaving the rest of the song unchanged |
  | **Also transpose {beats_time:} chords** | Extends transposition to chord names inside `{beats_time: C=4 G=2 …}` directives, respecting the same scope (selection or whole song) chosen with the option above |

  > **Note — Relative notations (Nashville and Roman):** **Nashville** (1, 2, 3… 7) and **Roman** (I, II, III… VII) notations represent *scale degrees*, not absolute pitches. For this reason they are intentionally excluded from transposition: shifting degree `[1]` from C to D would make no musical sense, since the degree remains the same regardless of key. If the text contains chords in Nashville or Roman notation, they are left unchanged after transposition.

- **Simplify chords** — finds the easiest key to play
- **Change notation** — converts between Anglo-Saxon notation (C D E…) and solfège (Do Re Mi…)
- **Normalize chords** — standardizes chord spelling (e.g. `Hm` → `Bm`)
- **Convert Tab → ChordPro** — automatically converts tab format (chords above text) to inline ChordPro. It acts on the selection or the whole song and is enabled only if the text is in tab format
- **Convert inline chords to ChordPro** — wraps in `[ ]` the chords *glued* to the lyrics (see below). It is enabled only when there is something to convert

> **Commands enabled only when needed** — **Integrate chords**, **Convert Tab → ChordPro** and **Convert inline chords to ChordPro** stay greyed out when they would have no effect: for example with an empty editor, with no chords, or with chords already in ChordPro. They enable themselves as soon as the text, the selection or the cursor position allows it. If you prefer to have them always available, turn off *Options → General → Enable the chord conversion commands only when needed*. **Remove chords**, instead, always follows the selection (enabled only if it contains chords).

#### Convert Inline Chords to ChordPro

For songs where chords are **stuck to the syllables** of the lyrics, with no square brackets — the typical format of many songbooks copied from the web or from old text files:

```
LAProtegga il nostro popoSOLlo
```

becomes:

```chordpro
[LA]Protegga il nostro popo[SOL]lo
```

The command acts on the **selection**, if any text is selected, otherwise on the **whole song**. The operation can be undone with a single <kbd>Ctrl</kbd>+<kbd>Z</kbd>.

**Notation used**

The conversion uses the **default notation** set in **Tools → Options… → General → Default notation**. If the song is written in another notation, change it *before* running the command, otherwise the chords will not be recognised.

**How chords are told apart from lyrics**

| Situation | Result |
| --- | --- |
| Root preceded by a **lowercase** letter | Chord inside the word → `popo[SOL]lo` |
| Root at the start of a word, followed by an **uppercase** letter | Chord → `[SOL]Fa che` |
| Root at the start of a word, followed by a **lowercase** letter | Depends on the notation (see below) |
| Line made up of **chords only** | All wrapped → `[D] [G] [A]` |
| `{…}` directives, `#` comments, text already in `[ ]` | Left untouched |

The ambiguous case (root at the start of a word followed by a lowercase letter) is resolved according to the notation:

- **Notations whose roots are all uppercase and at least 2 characters long** (`DO RE MI FA SOL LA SI`): accepted, since `REtuoi` is not an Italian word.
- **Single-letter notations** (`C D E`) **or capitalised ones** (`Do Re Mi`): rejected, otherwise common words such as `Fai` would become `[F]ai` or `[Fa]i`.

Accidentals (`#`, `b`, `♯`, `♭`), qualities (`-`, `m`, `M`, `min`, `maj`, `dim`, `aug`, `°`, `+`), extensions (`sus`, `add`, digits) and slash bass notes (`Am/C`) are recognised as well. A `b` counts as a flat only if it is **not** followed by further lowercase letters, so `LAbella` stays `[LA]bella` rather than `[LAb]ella`.

**Messages**

| Outcome | Message |
| --- | --- |
| Conversion successful | Status bar: *«N chords converted to ChordPro»* |
| Empty text | Status bar: *«Nothing to convert: the text is empty»* |
| Chords already in `[ ]` | Status bar: *«Nothing to convert: chords are already in ChordPro format»* |
| No glued chords recognised | Warning dialog showing the notation used, an example of the expected format, and a suggestion to change the default notation |

> **Tip:** after converting, it is worth running **Tools → Check syntax** (<kbd>F7</kbd>) and glancing at the preview: lyric words that happen to match a note name may, in rare cases, be wrapped by mistake.

### Format and Structure

- **Song font** — opens the dialog to set the global font
- **Text font** — inserts `{textfont}`/`{textsize}`/`{textcolour}` directives for the current span
- **Chord font** — inserts `{chordfont}`/`{chordsize}`/`{chordcolour}` directives
- **Verse labels** — shows/hides verse labels in the preview
- **Chords above / below** — positions chords above or below the text
- **Show chords** — three modes: none / first verse only / entire song
- **Page/column break lines** — shows/hides guide lines in the preview

### Text Cleanup

- **Remove superfluous blank lines** — deletes double blank lines
- **Normalize multiple spaces** — reduces multiple spaces to one

### Musical Symbols Unicode ⌨️

- **Musical symbol (Unicode)…** (`Insert › Musical symbol (Unicode)…`, shortcut `Ctrl+Shift+M`) — opens the **Musical Symbols dialog**, from which you can choose a Unicode character and insert it at the cursor position. The symbols are organized into six tabs — *Notes and rests*, *Accidentals*, *Dynamics*, *Staff and clefs*, *Ornaments and articulations* and *Common (BMP)* — and the dialog offers a few insertion options:
  - **Custom size (pt)** — wraps the symbol in `{textsize:N}…{textsize}` to insert it at a specific point size (6–144 pt);
  - **Symbol colour** — applies a colour via `{textcolour:#RRGGBB}…{textcolour}`, with a *Pick…* picker; the choice is remembered across sessions;
  - **Wrap in a verse block (not counted)** — wraps the symbol in `{start_verse}…{end_verse}` without affecting the verse numbering.

  The option states are saved automatically. The two character families (BMP and SMP) and full details are covered in the *Musical Symbols Unicode — dialog* section.

### Syntax Check

**Check syntax** (`Tools › Syntax check`, <kbd>F7</kbd>) analyzes the ChordPro text and reports chords, directives and brackets that are not correct. The result appears in a dedicated window.

Detected issues are split into two severity levels, shown in the **Type** column with an icon:

| Type | Icon | Meaning |
| ---- | ---- | ------- |
| **Error** | ❌ | A structural problem or invalid value that must be fixed: an unclosed bracket, an unknown command, a missing or malformed numeric value, a token in the wrong format, etc. |
| **Warning** | ⚠️ | A **non-blocking** notice: typically an **unrecognized chord** (e.g. `[(FA)]`, `{taste: Xyz}`, `{beats_time: Xyz=2}`, `{fingering: Xyz …}`). The song still renders, but it is worth checking that the notation is intentional. |

The results window shows a table with the **Type**, **Line**, **Column** and **Description** columns. The background colour summarizes the outcome at a glance:

- **green** — no issues;
- **yellow** — warnings only;
- **orange** — at least one error.

The header reports the count (for example *“Found 1 warning:”* or *“Found 2 errors and 1 warning:”*). These controls help you review and correct the results:

- **Go to line** (or double-click a row) — moves the editor cursor to the line and column of the selected issue;
- **Fit width** — widens the window so the *Description* column shows the longest message in full;
- **Fix** — automatically fixes the selected error, when a safe fix exists (see *Automatic Fix*).

#### Automatic Fix

The **Fix** button, next to **Close**, fixes **only the selected error** in the list, with no manual editing. It is enabled only if a safe fix exists for that error; hover over the button and the tooltip explains what it will do. For other errors the button stays disabled.

After you click it:

1. the line is rewritten in the editor, as a single action you can undo with <kbd>Ctrl</kbd>+<kbd>Z</kbd>;
2. the check is run again on the updated text;
3. the window reopens in the same position with the next error selected. If none are left, the message *“No syntax errors found.”* appears.

If the line has changed in the meantime, nothing is modified and the status bar asks you to run the check again.

Fixable errors:

| Error | Example | What the fix does |
| ----- | ------- | ----------------- |
| Misspelled unknown command | `{beats_dtime: …}`, `{Titel: …}` | Renames it to the closest known command (`{beats_time: …}`, `{title: …}`). It acts only when there is a single, very close candidate and the name has at least 4 letters; any trailing comment on the line is left untouched. |
| `{beats_time:}` not matching the chord line | `{beats_time: Em=4 …}` above `[Em-]…` | Rewrites the directive according to the chords of the text, which is taken as authoritative. |

For `{beats_time:}` the exact behaviour is:

- if the chord count is the same, only the differing chords are renamed; beat counts and spacing stay as they were;
- if the count differs, the two sequences are aligned: shared chords keep their beats, added chords get `=1`, and chords no longer in the text are removed (it is worth re-checking the total number of beats);
- **one error is reported per directive**, even when several chords differ: the message names the first and shows both full sequences, and **Fix** aligns them all at once.

> **Note** — Because the fix adapts `{beats_time:}` to the text, if the mistake was actually in the text (for example `[Em]` instead of `[Em-]`), press <kbd>Ctrl</kbd>+<kbd>Z</kbd> and correct the chord by hand.

> **Note** — Two problems on the same line may appear one at a time: a misspelled command (`{beats_dtime}`) prevents the coherence check until it is renamed. After the first click on **Fix** the other error appears by itself, already selected.


### Spell Check (<kbd>F6</kbd>)

Songpress++ includes a **spell checker** based on the **Hunspell** engine (via the PyEnchant library) that checks **only the sung lyrics**: chords inside `[ ]` and directives inside `{ }` are skipped, so a chord name or a directive is never flagged as an error. Words containing digits are ignored as well.

Spell checking is available through three commands in the **Tools** menu:

| Command | Shortcut | Function |
| --- | --- | --- |
| **Spell check…** | <kbd>F6</kbd> | Opens the correction dialog that steps through errors one by one |
| **Live spell underline** | — | Toggles the **red squiggle** under misspelled words, updated as you type |
| **Spell check options…** | — | Default language, underline at startup, colour, personal dictionary, dictionary installation |

#### Chords Inside Words (`sal[LA-]varmi`)

In the ChordPro format a chord can fall **in the middle of a word**. By default Songpress++ **reassembles** the word before checking it, treating the chord as invisible:

```chordpro
sal[LA-]varmi     →  checked as “salvarmi”
can[DO]-tare      →  checked as “cantare”
```

Hyphens `-` and underscores `_` used for syllabification or joining are removed during reassembly. Conversely, a chord **preceded or followed by a space** separates two distinct words (`When [Am]arriving` → “When”, “arriving”).

This behaviour is controlled by the **“Merge words split by inline chords”** checkbox in *Spell check options…*. Turning it off restores the classic behaviour, in which an inline chord splits the word into two tokens (`sal` + `varmi`), producing false errors.

#### Correction Dialog (<kbd>F6</kbd>)

The **Spell check** dialog works like the one in mainstream word processors: it shows one misspelled word at a time, with a list of suggestions and the number of errors still to correct. The matching word is selected and scrolled into view in the editor.

| Button | Action |
| --- | --- |
| **Ignore** | Skips this occurrence |
| **Ignore all** | Ignores every occurrence of the word for the current session |
| **Add to dictionary** | Saves the word to the personal dictionary (permanently) |
| **Change** | Replaces it with the selected suggestion (or with the text typed in the field) |
| **Change all** | Replaces every occurrence of the word |
| **Close** | Closes the dialog |

The **language** field at the bottom of the dialog lets you switch the checking language on the fly. You can also correct the word **by hand**, typing it in the text field before pressing *Change*; double-clicking a suggestion is equivalent to *Change*. If the document contains no errors, the “spell check complete” message appears directly, without opening the dialog.

#### Live Red Squiggle

With **live underlining** enabled, unrecognized words are underlined by a squiggle (red by default) that updates automatically as you type, with a short delay (~350 ms) so it does not slow down typing. The squiggle colour is customizable in *Spell check options…*.

#### Spell Check Options

The **Spell check options…** panel gathers all settings:

| Option | Description |
| --- | --- |
| **Enable spell checking** | Master switch for the feature |
| **Default language** | Language used at startup and by the live squiggle |
| **Underline misspelled words at startup** | Turns the live squiggle on automatically when the program opens |
| **Merge words split by inline chords** | Reassembles words such as `sal[LA-]varmi` (see above) |
| **Underline colour** | Squiggle colour (red by default) |

Settings are saved and persist between sessions.

#### Personal Dictionary

Words added with **Add to dictionary** are saved, one per line, in a plain text file that can also be edited by hand:

| System | Path |
| --- | --- |
| **Linux/Debian** | `~/.config/songpress/user_dict.txt` |
| **Windows** | `%APPDATA%\Songpress\user_dict.txt` |
| **macOS** | `~/Library/Application Support/Songpress/user_dict.txt` |

From the *Spell check options…* panel the **Open…** and **Empty** buttons let you open the file in the system editor or clear it, respectively.

#### Installing Dictionaries

The engine needs **Hunspell** dictionaries (pairs of `.aff` + `.dic` files) for each language.

- **On Linux/Debian** it is best to install the system dictionaries, for example:
  ```
  sudo apt install hunspell-it hunspell-en-us
  ```
- **On Windows** the dictionaries are not present in the system: install them directly from the program with the **Install dictionaries…** button (in *Spell check options…*).

The **Install dictionaries** window shows the already-installed languages and those available to download, and downloads the `.aff`/`.dic` pairs from open-source repositories (mainly the **LibreOffice** project). The new language is usable **immediately, without restarting** the program. Dictionaries downloaded by the user can be removed with **Uninstall**; system dictionaries, marked as *[system]*, are never touched.

Languages available in the catalog: Italian, English (US/UK), Spanish, Portuguese (PT/BR), German, Dutch, Polish, Russian, Danish, Czech, Hungarian, Greek, Croatian, Slovenian, Romanian, and Latin.

> **Note — engine not available** — Spell checking requires the **PyEnchant** library (`pip install pyenchant`). If it is not installed, the feature is disabled without blocking the program: on first use a message appears with instructions for installing it.


### Copy AI beats_time Prompt (<kbd>Ctrl</kbd>+<kbd>Shift</kbd>+<kbd>B</kbd>)

**Tools › Copy AI beats_time prompt**

Copies to the clipboard a **ready-to-paste prompt** for an AI assistant, asking it to add `{beats_time:}` directives to the current song file by reading a PDF score. The AI analyses the score, calculates the beat duration of each chord, and returns the `.crd` file with the directives already inserted.

**How it works:**

1. Open the song file (`.crd`, `.cho`, `.chordpro`, etc.)
2. Choose **Tools › Copy AI beats_time prompt** or press <kbd>Ctrl</kbd>+<kbd>Shift</kbd>+<kbd>B</kbd>
3. Open your preferred AI assistant (see below)
4. Attach the PDF score and the song file
5. Paste the copied prompt and send

If the PDF score has a different name than the song file, edit it in the prompt before sending. The song filename and the PDF name are filled in automatically from the open document; the PDF name is assumed to be the same as the song file with a `.pdf` extension.

**Prompt structure copied to the clipboard:**

```
Add beats_time to MySong.crd using the score MySong.pdf.
The eighth note equals 1 beat. The beats_time must be written before the
chord line, example:
`{beats_time: DO=2 SOL=2 RE-=2 LA-=2}` / `[DO]Ecco[SOL]mi, [RE-]ecco[LA-]mi!`
```

**Compatible AI assistants**

Any AI assistant capable of reading PDF and text files is suitable. The following are a few examples — this list is not exhaustive and does not constitute a recommendation:

| Assistant | Address | Notes |
| --------- | ------- | ----- |
| Claude (Anthropic) | [claude.ai](https://claude.ai) | Supports PDF and text file attachments; free plan available |
| ChatGPT (OpenAI) | [chatgpt.com](https://chatgpt.com) | Supports PDF and text file attachments; free plan available |
| Gemini (Google) | [gemini.google.com](https://gemini.google.com) | Supports PDF attachments; free plan available |
| Copilot (Microsoft) | [copilot.microsoft.com](https://copilot.microsoft.com) | Built into Windows 11 and Microsoft 365 |

> **Note** — If no song file is open, a warning dialog is shown. Open the file first, then use the command.

### Song Statistics (<kbd>F8</kbd>)

**Tools › Song Statistics…** opens a summary dialog that analyzes the open document and provides an instant difficulty rating.

#### Dialog Sections

| Section | Information shown |
|---|---|
| **Structure** | Number of verses, choruses, bridges and estimated pages |
| **Lyrics** | Active lyrics lines and word count (chords and directives excluded) |
| **Chords** | Total chords, unique chords and percentage of complex chords (7th, dim, aug, sus, add…) |
| **Metadata** | Key, tempo BPM, time signature, capo and duration (if present in the file) |

#### Difficulty Rating

The dialog shows a **1-to-5-star** rating based on a 0–100 score calculated automatically:

| Stars | Verdict | Conditions |
|---|---|---|
| ★★★★★ | Excellent for beginners | ≤ 12 unique chords, no complex chords |
| ★★★★☆ | Accessible | Few complex chords or simple structure |
| ★★★☆☆ | Intermediate | Moderately complex chords |
| ★★☆☆☆ | Advanced | Many complex chords or elaborate structure |
| ★☆☆☆☆ | Very difficult | Song with no chords or very complex chords |

The bar below the stars displays the raw score (0–100).

#### Duration

The dialog shows the song duration in the **Metadata** section with two distinct modes:

- **Declared duration** — if the file contains a `{duration:MM:SS}` directive on an active line (not commented out with `#`), that value is used and the statistics row is labelled **«Duration»**.
- **Estimated duration** — if `{duration:}` is absent or commented out (`#{duration:12:45}`), the dialog calculates an approximate estimate from the `{tempo:}` and `{time:}` directives, by multiplying the number of chord changes by the duration of each beat. The row is labelled **«Estimated duration»**.

> **Note** — The automatic estimate is indicative: it does not account for repeats, multiple choruses or pauses. Adding `{duration:MM:SS}` with the actual playing time of the song displays a precise value in the statistics.

### Screen Ruler (<kbd>F9</kbd>)

**Tools › Screen ruler…** measures, in pixels (or other units), the width and height of anything visible on screen: the real height of a text in the preview, the distance between two lines, the space above chords, a page margin.

When started, Songpress++ captures an image of the screen and shows it full screen; a small toolbar with the measuring modes and options appears at the top. Measurements are taken on that image, so what you see does not change while the ruler is open.

#### Measuring modes

On the toolbar each mode is an icon button: square with corner dots (*Bounds*), cross (*Spacing*), horizontal double arrow (*Horizontal*) and vertical double arrow (*Vertical*). Hovering over a button shows its name and description. If you prefer written names, choose **Options › General › Screen ruler › Mode buttons › Text labels**; the choice is saved and takes effect the next time the ruler is opened.

| Mode | Key | How to use it |
|---|---|---|
| **Bounds** | <kbd>1</kbd> | Drag a rectangle with the mouse: its *width × height* is shown. |
| **Spacing** | <kbd>2</kbd> | No dragging: a cross starts from the cursor and stops at the first edges to the left, right, top and bottom. Measures the uniform space around the cursor. |
| **Horizontal** | <kbd>3</kbd> | Like *Spacing*, horizontal only. |
| **Vertical** | <kbd>4</kbd> | Like *Spacing*, vertical only. |

In **Horizontal** and **Vertical** modes the cross-shaped mouse pointer is hidden so it does not cover the measured spot: the position is shown by the measuring line itself. The pointer reappears over the toolbar.

#### Toolbar options

The *Fit to content*, *Show cross*, *Smooth zoom* and *High resolution* checkboxes appear side by side on the toolbar or, if **In a list** is chosen in **Options › General › Screen ruler › Options**, in a vertical list opened by the list button on the toolbar. The list stays open while you toggle the checkboxes and closes when you click elsewhere, press <kbd>Esc</kbd> or press the button again. The <kbd>F</kbd>, <kbd>C</kbd>, <kbd>S</kbd> and <kbd>H</kbd> keys work in both cases.

| Option | Function |
|---|---|
| **Fit to content** | *Bounds* mode only. The dragged rectangle automatically shrinks around the content that differs from the background. The original rectangle stays visible as a grey dashed outline. On by default (key <kbd>F</kbd>). |
| **Show cross** | Shows or hides the measuring cross: the dashed lines following the cursor in *Bounds* mode and the orange lines with end ticks in *Spacing*, *Horizontal* and *Vertical* modes. When hidden, only the measurement label remains visible, which avoids covering the text being measured. The setting is remembered until Songpress++ is closed (key <kbd>C</kbd>). |
| **Tolerance** | Maximum colour difference (0–255) beyond which a pixel is treated as an edge. Low values make the measurement sensitive to shading (antialiasing); high values ignore small variations. Default: 30. The value is remembered and is the same as **Options › General › Screen ruler › Tolerance**, where you can also choose not to show the field on the toolbar. |
| **Unit** | `px`, `pt`, `mm`, `cm`, `in` (key <kbd>U</kbd> cycles to the next one). |
| **Smooth zoom** | While zoomed, enlarges the view with bicubic interpolation: pixels no longer appear as squares, but edges become blurred. Off by default, because sharp pixels are clearer for measuring. The setting is remembered until Songpress++ is closed (key <kbd>S</kbd>). |
| **High resolution** | HiDPI screens only (scaling above 100%). The magnified view uses all the physical pixels of the screen instead of the logical pixels, so icons and text show more detail. On by default; at 100% the checkbox is disabled (greyed out) because there are no extra pixels. The setting is remembered until Songpress++ is closed (key <kbd>H</kbd>). |
| **Zoom − / +** | Magnifies the view around the cursor, from 1× to 8× in steps of 1. See *Magnification* below. |
| **✕** | Closes the ruler (same as <kbd>Esc</kbd>). |

#### Magnification

To measure small elements precisely (a chord, the thickness of a line, the gap between two letters) you can magnify the view with <kbd>+</kbd>, <kbd>Ctrl</kbd>+mouse wheel or the **− / +** toolbar buttons. Zooming happens around the cursor, from 1× to 8× in steps of 1, and every screen pixel becomes a clearly visible square, with no smoothing. The ruler toolbar does not change size: only the captured image is magnified.

The magnified image cannot contain more detail than the screen itself: a 16×16 pixel icon, magnified, shows its 256 squares. The toolbar offers two **view-only** checkboxes for a different look, also toggled with the <kbd>S</kbd> and <kbd>H</kbd> keys:

- **Smooth zoom** — removes the blocky look by smoothing colour transitions; the image looks smoother but less sharp.
- **High resolution** — on HiDPI screens (for example at 150% or 200% scaling) the screen has more physical pixels than the logical pixels used for measuring: with this option the magnified view uses them all and shows finer real detail.

The two options can be combined.

Zoom **changes only the view, not the measurement**: a text 12 pixels high is always reported as `12 px`, at 1× as well as at 8×, with or without *Smooth zoom* and *High resolution*. The arrow keys also always move the cursor by 1 real pixel.

| Action | Effect |
|---|---|
| <kbd>+</kbd> / <kbd>-</kbd> or <kbd>Ctrl</kbd>+mouse wheel | Zooms in / out around the cursor |
| <kbd>0</kbd> | Back to the 1:1 view |
| Mouse wheel (while zoomed) | Scrolls the view vertically; with <kbd>Shift</kbd> horizontally |
| Middle-button drag | Moves the magnified view |
| Arrow keys past the edge | The view scrolls automatically |

#### Measuring the height or width of a text

1. Open the ruler with <kbd>F9</kbd>.
2. Keep **Bounds** mode with **Fit to content** enabled.
3. Drag a generous rectangle around the word or line, including some background on every side.
4. The rectangle shrinks around the letters by itself and shows, for example, `212 × 17 px`: 212 is the text width, 17 the height from the highest ascender to the lowest descender actually present.

To measure the **space between two lines**, use **Vertical** mode instead and place the cursor in the empty space between the lines.

#### Controls

| Action | Effect |
|---|---|
| Left click | Pins the current measurement (it stays drawn in blue) and copies it to the clipboard, e.g. `212 × 17 px` |
| Right click | Clears pinned measurements; if there are none, closes the ruler |
| <kbd>Ctrl</kbd>+<kbd>C</kbd> | Copies the current (or last pinned) measurement to the clipboard |
| <kbd>←</kbd> <kbd>→</kbd> <kbd>↑</kbd> <kbd>↓</kbd> | Moves the cursor by 1 pixel (10 pixels with <kbd>Shift</kbd>) |
| <kbd>C</kbd> | Shows / hides the measuring cross |
| <kbd>S</kbd> | Toggles *Smooth zoom* |
| <kbd>H</kbd> | Toggles *High resolution* (HiDPI screens only) |
| <kbd>+</kbd> / <kbd>-</kbd> / <kbd>0</kbd> | Zoom in / out / back to 1:1 |
| <kbd>Del</kbd> / <kbd>Backspace</kbd> | Clears pinned measurements |
| <kbd>Esc</kbd> | Cancels the drag in progress or closes the ruler |

> **Note — physical units** — Values in `mm`, `cm`, `pt` and `in` are computed from the DPI reported by the operating system (often 96 on Linux) and are exact only if that value matches the monitor's real resolution. Pixel measurements are always precise. To measure the printed size of an element, use the preview at 100% zoom.

> **Note — Linux / Wayland** — On Wayland applications cannot read the screen directly. Songpress++ tries, in order: **grim** (Sway/wlroots) or **spectacle** (KDE) if installed, then the **xdg-desktop-portal**, available out of the box on GNOME and KDE, and finally **gnome-screenshot**. With the portal nothing needs to be installed: on first use the desktop may ask for permission to capture the screen; if you deny or cancel it, the ruler does not open. On X11 and Windows nothing extra is needed. With HiDPI scaling enabled, measurements are expressed in logical pixels; the **High resolution** option uses physical pixels only for the magnified view.

### Directive Intellisense (`Ctrl+Space`)

Pressing `Ctrl+Space` while the cursor is inside a pair of curly braces `{…}` opens a pop-up list of all ChordPro directives supported by Songpress++. Selecting an entry from the list (with `Enter` or double-click) inserts the directive at the correct position.

While you scroll through the list, a small **tooltip** appears next to the current line with a short description of the highlighted directive and, where useful, a usage example (for instance `taste` and `fingering` list their available options). Directives without a description show no tooltip.

**Options inside an already written directive.** When the cursor is *after* the name of a directive that has options, `Ctrl+Space` offers the options still missing instead of the directive list. Example: with `{taste:SOL start=SI |}` it shows `octave=`, `hand=` and `middlec=` (options already present, such as `start=`, are not offered again). Choosing an option with predefined values, such as `middlec=`, immediately opens a second list with the values (`show`, `hide`, …). Available options:

| Directive | Options |
|---|---|
| `taste`, `fingering` | `start=`, `octave=`, `hand=`, `middlec=` |
| `start_of_grid` (`sog`) | `size=`, `chordtopspacing=`, `linespacing=`, `sizedir=` |
| `image` | `width=`, `height=`, `scale=`, `align=`, `border=`, `left`, `center`, `right` |
| `linespacing` | `rel` |

Options and their values (for instance `R`/`L`, `octave=`, `middlec=`) also have a short descriptive tooltip.

This feature can be enabled or disabled in **Tools → Options… → General tab → Enable directive intellisense (Ctrl+Space)**.

---

## Musical Symbols Unicode — Dialog

The **Musical Symbols** dialog (`Insert › Musical symbol (Unicode)…`, `Ctrl+Shift+M`) lets you insert any special Unicode musical character into the editor, including symbols from the **Musical Symbols** block (U+1D100–U+1D1FF) and common BMP characters.

### Dialog Structure

The dialog is organized into **six tabs** by category:

| Tab | Contents |
| ---------------------------- | ------------------------------------------------------------------ |
| **Notes and rests** | Notes from breve to 128th, noteheads, rests of every value and multi-measure rest (U+1D13A–U+1D164) |
| **Accidentals** | Sharp, flat, natural, double accidentals, quarter-tone and microtonal (raised/lowered) accidentals |
| **Dynamics** | *p*, *m*, *f* and compounds (*pp*, *mp*, *mf*, *ff*, *sf*, *sfz*, *fp*…), rinforzando, crescendo/decrescendo |
| **Staff and clefs** | Clefs (treble, bass, C clef, with octave variants), barlines, repeats, *segno*, *coda*, *dal segno*, *da capo* |
| **Ornaments and articulations** | Fermata, breath mark, caesura, trills, turns, grace notes, slurs and phrases |
| **Common (BMP)** | ♩ ♪ ♫ ♬ ★ † ½ ¼ × – — … and other common characters |

### How to Insert a Symbol

1. Open the dialog with `Insert › Musical symbol (Unicode)…` or `Ctrl+Shift+M`.
2. Select the tab for the desired category.
3. **Click** a cell to select the symbol — the enlarged preview and description with the Unicode codepoint (e.g. `U+1D157`) appear at the bottom.
4. Press **Insert** or **double-click** the cell to insert the character at the cursor and close the dialog.
5. Press **Close** (or `Esc`) to cancel without inserting anything.

> **Tip** — Hovering over cells shows a tooltip with the symbol name and codepoint.

### Insertion Options

At the bottom of the dialog there are two options that control how the symbol is inserted into the editor. Their state is saved automatically and restored the next time the application is opened.

**Custom size (pt)** — checkbox + numeric field (6–144)

When enabled, the symbol is wrapped with `{textsize:N}` and `{textsize}` directives to apply the chosen point size and then restore the original. The second `{textsize}` without an argument is the correct reset form (unlike `{textsize:}` with a trailing colon, which is a syntax error detected by the syntax checker).

| Checkbox | Inserted text |
| -------- | ------------- |
| off | `♩` |
| on (pt = 24) | `{textsize:24}♩{textsize}` |

> **Note** — Not all symbols can be resized: SMP-plane characters (U+1D100–U+1D1FF) require a font with adequate coverage (FreeSerif, Bravura, etc.) in the `fonts/` folder. If the font does not cover the glyph, the size is applied but the character may not be visible.

**Wrap symbol in a verse block (not counted)** — checkbox

When enabled, the symbol is enclosed in a `{start_verse}…{end_verse}` block. It then appears in the preview as a standalone verse block, but is **not counted** in the sequential verse numbering — adjacent verses keep their correct numbers.

| Checkbox | Inserted text |
| -------- | ------------- |
| off | `♩` |
| on | `{start_verse}♩{end_verse}` |

Both options can be combined: if both are active, the result is:

```chordpro
{start_verse}{textsize:24}♩{textsize}{end_verse}
```

The same settings are also accessible from **Preferences → Format → Musical symbol insertion**, where they are saved permanently.

### SMP and BMP symbols — what's the difference

The characters offered by the dialog belong to two Unicode families that Songpress++ handles very differently. Knowing which family a symbol belongs to explains why some behave like ordinary text while others need a dedicated font.

| | **BMP** (Basic Multilingual Plane) | **SMP** (Supplementary Multilingual Plane) |
| --- | --- | --- |
| **What they are** | Characters with codepoint ≤ U+FFFF | Characters with codepoint > U+FFFF |
| **Examples** | ♩ ♪ ♫ ♬ ★ † ½ ¼ × – — … | 𝄞 𝄢 and the other glyphs of the *Musical Symbols* block (U+1D100–U+1D1FF) |
| **Where in the dialog** | **Common (BMP)** tab | *Notes and rests*, *Accidentals*, *Dynamics*, *Staff and clefs*, *Ornaments and articulations* tabs |
| **Font coverage** | almost every system font contains them | common fonts (Arial, Times, Calibri) do **not** cover them: a dedicated font is needed (FreeSerif, bundled) |
| **How they are rendered** | **directly with the song font**, exactly like a letter | through a **separate drawing path** (GDI+/`GraphicsContext` in the preview, FreeType/Pillow rasterization in print) |
| **Resizable with `{textsize:}`** | yes, always | yes, but only if the font covers the glyph |
| **Vertical alignment** | natural (they are normal text) | the glyph tends to sit higher: adjust it with **Symbol vertical drop (%)** in the Options |

In short: a **BMP** symbol is a text character in every respect — it scales, prints and aligns like the letters next to it, with no special handling. An **SMP** symbol is "real" musical notation that ordinary fonts don't contain, so Songpress++ draws it separately with FreeSerif.

In the dialog, the description of the selected symbol (at the bottom) states which plane it belongs to, so you immediately know whether it needs the dedicated font.

> **Symbol vertical drop (%)** — Because SMP glyphs are drawn with a separate path, they tend to appear slightly higher than the letters. The **Preferences → Format → Musical symbol insertion → Symbol vertical drop (%)** option lowers them until they line up with the text row, updating the preview in real time. At **0** the symbol stays in its raw position, the default **~5** aligns it to the row; higher values lower it further. BMP symbols are unaffected.

Symbols in the Musical Symbols block (U+1D100–U+1D1FF) belong to the Unicode **Supplementary Multilingual Plane** (SMP, codepoints > U+FFFF). Common system fonts (Arial, Times New Roman, Calibri) do not cover this range; Songpress++ solves this in two distinct ways:

**In the editor (text panel)** — the editor uses the **DirectWrite** rendering engine (`SetTechnology(STC_TECHNOLOGY_DIRECTWRITE)`), which enables automatic Windows font-fallback: if the chosen editor font does not contain the glyph, Windows automatically searches among installed fonts for a suitable one.

**In the preview and print** — the renderer uses **GDI+** via `wx.GraphicsContext` exclusively for SMP characters. For every string containing at least one codepoint > U+FFFF, Songpress++ creates a separate graphics context and sets the font in the following priority order:

1. **FreeSerif** (GNU FreeFont) — complete coverage of the Musical Symbols block; must be present at `<install>/fonts/FreeSerif.ttf`.
2. **Segoe UI Symbol** — included by default on Windows 10/11; partial SMP coverage.
3. Current document font — used as a last resort (will show boxes for missing glyphs).

Normal text (chords, song text, titles) continues to use the classic GDI renderer with no additional overhead.

### How to Change Symbol Size in the Preview

Musical symbols are rendered at the same size as the surrounding text, automatically scaled according to:

- **Global song font** — changeable via `Format › Song font…`. Increasing the point size of the main font proportionally increases SMP symbols as well.
- **`{textsize:Pt}` directive** — inserted directly in the ChordPro text before the symbol, sets the point size for that span. Example:

  ```chordpro
  {textsize:24}𝄞{textsize}
  ```

  The second `{textsize}` (without argument) restores the default size.

- **`{textsize:N%}` directive** — percentage version, relative to the document's base size. Example for a symbol at 150%:

  ```chordpro
  {textsize:150%}𝅘𝅥𝅮{textsize}
  ```

- **Preview zoom** — the zoom slider in the preview toolbar scales the whole page (text + symbols) without modifying the file. It does not affect printing.

> **Technical note** — The renderer automatically multiplies the font's point size by the current zoom factor before creating the `wx.GraphicsFont`, so SMP symbols always maintain the same proportions as the surrounding GDI text.

### Adding Custom Symbol Libraries

Songpress++ automatically loads **all** `.ttf` files found in the `fonts/` folder inside the installation directory. To add support for new Unicode symbols, simply copy the font file into that folder — no additional configuration is required.

```
<installation>/
  fonts/
    FreeSerif.ttf           ← included — complete Musical Symbols coverage
    Bravura.ttf             ← SMuFL font (professional music notation)
    NotoMusic.ttf           ← Google Noto — broad SMP coverage
    SegoeUISymbol.ttf       ← optional local copy of Segoe UI Symbol
    any_other.ttf           ← loaded and used automatically
```

**Priority order** — Fonts are tried in the following order:

1. `FreeSerif.ttf` — highest priority (guaranteed Musical Symbols coverage)
2. `Bravura.ttf` — if present
3. `NotoMusic.ttf` / `NotoMusicRegular.ttf` — if present
4. All other `.ttf` files in the folder, in alphabetical order
5. **Segoe UI Symbol** — Windows 10/11 system font (automatic fallback, no file to copy)
6. Current document font — last resort (will show boxes for missing glyphs)

For each SMP character, Songpress++ walks this list and uses the first font that wx can load successfully. If a font does not cover a particular glyph, GDI+ does not perform further automatic fallback — the correct font must therefore be present in the `fonts/` folder.

> **Tip** — **SMuFL** fonts (Standard Music Font Layout, <https://www.smufl.org>) such as Bravura, Petaluma or Leland cover hundreds of specialized musical symbols not included in FreeSerif. For Gregorian or mensural notation, fonts such as **Caeciliae** or **Volpiano** are recommended.

---


## Read-only mode

**Read-only mode** protects a song from being overwritten: the text stays **editable** (you can try a transposition, change chords, rewrite a verse), but you cannot save it under the same name as the open file. To keep your changes you must choose a **different name**, and the original file stays untouched. It is useful, for example, when you start from a finished song or from a template and want to adapt it without risking the original with a careless save.

### How to turn it on

- **File → Read only**: turns the mode on or off. The icon of the item shows the state: **open** padlock = mode off, **closed** padlock = mode on.
- **Button in the Standard toolbar** (padlock, just before *Options*): one click turns the mode on or off; while the mode is on the button looks pressed. You can hide it from **Tools → Options → Toolbars → Standard**.
- **Icon in the status bar** (bottom right): one click turns the mode on or off.
- **Automatic on opening** — every time a file is opened, Songpress++ checks whether it is write-protected (the Windows "Read-only" attribute, or permissions without write access on Linux, for example after `chmod -w`). If it is, the mode turns on by itself; if the file is writable, the mode is turned off. The templates shipped with the program are excluded from this check, because their saves are already redirected to the user's copy.

> **Note** — For a **new** song that has not been saved yet there is no file to protect: if you turn the mode on, it turns itself off on the first save.

### How to tell it is on

- The window title ends with **[Read only]**.
- The Standard toolbar button looks pressed and shows the closed padlock.
- The status bar shows the closed padlock; hover it to read whether the mode is on or off.
- In the **File** menu the *Read only* item shows the closed padlock.

### What happens when you save

With the mode on, **Save**, **Save as** and the "Do you want to save it?" prompt that appears when you close the program or open/create another song all go through the same procedure:

1. The **Save as** dialog opens, because the name of the open file cannot be used.
2. If you choose **the same name** as the open file, the message *"Read-only mode is on: this file cannot be overwritten. Choose a different file name."* appears and the dialog opens again.
3. If you choose a **different name**, the song is saved under that name. From then on the open song is the **new file**, the mode turns off and later saves are normal. The original is not touched.
4. If you **cancel**, nothing is saved: the song stays modified and read-only. If you cancel while closing the program, the closing is interrupted.

> **Note** — Read-only is a protection inside the program: it does not change the file permissions on disk, and it does not prevent saving the same text with another program. On Linux, running Songpress++ as *root* makes every file writable, so automatic read-only opening does not trigger; the menu item, the button and the status bar icon still work.

## Single Instance Mode

**Path:** *Options → General 2 → General → Single instance: open files in the existing window*

When this option is enabled (default: **on**), Songpress++ operates in **single-instance mode**: opening a file from Windows Explorer, from the command line, or by double-clicking a `.crd` / `.cho` / `.chordpro` file always routes the file to the **already-running window** instead of launching a new process.

### How it works

1. When Songpress++ starts, it opens a **local socket** on port 47833 (localhost only, invisible to the network).
2. If a second invocation is triggered (e.g. double-clicking another file), the new process detects the listening socket, **sends the file path** to the running instance, and exits immediately.
3. The running window receives the path, **brings itself to the front**, and opens the file as if the user had used *File → Open*.

The entire handshake is silent: no dialogs or notifications appear during normal operation.

### Error cases

| Situation | Behaviour |
|---|---|
| File passed on the command line does not exist | An error dialog is shown before the application exits |
| No instance is listening (first launch, or previous instance crashed) | Songpress++ starts normally and becomes the new single instance |

### Pros and cons

| ✅ Advantages | ⚠️ Disadvantages |
|---|---|
| Avoids accidental proliferation of windows when opening multiple files from Explorer | Only one song can be open at a time per window (unless the file contains multiple `{new_song}` blocks) |
| Preserves layout, zoom level, and editor state of the existing window | If you deliberately want two independent windows (e.g. to compare two songs side by side), you must **disable** this option |
| Consistent with the behaviour of most professional editors (VS Code, Notepad++, Sublime Text) | Requires TCP port 47833 to be available on localhost; conflicts are extremely unlikely but possible in very restricted environments |
| Opening a file brings the window to the front automatically, without user intervention | |

### When to disable it

Uncheck *Single instance* if you need to:

- Work on **two or more songs simultaneously** in separate, independent windows.
- Run Songpress++ in a **multi-user terminal / RDS** environment where each session must be fully isolated.
- Troubleshoot a port conflict (check `startup.log` in `%LOCALAPPDATA%\Songpress++\` for diagnostics).

> **Note — startup.log** — Every single-instance event is logged in `%LOCALAPPDATA%\Songpress++\startup.log` (Windows) or `~/.Songpress++/startup.log` (Linux/macOS). The log records the config path read, the value of the `singleinstance` key, whether an existing instance was found, and whether the file was forwarded successfully. This is the first place to look when troubleshooting multiple-window behaviour.

---
## New from template — creating a song from a model

**File → New from template** opens a submenu listing the available song templates (`.crd` files). Picking one loads its content into a **new document**, ready to customise.

### How to use it

1. Open **File → New from template**.
2. Choose a template from the list (sorted alphabetically by name).
3. The template's content is placed into a **new, untitled document**, exactly like **New**: the title bar shows *Untitled* and the song is marked as «modified».
4. The first **Save** behaves like **Save As**: you choose the name and location.

The template file is **never overwritten**: the one you pick is only the starting point of the new song.

### Where templates come from

Templates are the `.crd` files inside `templates/songs`. Songpress++ looks in two folders:

- **package** — the `templates/songs` shipped with the application (the sample templates);
- **user** — the `templates/songs` inside the user data folder, where you put your own.

When two files share the same name, the **user copy wins**. If no template is found, the menu shows the disabled entry **(no template available)**.

### Adding or editing a template

- **Add your own**: drop a `.crd` file into the user templates folder. The quickest way is **Tools → Options → General → Open templates folder**, then go into `songs/` and copy your file there (or use *Save As* straight into it). The file name is what shows up in the menu.
- **Edit an existing one**: open it, change it and save. The changes are used immediately, because the template's content is re-read from the file every time you select it.

> **The list refreshes itself.** The submenu is rebuilt every time you open the **File** menu: templates added, renamed or deleted show up **right away**, without restarting the application. The *Open templates folder* button opens exactly the user folder the app reads from, so whatever you add or edit there becomes available at once.

---
## Options Window — Complete Reference

Opened from **Tools → Options…** (window title: *Songpress++ options*). It is a resizable tabbed dialog (minimum size 730 × 800 px).

### Buttons shared by all tabs

| Button | Function |
| ------ | -------- |
| 📌 **Pin** | Keeps the dialog open after pressing OK: preferences are saved and applied immediately, but the window stays available for further changes. Very handy when tuning colours and spacing while watching the preview update. |
| **OK** | Saves all preferences (`Preferences.Save()`) and closes the window. |
| **Cancel** | Closes without saving. Interactive previews (syntax colours, editor background…) are discarded. |

> **Restarting Songpress++** — Some settings only take effect after a restart; in practice the only one is the **interface language**. Songpress++ can restart itself: it saves the preferences, closes the current window and reopens automatically. If the song has unsaved changes, Songpress++ asks **first** whether to save them: pressing **Cancel** stops the restart and no second window is opened. The new instance starts only after the current one has closed successfully. There are two ways to trigger it:
>
> - **Language change.** When you pick a different language (**Language** field, *Song* group below) and confirm, a message appears with two buttons: **OK** (the new language is applied at the next launch) and **Restart now** (restarts Songpress++ immediately, applying the language right away).
> - **File menu → 'Restart Songpress++'.** A quick-restart item, available at any time without having to close and reopen the app manually (it can be shown/hidden from the *General* group below).
>
> The automatic restart works whether Songpress++ was launched from the desktop menu or from a terminal. Every other option takes effect at once, without a restart.

> **Technical note (Linux) — how the automatic restart works.** To make the new instance survive the exit of the old one, Songpress++ picks the launch method based on *how* it was started, telling the cases apart by the presence of a controlling terminal (tty):
>
> - **Desktop menu (KDE/GNOME, no tty)** — the app runs inside a transient systemd *scope* that would be torn down on its exit, killing the child process; the new instance is therefore started in a fresh, independent scope with `systemd-run --user --scope` (and with `argv[0]` made absolute). → reopens.
> - **Interactive terminal (tty)** — the classic detach is enough (`setsid`, i.e. `start_new_session`): there is no scope to tear down. → reopens as before.
> - **Terminal with redirected streams** (e.g. `songpress++ >log 2>&1 </dev/null &`, no tty) — the `systemd-run` branch is used; thanks to the absolute `argv[0]` the restart holds even if the working directory changes.

---

### *General* tab

#### **Song** group

| Field | Default | Description |
| ----- | ------- | ----------- |
| **Default notation** | first in list | Chord notation used for new songs (Italian, English, German…). |
| **Default file extension** | `crd` | Extension proposed when saving. Values: `crd`, `pro`, `chopro`, `chordpro`, `cho`, `sng`. |
| **Language** | system language | Interface language, shown with a flag. **Requires a restart.** |

#### **General** group

| Command / option | Default | Description |
| ---------------- | :-----: | ----------- |
| **Clear recent files** (button) | — | Empties the recent-files list. The removal happens when you confirm with OK. |
| **Open templates folder** (button) | — | Opens the **user** templates folder (`templates/`, also used for colour themes) in the system file manager — the same one the app reads from. `.crd` files placed in `songs/` appear under *File → New from template* (see the *New from template* chapter). |
| **Enable 'Save' button only when the song is modified** | ✓ | Save (menu and toolbar) stays greyed out until there are unsaved changes. |
| **Enable the chord conversion commands only when needed** | ✓ | **Integrate chords**, **Convert Tab to ChordPro** and **Convert inline chords to ChordPro** stay greyed out when they have nothing to do (see *Chord Management*). When unchecked, they are always enabled. The value is saved on exit and restored at startup. |
| **Enable directive intellisense (Ctrl+Space)** | ✓ | Auto-completion of ChordPro directives in the editor. |
| **Enable multi-cursor (Alt+Click, Ctrl+D)** | ☐ | Alt+Click adds a cursor; Ctrl+D selects the next occurrence of the current word. |
| **Single instance: open files in the existing window** | ✓ | Files opened from Explorer or the command line reuse the existing window. See *Single instance mode*. |
| **Show 'Restart Songpress++' in the File menu** | ✓ | Adds a **Restart Songpress++** item to the **File** menu, for a quick restart without closing and reopening the app manually (see the *Restarting Songpress++* box above). |
| **Show the full file path in the title bar** | ☐ | Shows the **complete path** of the open file (e.g. `C:\Songs\ballad.crd`) in the title bar instead of just its name. For a new, unsaved song it still shows *Untitled*. The leading asterisk that marks unsaved changes is unaffected. |
| **Show debug messages (theme save path)** | ☐ | Shows diagnostic popups (e.g. where a theme file was written). Troubleshooting only. |
| **Save window size and position on exit** | ✓ | Restores the window geometry at the next launch. |
| **Replace spaces with '_' in saved file names** | ☐ | Whitespace in the file name (not the folder path) becomes an underscore when saving or exporting. |
| **Suggest the song {title:} as file name in 'Save as'** | ☐ | Proposes the title as the default file name, stripped of invalid characters. See *Saved File Names*. |
| **Toolbar icon size** | Small | Radio: **Small (16×16)**, **Medium (19×19)**, **Large (21×21)**. |

> Checkboxes in this group are sorted alphabetically according to the interface language, so the on-screen order may differ from the table.

#### **Screen ruler** group

Options for the *Screen ruler* (<kbd>F9</kbd>) toolbar. They take effect the next time the ruler is opened.

| Command / option | Default | Description |
| ---------------- | :-----: | ----------- |
| **Mode buttons** | Icons | Radio: **Icons** (16×16 icons, the name appears in the tooltip) or **Text labels** (the mode name on the button). |
| **Options** | Side by side | Radio: **Side by side** (the *Fit to content*, *Show cross*, *Smooth zoom* and *High resolution* checkboxes next to each other on the toolbar) or **In a list** (a button opens a vertical list with the same checkboxes instead; the toolbar becomes shorter). |
| **Keep icons at 16×16 real pixels** | ✓ | With display scaling above 100% (e.g. 150%) the toolbar icons are not enlarged: they stay sharp at 16×16 pixels but look smaller than the text. When disabled, they are enlarged like the other icons and may look slightly blurred. No effect at 100%. |
| **Tolerance** | 30 | Maximum colour difference (0–255) beyond which a pixel is treated as an edge. It is **the same value** as the *Tolerance* field of the ruler toolbar: if you change it on the toolbar, it is saved when the ruler closes and shows up here; if you change it here, the ruler opens with the new value. |
| **Show also in the "Screen ruler..." toolbar** | ✓ | When enabled, the *Tolerance* field is also shown on the ruler toolbar. When disabled, the tolerance can be changed only here and the toolbar becomes shorter. |

---

### *Editor* tab

#### **Editor font** group

| Field | Default | Description |
| ----- | ------- | ----------- |
| **Font** | system fixed-width font | Editor typeface (list with preview). |
| **Size** | 12 | Font size (7–20). |
| **Editor background colour** | `#FFFFFF` | Background of the writing area. |
| **Selection colour** | `#C0C0C0` | Background of selected text. |
| **Caret colour** | `#000000` | Colour of the insertion caret. |
| **Editor caption colour** | `#4682C8` | Title bar colour of the *Editor* AUI pane. |
| **Page caption colour** | `#329B82` | Title bar colour of the *Page* AUI pane. |

Each colour has three controls: the **hex** field (`#RRGGBB`, editable by hand), the **Pick…** button (system colour picker) and the **swatch** preview.

#### **Syntax colours** group

Controls ChordPro syntax highlighting in the editor. The preview at the bottom of the tab shows the result immediately on a sample song.

| Element | Default |
| ------- | ------- |
| **Normal text** | `#000000` |
| **Chorus** | `#000000` |
| **Chords** | `#FF0000` |
| **Commands** | `#0000FF` |
| **Attributes** | `#008000` |
| **Comments** | `#808080` |
| **Tab / Grid** | `#8B5A00` |

**Theme bar** — saves and reuses colour combinations:

- **Theme** (list) — themes available in the `templates/` folder.
- **Load** — applies the selected theme to the colour fields.
- **Save** — asks for a name and stores the current combination as a theme.
- **Delete** — removes the selected theme after confirmation.

The three buttons show a small 16×16 icon next to their label.

> **Note — choosing a theme.** Picking a theme from the list **does not apply it**: the colours change only when you press **Load**. As long as the selected theme differs from the applied one, an ℹ message appears below the bar: *"Theme changed: press "Load" to apply it."* It disappears after **Load**, **Save** or **Delete**. The ℹ icon follows the common info-icon rule: vector SVG `img/vector/info.svg` at 16×16 adapted to the DPI, then `img/info.png` as a fallback, then the system icon.

> With *Show debug messages* enabled, saving a theme also displays the full path of the file that was created.

---

### *AutoAdjust* tab

Controls the automatic fix-up offers made when opening or saving a song.

| Option | Default | Description |
| ------ | :-----: | ----------- |
| **Offer to remove blank lines** | ✓ | Offers to delete unnecessary blank lines. |
| **Offer to convert songs in tab** | ✓ | Offers to convert *chords-over-lyrics* format to ChordPro. |
| **Offer to transpose songs to simplify chords** | ☐ | Offers to transpose to the key with the simplest chord shapes. |
| **Level bar colour** | `#2980B9` | Colour of the bars in the simplification sliders below. |

Below, the scrollable **chord simplification** panel has one slider per chord group: it sets how "easy" that group is considered when Songpress++ looks for the optimal key.

---

### *Format* tab

#### **Title and structure** group

| Field | Default | Range |
| ----- | :-----: | ----- |
| **Title underline thickness** | 4 | 1–5 |
| **Verse number box thickness** | 1 | 1–5 |

#### **Chords and keyboard** group

| Field | Default | Description |
| ----- | ------- | ----------- |
| **Klavier key colour** | `#D23C3C` | Key highlight in the keyboard diagram. |
| **Different colour for the upper octave key** | off, `#3C78D2` | On 8-key keyboards, draws the rightmost key matching the first one in a second colour (e.g. high B on B…B). |
| **Keyboard size (%)** | 100 | Size of the keyboards at the bottom of the page (50–200). Lower values fit more of them on each row. Applies to preview and print; for a single song it can be changed for printing only (see *Print Options*). |
| **Finger number colour** | `#1A1A1A` | Colour of `{fingering:}` numbers. |
| **Chord arrow size (%)** | 90 | Size of the `[C^]` / `[Cv]` direction arrow, as a percentage of the chord height (30–150). |
| **Chord arrow position** | Next to the chord | Where to draw the direction arrow: *Next to the chord* (right after the name) or *Next to the beat count (if present)* (beside the `{beats_time:}` number, with the same alignment as the number). When the number is not visible the arrow stays next to the chord. The choice is saved. |
| **Custom colour for the up arrow** | off, `#2E7D32` | When on, the up arrow uses this colour; otherwise it uses the chord colour. |
| **Custom colour for the down arrow** | off, `#C03030` | When on, the down arrow uses this colour; otherwise it uses the chord colour. |

#### **Tempo** group

| Field | Default | Description |
| ----- | ------- | ----------- |
| **Tempo icon size** | 24×24 | Size of the `{tempo_*}` directive icons: 16×16, 24×24, 32×32. |

#### **Chord grid (`{start_of_grid}`…`{end_of_grid}`)** group

| Field | Default | Description |
| ----- | :-----: | ----------- |
| **Display mode** | Pipe | **Pipe table** (`\| C \| G \| Am \| F \|`), **Plain spacing** (chords spaced without pipes), **Table** (cells with drawn borders). |
| **Default label** | *Grid* | Label used when `{start_of_grid}` has no argument. `{start_of_grid: Intro}` overrides it. |
| **Space bar inserts the pipe `\|` separator (pipe mode)** | ✓ | Inside a grid block the space bar inserts a `\|`, shifting the current cell to the right. Disable it to type normal spaces. |
| **`size=N` affects** | Width and height | Whether `size=N` multiplies cell padding in **width and height**, **width only** or **height only**. |

#### **Musical symbol insertion** group

| Field | Default | Description |
| ----- | :-----: | ----------- |
| **Custom size when inserting musical symbols (pt)** | ☐ | When enabled, the symbol is wrapped in `{textsize:N}`…`{textsize:}` with the size chosen in the spin control (6–144, default 24). |
| **Wrap symbol in a verse block (not counted)** | ☐ | The symbol is wrapped in `{start_verse}`…`{end_verse}` so it is excluded from verse numbering. |
| **Symbol vertical drop (%)** | 5 | Lowers **SMP** symbols to line them up with the text row (0–25); 0 = raw position, ~5 aligns them (default). Updates the preview in real time. Does not affect BMP symbols. |

#### **Beat count (`{beats_time}`)** group

| Field | Default | Description |
| ----- | :-----: | ----------- |
| **Colour** | `#6464C8` | Colour of the beat number/dots. |
| **Font size (% of chord font)** | 60 | 30–150 %. |
| **Bold** | ☐ | Draws the number in bold. |
| **Position** | Right | Left / Center / Right relative to the chord name. |
| **Display mode** | Number | **Number**, **Dots** (between chords) or **Both**. |

---

### *Songpress++ Page* tab

Holds three groups already described in detail in the *Page options*, *Printing and Preview* and *No chords: blocks to hide* chapters:

- **Songpress++ Page** — Double-click jumps to the editor (✓), Minimum panel size 370×520 (✓), Show page indicator (✓), Delay preview refresh while typing — debounce (✓), Grey background (✓).
- **Print** — Live update of duplex/colour status in the print preview every 1.5 s (✓), Keep print preview always on top (☐), Show print preview before printing (✓).
- **No chords: blocks to hide** — Intro chords, Bridge, Grid, Time signature `{time}`, Tempo `{tempo_*}`, Musical symbols `{textsize:N}𝄽{textsize}` (all ☐).

---

### *Quick guide* tab

| Field | Default | Description |
| ----- | ------- | ----------- |
| **Markdown viewer** | Automatic | Engine used to render this guide: **Automatic** (tries *python-markdown*, then *mistune*, then the built-in parser), **python-markdown**, **mistune**, **Built-in parser**. The first two must be installed separately. |

---

### *Context menu* tab

Chooses which entries appear in the editor's right-click menu.

| Group | Items |
| ----- | ----- |
| **History** | Undo, Redo |
| **Edit** | Cut, Copy, Paste, Delete + **Ask confirmation before deleting** (☐, sub-option of *Delete*) |
| **Special actions** | Edit directive, Paste chords, Propagate verse chords, Propagate chorus chords, Copy text only |
| **Selection** | Select all |
| **Appearance** | **Show icons in context menu** (✓) |

---

### *File associations* tab

Associates extensions with Songpress++ **for the current user only**.

- Checkboxes for: `.crd`, `.cho`, `.chordpro`, `.chopro`, `.pro`, `.tab`, `.sng`
- **Associate all** / **Unassociate all** and **Apply now** buttons

> **On Linux** the controls are disabled: with the `.deb` package MIME associations are handled by the system (`/usr/share/mime`) and are not touched by the application. On Windows the keys are written under `HKEY_CURRENT_USER`. On other systems the tab shows a "not available" notice.

---

### *Toolbars* tab

Contains four sub-tabs — **Standard**, **Format**, **Insert**, **View** — with one checkbox per icon of the corresponding bar, plus **Select all** / **Deselect all** buttons at the top, above the sub-tabs (acting only on the open sub-tab). Details and separator behaviour in the *Toolbar Customisation* chapter.

---

## Toolbar Customisation

Songpress++ lets you show or hide individual icons in each of the four toolbars: **Standard**, **Format**, **Insert** and **View**.

### How to access the settings

Open **Tools → Options…** and select the **Toolbars** tab. The tab contains four sub-tabs, one per toolbar:

| Sub-tab   | Toolbar              | Configurable icons |
|-----------|----------------------|--------------------|
| Standard  | Standard toolbar     | New, Open, Save, Print preview, Print, Undo, Redo, Cut, Copy, Copy as image, Paste, Paste chords, Check syntax, Read only, Options… |
| Format    | Format toolbar       | Font, Show/hide chords, Linespacing |
| Insert    | Insert toolbar       | All insert icons (title, chords, verses, musical metadata, images, symbols, etc.). The chorus has a single icon, *Chorus…*, which opens the same dialog as the menu item |
| View      | View toolbar         | Show Songpress++ Page, Show verse and chorus labels |

### How to show or hide an icon

1. In the corresponding sub-tab, **check** the box to show the icon, **uncheck** it to hide it.
2. The **Select all** and **Deselect all** buttons, at the top above the sub-tabs, act only on the open sub-tab.
3. Click **OK**: the toolbar updates immediately.

Settings are saved to the application configuration file and restored at every startup.

> **Note:** hiding an icon from the toolbar does not remove the corresponding command. All commands remain accessible via the menu and keyboard shortcuts.

### Separator behaviour

Visual separators between icon groups are managed automatically: if all icons in a group are hidden, the separator between that group and the next disappears, preventing orphan separators in the toolbar.

### Developer notes

The full list of configurable icons is defined in the class constants `MAIN_TOOLBAR_ITEMS`, `FORMAT_TOOLBAR_ITEMS`, `INSERT_TOOLBAR_ITEMS` and `VIEW_TOOLBAR_ITEMS` in the `SongpressToolbarsMixin` mixin (`SongpressToolbars.py`). Each entry has the form `(xrc_name, label, pref_key)`.

When adding a new command to a toolbar, it is sufficient to:

1. Add the entry to the corresponding `*_TOOLBAR_ITEMS` constant.
2. Add the icon path to `_*_toolbar_icons` and the help text to `_*_toolbar_helps` inside the respective `_Build*ToolBar()` method.

**`MyPreferencesDialog` and `SongpressFrame` require no changes**: both read the `*_TOOLBAR_ITEMS` constants dynamically — the preferences dialog automatically generates checkboxes for every new entry, and the config save/load iterates over the full list.

### Icon format (vector and raster)

The icons of the **Standard**, **Format**, **Insert** and **View** toolbars are **always vector** at every size chosen in **Tools → Options… → General → Toolbar icon size** (16, 19, 21 or 32 px): they are loaded from the SVGs in `img/vector/` and rasterised at the real screen scale (DPI), so they stay sharp on high-resolution displays.

Raster images are only a **fallback**, used when an icon's SVG is missing:

| Size | Raster fallback |
|---|---|
| 16×16 | original PNG in `img/` |
| 19×19 and 21×21 | 16×16 PNG centred on a transparent canvas of the requested size |
| 32×32 | PNG in `img/32/` if present, otherwise the 16×16 PNG doubled |

All images in the **other bars** (editor bar, Songpress++ Page bar, screen ruler) are also **always vector**, falling back to the PNG if the SVG is missing (for the editor bar's zoom buttons, if the PNG is missing too, the system icon is used). **Print preview** icons are vector as first choice.

#### Image lookup order: vector first, then PNG

Throughout the program, interface images and symbols follow the **same rule**: the **SVG is tried first** in `img/vector/`, rasterised at the real device resolution (DPI, zoom, print); **only if the SVG is missing or cannot be loaded** does it fall back to the PNG in `img/`; as a last resort the system icon (or no image) is used.

| Element | 1st choice (vector) | 2nd choice (PNG) | Last fallback |
|---|---|---|---|
| Toolbar icons | `img/vector/<name>.svg` | `img/<name>.png` (at 32 px: `img/32/<name>.png`) | see table above |
| Info ('i') icons | `img/vector/info.svg` at 16×16, adapted to the DPI | `img/info.png` | system icon |
| Tempo icons (dialog, preview, print, PDF) | `img/vector/<name>.svg`, tinted with the chosen colour | `img/32/<name>.png`, then `img/<name>.png` | dialog: transparent bitmap |
| *Save to editor* / *Load from editor* buttons (print preview) | `img/vector/<name>.svg` at 16×16 | `img/<name>.png` resized to 16×16 | no icon |
| Screen ruler (modes, list, zoom −/+, close) | `img/vector/<name>.svg` | `img/<name>.png` resized | text button (`−`, `+`, `✕`, `☰`) |
| Editor zoom buttons | `img/vector/zoom_*.svg` | `img/zoom_*.png` | system icon |
| Song images `{image:}` | — | the file named in the directive: vector (SVG) or raster (PNG, JPG, GIF, BMP, TIFF) | — |

> **Note.** The `{image:}` directive does **not follow** this path: it always inserts only the image indicated by the user, raster or vector (SVG, rasterised at the real device resolution; see *Image Directive*); the SVGs in `img/vector/` are used only for the program's icons.

---

## Saved File Names

Two checkboxes in the **General** tab of **Tools → Options…** control the name proposed and used when saving a song. They are **independent** and can be enabled together: the first decides *which* name is proposed, the second *how* it is written.

| Option | Default | Effect |
|---|---|---|
| **Suggest the song `{title:}` as file name in 'Save as'** | off | The *File name* field of the "Save as" dialog is pre-filled with the song title |
| **Replace spaces with `_` in saved file names** | off | Every space in the file name (not in the folder path) becomes an underscore |

### Suggesting the Name from the Title

When enabled, Songpress++ reads the `{title:}` directive (or its short form `{t:}`) and proposes it as the file name, with the default extension already applied.

Extraction rules:

- the **first** valid `{title:}` or `{t:}` directive in the document is used;
- lines starting with `#` are ChordPro comments and are **ignored**, so a commented-out title is never proposed;
- inline chords inside the title are stripped: `{title: [C]Ave Maria}` → `Ave Maria`;
- if the closing `}` is missing, the rest of the line is used;
- characters not allowed in file names (`< > : " / \ | ? *`) are removed, and leading or trailing dots are stripped (to avoid hidden files on Linux);
- if the title is missing, empty or contains no valid characters, the field falls back to the default behaviour (current document name, or empty for a new song).

Other directives starting with `t` — `{tempo:}`, `{time:}`, `{taste:}` — are never mistaken for `{t:}`.

### How the Two Options Interact

The two options **compose** without conflicting. With `{title: Ave Maria splendore del mattino}` and the `crd` extension:

| Suggest title | Replace spaces | Proposed name |
|---|---|---|
| ✗ | ✗ | *(empty)* |
| ✓ | ✗ | `Ave del mattino.crd` |
| ✓ | ✓ | `Ave_del_mattino.crd` |
| ✗ | ✓ | *(empty, but manually typed spaces become `_`)* |

The name can still be edited in the dialog before confirming.

> **Note — Windows and Linux** — Behaviour is identical on both systems. Characters that are illegal on Windows are removed on Linux too, where some would technically be allowed: this keeps files portable across platforms.

> **Tip — Diagnostics** — If the name is not proposed even though the option is enabled, turn on **Show debug messages** in the same tab: Songpress++ will report the reason (option disabled, no `{title:}` directive found, or title with no valid characters).

---

## Display Preferences

The following controls are found in the **Formatting** tab of preferences and affect the preview and print output.

| Field                         | Default | Range | Step |
| ----------------------------- | ------- | ----- | ---- |
| Title underline thickness     | 4       | 1–5   | 1    |
| Verse number border thickness | 1       | 1–5   | 1    |

---

## Printing and Preview

- **Print preview** — shows the preview with "Print options", "Page setup" and "Driver settings" buttons
- **Print** — if the preference **Show print preview before printing** (the *General* tab in options) is enabled, the print preview is shown first; if disabled, the system print dialog opens (printer selection, number of copies, etc.) and printing starts after confirmation
- **Page setup** — paper, orientation and margins (in mm)

> **Automatic selection handling** — the print preview automatically detects whether a text selection is active in the editor (`_print_scope = 'auto'`): if a selection exists, only that portion is printed; otherwise the entire document is printed. No manual configuration is needed.

### Print preferences (*Songpress++ Page* tab)

> **Note — Automatic sorting** — The checkboxes in this group are sorted alphabetically according to the **active interface language**. The order may therefore differ from the one shown in this table.

| Preference | Default | Description |
| ---------- | ------- | ----------- |
| Show print preview before printing | ✅ on | When on, the **Print** command opens the preview first; when off, it opens the system print dialog directly |
| Live update of duplex/color status in print preview (every 1.5 s) | ✅ on | When on, the preview status bar queries the printer driver every 1.5 seconds and refreshes the duplex, color and orientation indicators in real time, even while the driver panel is open; when off, the status is read once when the preview opens |
| Keep print preview window always on top | ☐ off | When on, the preview window stays above all other windows (`wx.STAY_ON_TOP`); when off, it behaves as a normal window |

### Print Options

| Option                                         | Description                                                         |
| ---------------------------------------------- | ------------------------------------------------------------------- |
| Pages per sheet (1 / 2)                        | Selects how many logical pages to print on one physical sheet       |
| Columns per page (1 / 2)                       | Distributes text across one or two columns                          |
| Shrink if exceeds page                         | Reduces content only if it exceeds the page size (no upscaling)     |
| Shrink to fit current page                     | Further reduces to avoid content being cut at the bottom            |
| Don't replicate (leave right half blank)       | With 2 pages/sheet: leaves the second half blank instead of copying |
| Remove blank pages                             | Removes nearly-empty logical pages from the print output            |
| Blank page threshold (%)                       | Maximum page fill percentage below which a page is considered blank |
| Scale (%)                                      | Enlarges or reduces the whole printed content (50–200%, default 100%) |
| Position (Left / Center)                       | Horizontal position of the song on the page: against the left margin (default) or centered. Available only with **1 column** and **1 page per sheet**: otherwise the box is disabled |
| Keyboard size (%)                              | Size of the chord keyboards **for printing only** (50–200%); starts from the Preferences value. The *Default* button resets the box to it |
| Write page layout log (Diagnostics)            | Writes a log file with the layout parameters (see *Print diagnostics*); default off |
| Open folder (Diagnostics)                      | Opens the folder containing the log file; the full path is shown next to it |
| 📌 Pin                                          | Keeps the dialog open after OK, applying changes to the preview immediately |

#### Print diagnostics

At the bottom of the **Print Options** dialog is the **Diagnostics** section, useful for understanding why a song is laid out in a certain way (or for reporting a problem):

- **Write page layout log** — when on, the file `songpress_print_debug.log` is written on every preview/print. It records the layout parameters (shrink on, block-aware layout, columns, two pages per sheet, pages per sheet, vertical scale, offsets, clip area), the **block breaks** and the **clip regions** of each page. Default: off.
- **Open folder** — opens the log folder. The full path of the file is shown in grey next to the button.
- The file is in the system temporary folder: `%TEMP%` on Windows, `/tmp` (or `$TMPDIR`) on Linux and macOS.

The log is for diagnostics only: leaving it off does not affect printing.

The `{new_page}` directive in the text forces a new logical page during printing. With the 2-column layout, `{column_break}` forces a jump to the next column.

#### Print settings stored in the song

The dialog settings can be saved **inside the song**, as a comment line at the **first line** of the editor:

```
# {print_options: pages=1; cols=1; fit=0; shrink=0; minmargin=0; nomirror=0; blank=1; blankthr=5; scale=100; pos=1; kbd=70; paper=3; orient=1; margins=5,5,5,5}
```

The line starts with `#`, so it does not appear in the preview or in print. In the **Settings in the song** section of the dialog, **Save in editor** writes (or updates) the line and **Load from editor** reads the values back into the dialog; they are applied by pressing **OK**. The line is read **only if it is the first line** of the song.

| Key         | Values  | Meaning                                                    |
| ----------- | ------- | ---------------------------------------------------------- |
| `pages`     | 1–2     | Pages per sheet                                            |
| `cols`      | 1–2     | Columns per page                                           |
| `fit`       | 0–1     | Shrink if exceeds page                                     |
| `shrink`    | 0–1     | Shrink to fit current page                                 |
| `minmargin` | 0–20    | Minimum margin (mm) used by *Shrink*                       |
| `nomirror`  | 0–1     | Don't replicate (leave right half blank)                   |
| `blank`     | 0–1     | Remove blank pages                                         |
| `blankthr`  | 1–95    | Blank page threshold (%)                                   |
| `scale`     | 50–200  | Scale (%)                                                  |
| `pos`       | 0–1     | Song position: 0 = left, 1 = centered — **optional**       |
| `kbd`       | 50–200  | Keyboard size (%) — **optional**                           |
| `paper`     | 0–200   | Paper size                                                 |
| `orient`    | 1–2     | Orientation (1 = portrait, 2 = landscape)                  |
| `margins`   | 4 numbers 0–100 | Margins in mm: top, bottom, left, right            |

**Position (`pos`).** With `pos=1` the song is centered on the page; with `pos=0` (or without the key) it stays against the left margin. Centering uses the song's **real width**, including the chord keyboards at the bottom of the page (at the keyboard size chosen for printing), and applies to each part of the song separated by `{new_page}`. It applies only with `cols=1` and `pages=1`: with 2 columns or 2 pages per sheet the key is ignored. The key is optional and is not reported when missing; the syntax check reports a value outside 0–1.

**Keyboard size (`kbd`).** Fits more keyboards on each row of the *Chords* section at the bottom of the page (low value) or enlarges them. It applies **only to print and print preview**: the preview in the editor always uses the size set in the Preferences. The key is optional: if it is missing, print uses the Preferences value, and existing songs stay as they were. If the box in the dialog matches the Preferences, print keeps following them even if you change them later.

**Saving it in the song or not.** In the **Settings in the song** section, the **Also save the keyboard size in the song** checkbox decides whether *Save in editor* also writes `kbd=`. It is enabled **only if the song contains keyboards** (`{taste:}` or `{fingering:}`; comment lines do not count): without keyboards the size is irrelevant, and the checkbox and the field stay disabled. It ticks itself when you set the size to a value different from the Preferences; the *Default* button clears it. With the checkbox empty, the saved line has no `kbd` (and an existing `kbd` is removed).

The syntax check reports unknown keys, out-of-range values (e.g. `kbd=20`) and missing keys, except for `kbd` and `pos`.

### Persistence of Print Options

All settings in the **Print options** dialog and in the **Page setup** window are **saved automatically** and restored the next time Songpress++ starts. Saving happens at two moments:

- **When confirming with OK** in the *Print options* dialog (immediate save, so settings are not lost if the program terminates unexpectedly).
- **When the program is closed**, together with the other preferences.

Restoring happens **when the program starts**, before printing or preview become available.

Values are stored in the `/PageSetup` section of the user configuration (`~/.Songpress++/Songpress++.ini` on Linux, the system registry on Windows).

| Saved parameter            | Configuration key      | Default    |
| -------------------------- | ---------------------- | ---------- |
| Top margin (mm)            | `margin_top`           | 15         |
| Bottom margin (mm)         | `margin_bottom`        | 15         |
| Left margin (mm)           | `margin_left`          | 15         |
| Right margin (mm)          | `margin_right`         | 15         |
| Paper size                 | `paper_id`             | A4         |
| Orientation                | `orientation`          | Portrait   |
| Pages per sheet            | `two_pages_per_sheet`  | 1 page     |
| Columns per page           | `columns_per_page`     | 1 column   |
| Shrink if exceeds page     | `fit_to_page`          | off        |
| Shrink to fit current page | `shrink_to_fit`        | off        |
| Min margin for auto-shrink (mm) | `min_margin_shrink` | 5 (0–20) |
| Don't replicate (right half blank) | `no_mirror_right` | off     |
| Remove blank pages         | `remove_blank_pages`   | off        |
| Blank page threshold (%)   | `blank_page_threshold` | 5          |
| 📌 Pin button state         | `print_options_pinned` | off        |
| Song position              | `print_h_center`       | Left       |
| Write page layout log      | `print_debug`          | off        |

> **Exception — Scale (%)** — The **Scale** value is **never** saved. It stays active for the whole working session (handy when adjusting it with the dialog pinned while watching the preview), but it always returns to **100%** each time Songpress++ restarts. This prevents unnoticed enlarged or reduced printouts after the scale was used for a single song. Any leftover value stored by earlier versions is removed from the configuration as well.

> **Keyboard size (print)** — Like Scale, the **Keyboard size** value in the dialog is not saved in the configuration: at every start, print uses the Preferences size. To keep it for a song, use **Save in editor** (key `kbd`).

> **Note** — Values read from the configuration are validated: if a key is missing, unreadable, or out of range (for example a column count other than 1 or 2, or a blank page threshold outside the 1–95 range), the default value is used silently.

### Print Settings and Explanations

![Songpress++ Page Setup](./img/GUIDE/ImpostaPagina_en.png)
![Songpress++ Print Options](./img/GUIDE/OpzioniDiStampa_en.png)

**What is "Minimum margin for auto-shrink (mm)"?**

This is a control parameter for the Shrink to fit function, which activates when the option **"Shrink to fit current page (avoid bottom cut)"** is checked.

How the logic works: Songpress++ measures, for each segment of the song (separated by `{new_page}`), how much content overflows beyond the bottom of its last page, and attempts to recover exactly that space in two steps:

**First step** — reduces the top and bottom margins, distributing the reduction proportionally to the available headroom of each (not necessarily 50/50: if one margin is already close to the minimum, it is reduced less than the other). The reduction stops as soon as the overflow is recovered, or when both margins have reached the minimum value configured by this SpinCtrl. The minimum can be set from 0 to 20 mm. If the user-set margin is, for example, 20 mm, it can be automatically compressed down to 5 mm (default). This prevents the auto-reduction from completely zeroing out the margins.

**Second step** — scales the content (shrinks text/chords), only if margin reduction alone was not sufficient. The scale factor is calculated separately for each segment and the most restrictive one is applied, ensuring no segment is clipped.

In practice: the value (default 5 mm) represents the floor below which margins never drop during auto-reduction. The higher the value, the less aggressive the margin compression (and the sooner text scaling begins). The control is disabled when the Shrink if exceeds page checkbox is off, and re-enables automatically when it is turned on.

**What is "Blank page threshold (%)"?**

This is the control parameter for the **"Remove blank pages"** function, which activates when the corresponding checkbox is checked.

During printing it can happen that the last element of a song (for example the chord keyboard diagram) overflows slightly beyond the page boundary, generating an additional physical sheet that is almost entirely blank. The "Remove blank pages" function detects this situation and automatically suppresses that residual page.

The threshold (default **5%**) represents the maximum percentage of page height that the remaining content may occupy for the page to be considered "blank" and removed. If the overflow is less than or equal to this threshold, the page is suppressed; if it is greater, the page is kept because it is considered genuinely necessary.

Practical examples:

- **5%** (default) — removes the page only for minimal overflows (a few pixels, typically a chord keyboard or a final symbol).
- **20%** — also removes the page when the remaining content occupies up to one fifth of the page.
- **50%** — removes the page if it is less than half full (not recommended: risks cutting visible content).

The control is disabled when the "Remove blank pages" checkbox is off, and re-enables automatically when it is turned on.

### "Driver settings" button in the preview

The preview toolbar includes the **Driver settings…** button, which opens the native printer driver panel (`DocumentProperties` on Windows). From this panel you can change all driver settings: orientation, duplex, color, number of copies, paper size, and any model-specific options (e.g. print quality, paper tray).

#### How it works internally

The panel is opened following three cascading paths:

**Attempt 1 — pywin32 (preferred path on Windows)**

Uses the `win32print` and `pywintypes` bindings included with the `pywin32` dependency:

1. First call to `DocumentProperties(hwnd, hprinter, name, None, None, 0)` → retrieves the total size of the driver-specific DEVMODE.
2. Allocates a `pywintypes.DEVMODEType(driver_extra)` with the correct size (fixed size + `dmDriverExtra`).
3. Second call with `DM_OUT_BUFFER` → reads the current driver settings into the allocated buffer.
4. Third call with `DM_IN_BUFFER | DM_OUT_BUFFER | DM_IN_PROMPT` → **shows the native driver panel** and waits for the user's confirmation.

**Attempt 2 — pure ctypes via `winspool.drv` (fallback, no external dependencies)**

If `pywin32` is unavailable or raises an error, the same logic is applied via `ctypes.WinDLL('winspool.drv')`, calling `DocumentPropertiesW` directly with `ctypes.create_string_buffer` buffers. The relevant DEVMODE fields (orientation, paper size, copies, color, duplex) are read using fixed offsets in the `DEVMODEW` structure.

**Attempt 3 — Page Setup dialog (non-Windows or both attempts failed)**

On platforms other than Windows, or if both previous attempts fail, the standard **Page Setup** dialog (`wx.PageSetupDialog`) is opened, where orientation, paper size and margins can be changed. Changes confirmed with OK are applied to the preview.

#### Propagation of changes

When the user confirms with OK, Songpress++ automatically propagates the readable fields back into `wx.PrintData` (orientation, duplex, color, copies, paper size) and refreshes the preview status bar. If the orientation has changed, the preview reloads automatically to show the sheet in the correct direction.

> **Note** — The **Driver settings…** button is only available inside the print preview, not from the main menu.

### Automatic printer detection in the preview

The print preview status bar displays four indicators that read the **actual** settings of the selected printer, not just the values set by wx:

| Indicator | Possible values |
| --------- | --------------- |
| **Duplex** | `Duplex: off (simplex)` · `Duplex: ON — long-edge binding` · `Duplex: ON — short-edge binding` |
| **Color** | `Color: color print` · `Color: black & white` |
| **Print scope** | `Printing whole document` (green) · `Printing selection only` (amber) |
| **Orientation** | Portrait sheet icon or landscape sheet icon |

**How detection works (Windows)**

On Windows, color detection uses three sources in cascade, each activated only if the previous one produced no result; duplex detection uses only source 1. On macOS and Linux, the value returned by `wx.PrintData` is used instead.

| Source | API | When used |
| ------ | --- | --------- |
| **1 — DEVMODE** | `win32print.GetPrinter` level 2 | Always first: reflects the user's choice in the driver panel |
| **2 — Hardware capability** | `win32print.GetPrinterCaps(DC_COLORDEVICE)` | Only if `dmColor` is absent: indicates whether the printer is physically capable of color |
| **3 — wx fallback** | `wx.PrintData.GetColour()` | Only if both previous sources fail |

| Field | Values |
| ----- | ------ |
| `DEVMODE.dmDuplex` | `1` = simplex · `2` = duplex long-edge · `3` = duplex short-edge |
| `DEVMODE.dmColor` | `1` = monochrome (`DMCOLOR_MONOCHROME`) · `2` = color (`DMCOLOR_COLOR`) |
| `DC_COLORDEVICE` | `0` = hardware B/W only (absolute certainty) · `1` = hardware capable of color |

**Reliability by printer type**

| Situation | Duplex detected? | Color detected? |
| --------- | ---------------- | --------------- |
| Local printer with native driver (e.g. Brother, HP, Canon) | ✅ yes | ✅ yes |
| Network printer with native driver installed | ✅ yes | ✅ yes |
| PDF printer (Microsoft Print to PDF, PDFCreator) | ⚠️ depends | ⚠️ depends |
| Network printer via IPP without native driver (generic TCP/IP port only) | ❌ often no | ❌ often no |
| B/W-only printer that does not expose `dmColor` in DEVMODE | ✅ yes | ✅ yes (via `DC_COLORDEVICE`) |
| macOS / Linux | ⚠️ wx value only | ⚠️ wx value only |

> **Note** — If `win32print` is unavailable or a global error occurs, both indicators automatically fall back to the value provided by `wx.PrintData`. The `DC_COLORDEVICE` source is wrapped in its own `try/except`: if `GetPrinterCaps` is not supported by the driver, the fallback chain continues to wx without interrupting detection.

---

## Export

| Format              | Notes                                         |
| ------------------- | --------------------------------------------- |
| SVG                 | Vector, scalable                              |
| EMF                 | Windows vector format                         |
| PNG                 | Raster image                                  |
| HTML                | Web page with colored chords                  |
| Tab                 | Text format with chords above                 |
| PDF                 | PDF document (page setup dialog shown first, then file name) |
| PowerPoint (.pptx)  | Presentation                                  |
| Create Songbook PDF | PDF song collection with clickable index      |
| Create Index        | Two-column PDF/DOCX index (number and title)  |
| Canzonatore         | Merges multiple ChordPro files into one       |
| Copy as image       | Copies to clipboard as vector image           |
| Copy text only      | Copies text without chords                    |
| Edit directive      | Shown at the top of the menu when you right-click a directive that has its own dialog (`{taste:}`, `{fingering:}`, `{define:}`, `{time:}`, `{tempo:}`, `{tempo_label:}`, `{key:}`, `{beats_time:}`, `{linespacing:}`, `{image:}`, the Transposer indicator `{start_of_tab: TP}` (opening line only), a musical symbol with size `{textsize:12}𝅗{textsize}` (reopens the symbol map), and the opening lines of the blocks `{start_chorus}` / `{soc}` and `{start_chord}`: not the closing or inner lines; the label is edited): reopens the dialog that created it, pre-filled with the current values, and on confirmation replaces only the value. It can be hidden in Options (*Context menu* tab → *Special actions*). |

> **Note — Export PDF:** the export flow opens the **Page setup** dialog first (paper size, orientation, margins in mm); only after confirmation is the output filename requested. The margin settings are stored and reused in subsequent exports.

---

## Watermark 🖊

The **Watermark** command (*File* menu) overlays a diagonal caption on the song (for example *DRAFT*, *SAMPLE*, *PROOF*) drawn **behind** the text, so it never covers the content. The watermark is **always applied in print and in every exported format** (PNG, SVG, EMF, EPS, PDF) and, optionally, in the Songpress++ preview too.

### Dialog

| Field | Default | Description |
| ----- | ------- | ----------- |
| Enable watermark | ☐ off | Turns the watermark on or off for the current song. When unchecked, all other fields are disabled |
| Show in Songpress++ Page | ✅ on | If on, the watermark also appears in the Page panel; print and export apply it regardless of this option |
| Text | `DRAFT` | Watermark text. May contain spaces and symbols; if empty, no watermark is drawn |
| Opacity (%) | 12 | Caption intensity, from 2 to 100. **Higher = darker**. Transparency is simulated by blending the colour toward the white of the sheet, so the result is identical in every format (including SVG and EPS, which have no alpha support) |
| Angle (°) | 45 | Caption tilt, from −90 to +90 degrees |
| Size (%) | 100 | Font scale, from 20 to 300 |
| Colour | black | Watermark colour (before the blend toward white produced by opacity) |
| Tile (repeat over the page) | ☐ off | When off, a single centred caption; when on, the caption is tiled across the whole page |

### Where the settings are stored

The watermark configuration is **per-document**: it is written at the top of the `.crd` file as a `{watermark: …}` directive, so each song keeps its own watermark and restores it when reopened.

The **style fields** — opacity, angle, size, colour and tile — are additionally stored as **global preferences**: the last combination used becomes the default for new songs (or songs without a directive). The *Enable*, *Text* and *Show in preview* fields instead stay tied to the individual document.

### The `{watermark:}` directive

The directive is handled automatically by the dialog, but it can also be typed or edited by hand in the editor: watermark, preview and dialog state realign on their own. The `text=` field is always **last**, so it may contain `=` and `;` without breaking parsing; braces in the text are neutralised.

```chordpro
{watermark: enabled=1; opacity=12; angle=45; sizePct=100; tile=0; showInPreview=1; colourHex=#000000; text=DRAFT}
```

| Key | Values | Meaning |
| --- | ------ | ------- |
| `enabled` | 0 / 1 | Watermark active |
| `opacity` | 2–100 | Intensity (higher = darker) |
| `angle` | −90…90 | Tilt in degrees |
| `sizePct` | 20–300 | Font scale as a percentage |
| `tile` | 0 / 1 | 0 = single centred caption; 1 = tiled repeat |
| `showInPreview` | 0 / 1 | Also show the watermark in the preview |
| `colourHex` | `#RRGGBB` | Caption colour |
| `text` | free text | Watermark text (always the last field) |

---

## Create Songbook PDF

The **Create Songbook PDF** function (*File → Create Songbook PDF…*) generates a complete PDF document from all ChordPro songs in a selected folder.

### How to use

1. Choose the **songs folder** using the *Browse…* button
2. Specify the **output PDF file**
3. Fill in the optional fields: **Songbook title**, **Author / Group**, **Year**
4. Select the **extensions** to include (`.crd`, `.cho`, `.chordpro`, `.chopro`, `.pro`, `.tab`, `.sng`, `.txt`)
5. Choose whether to make **index entries clickable**
6. Adjust page setup and print options
7. Click **OK** to start generation

### Structure of the generated PDF

| Section   | Description |
| --------- | ----------- |
| Cover     | Title, author and year on a dark-blue background with an orange band |
| Songs     | One song per page (or more if the text is long); songs are sorted alphabetically by the title extracted from `{t:}` or `{title:}`, falling back to the filename |
| Index     | Numbered list of all songs with dot leaders and page numbers |

### Options

| Option | Description |
| ------ | ----------- |
| Extensions | Select which file types to include in the collection |
| Clickable index entries (PDF links) | When enabled, each index entry is an internal PDF link that jumps directly to the song's page; the title appears in blue with an underline |
| Pages per sheet (1 / 2) | Places two songs side by side on one physical sheet |
| Page setup | Paper size, orientation and margins |
| Print options | 2-pages-per-sheet mode |

### Notes

- Images inserted with `{image: filename.png}` are looked up **in the same folder as the source file** and included in the PDF automatically.
- Songs are always sorted alphabetically, regardless of the file order in the folder.
- To include `.txt` files (which usually contain no ChordPro directives), tick the corresponding extension in the list.

---

## Create Index

The **Create Index** function (*File → Create Index PDF…*, or by launching `CreaIndice.py` as a stand-alone program) generates a **two-column index — song number and title — sorted by song number**, from all the ChordPro files in a folder. The index can be produced as a **PDF** or a **DOCX**.

Unlike the internal index of the *Songbook PDF* (sorted by title and tied to a single collection document), *Create Index* produces a self-contained list, meant as a numeric table of contents for the songbook.

### How to use

1. Choose the **Main folder** with the songs; the **Include subfolders** option extends the scan to nested folders
2. Optional: tick **Exclude files with “watermark”** to leave out songs containing a `{watermark: …}` directive (draft / stamped copies). Once it is on, you can also tick **Add a note at the end of the index about excluded songs** (with the info icon), which prints a notice about the exclusion at the end of the index
3. Select the file **extension** to include via the radio buttons: `.cho`, `.chopro`, `.pro`, `.crd`, `.txt`, **All files** or **Other…** (free-text field). Each entry shows the **number of files** found with that extension. On opening, the radio matching the **Default file extension** set in *Options → General* is already selected
4. Optional: set a **background watermark** (image) with opacity, angle and size, and choose whether to render it in **colour** or in **black and white**
5. Optional: customize the **Index title** (default "Index")
6. Optional: tick **Write the number of songs in the index** to add a line with the total number of songs at the end of the index
7. Leave the **Open the PDF now** checkbox on, or turn it off
8. Click **Generate PDF** or **Generate DOCX** and choose where to save the file

### How number and title are extracted

| Field | Source | If missing |
| ----- | ------ | ---------- |
| **Song number** | First `{subtitle:}` / `{st:}` containing `numero: N` (e.g. `{subtitle: Canto numero: 22}`); otherwise, the first integer found in a subtitle | The song is placed **at the end** of the list |
| **Title** | First `{title:}` / `{t:}` directive | The file name (without extension) |

Sorting is by **ascending number**; songs without a number are listed **after** the numbered ones, alphabetically by title.

### Options

| Option | Default | Description |
| ------ | ------- | ----------- |
| Main folder | last used | Folder of songs to scan. **The last path used is remembered** and restored at the next launch |
| Include subfolders | ✅ on | Also scans nested folders |
| Exclude files with “watermark” | ☐ off | When enabled, files containing a `{watermark: …}` directive (draft / stamped copies) are left out of the index and the counts. The file count updates as soon as the box is ticked. The scan is fast and its results are remembered (see *Notes*) |
| Add a note at the end of the index about excluded songs | ☐ off | Available **only when “Exclude files with “watermark”” is on**: otherwise the checkbox and its info icon stay disabled. When enabled, a line with the info icon and the text “Songs with a watermark have been excluded from this index.” is added at the end of the index (both PDF and DOCX). The choice is **remembered across launches** |
| File extension | from *Options* | File type to include. At startup the radio matching the **Default file extension** from *Options → General* is preselected (if that extension is not among the fixed ones, **Other…** is selected and the field filled in automatically); **All files** automatically skips binaries (`.pdf`, `.docx`, `.svg`, `.emf` and the images `.png`, `.jpg`, `.jpeg`, `.webp`, `.gif`, `.bmp`, `.tif`, `.tiff`); **Other…** enables a field for a custom extension |
| Background watermark | none | Image (PNG, JPG/JPEG, WebP, GIF, BMP, TIFF) drawn behind the text on every page, with **Opacity (%)**, **Angle (°)** and **Size (%)**. The **Rendering** option lets you choose **colour** (default) or **black and white** (the image is desaturated while keeping its transparency). These controls are enabled **only when an image is selected** (otherwise they stay disabled). All these values are **remembered across launches** |
| Index title | `Index` | Heading printed at the top of the index |
| Write the number of songs in the index | ☐ off | When enabled, a bold line with the total number of songs (e.g. “Total songs in the index: 120”) is added right after the table (PDF and DOCX), before the excluded-songs note if any. The choice is **remembered across launches** |
| Open the PDF now | ✅ on | When enabled, the generated file (PDF or DOCX) is opened with the system's default application once created. The choice is remembered across launches |

### Notes

- The last **Main folder** used is saved and restored automatically at restart; if the folder no longer exists, it falls back to the home folder.
- On opening, the **extension** radio reflects the **Default file extension** set in *Options → General* (read from Songpress++'s settings); when the window is launched as a stand-alone program it falls back to `crd`.
- The **watermark** values (Opacity, Angle, Size and the Colour/Black-and-white choice) are remembered on every change and restored when the window is reopened.
- The **watermark** controls (Opacity, Angle, Size and Rendering) are disabled until an image is selected, and turn on automatically as soon as the **Image** field contains a path.
- **Watermark opacity warning.** When an image is selected and **Opacity** is above **50%**, a red warning appears under the control (“with opacity above 50% the text may be hard to read”). It is only a warning: the value is not clamped.
- Every control in the window has an explanatory **tooltip**.
- The **note about excluded songs** is printed only if **both** checkboxes are on (“Exclude files with “watermark”” and “Add a note at the end of the index…”). If you turn the exclusion off, the note checkbox is disabled and the note is not printed, but your choice stays stored and comes back together with the exclusion.
- The note's icon is a vector image (`img/vector/info.svg`, in the `img` folder next to `CreaIndice.py`); if it is missing, `img/info.png` is used. In the windows the order is: SVG at 16×16 adapted to the DPI, then `img/info.png` as a fallback, then the system icon. In the **PDF** the icon stays vector if `svglib` is installed; otherwise (and in the **DOCX**, which does not support SVG) a high-resolution image derived from the SVG is used. If no icon is available, the note is still printed, without the icon. The note text follows Songpress++'s interface language.
- **“watermark” scan speed.** The search for the `{watermark}` directive is now much faster: files are read directly as bytes (without trying several text encodings), checked **in parallel** when there are more than 16, and each file's result is **remembered** until the file changes (date or size). So turning the checkbox back on, changing the extension or generating the index does not reread the files: only the **first** scan of a folder takes longer, later ones are almost instant.
- The song number is searched in **all** the file's subtitles: it is enough for one of them to contain `numero: N`.
- **PDF** generation requires the `reportlab` library, **DOCX** requires `python-docx`; the **watermark** requires `Pillow`; the vector icon in the PDF uses `svglib` (optional). If a library is missing, the program shows a notice with the `pip` command to install it.
- *Create Index* can also be used as a stand-alone program (`python3 CreaIndice.py [folder]`), handy for quickly producing a table of contents without opening Songpress++.

---

## Canzonatore — Merge Songs

The **Canzonatore** function (*File → Canzonatore (unisci brani)…* / *Merge songs…*) merges multiple ChordPro files into a single text file, inserting a separator between songs.

### How to use

1. Open the dialog from *File → Merge songs (Canzonatore)…*
2. Add files using **Add files…** (multi-selection) or **Add folder…** (imports all supported files in the folder in alphabetical order)
3. Reorder songs using the **▲ Up** and **▼ Down** buttons
4. Choose the **separator** between songs and the **output encoding**
5. Click **Merge…**, choose where to save the output file, and confirm

### Options

| Option | Values | Description |
| ------ | ------ | ----------- |
| Song separator | `{new_page}` (default) | Inserts an explicit page break between songs |
| | Blank line | Separates songs with a blank line |
| Output encoding | UTF-8 (default) | Recommended for maximum compatibility |
| | Latin-1 (ISO-8859-1) | For compatibility with older software |
| Open merged file in editor | ✅ on by default | Automatically opens the resulting file in the Songpress++ editor when merging is complete |

### Supported extensions

`.crd` `.cho` `.chordpro` `.chopro` `.pro` `.tab` `.cpm`

### Double-click in the list

Double-clicking (or pressing Enter) on a file in the list opens it in the Songpress++ editor. You can review a file before merging without leaving the dialog.

### Completion dialog

When merging is complete, a dialog appears with:
- **File link** — click to open the file with the system's default application
- **Folder link** — click to open the file manager at the folder containing the file (with file selection on Windows and macOS)

### Notes

- Files already in the list are not added a second time (automatic deduplication).
- The encoding of source files is detected automatically (UTF-8-BOM → UTF-8 → Latin-1).
- If a file cannot be read, it is skipped and reported in the completion dialog; merging continues with the remaining files.

## Supported Import File Formats

| Extension   | Description                          |
| ----------- | ------------------------------------ |
| `.crd`      | ChordPro (main extension)            |
| `.cho`      | ChordPro                             |
| `.chordpro` | ChordPro                             |
| `.chopro`   | ChordPro                             |
| `.pro`      | ChordPro                             |
| `.tab`      | Tab format (chords above text)       |

---

## Guide: Page Panel — Songpress++

The **Page** panel (PreviewCanvas) shows in real time the graphical rendering of the ChordPro song as you type in the editor. It is docked as an AUI panel on the right side of the main window and can be resized, hidden, or undocked like any other AUI panel.

---

## Visual Structure

![Songpress++ Page Panel](./img/GUIDE/AnteprimaSonpress++_en.png)

The compact toolbar at the top groups all controls; below it is the scrollable area with the rendered song content.

---

## Page Toolbar

### 📋 Copy to Clipboard

Copies the graphical rendering of the song to the **system clipboard** as an image (metafile / bitmap), ready to be pasted into a Word document, presentation, or other application.

---

### Zoom Controls

| Element               | Function                                                   |
| --------------------- | ---------------------------------------------------------- |
| **−** button          | Reduces zoom by 10%                                        |
| Horizontal **slider** | Drag to freely set zoom between 30% and 300%               |
| **+** button          | Increases zoom by 10%                                      |
| **`xx%`** label       | Shows current percentage (read-only)                       |
| **1:1** button        | Resets zoom to exactly 100%                                |

All controls are **bidirectionally synchronized**: using the mouse wheel, keyboard, or dragging the slider always updates all other elements.

**Range:** 30% – 300%, step 10%.

---

### ⛶ Fullscreen

Opens the preview in a **dedicated fullscreen window** (`F11`).

The fullscreen window shares the same renderer as the main panel: content is always up to date. It has its own toolbar with a zoom slider and *Fit* button. Close it with `Esc`, `F11`, or the *Exit Fullscreen* button.

> Double-click to navigate to the corresponding editor line is also active in the fullscreen window.

---

### Fit (Fit-to-width)

Automatically calculates the zoom that makes the song width fit **exactly** in the available panel width, taking into account dynamic margins (3% per side) and any vertical scrollbar. Pressing the button multiple times gives the same result (idempotent operation).

**Shortcut:** `Ctrl+Shift+G`

---

### Page Indicator

The label at the bottom of the toolbar (e.g. `Page 2 of 5`) shows the current page based on the vertical scroll position. It updates on every scroll. Can be hidden in preferences.

The page count is calculated based on the **current paper format** (width, height and margins) set in *File → Page Setup*.

---

## Mouse and Keyboard Interaction

### Zoom

| Gesture / key        | Effect                             |
| -------------------- | ---------------------------------- |
| `Ctrl` + scroll up   | Zoom in (+10%)                     |
| `Ctrl` + scroll down | Zoom out (−10%)                    |
| `Ctrl++`             | Zoom in (+10%)                     |
| `Ctrl+-`             | Zoom out (−10%)                    |
| `Ctrl+0`             | Reset zoom 100%                    |
| `Ctrl+Shift+G`       | Fit-to-width                       |
| `F11`                | Open / close fullscreen window     |

### Scrolling

| Key                       | Effect                           |
| ------------------------- | -------------------------------- |
| Mouse wheel (without Ctrl)| Normal vertical scrolling        |
| `Ctrl+PgDn`               | Scroll one page down             |
| `Ctrl+PgUp`               | Scroll one page up               |

> Scroll granularity is **proportional to zoom**: at very high zoom the scroll is finer, so navigation remains precise.

### Double Click → Editor Navigation

By **double-clicking** on a point in the preview, Songpress++ identifies the nearest token (word or chord) to the click and **moves the editor cursor** to the corresponding source line.

The mechanism works in three steps:

1. The click coordinates are corrected for scroll and zoom and mapped back to renderer coordinates.
2. A **precise hit-test** is performed on the tree of rendered boxes (SongSong → SongBlock → SongLine → SongText), finding the nearest token by Euclidean distance.
3. The token text is searched in the ChordPro source using a **concentric circles strategy** (±5 lines → ±20 lines → entire file), to correctly handle chords repeated many times.

This function can be disabled in preferences.

**Double-click on a keyboard.** If the double-click lands on a keyboard (klavier) drawn by a `{taste:}` or `{fingering:}` directive, the editor **selects the matching directive**, so you can edit it straight away. Keyboards are matched to directives in order: the first keyboard to the first directive in the text, the second to the second, and so on (empty directives and `#` comment lines are not counted). It also works in the fullscreen window.

---

## Layout and Background

![Songpress++ Page Preferences](./img/GUIDE/AnteprimaSonpress++Preferenze_en.png)

### Page Background

The preview area simulates a **white sheet on a gray background**: the renderer draws the content as if on paper, with the same dimensions and margins as the current paper format. The gray background can be changed to pure white in preferences.

### Dynamic Horizontal Margin

The left and right margin of the content is calculated as **3% of the panel width** (minimum 8 px). This makes the preview adapt automatically when the panel is resized.

### Columns

If the source text contains the `{column_break}` (or `{colb}`) directive, the renderer automatically switches to a **two-column layout**. No manual action is required.

---

## Refresh Debounce

To avoid continuous redraws during fast typing, the preview refresh is governed by a **300 ms debounce timer**:

- Every text change starts (or restarts) the timer.
- The redraw only happens **when typing stops** for at least 300 ms.
- If you prefer immediate feedback on every keystroke, debounce can be disabled in preferences.

---

## Minimum Panel Size

By default the Page panel has a minimum size of **370 × 520 px**: dragging the AUI splitter below this threshold is not possible, either at startup or during the session. The threshold can be removed in preferences for those working on small monitors or wanting to maximize editor space.

---

## Page Options

Options are found in **Tools → Options... → Songpress++ Page tab**.
All changes are applied **immediately** to the open panel, without needing to restart.

> **Note — Automatic sorting** — The checkboxes in this group (as well as those in the *Print* and *No chords: blocks to hide* groups) are sorted alphabetically according to the **active interface language**. The order may therefore differ from the one shown in this table.

| Option                                     | Default | Description                                                                                     |
| ------------------------------------------ | :-----: | ----------------------------------------------------------------------------------------------- |
| **Show page indicator**                    | ✓       | Shows/hides the "Page X of Y" label in the toolbar                                              |
| **Gray background**                        | ✓       | Gray background with simulated "white sheet"; if unchecked, pure white background               |
| **Debounce refresh**                       | ✓       | Delays redraw by 300 ms after last keystroke; uncheck for immediate feedback                    |
| **Double-click brings focus to editor**    | ✓       | Enables editor navigation on double-click in the preview                                        |
| **Minimum panel size**                     | ✓       | Enforces minimum size of 370 × 520 px on the AUI panel                                          |

> **Note on *Minimum panel size*:** this preference acts both on the underlying `wx.Window` and on the AUI pane via `_ApplyPreviewMinSize()`. The change is therefore effective immediately, without restarting.

---

## No Chords: Blocks to Hide

When the **Show chords** slider (Format toolbar) is set to **None**, the preview and print output omit all inline `[…]` chords. With this setting active, you can also hide structural blocks that contain only chords and would be meaningless without them.

Options are found in **Tools → Options... → Songpress++ Page tab → No chords: blocks to hide**.

> **Note — Automatic sorting** — The checkboxes in this group are sorted alphabetically according to the **active interface language**. The order may therefore differ from the one shown in this table.

| Option | Default | Description |
| ------ | :-----: | ----------- |
| **Intro chords `{start_chord}`\`{end_chord}`** | ☐ | Hides the entire intro chord block (including its content) when chords are disabled |
| **Bridge `{start_bridge}`\`{end_bridge}`** | ☐ | Hides bridge blocks when chords are disabled (also covers `{start_of_bridge}`/`{sob}`) |
| **Grid `{start_of_grid}`\`{end_of_grid}`** | ☐ | Hides chord grid blocks when chords are disabled (also covers `{sog}`, `{grid}`) |
| **Tempo `{tempo_m}`\`{tempo_s}`\`{tempo_sp}`\`{tempo_c}`\`{tempo_cp}`\`{tempo_label}`** | ☐ | Hides all tempo directives when chords are disabled |
| **Time signature `{time}`** | ☐ | Hides `{time:…}` directives (e.g. `4/4`) when chords are disabled |
| **Musical symbols `{textsize:N}𝄽{textsize}`** | ☐ | Hides the musical symbols `{textsize:N}𝄽{textsize}` (any size `N`) and the spaces around them when chords are disabled |

> **Note:** the checkboxes take effect **only** when the Show chords slider is set to *None* (value 0). With the other modes (*First verse only*, *Entire song*) blocks are always rendered normally, regardless of these settings.

> **Note:** the filter acts on the text passed to the renderer before each redraw. The source document in the editor is never modified.

> **Technical note:** `{start_chord}`, `{start_bridge}`, `{start_of_grid}` are **paired blocks** (open tag + content + close tag): the entire section is suppressed. `{tempo_m}`, `{tempo_s}`, `{tempo_sp}`, `{tempo_c}`, `{tempo_cp}`, `{tempo_label}` and `{time}` are **single directives**: only the line containing them is removed. The musical symbols `{textsize:N}𝄽{textsize}` are neither a block nor a line of their own: only the symbol (with the spaces around it) is removed, the rest of the line stays.

### `{new_song}` compatibility with chord filters

| *Show chords* slider mode | Internal value | Compatible with `{new_song}`? | Notes |
| ------------------------- | :------------: | :---------------------------: | ----- |
| **None** | `0` | ✅ | `_strip_nochords_blocks()` does not touch `{new_song}`; the next song is filtered correctly |
| **First verse only** *(one verse per chord pattern)* | `1` | ✅ | `{new_song}` also clears `chordPatterns`: patterns from the previous song no longer affect the comparison for the next one |
| **Entire song** | `2` | ✅ | No filtering active; `{new_song}` only resets verse/chorus counters |

> **Technical detail (mode 1):** before the fix, `chordPatterns` was not reset at `{new_song}`. The renderer compared verses of the second song against chord patterns from the first one via `minEditDist`, incorrectly stripping chords from verses that should have shown them. The fix adds `self.chordPatterns = []` alongside the other resets in `Renderer.py`.

---

## Shortcuts — Summary

| Shortcut                | Function                                  |
| ----------------------- | ----------------------------------------- |
| `Ctrl++`                | Zoom in                                   |
| `Ctrl+-`                | Zoom out                                  |
| `Ctrl+0`                | Zoom 100%                                 |
| `Ctrl+Shift+G`          | Fit width to panel                        |
| `F11`                   | Open / close fullscreen window            |
| `Ctrl+Wheel`            | Zoom with mouse wheel                     |
| `Ctrl+PgDn`/`Ctrl+PgUp` | Scroll one page                           |
| Double click            | Navigate to source line in editor         |
| `Esc` (fullscreen)      | Close fullscreen window                   |

---

## Guide: Find / Replace — Songpress++

![Songpress++ Print Options](./img/GUIDE/Trova-Sostituisci_en.png)

The **Find / Replace** window (`Ctrl+H` or *Edit* menu) is organized in two tabs alongside a vertical column of buttons. Options are **synchronized** between the two tabs: checking a checkbox in the *Find* tab automatically updates the *Replace* tab, and vice versa.

![Songpress++ Print Options](./img/GUIDE/Trova-Sostituisci2_en.png)

---

## Window Structure

| Area                  | Content                                                                          |
| --------------------- | -------------------------------------------------------------------------------- |
| **Find** tab          | Search field, options, direction                                                 |
| **Replace** tab       | Two fields (Find / Replace with), same options + *Silent wrap*                   |
| Right column          | Action buttons                                                                   |
| Bottom label          | Counter or result messages (e.g. "3 matches found")                              |

---

## Buttons

| Button                | Function                                                                                                                                                   |
| --------------------- | ---------------------------------------------------------------------------------------------------------------------------------------------------------- |
| **Find Next**         | Finds the next (or previous, depending on direction) occurrence. Pressing `Enter` in the text field is equivalent to clicking this button.                 |
| **Replace**           | If the currently selected text matches the search term, replaces it and advances to the next occurrence.                                                   |
| **Replace All**       | Replaces all occurrences in the document in a single **undoable** operation with `Ctrl+Z`. Shows the number of replacements made when done.                |
| **Count Matches**     | Counts all occurrences and shows the number in the label below the tab, without moving the cursor.                                                         |
| **Close**             | Closes the dialog (or `Esc`).                                                                                                                              |

> **Note:** the *Replace* and *Replace All* buttons are only visible when the **Replace** tab is active.

---

## Options (Checkboxes)

### ☐ Whole Words Only

Limits the search to occurrences where the term is delimited by **non-alphanumeric characters** (spaces, punctuation, start/end of line).

| Search                           | Text        | Found?                                |
| -------------------------------- | ----------- | ------------------------------------- |
| `sol` — ✗ Whole words only       | `dissolve`  | **Yes** (`dis`**`sol`**`ve`)          |
| `sol` — ✓ Whole words only       | `dissolve`  | **No**                                |
| `sol` — ✓ Whole words only       | `[Sol]`     | **Yes** (`[` `]` are delimiters)      |
| `sol` — ✓ Whole words only       | `sol mi fa` | **Yes**                               |

**Typical use in Songpress++:** find the chord `[La]` without hitting `[LaM]` or `[La7]` — but for this case it is more effective to use regular expressions (see below).

> ⚠️ *Whole words only* is **incompatible** with Regular Expressions: if both are active, the search uses only the regex flag and ignores the automatic word boundary. To combine the two behaviors, embed `\b` in the pattern (e.g. `\bsol\b`).

---

### ☐ Match Case

By default the search is **case-insensitive**: `Alleluia`, `alleluia` and `ALLELUIA` are equivalent.

Enabling this option makes the match **exact**:

| Search                  | Text       | Found?    |
| ----------------------- | ---------- | --------- |
| `Alleluia` — ✗ Case     | `alleluia` | **Yes**   |
| `Alleluia` — ✓ Case     | `alleluia` | **No**    |
| `Alleluia` — ✓ Case     | `Alleluia` | **Yes**   |

**Typical use:** correcting uniform capitalization of a title or a chord written inconsistently (`Re` vs `re`).

---

### ☐ Regular Expressions

Activates the **regex** engine built into Scintilla (compatible with extended POSIX / ECMA). The *Find* field becomes a **pattern** and the *Replace with* field can use **group references**.

When this option is active, text is interpreted literally only for normal characters; metacharacters have special meaning.

---

## Regular Expressions — Guide and Examples

### Fundamental Metacharacters

---

### Practical Examples in ChordPro Context

#### 1 — Find a Specific Chord (Without Hitting Variants)

**Problem:** search for `[Re]` without finding `[Rem]`, `[Re7]`, `[Re/Fa#]` etc.

```text
Pattern:  \[Re\]
```

The `[` and `]` must be **escaped** because they are metacharacters (character class delimiters).

---

#### 2 — Find Any Major Chord: Do, Re, Mi…

```text
Pattern:  \[(Do|Re|Mi|Fa|Sol|La|Si)\]
```

Finds `[Do]`, `[Re]`, `[Mi]` etc. but **not** `[Dom]`, `[Re7]`.

---

#### 3 — Find Any Chord (Opening + Content + Closing)

```text
Pattern:  \[[^\]]+\]
```

Read: `\[` — literal open square bracket; `[^\]]+` — one or more characters that are **not** `]`; `\]` — literal close square bracket.

Finds all chords in the document; useful with *Count Matches* to count how many chords there are.

---

#### 4 — Rename a Chord While Keeping Variants (Group Substitution)

**Problem:** the song uses `Sib` but I want `Bb`. I need to transform `[Sib]`, `[Sibm]`, `[Sib7]`, `[Sibm7]` etc. all at once.

```text
Find:     \[Sib([^\]]*)\]
Replace:  [Bb\1]
```

- `([^\]]*)` captures everything after `Sib` up to `]` (e.g. `m`, `7`, `m7`, empty).
- `\1` in the *Replace* field reinserts the captured suffix.

| Before    | After    |
| --------- | -------- |
| `[Sib]`   | `[Bb]`   |
| `[Sibm]`  | `[Bbm]`  |
| `[Sib7]`  | `[Bb7]`  |
| `[Sibm7]` | `[Bbm7]` |

---

#### 5 — Remove Double (or Multiple) Spaces in a Text Line

```text
Find:     [ ]{2,}
Replace:  (empty field)
```

`[ ]{2,}` means "at least 2 consecutive spaces". Alternatively: `<space><space>+` (one space followed by `+`).

---

### 6 — Add a Label to All Comment Lines

ChordPro comment lines start with `#`. To wrap them in `{comment: …}`:

```chordpro
Find:     ^#(.+)$
Replace:  {comment: \1}
```

- `^` — start of line
- `#` — the literal hash character
- `(.+)` — captures the rest of the line (group 1)
- `$` — end of line
- `\1` — reinserts the captured content

---

#### 7 — Find Empty Verses (Completely Blank Lines)

```text
Pattern:  ^$
```

Finds every line that contains nothing. Useful for counting or removing extra blank lines. With *Replace All* and an empty replacement field, all blank lines are deleted (caution: invasive operation).

---

#### 8 — Find Titles Written in ALL CAPS

```text
Pattern:  ^[A-Z][A-Z ]+$
```

Finds lines composed only of uppercase letters (and spaces), length ≥ 2. Useful for identifying caps-lock titles to normalize.

---

### Notes on Scintilla Behavior

- The regex engine is **Scintilla's (POSIX-like)**: supports `()`, `[]`, `\b`, `\d`, `\w`, `\s`, `{n,m}`, but **not** lookahead `(?=…)` or lookbehind `(?<=…)`.
- In patterns **backslashes must be single** (`\[`, `\d`), not doubled as in Python.
- Group references in the *Replace* field are written `\1`, `\2` (not `$1`).
- The *Match Case* flag combines freely with regex.

---

## Exclusive Option of the Replace Tab

### ☐ Silent Wrap

When the search reaches the end of the document (or the beginning, if direction is *Up*), normally a dialog appears asking for confirmation before wrapping around.

Enabling this option causes **wrapping to happen automatically and silently**, without interrupting the workflow.

---

## Direction: Up / Down

Controls whether *Find Next* searches **downward** (after the cursor) or **upward** (before the cursor). The default direction is **Down**.

Has no effect on *Replace All* and *Count Matches*, which always operate on the entire document.

---

## Search History

The *Find* and *Replace with* fields are **ComboBoxes** that store up to **10** recent searches. Clicking the field arrow (or pressing `Alt+↓`) opens the history list.

---

## Keyboard Shortcuts

| Key                              | Action                          |
| -------------------------------- | ------------------------------- |
| `Enter` in Find field            | Find Next                       |
| `Enter` in Replace with field    | Execute Replace                 |
| `Esc`                            | Close dialog                    |
| `Ctrl+Z` (in editor)             | Undo a *Replace All*            |

---

## Status Bar

The **status bar** is located at the bottom of the Songpress++ window and displays real-time information about the editor state and keyboard status.

### Left Field — Messages

The wider field on the left displays temporary application messages (for example, notices about completed operations or instructions for special commands). The message disappears automatically after a few seconds.

### Center Field — Editor Indicators

The second field shows indicators for the currently active editor modes:

| Indicator | Meaning |
| --------- | ------- |
| **● Intellisense** | Autocomplete is active. Typing `{` followed by a few letters and pressing <kbd>Ctrl</kbd>+<kbd>Space</kbd> opens the ChordPro directive menu. |
| **● Multicursor** | Multicursor mode is active. Multiple simultaneous cursors can be placed in the text. |

Indicators appear only when the corresponding mode is enabled in Preferences. Both can be toggled from the *Edit → Preferences* menu.

### Right Field — Lock Keys

The third field, on the right, permanently shows the state of the **keyboard lock keys**, in Debian/GNOME style:

| Badge | Key | Behaviour |
| ----- | --- | --------- |
| **CAPS** | <kbd>Caps Lock</kbd> | **On** (grey background, dark text): letters are typed in uppercase. **Off**: the badge is not shown. |
| **NUM** | <kbd>Num Lock</kbd> | **On**: the numeric keypad produces digits. **Off**: the badge is not shown. |
| **SCR** | <kbd>Scroll Lock</kbd> | **On**: Scroll Lock is engaged. **Off**: the badge is not shown. |

> **Tooltip** — Hovering the mouse pointer over a badge shows a tooltip that explicitly states the current key state (e.g. *Caps Lock: on* / *Caps Lock: off*).

#### Windows vs Linux differences

The three badges **do not behave identically on both platforms**, because their behaviour depends on how the operating system exposes the lock-key state.

| Badge | Windows | Linux (X11 / Wayland) |
| ----- | ------- | --------------------- |
| **CAPS** | Reflects the *lock* state: stays lit while Caps Lock is engaged. | Same as Windows: Caps Lock is a real modifier (`Lock`), so its state is read correctly. |
| **NUM** | Reflects the *lock* state: stays lit while Num Lock is engaged. | Same as Windows: Num Lock is a real modifier (`Mod2`). |
| **SCR** | Reflects the *lock* state: stays lit while Scroll Lock is engaged. | ⚠️ **Appears only while the key is physically held down and disappears as soon as it is released.** |

> **Note — SCR on Linux** — In modern keyboard layouts (XKB), `Scroll_Lock` is no longer mapped to a modifier or to a system LED, so there is no "engaged/disengaged" state the application can query. In that case the library function used by Songpress++ returns only the *instantaneous* key state (pressed/released). As a result, on Linux the **SCR** badge flickers — it shows up while <kbd>Scroll Lock</kbd> is held down and vanishes on release — instead of staying lit. **This is not a Songpress++ defect**: it is a limitation of the desktop environment. The **CAPS** and **NUM** indicators, by contrast, behave identically on Windows and Linux.

### Padlock Field — Read-only mode

The fourth field, at the far right, holds the icon of **read-only mode**: **open** padlock (green) when the mode is off, **closed** padlock (red) when it is on. Hovering the icon shows a tooltip describing the state; one click on the icon turns the mode on or off. See the chapter *Read-only mode*.

---

## Check Dependencies

**Help › Check dependencies…** opens a diagnostic window that lists the Python packages required by Songpress++, their installation status and the detected version. A summary line appears at the top: **✅ All required dependencies are installed correctly** or **❌ One or more required dependencies are missing**. The summary considers *required* dependencies only: if only an *optional* dependency is missing, the summary stays green.

### Checked packages

| Package         | Role                                    | Type                       |
| --------------- | --------------------------------------- | -------------------------- |
| **wxPython**    | Graphical user interface                | Required                   |
| **requests**    | Network requests                        | Required                   |
| **python-pptx** | PowerPoint export                       | Required                   |
| **pyshortcuts** | Desktop shortcut creation               | Required                   |
| **reportlab**   | PDF generation                          | Required                   |
| **svglib**      | Vector icons in the PDF                 | Optional                   |
| **pypdf**       | PDF manipulation                        | Required                   |
| **markdown**    | Markdown rendering                      | Required                   |
| **mistune**     | Markdown rendering                      | Required                   |
| **Pillow**      | Musical glyph rendering                 | Optional                   |
| **PyEnchant**   | Spell checker                           | Optional                   |
| **pywin32**     | Windows-specific features               | Optional (Windows only)    |

### Musical font self-tests

Below the package list, the window runs two checks on the fonts needed to render musical symbols:

- **FreeSerif → SMP** — an end-to-end check that the bundled **FreeSerif.ttf** file can rasterize a musical glyph from the SMP plane (e.g. U+1D13D), following exactly the same path used when printing. If this row is ✅, musical symbols will print correctly. The test targets the file *bundled* with Songpress++ and does not depend on system fonts; it does require **Pillow**.
- **NotoMusic → SMP** — checks the availability of the **NotoMusic** font for displaying SMP symbols *in the editor*. It is relevant only on **Linux**: there the editor (GTK) shows glyphs from the U+1D100–U+1D1FF block only if a font covering them is available. Outside Linux the system fonts already cover these symbols in the text control, so the row is not a requirement: it is shown as **–** (N/A) with the note *“Not required on this system”*. The font is looked up first among those bundled with the program, then among the system fonts; on **Linux** the installed fonts are located via **fontconfig** (`fc-list`/`fc-match`), which uses a cache and avoids a recursive scan of the font directories.

The **Python** and **wxPython** versions currently in use are shown at the bottom of the window.

> **System-specific rows** — Dependencies that do not apply to the current system are not flagged as missing (❌) but as **–** (not applicable): for example **pywin32** shows as **–** on Linux and macOS (it is only useful on Windows), and the **NotoMusic → SMP** row shows as **–** outside Linux.

> **Status icons** — The style of the ✅/❌ icons in the *Status* column can be chosen in the *General* tab of the **Options** window (native glyphs or images). If the images are unavailable, the window automatically falls back to the glyphs.

> **Refreshing the check** — To open quickly, the window detects the packages without loading them and caches the result for the current session. As a result, if you install a missing dependency while Songpress++ is running, reopen the window after **restarting** the program to see its status updated.

---

## License and Credits

**Songpress++** is a derivative work of **Songpress**, originally developed by Luca Allulli / [Skeed](https://www.skeed.it/songpress) — copyright © 2009–2026 Luca Allulli (Skeed).

The modifications present in Songpress++ are copyright © Denisov21.

Songpress++ is distributed under the terms of the **GNU General Public License version 2** (GPL v2), the same license as the original project. The program is free software: you can redistribute it and/or modify it under the terms of the GPL v2 as published by the Free Software Foundation. The program is distributed in the hope that it will be useful, but **without any warranty**, not even the implied warranty of merchantability or fitness for a particular purpose.

The full text of the license is available at: <https://www.gnu.org/licenses/old-licenses/gpl-2.0.html>

## Third-Party Components

Songpress (and consequently Songpress++) makes use of the following third-party software components:

| Component                               | License                                                         | Reference                                      |
| --------------------------------------- | --------------------------------------------------------------- | ---------------------------------------------- |
| Python and Python standard library      | Python Software Foundation License                              | <https://www.python.org>                       |
| wxPython                                | wxWindows Library Licence                                       | <https://wxpython.org>                         |
| uv (Windows installer only)             | MIT License — copyright © 2025 Astral Software Inc.             | <https://github.com/astral-sh/uv>              |
| INetC (NSIS plugin, installer only)     | zlib/libpng License — copyright © 2004–2015 Takhir Bedertdinov  | <https://nsis.sourceforge.io/Inetc_plug-in>    |
